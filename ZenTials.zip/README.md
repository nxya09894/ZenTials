# ZenTials

All-in-one core plugin for SMP servers. Created by **Jeremiah Alcantara (Niya)**.
Paper 26.3 · Java 25 · Optional: Vault, PlaceholderAPI, LuckPerms.

## Install
1. Drop `ZenTials.jar` into `plugins/` and restart.
2. Edit `plugins/ZenTials/config.yml` (server name, module switches).
3. Each module has its own folder in `plugins/ZenTials/modules/`. After editing: `/zt reload`.

## Modules
| Module | What it does | Main commands |
|---|---|---|
| economy | Money, bank, pay, history, Vault | `/eco` `/pay` `/bank` |
| teleport | Menu, warps, places, RTP, TPA, spawn, back | `/tp` `/rtp` `/spawn` `/back` `/warp` |
| graves | Safe-spot graves with hologram and items | `/graves` `/death` |
| aura | Tab list, name tags, scoreboard, chat style, chat tags, animations | `/aura` `/tag` `/sb` |
| chat | Join/quit, private messages, ignore, broadcast | `/msg` `/r` `/ignore` `/broadcast` |
| npc | Mannequin NPCs with actions | `/npc` |
| holograms | Text and leaderboards | `/hologram` |
| auth | Login/register for cracked servers (Java + Bedrock). **OFF by default** | `/login` `/register` `/auth` |
| ryuudules | Your own systems in simple `.ryu` scripts | `/ryu` |

Turn any module off (auth is the only one that is off until you switch it on) in `config.yml` under `modules:`.

## Folders
* `modules/` settings per module · `data/` saved data (do not edit) · `ryuudules/` scripts (see its README).

## Admin
`/zt reload` · `/zt about` · `/zt db status` · `/ryu errors`

Built for servers with 100+ players: saves run in the background, screens refresh in small slices, and chat is formatted once per message.

© 2026 Jeremiah Alcantara (Niya). All rights reserved. See LICENSE.

## Auth module (login for cracked servers)
Off by default. To use it: set `online-mode=false`, put `auth: true` under `modules:` in `config.yml`, restart.
* Players: `/register <pw> <pw>`, `/login <pw>`, `/changepassword`, `/logout`, `/unregister`.
* Admins: `/auth register|unregister|changepassword|forcelogin|info|status|unlock|reload`.
* Bedrock (Geyser + Floodgate): Bedrock players must `/register` and `/login` too (default). Set `bedrock.trust-floodgate: true` to let Xbox-verified players skip it.
* Java 1.21.6+ players get a login/register window (`login.dialog`); everyone can still use the chat commands.
* Passwords: PBKDF2-SHA512 + salt + pepper (`data/auth-pepper.key`, **back it up with the database**). Wrong-password limits per player and per IP, connection flood limit, exact name case, nothing allowed before login, passwords hidden from the server log.
* Settings in `modules/auth/config.yml`, texts in `modules/auth/messages.yml`. Other plugins can use `ZenTials#auth().isAuthenticated(player)` or listen to `PlayerAuthEvent`.
