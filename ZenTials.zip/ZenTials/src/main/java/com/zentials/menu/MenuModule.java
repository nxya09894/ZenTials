package com.zentials.menu;

import com.zentials.ZenTials;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /menu (aliases /cmds /commands /panel): a clickable panel of simple commands (rtp, spawn, back ...).
 * Edit the list in config.yml under menu.items. Each item: material, name, lore (list), command (no slash),
 * permission (optional), close (default true), console (run as console, default false).
 */
public final class MenuModule implements ZModule, CommandExecutor {
    private final ZenTials plugin;

    private record Entry(Material mat, String name, List<String> lore, String command, String perm, boolean close, boolean console) {
    }

    private String title;
    private final List<Entry> entries = new ArrayList<>();

    public MenuModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "menu";
    }

    @Override
    public void enable() {
        readConfig();
        PluginCommand c = plugin.getCommand("menu");
        if (c != null) c.setExecutor(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public void reload() {
        readConfig();
    }

    private void readConfig() {
        entries.clear();
        var c = plugin.getConfig();
        title = c.getString("menu.title", "&b&lQUICK COMMANDS");
        for (Map<?, ?> m : c.getMapList("menu.items")) {
            Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
            if (mat == null) mat = Material.PAPER;
            Object cmd = m.get("command");
            if (cmd == null) continue;
            List<String> lore = new ArrayList<>();
            if (m.get("lore") instanceof List<?> l) for (Object o : l) lore.add(String.valueOf(o));
            Object nm = m.get("name");
            Object perm = m.get("permission");
            Object close = m.get("close");
            Object con = m.get("console");
            entries.add(new Entry(mat, nm == null ? "&f/" + cmd : String.valueOf(nm), lore, String.valueOf(cmd),
                    perm == null ? "" : String.valueOf(perm), close == null || Boolean.parseBoolean(String.valueOf(close)),
                    con != null && Boolean.parseBoolean(String.valueOf(con))));
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) return true;
        open(p);
        return true;
    }

    private void open(Player p) {
        List<Entry> vis = new ArrayList<>();
        for (Entry e : entries) if (e.perm().isEmpty() || p.hasPermission(e.perm())) vis.add(e);
        int rows = Math.min(6, Math.max(3, (vis.size() + 6) / 7 + 2));
        Gui g = new Gui(Text.c(title), rows);
        for (int i = 0; i < rows * 9; i++) g.set(i, Items.of(Material.GRAY_STAINED_GLASS_PANE, " "), e -> {
        });
        int idx = 0;
        for (Entry en : vis) {
            int row = idx / 7;
            int slot = 9 * (row + 1) + 1 + idx % 7;
            if (slot >= (rows - 1) * 9) break;
            idx++;
            List<String> lore = new ArrayList<>(en.lore());
            lore.add("&7/" + en.command());
            lore.add("&eClick to run");
            g.set(slot, Items.of(en.mat(), en.name(), lore.toArray(new String[0])), e -> {
                plugin.sfx().play(p, "click");
                if (en.close()) p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> Bukkit.dispatchCommand(
                        en.console() ? Bukkit.getConsoleSender() : p, en.command().replace("{player}", p.getName())));
            });
        }
        g.set(rows * 9 - 5, Items.of(Material.BARRIER, "&cClose"), e -> p.closeInventory());
        g.open(p);
        plugin.sfx().play(p, "open");
    }
}
