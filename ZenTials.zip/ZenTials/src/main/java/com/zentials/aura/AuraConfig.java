package com.zentials.aura;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import com.zentials.core.Papi;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Loads every file in plugins/ZenTials/aura/ and keeps the per-player data (aura/data.yml). */
final class AuraConfig {
    static final class Group {
        String id;
        int weight;
        String perm;
        String tabPrefix = "";
        String tabSuffix = "";
        String tagPrefix = "";
        String tagSuffix = "";
        String tagColor = "";
        String chatPrefix = "";
        String chatSuffix = "";
        String chatColor = "";
        String chatFormat = "";
    }

    static final class BoardDef {
        String id;
        int priority;
        String perm = "";
        List<String> worlds = new ArrayList<>();
        String title = "";
        List<String> lines = new ArrayList<>();
    }

    static final class TagDef {
        String id;
        String display;
        String perm = "";
        String material = "NAME_TAG";
        List<String> description = new ArrayList<>();
    }

    private final ZenTials plugin;
    private final File dataFile;

    YamlConfiguration main;
    YamlConfiguration groupsYml;
    YamlConfiguration animations;
    YamlConfiguration boardsYml;
    YamlConfiguration tagsYml;

    final Map<String, Group> groups = new LinkedHashMap<>();
    private final List<Group> byWeight = new ArrayList<>();
    final List<BoardDef> boards = new ArrayList<>();
    final Map<String, TagDef> tags = new LinkedHashMap<>();

    // per-player data
    final Map<UUID, String> playerTag = new ConcurrentHashMap<>();
    final Map<UUID, String> groupOverride = new ConcurrentHashMap<>();
    final Set<UUID> sbOff = ConcurrentHashMap.newKeySet();

    AuraConfig(ZenTials plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "aura/data.yml");
    }

    void load() {
        Cfg.migrate(plugin, "tab", "aura"); // old folder name
        main = Cfg.yamlWithDefaults(plugin, "aura/config.yml");
        groupsYml = Cfg.yaml(plugin, "aura/groups.yml");
        animations = Cfg.yaml(plugin, "aura/animations.yml");
        boardsYml = Cfg.yamlWithDefaults(plugin, "aura/scoreboard.yml");
        tagsYml = Cfg.yaml(plugin, "aura/tags.yml");
        if (!new File(plugin.getDataFolder(), "aura/README.md").exists()) {
            try {
                plugin.saveResource("aura/README.md", false);
            } catch (IllegalArgumentException ignored) {
                // optional file
            }
        }
        readGroups();
        readBoards();
        readTags();
        readData();
    }

    private void readGroups() {
        groups.clear();
        byWeight.clear();
        ConfigurationSection s = groupsYml.getConfigurationSection("groups");
        if (s != null) {
            for (String id : s.getKeys(false)) {
                ConfigurationSection c = s.getConfigurationSection(id);
                if (c == null) continue;
                Group g = new Group();
                g.id = id.toLowerCase(Locale.ROOT);
                g.weight = c.getInt("weight", 0);
                g.perm = c.getString("permission", "zentials.aura.group." + g.id);
                g.tabPrefix = c.getString("tab-prefix", "");
                g.tabSuffix = c.getString("tab-suffix", "");
                g.tagPrefix = c.getString("tag-prefix", "");
                g.tagSuffix = c.getString("tag-suffix", "");
                g.tagColor = c.getString("tag-color", "");
                g.chatPrefix = c.getString("chat-prefix", "");
                g.chatSuffix = c.getString("chat-suffix", "");
                g.chatColor = c.getString("chat-color", "");
                g.chatFormat = c.getString("chat-format", "");
                groups.put(g.id, g);
            }
        }
        if (!groups.containsKey("default")) {
            Group d = new Group();
            d.id = "default";
            d.perm = "";
            groups.put("default", d);
        }
        byWeight.addAll(groups.values());
        byWeight.sort((a, b) -> Integer.compare(b.weight, a.weight));
    }

    private void readBoards() {
        boards.clear();
        ConfigurationSection s = boardsYml.getConfigurationSection("boards");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(id);
            if (c == null) continue;
            BoardDef b = new BoardDef();
            b.id = id;
            b.priority = c.getInt("priority", 0);
            b.perm = c.getString("permission", "");
            b.worlds = c.getStringList("worlds");
            b.title = c.getString("title", "");
            b.lines = c.getStringList("lines");
            boards.add(b);
        }
        boards.sort((a, b) -> Integer.compare(b.priority, a.priority));
    }

    private void readTags() {
        tags.clear();
        ConfigurationSection s = tagsYml.getConfigurationSection("tags");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(id);
            if (c == null) continue;
            TagDef t = new TagDef();
            t.id = id.toLowerCase(Locale.ROOT);
            t.display = c.getString("display", id);
            t.perm = c.getString("permission", "");
            t.material = c.getString("material", "NAME_TAG");
            t.description = c.getStringList("description");
            tags.put(t.id, t);
        }
    }

    // ---------------------------------------------------------------- groups

    Group groupOf(Player p) {
        String ov = groupOverride.get(p.getUniqueId());
        if (ov != null && groups.containsKey(ov)) return groups.get(ov);
        String src = main.getString("group-source", "permission");
        if (src.toLowerCase(Locale.ROOT).startsWith("papi:")) {
            String v = Papi.set(p, src.substring(5)).trim().toLowerCase(Locale.ROOT);
            Group g = groups.get(v);
            if (g != null) return g;
            return groups.get("default");
        }
        for (Group g : byWeight) {
            if (g.id.equals("default")) continue;
            if (!g.perm.isBlank() && p.hasPermission(g.perm)) return g;
        }
        return groups.get("default");
    }

    // ---------------------------------------------------------------- tags

    String tagDisplay(UUID u) {
        String id = playerTag.get(u);
        if (id == null) return "";
        TagDef t = tags.get(id);
        return t == null ? "" : t.display;
    }

    boolean canUse(Player p, TagDef t) {
        return t.perm.isBlank() || p.hasPermission(t.perm) || p.hasPermission("zentials.aura.admin");
    }

    // ---------------------------------------------------------------- scoreboards

    BoardDef boardFor(Player p) {
        String w = p.getWorld().getName();
        for (BoardDef b : boards) {
            if (!b.perm.isBlank() && !p.hasPermission(b.perm)) continue;
            if (!b.worlds.isEmpty() && b.worlds.stream().noneMatch(x -> x.equalsIgnoreCase(w))) continue;
            return b;
        }
        return null;
    }

    // ---------------------------------------------------------------- data.yml

    private void readData() {
        playerTag.clear();
        groupOverride.clear();
        sbOff.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection t = y.getConfigurationSection("tags");
        if (t != null) for (String k : t.getKeys(false)) put(playerTag, k, t.getString(k));
        ConfigurationSection g = y.getConfigurationSection("groups");
        if (g != null) for (String k : g.getKeys(false)) put(groupOverride, k, g.getString(k));
        for (String k : y.getStringList("scoreboard-off")) {
            try {
                sbOff.add(UUID.fromString(k));
            } catch (IllegalArgumentException ignored) {
                // skip
            }
        }
    }

    private static void put(Map<UUID, String> m, String k, String v) {
        try {
            if (v != null) m.put(UUID.fromString(k), v);
        } catch (IllegalArgumentException ignored) {
            // skip
        }
    }

    void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        for (var e : playerTag.entrySet()) y.set("tags." + e.getKey(), e.getValue());
        for (var e : groupOverride.entrySet()) y.set("groups." + e.getKey(), e.getValue());
        List<String> off = new ArrayList<>();
        for (UUID u : sbOff) off.add(u.toString());
        y.set("scoreboard-off", off);
        try {
            dataFile.getParentFile().mkdirs();
            y.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Aura: could not save data.yml: " + e.getMessage());
        }
    }
}
