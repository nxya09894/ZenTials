package com.zentials.api;

import java.util.UUID;

/**
 * The public economy API of ZenTials. Amounts are in currency units (12.50 = 12 pesos 50 centavos).
 * Get it with: Bukkit.getServicesManager().load(EconomyApi.class)
 * or from Ryuudules scripts with the eco.* functions.
 *
 * All changes are written to the ZenTials database immediately and are included in the player's history.
 * The deposit/withdraw/transfer methods are silent: they do not send chat messages to the player.
 */
public interface EconomyApi {

    /** True if this player has an economy account. */
    boolean exists(UUID id);

    /** Wallet balance (0 if no account). */
    double balance(UUID id);

    /** Bank balance (0 if no account). */
    double bank(UUID id);

    /** True if the wallet has at least this amount. */
    boolean has(UUID id, double amount);

    /** Adds money to the wallet. Returns false if the account does not exist or the amount is invalid. */
    boolean deposit(UUID id, double amount, String reason);

    /** Removes money from the wallet. Returns false if there is not enough money. */
    boolean withdraw(UUID id, double amount, String reason);

    /** Moves money between two players atomically. Returns false if not enough money, frozen, or lockdown. */
    boolean transfer(UUID from, UUID to, double amount, String reason);

    /** Sets the wallet to an exact amount (admin style). */
    boolean setBalance(UUID id, double amount, String reason);

    /** "₱1,234.50" */
    String format(double amount);

    /** "₱1.2K" */
    String formatShort(double amount);

    /** Currency symbol. */
    String symbol();

    /** Finds a player's UUID by name from the economy accounts (null if unknown). */
    UUID uuidOf(String name);
}
