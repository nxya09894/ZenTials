package com.zentials.core;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class Cfg {
    private Cfg() {
    }

    /** Loads plugins/ZenTials/<path>, copying the default from the jar if missing. */
    public static YamlConfiguration yaml(JavaPlugin p, String path) {
        File f = new File(p.getDataFolder(), path);
        if (!f.exists()) p.saveResource(path, false);
        return YamlConfiguration.loadConfiguration(f);
    }

    /** Same as yaml(), but keys missing from the file fall back to the jar default (good for updates). */
    public static YamlConfiguration yamlWithDefaults(JavaPlugin p, String path) {
        YamlConfiguration y = yaml(p, path);
        InputStream in = p.getResource(path);
        if (in != null) {
            YamlConfiguration def = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            y.setDefaults(def);
            y.options().copyDefaults(true);
        }
        return y;
    }
}
