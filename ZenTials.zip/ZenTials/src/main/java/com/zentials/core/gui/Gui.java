package com.zentials.core.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/** A chest GUI. Slots can have click handlers. Everything in it is locked (no taking items). */
public final class Gui implements InventoryHolder {
    private final Inventory inv;
    private final Map<Integer, Consumer<InventoryClickEvent>> handlers = new HashMap<>();

    public Gui(Component title, int rows) {
        this.inv = Bukkit.createInventory(this, rows * 9, title);
    }

    public Gui set(int slot, ItemStack item) {
        if (slot >= 0 && slot < inv.getSize()) inv.setItem(slot, item);
        return this;
    }

    public Gui set(int slot, ItemStack item, Consumer<InventoryClickEvent> onClick) {
        set(slot, item);
        if (slot >= 0 && slot < inv.getSize()) handlers.put(slot, onClick);
        return this;
    }

    void click(InventoryClickEvent e) {
        Consumer<InventoryClickEvent> h = handlers.get(e.getRawSlot());
        if (h != null) h.accept(e);
    }

    public void open(Player p) {
        p.openInventory(inv);
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
