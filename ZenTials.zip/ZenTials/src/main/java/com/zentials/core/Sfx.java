package com.zentials.core;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;

public final class Sfx {
    private final JavaPlugin plugin;
    private final Map<String, Sound> map = new HashMap<>();

    public Sfx(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        map.clear();
        YamlConfiguration y = Cfg.yamlWithDefaults(plugin, "sounds.yml");
        for (String k : y.getKeys(false)) {
            String raw = y.getString(k, "");
            if (raw.isBlank()) continue;
            String[] p = raw.split(",");
            try {
                float vol = p.length > 1 ? Float.parseFloat(p[1].trim()) : 1f;
                float pitch = p.length > 2 ? Float.parseFloat(p[2].trim()) : 1f;
                map.put(k.toLowerCase(), Sound.sound(Key.key(p[0].trim()), Sound.Source.MASTER, vol, pitch));
            } catch (Exception e) {
                plugin.getLogger().warning("Bad sound entry in sounds.yml: " + k);
            }
        }
    }

    public void play(Player p, String key) {
        Sound s = map.get(key.toLowerCase());
        if (s != null) p.playSound(s);
    }
}
