package com.zentials.core;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/** "Type it in chat" input for GUIs. Typing "cancel" cancels. Expires after 60 seconds. */
public final class Prompts implements Listener {
    private record Pending(Consumer<String> onInput, Runnable onCancel, long expires) {
    }

    private final JavaPlugin plugin;
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public Prompts(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void ask(Player p, Consumer<String> onInput, Runnable onCancel) {
        pending.put(p.getUniqueId(), new Pending(onInput, onCancel, System.currentTimeMillis() + 60000L));
        p.closeInventory();
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Pending pe = pending.remove(e.getPlayer().getUniqueId());
        if (pe == null) return;
        if (System.currentTimeMillis() > pe.expires()) return;
        e.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (msg.equalsIgnoreCase("cancel")) pe.onCancel().run();
            else pe.onInput().accept(msg);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pending.remove(e.getPlayer().getUniqueId());
    }
}
