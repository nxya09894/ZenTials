package com.zentials.core;

public interface ZModule {
    String id();

    void enable() throws Exception;

    void disable();

    void reload();
}
