package com.zentials.economy;

import com.zentials.ZenTials;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.PluginManager;

public final class EconomyModule implements ZModule, Listener {
    final ZenTials plugin;
    Lang lang;
    EcoService svc;
    EcoGui gui;

    public EconomyModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "economy";
    }

    @Override
    public void enable() {
        lang = new Lang(plugin);
        svc = new EcoService(this);
        svc.loadConfig();
        svc.load();
        gui = new EcoGui(this);

        PluginManager pm = Bukkit.getPluginManager();
        pm.registerEvents(this, plugin);

        EcoCommands cmds = new EcoCommands(this);
        for (String n : new String[]{"economy", "pay", "bank"}) {
            PluginCommand c = plugin.getCommand(n);
            if (c != null) {
                c.setExecutor(cmds);
                c.setTabCompleter(cmds);
            }
        }

        hooks(pm);

        long auto = Math.max(1, svc.autosaveMinutes) * 1200L;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> svc.save(false), auto, auto);
        Bukkit.getScheduler().runTaskTimer(plugin, svc::recomputeRanks, 600L, 600L);
    }

    private void hooks(PluginManager pm) {
        if (pm.getPlugin("Vault") != null) {
            try {
                VaultHook.register(plugin, svc);
                plugin.getLogger().info("Vault: connected (ZenTials is now the economy provider).");
            } catch (Throwable t) {
                plugin.getLogger().warning("Vault: link failed - " + t);
            }
        } else {
            plugin.getLogger().info("Vault: not installed, skipped.");
        }
        if (pm.getPlugin("PlaceholderAPI") != null) {
            try {
                PapiHook.register(plugin, svc);
                plugin.getLogger().info("PlaceholderAPI: connected (%zen_balance%, %zen_bank%, %zen_rank%, ...). TAB can use these directly.");
            } catch (Throwable t) {
                plugin.getLogger().warning("PlaceholderAPI: link failed - " + t);
            }
        } else {
            plugin.getLogger().info("PlaceholderAPI: not installed, skipped.");
        }
        plugin.getLogger().info("LuckPerms: use the economy.* permission nodes (see plugin.yml / README).");
    }

    @Override
    public void disable() {
        if (svc != null) svc.save(true);
    }

    @Override
    public void reload() {
        lang.load();
        svc.loadConfig();
    }

    // ---------------------------------------------------------------- helpers

    void msg(CommandSender to, String key, String... kv) {
        to.sendMessage(Text.c(lang.raw(key, kv)));
    }

    void sfx(Player p, String key) {
        Account a = svc.get(p.getUniqueId());
        if (a != null && !a.sound) return;
        plugin.sfx().play(p, key);
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        boolean created = svc.get(p.getUniqueId()) == null;
        Account a = svc.ensure(p.getUniqueId(), p.getName());
        a.name = p.getName();
        if (created) {
            svc.recomputeRanks();
            msg(p, "account-created", "amount", svc.fmt(a.balance));
            sfx(p, "success");
        }
    }
}
