package com.zentials.economy;

import com.zentials.core.Cfg;
import com.zentials.core.Text;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Event-driven job income: no loops, no per-block variables, capped memory. */
final class JobsService implements Listener {

    record Cat(String id, String label, String type, long cap, String tool) {
    }

    record Rate(Cat cat, long cents, String label) {
    }

    record Pos(UUID world, long key) {
    }

    private static final class State {
        long start;
        long earned;
        boolean capMsg;
    }

    private static final int MAX_PLACED = 50000;

    private final EconomyModule mod;
    private final Map<String, Cat> cats = new HashMap<>();
    private final Map<Material, Rate> blocks = new EnumMap<>(Material.class);
    private final Map<EntityType, Rate> mobs = new EnumMap<>(EntityType.class);
    private long windowMs = 3600000L;
    private final Map<UUID, Map<String, State>> states = new HashMap<>();
    private final Map<UUID, Map<String, Long>> buffer = new HashMap<>();
    private final Set<Pos> placed = Collections.newSetFromMap(new LinkedHashMap<Pos, Boolean>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Pos, Boolean> e) {
            return size() > MAX_PLACED;
        }
    });

    JobsService(EconomyModule mod) {
        this.mod = mod;
    }

    void load() {
        cats.clear();
        blocks.clear();
        mobs.clear();
        YamlConfiguration y = Cfg.yaml(mod.plugin, "modules/economy/jobs.yml");
        windowMs = Math.max(1, y.getLong("cap-window-minutes", 60)) * 60000L;
        ConfigurationSection cs = y.getConfigurationSection("categories");
        if (cs == null) return;
        int count = 0;
        for (String id : cs.getKeys(false)) {
            ConfigurationSection c = cs.getConfigurationSection(id);
            if (c == null) continue;
            String type = c.getString("type", "BLOCK_BREAK").toUpperCase();
            String label = c.getString("label", pretty(id));
            Cat cat = new Cat(id, label, type, EcoService.cents(c.getDouble("cap", 0)),
                    c.getString("require-tool", "").toUpperCase());
            cats.put(id, cat);
            ConfigurationSection rs = c.getConfigurationSection("rates");
            if (rs == null) continue;
            for (String key : rs.getKeys(false)) {
                Rate r = new Rate(cat, EcoService.cents(rs.getDouble(key)), label + " - " + pretty(key));
                if (type.equals("MOB_KILL")) {
                    try {
                        mobs.put(EntityType.valueOf(key.toUpperCase()), r);
                        count++;
                    } catch (IllegalArgumentException ex) {
                        mod.plugin.getLogger().warning("jobs.yml: unknown mob '" + key + "' in " + id);
                    }
                } else {
                    Material m = Material.matchMaterial(key);
                    if (m == null) {
                        mod.plugin.getLogger().warning("jobs.yml: unknown block '" + key + "' in " + id);
                    } else {
                        blocks.put(m, r);
                        count++;
                    }
                }
            }
        }
        mod.plugin.getLogger().info("Jobs: " + cats.size() + " categories, " + count + " rates.");
    }

    private static String pretty(String key) {
        String k = key.toUpperCase().replace("DEEPSLATE_", "");
        if (k.endsWith("_ORE")) k = k.substring(0, k.length() - 4);
        StringBuilder sb = new StringBuilder();
        for (String w : k.toLowerCase().split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    private static Pos pos(Block b) {
        return new Pos(b.getWorld().getUID(), b.getBlockKey());
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Rate r = blocks.get(e.getBlockPlaced().getType());
        if (r != null && r.cat().type().equals("BLOCK_BREAK")) placed.add(pos(e.getBlockPlaced()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE) return;
        Block b = e.getBlock();
        Rate r = blocks.get(b.getType());
        if (r == null) return;
        Cat c = r.cat();
        if (c.type().equals("BLOCK_BREAK")) {
            if (placed.remove(pos(b))) return;
            if (!c.tool().isEmpty()
                    && !p.getInventory().getItemInMainHand().getType().name().contains(c.tool())) return;
        } else if (c.type().equals("CROP_BREAK")) {
            if (b.getBlockData() instanceof Ageable ag && ag.getAge() < ag.getMaximumAge()) return;
        }
        payout(p, r);
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        Player p = e.getEntity().getKiller();
        if (p == null || p.getGameMode() == GameMode.CREATIVE) return;
        Rate r = mobs.get(e.getEntityType());
        if (r != null) payout(p, r);
    }

    // ---------------------------------------------------------------- payout

    private void payout(Player p, Rate r) {
        EcoService svc = mod.svc;
        if (!svc.jobsEnabled) return;
        Account a = svc.get(p.getUniqueId());
        if (a == null || a.frozen) return;
        Cat cat = r.cat();
        long now = System.currentTimeMillis();
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .computeIfAbsent(cat.id(), k -> new State());
        if (s.start == 0) {
            s.start = now;
        } else if (now - s.start >= windowMs) {
            s.start = now;
            s.earned = 0;
            s.capMsg = false;
        }
        long amount = r.cents();
        if (cat.cap() > 0) {
            if (s.earned >= cat.cap()) {
                if (!s.capMsg) {
                    s.capMsg = true;
                    mod.msg(p, "job-cap", "category", cat.label(), "cap", svc.fmt(cat.cap()));
                    mod.sfx(p, "warn");
                }
                return;
            }
            if (s.earned + amount > cat.cap()) amount = cat.cap() - s.earned;
        }
        if (amount <= 0) return;
        s.earned += amount;
        svc.addRaw(a, amount);
        buffer.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).merge(cat.id(), amount, Long::sum);
        if (a.jobNotify) {
            p.sendActionBar(Text.c(mod.lang.raw("job-actionbar", "amount", svc.fmt(amount), "label", r.label())));
            mod.sfx(p, "payout");
        }
    }

    // ---------------------------------------------------------------- history flush

    void flush(UUID id) {
        Map<String, Long> m = buffer.remove(id);
        if (m == null) return;
        Account a = mod.svc.get(id);
        if (a == null) return;
        for (Map.Entry<String, Long> en : m.entrySet()) {
            mod.svc.logJob(a, en.getValue(), "Job income - " + en.getKey());
        }
    }

    void flushAll() {
        for (UUID id : new ArrayList<>(buffer.keySet())) flush(id);
    }
}
