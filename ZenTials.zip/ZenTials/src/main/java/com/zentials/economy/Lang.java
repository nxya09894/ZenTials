package com.zentials.economy;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import org.bukkit.configuration.file.YamlConfiguration;

final class Lang {
    private final ZenTials plugin;
    private YamlConfiguration y;

    Lang(ZenTials plugin) {
        this.plugin = plugin;
        load();
    }

    void load() {
        y = Cfg.yamlWithDefaults(plugin, "modules/economy/messages.yml");
    }

    String raw(String key, String... kv) {
        String s = y.getString(key);
        if (s == null) s = "&c[missing message: " + key + "]";
        s = s.replace("{prefix}", y.getString("prefix", ""));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return s;
    }
}
