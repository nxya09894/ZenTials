package com.zentials.economy;

import com.zentials.api.EconomyApi;

import java.util.UUID;

final class EcoApiImpl implements EconomyApi {
    private final EcoService s;

    EcoApiImpl(EcoService s) {
        this.s = s;
    }

    /** Amount in units -> cents, or -1 if invalid. */
    private static long c(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d) || d < 0 || d > 1e12) return -1;
        return EcoService.cents(d);
    }

    @Override
    public boolean exists(UUID id) {
        return s.get(id) != null;
    }

    @Override
    public double balance(UUID id) {
        Account a = s.get(id);
        return a == null ? 0 : a.balance / 100.0;
    }

    @Override
    public double bank(UUID id) {
        Account a = s.get(id);
        return a == null ? 0 : a.bank / 100.0;
    }

    @Override
    public boolean has(UUID id, double amount) {
        Account a = s.get(id);
        long c = c(amount);
        return a != null && c >= 0 && a.balance >= c;
    }

    @Override
    public boolean deposit(UUID id, double amount, String reason) {
        long c = c(amount);
        return c > 0 && s.add(id, c, reason == null ? "API" : reason, false);
    }

    @Override
    public boolean withdraw(UUID id, double amount, String reason) {
        long c = c(amount);
        return c > 0 && s.remove(id, c, reason == null ? "API" : reason, false);
    }

    @Override
    public boolean transfer(UUID from, UUID to, double amount, String reason) {
        long c = c(amount);
        return c > 0 && s.transferQuiet(from, to, c, reason == null ? "API" : reason);
    }

    @Override
    public boolean setBalance(UUID id, double amount, String reason) {
        long c = c(amount);
        Account a = s.get(id);
        if (a == null || c < 0) return false;
        s.adminOp(a, "set", c);
        return true;
    }

    @Override
    public String format(double amount) {
        return s.fmt(EcoService.cents(amount));
    }

    @Override
    public String formatShort(double amount) {
        return s.fmtShort(EcoService.cents(amount));
    }

    @Override
    public String symbol() {
        return s.symbol;
    }

    @Override
    public UUID uuidOf(String name) {
        if (name == null) return null;
        Account a = s.findByName(name);
        return a == null ? null : a.id;
    }
}
