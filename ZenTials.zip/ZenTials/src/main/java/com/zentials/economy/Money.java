package com.zentials.economy;

import java.math.BigDecimal;
import java.util.regex.Pattern;

final class Money {
    private static final Pattern P = Pattern.compile("^\\d{1,10}(\\.\\d{1,2})?$");

    private Money() {
    }

    /** Returns cents, or -1 if invalid. */
    static long parse(String t, boolean allowZero, long maxCents) {
        if (t == null || !P.matcher(t).matches()) return -1;
        long c = new BigDecimal(t).movePointRight(2).longValue();
        if (c < 0 || c > maxCents) return -1;
        if (c == 0 && !allowZero) return -1;
        return c;
    }

    /** 0.002 -> "0.2" */
    static String pct(double rate) {
        return java.math.BigDecimal.valueOf(rate).movePointRight(2).stripTrailingZeros().toPlainString();
    }

    static String duration(long ms) {
        long m = Math.max(0, ms) / 60000;
        return (m / 60) + "h " + (m % 60) + "m";
    }
}
