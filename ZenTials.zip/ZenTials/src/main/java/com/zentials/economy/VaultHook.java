package com.zentials.economy;

import com.zentials.ZenTials;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.ServicePriority;

final class VaultHook {
    private VaultHook() {
    }

    static void register(ZenTials plugin, EcoService svc) {
        Bukkit.getServicesManager().register(Economy.class, new VaultEconomy(svc), plugin, ServicePriority.Highest);
    }
}
