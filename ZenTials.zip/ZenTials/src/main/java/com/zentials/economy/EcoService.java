package com.zentials.economy;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** The economy engine. All balance changes go through here (one lock, all in memory). */
final class EcoService {
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("MM/dd HH:mm");

    private final EconomyModule mod;
    private final ZenTials plugin;
    final Map<UUID, Account> accounts = new ConcurrentHashMap<>();
    final ArrayDeque<String> globalLog = new ArrayDeque<>();
    volatile boolean lockdown;
    private volatile boolean dirty;
    private File file;

    String symbol = "\u20B1";
    String nameSingular = "peso";
    String namePlural = "pesos";
    long startBalance;
    long maxAmount;
    long payMin;
    long payMax;
    long payCooldownMs;
    long bankCap;
    long interestMax;
    long interestCooldownMs;
    double interestRate;
    int histMax = 20;
    int globalMax = 30;
    int autosaveMinutes = 5;
    private volatile List<Tier> tiers = List.of();
    volatile List<TopEntry> top = List.of();

    record Tier(String perm, long cap) {
    }

    record TopEntry(String name, long balance) {
    }
    private long bankCapCfg;
    private double rateCfg;
    private long capOverride = -1;
    private double rateOverride = -1;

    EcoService(EconomyModule mod) {
        this.mod = mod;
        this.plugin = mod.plugin;
    }

    static long cents(double d) {
        return Math.round(d * 100.0);
    }

    void loadConfig() {
        YamlConfiguration y = Cfg.yamlWithDefaults(plugin, "modules/economy/economy.yml");
        symbol = y.getString("currency.symbol", "\u20B1");
        nameSingular = y.getString("currency.name", "peso");
        namePlural = y.getString("currency.name-plural", "pesos");
        startBalance = cents(y.getDouble("starting-balance", 3000));
        maxAmount = cents(y.getDouble("max-amount", 10000000));
        payMin = cents(y.getDouble("pay.min", 1));
        payMax = cents(y.getDouble("pay.max", 100000));
        payCooldownMs = y.getLong("pay.cooldown-seconds", 3) * 1000L;
        bankCapCfg = cents(y.getDouble("bank.cap", 100000));
        rateCfg = y.getDouble("bank.interest-rate", 0.002);
        interestMax = cents(y.getDouble("bank.interest-max", 200));
        interestCooldownMs = y.getLong("bank.interest-cooldown-hours", 24) * 3600000L;
        histMax = y.getInt("history.player-entries", 20);
        globalMax = y.getInt("history.global-entries", 30);
        autosaveMinutes = y.getInt("autosave-minutes", 5);
        List<Tier> tl = new ArrayList<>();
        for (Map<?, ?> m : y.getMapList("bank.cap-tiers")) {
            Object perm = m.get("permission");
            Object cap = m.get("cap");
            if (perm != null && cap instanceof Number n) tl.add(new Tier(String.valueOf(perm), cents(n.doubleValue())));
        }
        tiers = tl;
        applyLive();
    }

    private void applyLive() {
        bankCap = capOverride >= 0 ? capOverride : bankCapCfg;
        interestRate = rateOverride >= 0 ? rateOverride : rateCfg;
    }

    String fmt(long cents) {
        long a = Math.abs(cents);
        return (cents < 0 ? "-" : "") + symbol + String.format(Locale.US, "%,d", a / 100)
                + "." + String.format(Locale.US, "%02d", a % 100);
    }

    /** 1250 -> "₱12.5" style short form: 3K, 1.2M, 4B. */
    String fmtShort(long cents) {
        double v = cents / 100.0;
        double abs = Math.abs(v);
        String suf = "";
        if (abs >= 1_000_000_000d) {
            v /= 1_000_000_000d;
            suf = "B";
        } else if (abs >= 1_000_000d) {
            v /= 1_000_000d;
            suf = "M";
        } else if (abs >= 1_000d) {
            v /= 1_000d;
            suf = "K";
        }
        String num;
        if (suf.isEmpty()) {
            num = v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.2f", v);
        } else {
            num = String.format(Locale.US, "%.1f", v);
            if (num.endsWith(".0")) num = num.substring(0, num.length() - 2);
        }
        return symbol + num + suf;
    }

    /** Bank cap for this player: base cap, or the highest cap-tier permission they have (LuckPerms groups). */
    long capFor(Account a) {
        long cap = bankCap;
        List<Tier> t = tiers;
        if (t.isEmpty()) return cap;
        Player p = Bukkit.getPlayer(a.id);
        if (p == null) return cap;
        for (Tier x : t) {
            if (x.cap() > cap && p.hasPermission(x.perm())) cap = x.cap();
        }
        return cap;
    }

    // ---------------------------------------------------------------- accounts

    Account get(UUID id) {
        return accounts.get(id);
    }

    Account ensure(UUID id, String name) {
        return accounts.computeIfAbsent(id, k -> {
            Account a = new Account(k);
            a.name = name == null ? "?" : name;
            a.balance = startBalance;
            dirty = true;
            return a;
        });
    }

    // ---------------------------------------------------------------- money ops

    boolean add(UUID id, long c, String reason, boolean announce) {
        if (c <= 0) return false;
        Account a = accounts.get(id);
        if (a == null) return false;
        long bal;
        synchronized (this) {
            a.balance += c;
            bal = a.balance;
            log(a, "add", c, reason);
        }
        if (announce) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                if (a.notify) mod.msg(p, "received", "amount", fmt(c), "reason", reason, "balance", fmt(bal));
                mod.sfx(p, "cash");
            }
        }
        return true;
    }

    boolean remove(UUID id, long c, String reason, boolean announce) {
        if (c <= 0) return false;
        Account a = accounts.get(id);
        if (a == null) return false;
        long bal;
        boolean ok;
        synchronized (this) {
            ok = a.balance >= c;
            if (ok) {
                a.balance -= c;
                log(a, "remove", c, reason);
            }
            bal = a.balance;
        }
        Player p = announce ? Bukkit.getPlayer(id) : null;
        if (!ok) {
            if (p != null) {
                mod.msg(p, "insufficient", "need", fmt(c - bal));
                mod.sfx(p, "error");
            }
            return false;
        }
        if (p != null) {
            if (a.notify) mod.msg(p, "removed", "amount", fmt(c), "reason", reason, "balance", fmt(bal));
            mod.sfx(p, "warn");
        }
        return true;
    }

    boolean pay(Player from, Account to, long c) {
        Account fa = ensure(from.getUniqueId(), from.getName());
        if (fa.id.equals(to.id)) {
            mod.msg(from, "pay-self");
            mod.sfx(from, "error");
            return false;
        }
        if (c < payMin) {
            mod.msg(from, "pay-min", "amount", fmt(payMin));
            mod.sfx(from, "error");
            return false;
        }
        if (c > payMax) {
            mod.msg(from, "pay-max", "amount", fmt(payMax));
            mod.sfx(from, "error");
            return false;
        }
        String err;
        long need = 0;
        synchronized (this) {
            if (lockdown) err = "lockdown";
            else if (fa.frozen) err = "frozen-self";
            else if (to.frozen) err = "frozen-target";
            else if (fa.balance < c) {
                err = "insufficient";
                need = c - fa.balance;
            } else {
                fa.balance -= c;
                log(fa, "pay_out", c, "To " + to.name);
                to.balance += c;
                log(to, "add", c, "From " + fa.name);
                err = null;
            }
        }
        if (err != null) {
            mod.msg(from, err, "need", fmt(need));
            mod.sfx(from, "error");
            return false;
        }
        mod.msg(from, "pay-sent", "amount", fmt(c), "player", to.name);
        mod.sfx(from, "success");
        Player tp = Bukkit.getPlayer(to.id);
        if (tp != null) {
            if (to.notify) mod.msg(tp, "pay-received", "amount", fmt(c), "player", fa.name);
            mod.sfx(tp, "cash");
        }
        return true;
    }

    // ---------------------------------------------------------------- admin ops

    synchronized void adminOp(Account a, String op, long c) {
        switch (op) {
            case "set" -> {
                a.balance = c;
                log(a, "admin_set", c, "Set by admin");
            }
            case "add" -> {
                a.balance += c;
                log(a, "admin_add", c, "Added by admin");
            }
            case "remove" -> {
                long took = Math.min(c, a.balance);
                a.balance -= took;
                log(a, "admin_remove", took, "Removed by admin");
            }
            case "bankset" -> {
                a.bank = Math.min(c, capFor(a));
                log(a, "admin_bank_set", a.bank, "Bank set by admin");
            }
            case "bankadd" -> {
                a.bank = Math.min(a.bank + c, capFor(a));
                log(a, "admin_bank_add", c, "Bank added by admin");
            }
            case "bankremove" -> {
                long took = Math.min(c, a.bank);
                a.bank -= took;
                log(a, "admin_bank_remove", took, "Bank removed by admin");
            }
            default -> {
            }
        }
        dirty = true;
    }

    synchronized void markDirty() {
        dirty = true;
    }

    synchronized void wipeHistory(Account a) {
        a.history.clear();
        dirty = true;
    }

    // ---------------------------------------------------------------- bank

    synchronized String bankDeposit(Account a, long c) {
        if (lockdown) return "lockdown-bank";
        if (a.frozen) return "frozen-bank";
        if (a.balance < c) return "insufficient";
        if (a.bank + c > capFor(a)) return "bank-full";
        a.balance -= c;
        a.bank += c;
        log(a, "bank_deposit", c, "Deposit");
        return null;
    }

    synchronized String bankWithdraw(Account a, long c) {
        if (lockdown) return "lockdown-bank";
        if (a.frozen) return "frozen-bank";
        if (a.bank < c) return "bank-insufficient";
        a.bank -= c;
        a.balance += c;
        log(a, "bank_withdraw", c, "Withdraw");
        return null;
    }

    long interestAmount(Account a) {
        long i = Math.round(a.bank * interestRate);
        if (i > interestMax) i = interestMax;
        long room = capFor(a) - a.bank;
        if (i > room) i = room;
        return Math.max(i, 0);
    }

    long interestWait(Account a) {
        if (a.lastInterest == 0) return 0;
        long left = interestCooldownMs - (System.currentTimeMillis() - a.lastInterest);
        return Math.max(left, 0);
    }

    /** Returns amount claimed, -1 cooldown, 0 nothing to claim, -2 lockdown, -3 frozen. */
    synchronized long claimInterest(Account a) {
        if (lockdown) return -2;
        if (a.frozen) return -3;
        if (interestWait(a) > 0) return -1;
        long amt = interestAmount(a);
        if (amt <= 0) return 0;
        a.bank += amt;
        a.lastInterest = System.currentTimeMillis();
        log(a, "interest", amt, "Bank interest");
        return amt;
    }

    // ---------------------------------------------------------------- history

    static String typeLabel(String t) {
        return switch (t) {
            case "add" -> "Received";
            case "remove" -> "Spent";
            case "pay_out" -> "Payment";
            case "bank_deposit" -> "Bank Deposit";
            case "bank_withdraw" -> "Bank Withdraw";
            case "interest" -> "Interest";
            case "admin_set" -> "Admin Set";
            case "admin_add" -> "Admin Add";
            case "admin_remove" -> "Admin Remove";
            case "admin_bank_set" -> "Admin Bank Set";
            case "admin_bank_add" -> "Admin Bank Add";
            case "admin_bank_remove" -> "Admin Bank Remove";
            default -> t;
        };
    }

    /** Caller must hold the service lock. */
    private void log(Account a, String type, long cents, String note) {
        String ts = TS.format(LocalDateTime.now());
        a.history.addLast(ts + "|" + type + "|" + fmt(cents) + "|" + note);
        while (a.history.size() > histMax) a.history.pollFirst();
        {
            globalLog.addLast("&8[&7" + ts + "&8] &f" + a.name + " &7\u00BB " + typeLabel(type)
                    + " &f" + fmt(cents) + " &8(&7" + note + "&8)");
            while (globalLog.size() > globalMax) globalLog.pollFirst();
        }
        dirty = true;
    }

    String renderHistory(String raw) {
        String[] p = raw.split("\\|", 4);
        if (p.length < 4) return "&7" + raw;
        return "&8[&7" + p[0] + "&8] &f" + typeLabel(p[1]) + " &f" + p[2] + " &8(&7" + p[3] + "&8)";
    }

    synchronized List<String> historyOf(Account a) {
        List<String> out = new ArrayList<>();
        for (String h : a.history) out.add(renderHistory(h));
        return out;
    }

    synchronized List<String> globalLogCopy() {
        return new ArrayList<>(globalLog);
    }

    // ---------------------------------------------------------------- ranks

    void recomputeRanks() {
        List<Account> l = new ArrayList<>(accounts.values());
        l.sort((x, y) -> Long.compare(y.balance, x.balance));
        int rank = 1;
        for (int i = 0; i < l.size(); i++) {
            if (i > 0 && l.get(i).balance != l.get(i - 1).balance) rank = i + 1;
            l.get(i).rank = rank;
        }
        List<TopEntry> t = new ArrayList<>();
        for (int i = 0; i < Math.min(10, l.size()); i++) t.add(new TopEntry(l.get(i).name, l.get(i).balance));
        top = List.copyOf(t);
    }

    // ---------------------------------------------------------------- persistence

    void load() {
        file = new File(plugin.getDataFolder(), "data/economy.yml");
        file.getParentFile().mkdirs();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        lockdown = y.getBoolean("global.lockdown", false);
        capOverride = y.getLong("global.bank-cap-override", -1);
        rateOverride = y.getDouble("global.interest-rate-override", -1);
        applyLive();
        globalLog.addAll(y.getStringList("global.log"));
        ConfigurationSection ps = y.getConfigurationSection("players");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                UUID id;
                try {
                    id = UUID.fromString(k);
                } catch (IllegalArgumentException e) {
                    continue;
                }
                ConfigurationSection s = ps.getConfigurationSection(k);
                if (s == null) continue;
                Account a = new Account(id);
                a.name = s.getString("name", "?");
                a.balance = s.getLong("balance");
                a.bank = s.getLong("bank");
                a.lastInterest = s.getLong("last-interest");
                a.frozen = s.getBoolean("frozen");
                a.pub = s.getBoolean("settings.public", true);
                a.notify = s.getBoolean("settings.notify", true);
                a.sound = s.getBoolean("settings.sound", true);
                a.confirm = s.getBoolean("settings.confirm", true);
                a.history.addAll(s.getStringList("history"));
                accounts.put(id, a);
            }
        }
        recomputeRanks();
        plugin.getLogger().info("Economy: loaded " + accounts.size() + " accounts.");
    }

    void save(boolean sync) {
        if (!dirty) return;
        YamlConfiguration y = new YamlConfiguration();
        synchronized (this) {
            dirty = false;
            y.set("global.lockdown", lockdown);
            y.set("global.bank-cap-override", capOverride);
            y.set("global.interest-rate-override", rateOverride);
            y.set("global.log", new ArrayList<>(globalLog));
            for (Account a : accounts.values()) {
                String b = "players." + a.id + ".";
                y.set(b + "name", a.name);
                y.set(b + "balance", a.balance);
                y.set(b + "bank", a.bank);
                y.set(b + "last-interest", a.lastInterest);
                y.set(b + "frozen", a.frozen);
                y.set(b + "settings.public", a.pub);
                y.set(b + "settings.notify", a.notify);
                y.set(b + "settings.sound", a.sound);
                y.set(b + "settings.confirm", a.confirm);
                y.set(b + "history", new ArrayList<>(a.history));
            }
        }
        final String out = y.saveToString();
        final File target = file;
        Runnable write = () -> {
            try {
                File tmp = new File(target.getParentFile(), "economy.yml.tmp");
                Files.writeString(tmp.toPath(), out);
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                plugin.getLogger().severe("Economy save failed: " + e.getMessage());
                dirty = true;
            }
        };
        if (sync) write.run();
        else Bukkit.getAsyncScheduler().runNow(plugin, t -> write.run());
    }

    // ---------------------------------------------------------------- settings flags

    boolean flag(Account a, String key) {
        return switch (key) {
            case "public" -> a.pub;
            case "notify" -> a.notify;
            case "sound" -> a.sound;
            case "confirm" -> a.confirm;
            default -> a.confirm;
        };
    }

    synchronized boolean flip(Account a, String key) {
        switch (key) {
            case "public" -> a.pub = !a.pub;
            case "notify" -> a.notify = !a.notify;
            case "sound" -> a.sound = !a.sound;
            case "confirm" -> a.confirm = !a.confirm;
            default -> a.confirm = !a.confirm;
        }
        dirty = true;
        return flag(a, key);
    }

    synchronized List<String> rawHistory(Account a) {
        return new ArrayList<>(a.history);
    }

    // ---------------------------------------------------------------- live settings and resets

    synchronized void setBankCap(long c) {
        capOverride = c;
        applyLive();
        dirty = true;
    }

    synchronized void setInterestRate(double r) {
        rateOverride = r;
        applyLive();
        dirty = true;
    }

    synchronized void resetLive() {
        capOverride = -1;
        rateOverride = -1;
        applyLive();
        dirty = true;
    }

    synchronized void resetEconomy() {
        for (Account a : accounts.values()) {
            a.balance = startBalance;
            a.bank = 0;
            a.lastInterest = 0;
        }
        dirty = true;
        recomputeRanks();
    }

    synchronized void wipeAllHistories() {
        for (Account a : accounts.values()) a.history.clear();
        globalLog.clear();
        dirty = true;
    }

    void adminLog(String text) {
        plugin.getLogger().info("[ADMIN] " + text);
    }
}
