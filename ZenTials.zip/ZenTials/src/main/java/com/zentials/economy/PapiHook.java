package com.zentials.economy;

import com.zentials.ZenTials;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Locale;

/**
 * %zen_balance% %zen_balance_raw% %zen_balance_short%
 * %zen_bank% %zen_bank_raw% %zen_bank_short%
 * %zen_networth% %zen_networth_raw% %zen_networth_short%
 * %zen_rank% %zen_rank_raw% %zen_symbol% %zen_frozen%
 * %zen_top_1_name% %zen_top_1_balance% %zen_top_1_balance_raw% %zen_top_1_balance_short%  (1 to 10)
 */
final class PapiHook extends PlaceholderExpansion {
    private final ZenTials plugin;
    private final EcoService svc;

    private PapiHook(ZenTials plugin, EcoService svc) {
        this.plugin = plugin;
        this.svc = svc;
    }

    static void register(ZenTials plugin, EcoService svc) {
        new PapiHook(plugin, svc).register();
    }

    @Override
    public @NotNull String getIdentifier() {
        return "zen";
    }

    @Override
    public @NotNull String getAuthor() {
        return "ZenTials";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    private static String raw(long cents) {
        return String.format(Locale.US, "%d.%02d", cents / 100, Math.abs(cents % 100));
    }

    private String top(String k) {
        String[] p = k.split("_", 3);
        if (p.length < 3) return null;
        int n;
        try {
            n = Integer.parseInt(p[1]);
        } catch (NumberFormatException e) {
            return null;
        }
        List<EcoService.TopEntry> t = svc.top;
        if (n < 1 || n > 10) return null;
        if (n > t.size()) return p[2].equals("name") ? "-" : "-";
        EcoService.TopEntry en = t.get(n - 1);
        return switch (p[2]) {
            case "name" -> en.name();
            case "balance" -> svc.fmt(en.balance());
            case "balance_raw" -> raw(en.balance());
            case "balance_short" -> svc.fmtShort(en.balance());
            default -> null;
        };
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        String k = params.toLowerCase(Locale.ROOT);
        if (k.equals("symbol")) return svc.symbol;
        if (k.startsWith("top_")) return top(k);
        if (player == null) return "";
        Account a = svc.get(player.getUniqueId());
        long bal = a == null ? 0 : a.balance;
        long bank = a == null ? 0 : a.bank;
        return switch (k) {
            case "balance" -> svc.fmt(bal);
            case "balance_raw" -> raw(bal);
            case "balance_short" -> svc.fmtShort(bal);
            case "bank" -> svc.fmt(bank);
            case "bank_raw" -> raw(bank);
            case "bank_short" -> svc.fmtShort(bank);
            case "networth" -> svc.fmt(bal + bank);
            case "networth_raw" -> raw(bal + bank);
            case "networth_short" -> svc.fmtShort(bal + bank);
            case "rank" -> a == null ? "-" : "#" + a.rank;
            case "rank_raw" -> a == null ? "0" : String.valueOf(a.rank);
            case "frozen" -> String.valueOf(a != null && a.frozen);
            default -> null;
        };
    }
}
