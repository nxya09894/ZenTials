package com.zentials.economy;

import com.zentials.ZenTials;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/** %eco_balance%  %eco_bank%  %eco_rank%  %eco_balance_raw%  %eco_bank_raw% */
final class PapiHook extends PlaceholderExpansion {
    private final ZenTials plugin;
    private final EcoService svc;

    private PapiHook(ZenTials plugin, EcoService svc) {
        this.plugin = plugin;
        this.svc = svc;
    }

    static void register(ZenTials plugin, EcoService svc) {
        new PapiHook(plugin, svc).register();
    }

    @Override
    public @NotNull String getIdentifier() {
        return "eco";
    }

    @Override
    public @NotNull String getAuthor() {
        return "ZenTials";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        Account a = svc.get(player.getUniqueId());
        if (a == null) a = new Account(player.getUniqueId());
        return switch (params.toLowerCase()) {
            case "balance" -> svc.fmt(a.balance);
            case "bank" -> svc.fmt(a.bank);
            case "rank" -> "#" + a.rank;
            case "balance_raw" -> String.valueOf(a.balance / 100.0);
            case "bank_raw" -> String.valueOf(a.bank / 100.0);
            default -> null;
        };
    }
}
