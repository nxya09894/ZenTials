package com.zentials.economy;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.List;

@SuppressWarnings("deprecation")
final class VaultEconomy implements Economy {
    private final EcoService svc;

    VaultEconomy(EcoService svc) {
        this.svc = svc;
    }

    private static OfflinePlayer byName(String n) {
        Player p = Bukkit.getPlayerExact(n);
        return p != null ? p : Bukkit.getOfflinePlayerIfCached(n);
    }

    private Account acct(OfflinePlayer p) {
        return p == null ? null : svc.get(p.getUniqueId());
    }

    private double bal(OfflinePlayer p) {
        Account a = acct(p);
        return a == null ? 0 : a.balance / 100.0;
    }

    private EconomyResponse deposit(OfflinePlayer p, double amt) {
        if (p == null) return new EconomyResponse(0, 0, ResponseType.FAILURE, "Player not found");
        if (amt < 0) return new EconomyResponse(0, bal(p), ResponseType.FAILURE, "Cannot deposit negative funds");
        long c = Math.round(amt * 100);
        Account a = svc.ensure(p.getUniqueId(), p.getName());
        if (c > 0) svc.add(a.id, c, "Deposit", false);
        return new EconomyResponse(amt, a.balance / 100.0, ResponseType.SUCCESS, null);
    }

    private EconomyResponse withdraw(OfflinePlayer p, double amt) {
        if (p == null) return new EconomyResponse(0, 0, ResponseType.FAILURE, "Player not found");
        if (amt < 0) return new EconomyResponse(0, bal(p), ResponseType.FAILURE, "Cannot withdraw negative funds");
        long c = Math.round(amt * 100);
        Account a = svc.ensure(p.getUniqueId(), p.getName());
        if (c > 0 && !svc.remove(a.id, c, "Purchase", false)) {
            return new EconomyResponse(0, a.balance / 100.0, ResponseType.FAILURE, "Insufficient funds");
        }
        return new EconomyResponse(amt, a.balance / 100.0, ResponseType.SUCCESS, null);
    }

    // ---- info
    @Override public boolean isEnabled() { return true; }
    @Override public String getName() { return "ZenTials"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) { return svc.fmt(Math.round(amount * 100)); }
    @Override public String currencyNamePlural() { return svc.namePlural; }
    @Override public String currencyNameSingular() { return svc.nameSingular; }

    // ---- accounts
    @Override public boolean hasAccount(String n) { return acct(byName(n)) != null; }
    @Override public boolean hasAccount(OfflinePlayer p) { return acct(p) != null; }
    @Override public boolean hasAccount(String n, String w) { return hasAccount(n); }
    @Override public boolean hasAccount(OfflinePlayer p, String w) { return hasAccount(p); }

    @Override public boolean createPlayerAccount(String n) { return createPlayerAccount(byName(n)); }
    @Override public boolean createPlayerAccount(OfflinePlayer p) {
        if (p == null || svc.get(p.getUniqueId()) != null) return false;
        svc.ensure(p.getUniqueId(), p.getName());
        return true;
    }
    @Override public boolean createPlayerAccount(String n, String w) { return createPlayerAccount(n); }
    @Override public boolean createPlayerAccount(OfflinePlayer p, String w) { return createPlayerAccount(p); }

    // ---- balance
    @Override public double getBalance(String n) { return bal(byName(n)); }
    @Override public double getBalance(OfflinePlayer p) { return bal(p); }
    @Override public double getBalance(String n, String w) { return bal(byName(n)); }
    @Override public double getBalance(OfflinePlayer p, String w) { return bal(p); }

    @Override public boolean has(String n, double amt) { return bal(byName(n)) + 0.001 >= amt; }
    @Override public boolean has(OfflinePlayer p, double amt) { return bal(p) + 0.001 >= amt; }
    @Override public boolean has(String n, String w, double amt) { return has(n, amt); }
    @Override public boolean has(OfflinePlayer p, String w, double amt) { return has(p, amt); }

    // ---- withdraw / deposit
    @Override public EconomyResponse withdrawPlayer(String n, double amt) { return withdraw(byName(n), amt); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer p, double amt) { return withdraw(p, amt); }
    @Override public EconomyResponse withdrawPlayer(String n, String w, double amt) { return withdraw(byName(n), amt); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer p, String w, double amt) { return withdraw(p, amt); }

    @Override public EconomyResponse depositPlayer(String n, double amt) { return deposit(byName(n), amt); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer p, double amt) { return deposit(p, amt); }
    @Override public EconomyResponse depositPlayer(String n, String w, double amt) { return deposit(byName(n), amt); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer p, String w, double amt) { return deposit(p, amt); }

    // ---- banks (not supported; ZenTials has its own personal bank)
    private static EconomyResponse noBank() {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "ZenTials has no Vault bank support");
    }
    @Override public EconomyResponse createBank(String name, String player) { return noBank(); }
    @Override public EconomyResponse createBank(String name, OfflinePlayer player) { return noBank(); }
    @Override public EconomyResponse deleteBank(String name) { return noBank(); }
    @Override public EconomyResponse bankBalance(String name) { return noBank(); }
    @Override public EconomyResponse bankHas(String name, double amount) { return noBank(); }
    @Override public EconomyResponse bankWithdraw(String name, double amount) { return noBank(); }
    @Override public EconomyResponse bankDeposit(String name, double amount) { return noBank(); }
    @Override public EconomyResponse isBankOwner(String name, String playerName) { return noBank(); }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) { return noBank(); }
    @Override public EconomyResponse isBankMember(String name, String playerName) { return noBank(); }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) { return noBank(); }
    @Override public List<String> getBanks() { return List.of(); }
}
