package com.zentials.holo;

import com.zentials.ZenTials;
import com.zentials.core.Papi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Floating text (TextDisplay) holograms and an automatic richest-players leaderboard.
 * Saved in modules/holograms/data.yml. Text accepts &colors, {online} {max}, and global PlaceholderAPI placeholders
 * (for example %zen_top_1_name%). Placeholders that depend on the viewer are not supported (one entity is shared by everybody).
 *
 * /hologram create <id> [text...]   /hologram eco <id>      (leaderboard of the richest players)
 * /hologram addline|setline|removeline  /hologram move|tp|delete|list|near|reload
 */
public final class HologramModule implements ZModule, Listener, TabExecutor {
    private static final String TAG = "&8[&bHolo&8]&7 ";
    private static final String PERM = "zentials.hologram";

    private static final class Holo {
        final String id;
        Location loc;
        String type = "text"; // text | eco
        final List<String> lines = new ArrayList<>();
        UUID entityId;

        Holo(String id) {
            this.id = id;
        }

        Entity entity() {
            if (entityId == null) return null;
            Entity e = Bukkit.getEntity(entityId);
            return e != null && e.isValid() ? e : null;
        }
    }

    private final ZenTials plugin;
    private final Map<String, Holo> holos = new LinkedHashMap<>();
    private final List<BukkitTask> tasks = new ArrayList<>();
    private NamespacedKey tagKey;
    private File file;
    private int refreshTicks;
    private int ecoRows;
    private String ecoTitle;
    private String ecoRow;

    public HologramModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "holograms";
    }

    @Override
    public void enable() {
        tagKey = new NamespacedKey(plugin, "holo");
        com.zentials.core.Cfg.migrate(plugin, "holograms.yml", "modules/holograms/data.yml");
        file = new File(plugin.getDataFolder(), "modules/holograms/data.yml");
        file.getParentFile().mkdirs();
        readConfig();
        load();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        PluginCommand c = plugin.getCommand("hologram");
        if (c != null) {
            c.setExecutor(this);
            c.setTabCompleter(this);
        }
        tasks.add(Bukkit.getScheduler().runTaskLater(plugin, () -> {
            purgeStale();
            spawnAll();
        }, 40L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 100L, refreshTicks));
    }

    @Override
    public void disable() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
        for (Holo h : holos.values()) {
            Entity e = h.entity();
            if (e != null) e.remove();
            h.entityId = null;
        }
    }

    @Override
    public void reload() {
        disable();
        readConfig();
        load();
        purgeStale();
        spawnAll();
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 100L, refreshTicks));
    }

    private void readConfig() {
        var c = plugin.moduleConfig("holograms");
        refreshTicks = Math.max(20, c.getInt("holograms.refresh-seconds", 15) * 20);
        ecoRows = Math.max(1, Math.min(10, c.getInt("holograms.eco-rows", 10)));
        ecoTitle = c.getString("holograms.eco-title", "&6&lRICHEST PLAYERS");
        ecoRow = c.getString("holograms.eco-row", "&e#{rank} &f{name} &8- &a{balance}");
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        holos.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("holograms");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Holo h = new Holo(id);
            h.loc = s.getLocation("loc");
            h.type = s.getString("type", "text");
            h.lines.addAll(s.getStringList("lines"));
            if (h.loc != null) holos.put(id, h);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Holo h : holos.values()) {
            y.set("holograms." + h.id + ".loc", h.loc);
            y.set("holograms." + h.id + ".type", h.type);
            y.set("holograms." + h.id + ".lines", h.lines);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------- display

    private void purgeStale() {
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e.getPersistentDataContainer().has(tagKey, PersistentDataType.STRING)) e.remove();
            }
        }
        for (Holo h : holos.values()) h.entityId = null;
    }

    private void spawnAll() {
        for (Holo h : holos.values()) spawn(h);
    }

    private boolean chunkLoaded(Location l) {
        World w = l.getWorld();
        return w != null && w.isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4);
    }

    private void spawn(Holo h) {
        if (h.entity() != null || h.loc == null || !chunkLoaded(h.loc)) return;
        TextDisplay td = h.loc.getWorld().spawn(h.loc, TextDisplay.class, e -> {
            e.setPersistent(false);
            e.setBillboard(Display.Billboard.CENTER);
            e.setAlignment(TextDisplay.TextAlignment.CENTER);
            e.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            e.setShadowed(true);
            e.setSeeThrough(false);
            e.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, h.id);
        });
        h.entityId = td.getUniqueId();
        render(h);
    }

    private String fill(String line) {
        var s = line.replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()));
        return Papi.set(null, s);
    }

    private Component build(Holo h) {
        List<String> out = new ArrayList<>();
        if (h.type.equals("eco")) {
            out.add(ecoTitle);
            var eco = plugin.economyApi();
            var top = eco == null ? List.<Map.Entry<String, Double>>of() : eco.top();
            for (int i = 0; i < ecoRows; i++) {
                if (i < top.size()) {
                    var en = top.get(i);
                    out.add(ecoRow.replace("{rank}", String.valueOf(i + 1)).replace("{name}", en.getKey())
                            .replace("{balance}", eco.format(en.getValue())));
                } else {
                    out.add(ecoRow.replace("{rank}", String.valueOf(i + 1)).replace("{name}", "-").replace("{balance}", "-"));
                }
            }
        } else {
            out.addAll(h.lines);
        }
        Component c = Component.empty();
        for (int i = 0; i < out.size(); i++) {
            if (i > 0) c = c.append(Component.newline());
            c = c.append(Text.c(fill(out.get(i))));
        }
        return c;
    }

    private void render(Holo h) {
        if (h.entity() instanceof TextDisplay td) td.text(build(h));
    }

    private void refreshAll() {
        for (Holo h : holos.values()) {
            if (h.entity() == null) spawn(h);
            else render(h);
        }
    }

    private void respawn(Holo h) {
        Entity e = h.entity();
        if (e != null) e.remove();
        h.entityId = null;
        spawn(h);
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        Chunk c = e.getChunk();
        for (Holo h : holos.values()) {
            if (h.loc.getWorld() == c.getWorld() && (h.loc.getBlockX() >> 4) == c.getX()
                    && (h.loc.getBlockZ() >> 4) == c.getZ()) {
                Bukkit.getScheduler().runTask(plugin, () -> spawn(h));
            }
        }
    }

    // ---------------------------------------------------------------- commands

    private void msg(CommandSender s, String m) {
        Text.send(s, TAG + m);
    }

    private Holo find(CommandSender s, String id) {
        Holo h = holos.get(id.toLowerCase(Locale.ROOT));
        if (h == null) msg(s, "&cNo hologram with id &f" + id + "&c. See &f/hologram list");
        return h;
    }

    private static String join(String[] a, int from) {
        return String.join(" ", java.util.Arrays.copyOfRange(a, from, a.length));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission(PERM)) {
            msg(s, "&cYou don't have permission.");
            return true;
        }
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create", "eco" -> {
                if (!(s instanceof Player p) || a.length < 2) {
                    msg(s, "&cUsage (in game): /hologram create <id> [text]   or   /hologram eco <id>");
                    return true;
                }
                String id = a[1].toLowerCase(Locale.ROOT);
                if (!id.matches("[a-z0-9_\\-]{1,32}")) {
                    msg(s, "&cThe id can only use letters, numbers, _ and - (max 32).");
                    return true;
                }
                if (holos.containsKey(id)) {
                    msg(s, "&cThat id already exists.");
                    return true;
                }
                Holo h = new Holo(id);
                h.loc = p.getLocation().add(0, 1.8, 0);
                if (sub.equals("eco")) h.type = "eco";
                else h.lines.add(a.length > 2 ? join(a, 2) : "&bNew hologram");
                holos.put(id, h);
                save();
                spawn(h);
                msg(s, "Created &f" + id + "&7.");
            }
            case "delete", "remove" -> {
                if (a.length < 2) return usage(s, "/hologram delete <id>");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                Entity e = h.entity();
                if (e != null) e.remove();
                holos.remove(h.id);
                save();
                msg(s, "Deleted.");
            }
            case "addline" -> {
                if (a.length < 3) return usage(s, "/hologram addline <id> <text>");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                h.type = "text";
                h.lines.add(join(a, 2));
                save();
                render(h);
                msg(s, "Line added (&f" + h.lines.size() + "&7).");
            }
            case "setline" -> {
                if (a.length < 4) return usage(s, "/hologram setline <id> <number> <text>");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                int i = num(a[2]);
                if (i < 1 || i > h.lines.size()) {
                    msg(s, "&cLine number must be 1 to " + h.lines.size() + ".");
                    return true;
                }
                h.lines.set(i - 1, join(a, 3));
                save();
                render(h);
                msg(s, "Line set.");
            }
            case "removeline" -> {
                if (a.length < 3) return usage(s, "/hologram removeline <id> <number>");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                int i = num(a[2]);
                if (i < 1 || i > h.lines.size()) {
                    msg(s, "&cLine number must be 1 to " + h.lines.size() + ".");
                    return true;
                }
                h.lines.remove(i - 1);
                save();
                render(h);
                msg(s, "Line removed.");
            }
            case "move", "movehere" -> {
                if (!(s instanceof Player p) || a.length < 2) return usage(s, "/hologram move <id>  (in game)");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                h.loc = p.getLocation().add(0, 1.8, 0);
                save();
                respawn(h);
                msg(s, "Moved to you.");
            }
            case "tp" -> {
                if (!(s instanceof Player p) || a.length < 2) return usage(s, "/hologram tp <id>  (in game)");
                Holo h = find(s, a[1]);
                if (h == null) return true;
                p.teleportAsync(h.loc);
            }
            case "list" -> {
                if (holos.isEmpty()) msg(s, "No holograms.");
                for (Holo h : holos.values()) {
                    Text.send(s, " &8- &f" + h.id + " &7(" + h.type + ", " + h.lines.size() + " lines) &8| &7"
                            + (h.loc.getWorld() == null ? "?" : h.loc.getWorld().getName()) + " "
                            + h.loc.getBlockX() + "," + h.loc.getBlockY() + "," + h.loc.getBlockZ());
                }
            }
            case "near" -> {
                if (!(s instanceof Player p)) return true;
                Holo best = null;
                double bd = Double.MAX_VALUE;
                for (Holo h : holos.values()) {
                    if (h.loc.getWorld() != p.getWorld()) continue;
                    double d = h.loc.distanceSquared(p.getLocation());
                    if (d < bd) {
                        bd = d;
                        best = h;
                    }
                }
                msg(s, best == null ? "None in this world." : "Nearest: &f" + best.id + " &7(" + (int) Math.sqrt(bd) + " blocks)");
            }
            case "reload" -> {
                reload();
                msg(s, "Holograms reloaded.");
            }
            default -> {
                msg(s, "Commands:");
                for (String l : new String[]{"/hologram create <id> [text]", "/hologram eco <id>  (richest players)",
                        "/hologram addline <id> <text>", "/hologram setline <id> <n> <text>", "/hologram removeline <id> <n>",
                        "/hologram move <id>", "/hologram tp <id>", "/hologram delete <id>", "/hologram list", "/hologram near",
                        "/hologram reload"}) {
                    Text.send(s, " &8- &f" + l);
                }
            }
        }
        return true;
    }

    private boolean usage(CommandSender s, String u) {
        msg(s, "&cUsage: " + u);
        return true;
    }

    private static int num(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission(PERM)) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("create", "eco", "addline", "setline", "removeline", "move", "tp", "delete", "list", "near", "reload"));
        } else if (a.length == 2 && !a[0].equalsIgnoreCase("create") && !a[0].equalsIgnoreCase("eco")) {
            out.addAll(holos.keySet());
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
