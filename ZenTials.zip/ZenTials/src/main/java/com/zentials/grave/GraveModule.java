package com.zentials.grave;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Skull;
import org.bukkit.block.data.Rotatable;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Graves: when a player dies their items go into a grave (a player head with the owner's skin) placed on the
 * nearest SAFE spot (never in lava / fire / void). Floating text shows name, date, coordinates and cause.
 * Breaking the head puts everything straight back into the inventory (armor goes back to the armor slots).
 * /death and the teleport menu's "Last Death Location" teleport on top of the latest grave.
 * Settings: plugins/ZenTials/graves.yml  Data: plugins/ZenTials/graves-data.yml
 */
public final class GraveModule implements ZModule, Listener, TabExecutor {
    private static final String T = "&8[&cGrave&8]&7 ";

    private static final class Grave {
        long id;
        UUID owner;
        String ownerName;
        String world;
        int x;
        int y;
        int z;
        int dx;
        int dy;
        int dz;
        long time;
        int xp;
        String cause = "Unknown";
        final Map<Integer, ItemStack> slotted = new TreeMap<>();
        final List<ItemStack> extra = new ArrayList<>();
        UUID display;
        Boolean lockShown;

        int itemCount() {
            int n = extra.size() + slotted.size();
            return n;
        }
    }

    private static final Set<Material> HARM = Set.of(Material.FIRE, Material.SOUL_FIRE, Material.CACTUS, Material.MAGMA_BLOCK,
            Material.CAMPFIRE, Material.SOUL_CAMPFIRE, Material.SWEET_BERRY_BUSH, Material.WITHER_ROSE, Material.POWDER_SNOW,
            Material.COBWEB, Material.LAVA, Material.POINTED_DRIPSTONE);

    private final ZenTials plugin;
    private final File dataFile;
    private final Map<Long, Grave> graves = new LinkedHashMap<>();
    private final Map<String, Grave> byBlock = new java.util.concurrent.ConcurrentHashMap<>();
    private long nextId = 1;
    private YamlConfiguration cfg;
    private BukkitTask task;
    private int tickCount;

    public GraveModule(ZenTials plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "graves-data.yml");
    }

    @Override
    public String id() {
        return "graves";
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void enable() {
        cfg = Cfg.yamlWithDefaults(plugin, "graves.yml");
        load();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        PluginCommand c = plugin.getCommand("graves");
        if (c != null) {
            c.setExecutor(this);
            c.setTabCompleter(this);
        }
        for (Grave g : graves.values()) ensureDisplay(g);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 20L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        save();
        for (Grave g : graves.values()) removeDisplay(g);
    }

    @Override
    public void reload() {
        cfg = Cfg.yamlWithDefaults(plugin, "graves.yml");
        for (Grave g : graves.values()) {
            g.lockShown = null;
            removeDisplay(g);
            ensureDisplay(g);
        }
    }

    private boolean disabledIn(World w) {
        for (String s : cfg.getStringList("disabled-worlds")) if (s.equalsIgnoreCase(w.getName())) return true;
        return false;
    }

    // ---------------------------------------------------------------- storage

    private static String enc(ItemStack it) {
        return Base64.getEncoder().encodeToString(it.serializeAsBytes());
    }

    private static ItemStack dec(String s) {
        return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
    }

    private static String key(String world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    private void load() {
        graves.clear();
        byBlock.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection s = y.getConfigurationSection("graves");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(id);
            if (c == null) continue;
            try {
                Grave g = new Grave();
                g.id = Long.parseLong(id);
                g.owner = UUID.fromString(c.getString("owner", ""));
                g.ownerName = c.getString("owner-name", "Unknown");
                g.world = c.getString("world", "world");
                g.x = c.getInt("x");
                g.y = c.getInt("y");
                g.z = c.getInt("z");
                g.dx = c.getInt("dx");
                g.dy = c.getInt("dy");
                g.dz = c.getInt("dz");
                g.time = c.getLong("time");
                g.xp = c.getInt("xp");
                g.cause = c.getString("cause", "Unknown");
                ConfigurationSection sl = c.getConfigurationSection("slots");
                if (sl != null) for (String k : sl.getKeys(false)) g.slotted.put(Integer.parseInt(k), dec(sl.getString(k, "")));
                for (String e : c.getStringList("extra")) g.extra.add(dec(e));
                graves.put(g.id, g);
                byBlock.put(key(g.world, g.x, g.y, g.z), g);
                nextId = Math.max(nextId, g.id + 1);
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Graves: skipped broken grave " + id + ": " + ex.getMessage());
            }
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Grave g : graves.values()) {
            String p = "graves." + g.id + ".";
            y.set(p + "owner", g.owner.toString());
            y.set(p + "owner-name", g.ownerName);
            y.set(p + "world", g.world);
            y.set(p + "x", g.x);
            y.set(p + "y", g.y);
            y.set(p + "z", g.z);
            y.set(p + "dx", g.dx);
            y.set(p + "dy", g.dy);
            y.set(p + "dz", g.dz);
            y.set(p + "time", g.time);
            y.set(p + "xp", g.xp);
            y.set(p + "cause", g.cause);
            for (var e : g.slotted.entrySet()) y.set(p + "slots." + e.getKey(), enc(e.getValue()));
            List<String> ex = new ArrayList<>();
            for (ItemStack it : g.extra) ex.add(enc(it));
            y.set(p + "extra", ex);
        }
        try {
            y.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Graves: could not save graves-data.yml: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- safe spot search

    private static boolean harm(Material m) {
        return HARM.contains(m);
    }

    private static boolean clearFeet(Block b) {
        Material m = b.getType();
        return !b.isLiquid() && !harm(m) && (m.isAir() || b.isReplaceable());
    }

    private static boolean clearAir(Block b) {
        Material m = b.getType();
        return !b.isLiquid() && !harm(m) && (m.isAir() || b.isPassable());
    }

    private static boolean groundOk(Block b) {
        Material m = b.getType();
        if (m == Material.WATER) return true;
        return m.isSolid() && !harm(m);
    }

    /** A grave (and a standing player above it) fits at this block: air-ish at y, y+1, y+2 and good ground below. */
    private boolean valid(World w, int x, int y, int z) {
        if (y <= w.getMinHeight() || y + 2 >= w.getMaxHeight()) return false;
        if (byBlock.containsKey(key(w.getName(), x, y, z))) return false;
        if (!clearFeet(w.getBlockAt(x, y, z))) return false;
        if (!clearAir(w.getBlockAt(x, y + 1, z)) || !clearAir(w.getBlockAt(x, y + 2, z))) return false;
        return groundOk(w.getBlockAt(x, y - 1, z));
    }

    /** Finds the nearest safe block for a grave around a location (the grave block itself is at the result). */
    public Location safeSpot(Location from) {
        World w = from.getWorld();
        int x = from.getBlockX();
        int y = from.getBlockY();
        int z = from.getBlockZ();
        int min = w.getMinHeight();
        int max = w.getMaxHeight() - 3;
        boolean nether = w.getEnvironment() == World.Environment.NETHER;
        if (!nether && (y <= min + 1 || y > max) && w.isChunkLoaded(x >> 4, z >> 4)) {
            y = w.getHighestBlockYAt(x, z) + 1;
        }
        y = Math.max(min + 2, Math.min(max, y));
        int r = cfg.getInt("search-radius", 8);
        int up = nether ? 16 : 20;
        int down = nether ? 16 : 8;
        if (nether) r = Math.max(r, 12);
        double bestD = Double.MAX_VALUE;
        int bx = 0;
        int by = 0;
        int bz = 0;
        boolean found = false;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = x + dx;
                int cz = z + dz;
                if (!w.isChunkLoaded(cx >> 4, cz >> 4)) continue;
                for (int dy = -down; dy <= up; dy++) {
                    double d = dx * dx + dz * dz + dy * dy * (dy > 0 ? 0.5 : 1.0);
                    if (d >= bestD) continue;
                    if (valid(w, cx, y + dy, cz)) {
                        bestD = d;
                        bx = cx;
                        by = y + dy;
                        bz = cz;
                        found = true;
                    }
                }
            }
        }
        if (found) return new Location(w, bx, by, bz);
        if (!nether) {
            // wider search on the surface only
            for (int rad = r; rad <= 48 && !found; rad += 2) {
                for (int dx = -rad; dx <= rad; dx += 2) {
                    for (int dz = -rad; dz <= rad; dz += 2) {
                        if (Math.abs(dx) != rad && Math.abs(dz) != rad) continue;
                        int cx = x + dx;
                        int cz = z + dz;
                        if (!w.isChunkLoaded(cx >> 4, cz >> 4)) continue;
                        int hy = w.getHighestBlockYAt(cx, cz) + 1;
                        double d = dx * dx + dz * dz;
                        if (d < bestD && valid(w, cx, hy, cz)) {
                            bestD = d;
                            bx = cx;
                            by = hy;
                            bz = cz;
                            found = true;
                        }
                    }
                }
            }
            if (found) return new Location(w, bx, by, bz);
            Location sp = w.getSpawnLocation();
            int sy = w.getHighestBlockYAt(sp.getBlockX(), sp.getBlockZ()) + 1;
            return new Location(w, sp.getBlockX(), sy, sp.getBlockZ());
        }
        return new Location(w, x, y, z);
    }

    // ---------------------------------------------------------------- death -> grave

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getPlayer();
        if (e.getKeepInventory() || disabledIn(p.getWorld())) return;
        boolean fullXp = cfg.getBoolean("full-xp", false);
        int xp = fullXp ? p.getTotalExperience() : e.getDroppedExp();
        List<ItemStack> rest = new ArrayList<>();
        for (ItemStack it : e.getDrops()) if (it != null && !it.getType().isAir()) rest.add(it.clone());
        if (rest.isEmpty() && xp <= 0) return;

        Grave g = new Grave();
        ItemStack[] inv = p.getInventory().getContents();
        for (int i = 0; i < inv.length; i++) {
            ItemStack it = inv[i];
            if (it == null || it.getType().isAir()) continue;
            int idx = -1;
            for (int k = 0; k < rest.size(); k++) {
                if (rest.get(k).equals(it)) {
                    idx = k;
                    break;
                }
            }
            if (idx >= 0) {
                g.slotted.put(i, it.clone());
                rest.remove(idx);
            }
        }
        g.extra.addAll(rest);

        Location death = p.getLocation();
        Location spot = safeSpot(death);
        g.id = nextId++;
        g.owner = p.getUniqueId();
        g.ownerName = p.getName();
        g.world = spot.getWorld().getName();
        g.x = spot.getBlockX();
        g.y = spot.getBlockY();
        g.z = spot.getBlockZ();
        g.dx = death.getBlockX();
        g.dy = death.getBlockY();
        g.dz = death.getBlockZ();
        g.time = System.currentTimeMillis();
        g.xp = Math.max(0, xp);
        g.cause = cause(p);

        e.getDrops().clear();
        e.setDroppedExp(0);
        if (fullXp) {
            e.setNewExp(0);
            e.setNewLevel(0);
            e.setNewTotalExp(0);
        }

        trimOld(p.getUniqueId());
        graves.put(g.id, g);
        byBlock.put(key(g.world, g.x, g.y, g.z), g);
        placeBlock(g, p);
        ensureDisplay(g);
        save();
        Text.send(p, T + "&cYou died. &7Your items are safe in a grave at &f" + g.x + " " + g.y + " " + g.z + " &8(" + g.world + ")&7.");
        Text.send(p, T + "&7Use &f/death &7to teleport to it, then break the head to get everything back.");
    }

    private static String cause(Player p) {
        var ev = p.getLastDamageCause();
        if (ev == null) return "Unknown";
        String n = ev.getCause().name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return n.substring(0, 1).toUpperCase(Locale.ROOT) + n.substring(1);
    }

    /** Keeps at most max-per-player graves: the oldest one drops its items on the ground. */
    private void trimOld(UUID owner) {
        int max = cfg.getInt("max-per-player", 5);
        if (max <= 0) return;
        List<Grave> mine = new ArrayList<>();
        for (Grave g : graves.values()) if (g.owner.equals(owner)) mine.add(g);
        while (mine.size() >= max) {
            Grave old = mine.remove(0);
            dropAll(old);
        }
    }

    private void placeBlock(Grave g, Player p) {
        World w = Bukkit.getWorld(g.world);
        if (w == null) return;
        Block b = w.getBlockAt(g.x, g.y, g.z);
        b.setType(Material.PLAYER_HEAD, false);
        if (b.getBlockData() instanceof Rotatable rot) {
            BlockFace f = p != null ? p.getFacing().getOppositeFace() : BlockFace.SOUTH;
            rot.setRotation(f);
            b.setBlockData(rot, false);
        }
        if (b.getState() instanceof Skull sk) {
            sk.setOwningPlayer(Bukkit.getOfflinePlayer(g.owner));
            sk.update(true, false);
        }
    }

    // ---------------------------------------------------------------- hologram

    private ZoneId zone() {
        try {
            String tz = cfg.getString("timezone", "");
            return tz == null || tz.isBlank() ? ZoneId.systemDefault() : ZoneId.of(tz);
        } catch (RuntimeException e) {
            return ZoneId.systemDefault();
        }
    }

    private String date(long ms) {
        String f = cfg.getString("date-format", "MMM d, yyyy h:mm a");
        try {
            return ZonedDateTime.ofInstant(Instant.ofEpochMilli(ms), zone()).format(DateTimeFormatter.ofPattern(f, Locale.ENGLISH));
        } catch (RuntimeException e) {
            return String.valueOf(ms);
        }
    }

    private boolean locked(Grave g) {
        int mins = cfg.getInt("protect-minutes", 15);
        return mins > 0 && System.currentTimeMillis() - g.time < mins * 60_000L;
    }

    private net.kyori.adventure.text.Component holoText(Grave g) {
        List<String> lines = new ArrayList<>();
        boolean lk = locked(g);
        for (String l : cfg.getStringList("hologram")) {
            lines.add(l.replace("{name}", g.ownerName).replace("{date}", date(g.time))
                    .replace("{x}", String.valueOf(g.x)).replace("{y}", String.valueOf(g.y)).replace("{z}", String.valueOf(g.z))
                    .replace("{world}", g.world).replace("{cause}", g.cause).replace("{items}", String.valueOf(g.itemCount()))
                    .replace("{status}", lk ? cfg.getString("status-locked", "&cOwner only") : cfg.getString("status-open", "&aAnyone can open")));
        }
        return Text.c(String.join("\n", lines));
    }

    private void ensureDisplay(Grave g) {
        World w = Bukkit.getWorld(g.world);
        if (w == null || !w.isChunkLoaded(g.x >> 4, g.z >> 4)) return;
        Block b = w.getBlockAt(g.x, g.y, g.z);
        if (b.getType() != Material.PLAYER_HEAD) placeBlock(g, null); // somebody removed the head (worldedit, etc.)
        Entity cur = g.display == null ? null : Bukkit.getEntity(g.display);
        if (cur != null && cur.isValid()) return;
        Location at = new Location(w, g.x + 0.5, g.y + cfg.getDouble("hologram-height", 1.4), g.z + 0.5);
        TextDisplay td = w.spawn(at, TextDisplay.class, d -> {
            d.setPersistent(false); // never saved, we respawn it ourselves
            d.setBillboard(Display.Billboard.CENTER);
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setBackgroundColor(Color.fromARGB(90, 0, 0, 0));
            d.setShadowed(true);
            d.setLineWidth(300);
            d.text(holoText(g));
        });
        g.display = td.getUniqueId();
        g.lockShown = locked(g);
    }

    private void removeDisplay(Grave g) {
        if (g.display == null) return;
        Entity e = Bukkit.getEntity(g.display);
        if (e != null) e.remove();
        g.display = null;
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        int cx = e.getChunk().getX();
        int cz = e.getChunk().getZ();
        String w = e.getWorld().getName();
        for (Grave g : graves.values()) {
            if (g.world.equals(w) && (g.x >> 4) == cx && (g.z >> 4) == cz) {
                g.display = null;
                Bukkit.getScheduler().runTask(plugin, () -> ensureDisplay(g));
            }
        }
    }

    // ---------------------------------------------------------------- periodic: lock text, expiry, particles

    private void tick() {
        tickCount++;
        int expire = cfg.getInt("expire-minutes", 0);
        boolean particles = cfg.getBoolean("particles", true);
        for (Grave g : new ArrayList<>(graves.values())) {
            World w = Bukkit.getWorld(g.world);
            if (w == null) continue;
            if (expire > 0 && System.currentTimeMillis() - g.time > expire * 60_000L && w.isChunkLoaded(g.x >> 4, g.z >> 4)) {
                dropAll(g);
                continue;
            }
            if (!w.isChunkLoaded(g.x >> 4, g.z >> 4)) continue;
            Entity d = g.display == null ? null : Bukkit.getEntity(g.display);
            if (d instanceof TextDisplay td) {
                boolean lk = locked(g);
                if (g.lockShown == null || g.lockShown != lk) {
                    g.lockShown = lk;
                    td.text(holoText(g));
                }
            } else {
                ensureDisplay(g);
            }
            if (particles && !w.getNearbyPlayers(new Location(w, g.x, g.y, g.z), 24).isEmpty()) {
                w.spawnParticle(Particle.SOUL, g.x + 0.5, g.y + 0.9, g.z + 0.5, 2, 0.2, 0.3, 0.2, 0.01);
            }
        }
    }

    // ---------------------------------------------------------------- remove / drop / collect

    private void removeGrave(Grave g) {
        graves.remove(g.id);
        byBlock.remove(key(g.world, g.x, g.y, g.z));
        removeDisplay(g);
        World w = Bukkit.getWorld(g.world);
        if (w != null) {
            Block b = w.getBlockAt(g.x, g.y, g.z);
            if (b.getType() == Material.PLAYER_HEAD) b.setType(Material.AIR, false);
        }
        save();
    }

    /** Removes the grave and drops all its items and xp on the ground (expiry, limit, admin remove). */
    private void dropAll(Grave g) {
        removeGrave(g);
        World w = Bukkit.getWorld(g.world);
        if (w == null) return;
        Location at = new Location(w, g.x + 0.5, g.y + 0.5, g.z + 0.5);
        for (ItemStack it : g.slotted.values()) w.dropItemNaturally(at, it);
        for (ItemStack it : g.extra) w.dropItemNaturally(at, it);
        if (g.xp > 0) {
            w.spawn(at, org.bukkit.entity.ExperienceOrb.class, o -> o.setExperience(g.xp));
        }
    }

    private void collect(Player p, Grave g) {
        removeGrave(g); // first, so it can never be collected twice
        PlayerInventory inv = p.getInventory();
        List<ItemStack> overflow = new ArrayList<>(g.extra);
        for (var en : g.slotted.entrySet()) {
            ItemStack cur = inv.getItem(en.getKey());
            if (cur == null || cur.getType().isAir()) inv.setItem(en.getKey(), en.getValue());
            else overflow.add(en.getValue());
        }
        int items = g.itemCount();
        for (ItemStack it : overflow) {
            for (ItemStack left : inv.addItem(it).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
        if (g.xp > 0) p.giveExp(g.xp);
        plugin.sfx().play(p, "claim");
        boolean own = p.getUniqueId().equals(g.owner);
        Text.send(p, T + (own ? "&aYou recovered your items" : "&aYou looted &f" + g.ownerName + "&a's grave")
                + " &7(" + items + " stacks" + (g.xp > 0 ? ", " + g.xp + " xp" : "") + ")&7.");
        if (!own) {
            Player o = Bukkit.getPlayer(g.owner);
            if (o != null) Text.send(o, T + "&c" + p.getName() + " &7opened your grave.");
        }
    }

    private boolean mayOpen(Player p, Grave g) {
        return p.getUniqueId().equals(g.owner) || !locked(g) || p.hasPermission("zentials.graves.admin");
    }

    // ---------------------------------------------------------------- block protection

    private Grave at(Block b) {
        if (b.getType() != Material.PLAYER_HEAD) return null;
        return byBlock.get(key(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent e) {
        Grave g = at(e.getBlock());
        if (g == null) return;
        e.setCancelled(true);
        e.setDropItems(false);
        Player p = e.getPlayer();
        if (!mayOpen(p, g)) {
            plugin.sfx().play(p, "error");
            Text.send(p, T + "&cThis is &f" + g.ownerName + "&c's grave. It opens for everyone after the protection time ends.");
            return;
        }
        collect(p, g);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        Grave g = at(e.getClickedBlock());
        if (g == null) return;
        Player p = e.getPlayer();
        if (cfg.getBoolean("right-click-collect", false) && mayOpen(p, g)) {
            e.setCancelled(true);
            collect(p, g);
            return;
        }
        p.sendActionBar(Text.c("&c" + g.ownerName + "&7's grave &8| &7died " + date(g.time) + " &8| &eBreak it to open"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> at(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> at(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (at(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (at(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (at(e.getToBlock()) != null) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- teleport support

    private List<Grave> mine(UUID u) {
        List<Grave> l = new ArrayList<>();
        for (Grave g : graves.values()) if (g.owner.equals(u)) l.add(g);
        return l;
    }

    private Location spotFor(Grave g) {
        World w = Bukkit.getWorld(g.world);
        if (w == null) return null;
        // standing spot = on top of the head. Re-check that it is still safe (lava may have flowed in).
        if (w.isChunkLoaded(g.x >> 4, g.z >> 4)) {
            boolean ok = clearAir(w.getBlockAt(g.x, g.y + 1, g.z)) && clearAir(w.getBlockAt(g.x, g.y + 2, g.z));
            if (!ok) {
                Location alt = safeSpot(new Location(w, g.x, g.y, g.z));
                return new Location(w, alt.getBlockX() + 0.5, alt.getBlockY(), alt.getBlockZ() + 0.5);
            }
        }
        return new Location(w, g.x + 0.5, g.y + 1.0, g.z + 0.5);
    }

    /** Where /death should send this player: on top of their newest grave, or null if they have none. */
    public Location teleportSpot(UUID owner) {
        List<Grave> l = mine(owner);
        if (l.isEmpty()) return null;
        return spotFor(l.get(l.size() - 1));
    }

    private void goTo(Player p, Grave g) {
        Location spot = spotFor(g);
        if (spot == null) {
            Text.send(p, T + "&cThat world is not loaded.");
            return;
        }
        double fee = p.hasPermission("zentials.graves.admin") ? 0 : cfg.getDouble("teleport-cost", 0);
        var tp = plugin.teleport();
        if (tp != null) tp.goTo(p, spot, "Grave #" + g.id, fee);
        else p.teleportAsync(spot);
    }

    // ---------------------------------------------------------------- /graves

    private void openList(Player p) {
        List<Grave> mine = mine(p.getUniqueId());
        Gui gui = new Gui(Text.c("&c&lYOUR GRAVES &8" + mine.size()), 3);
        for (int i = 0; i < 27; i++) gui.set(i, Items.of(Material.GRAY_STAINED_GLASS_PANE, " "), e -> {
        });
        int slot = 9;
        for (int i = mine.size() - 1; i >= 0 && slot < 18; i--, slot++) {
            Grave g = mine.get(i);
            List<String> lore = new ArrayList<>();
            lore.add("&7Died: &f" + date(g.time));
            lore.add("&7Cause: &f" + g.cause);
            lore.add("&7Location: &f" + g.x + ", " + g.y + ", " + g.z + " &8(" + g.world + ")");
            lore.add("&7Items: &f" + g.itemCount() + (g.xp > 0 ? " &7+ &f" + g.xp + " xp" : ""));
            lore.add(locked(g) ? "&cOnly you can open it for now" : "&eAnyone can open it");
            lore.add("");
            double fee = cfg.getDouble("teleport-cost", 0);
            lore.add("&aClick to teleport" + (fee > 0 ? " &7(costs " + fee + ")" : ""));
            gui.set(slot, Items.head(Bukkit.getOfflinePlayer(g.owner), "&cGrave #" + g.id, lore.toArray(new String[0])), e -> {
                p.closeInventory();
                if (graves.containsKey(g.id)) goTo(p, g);
            });
        }
        if (mine.isEmpty()) gui.set(13, Items.of(Material.BARRIER, "&7You have no graves"));
        gui.set(22, Items.of(Material.OAK_DOOR, "&cClose"), e -> p.closeInventory());
        gui.open(p);
        plugin.sfx().play(p, "open");
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        boolean admin = s.hasPermission("zentials.graves.admin");
        if (a.length == 0) {
            if (s instanceof Player p) openList(p);
            else Text.send(s, T + "Players only. Admin: /graves list <player> | remove <id> | tp <id> | reload");
            return true;
        }
        if (!admin) {
            Text.send(s, T + "&cNo permission.");
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                reload();
                Text.send(s, T + "&aReloaded.");
            }
            case "list" -> {
                Set<Long> shown = new HashSet<>();
                for (Grave g : graves.values()) {
                    if (a.length > 1 && !g.ownerName.equalsIgnoreCase(a[1])) continue;
                    if (shown.size() >= 30) break;
                    shown.add(g.id);
                    Text.send(s, "&8#" + g.id + " &f" + g.ownerName + " &7" + g.world + " " + g.x + " " + g.y + " " + g.z + " &8| &7" + date(g.time));
                }
                if (shown.isEmpty()) Text.send(s, T + "No graves.");
            }
            case "remove" -> {
                Grave g = a.length > 1 ? find(a[1]) : null;
                if (g == null) Text.send(s, T + "Usage: /graves remove <id>");
                else {
                    dropAll(g);
                    Text.send(s, T + "&aGrave #" + g.id + " removed. Its items were dropped there.");
                }
            }
            case "tp" -> {
                Grave g = a.length > 1 ? find(a[1]) : null;
                if (!(s instanceof Player p) || g == null) Text.send(s, T + "Usage: /graves tp <id>");
                else goTo(p, g);
            }
            default -> Text.send(s, T + "/graves list [player] | remove <id> | tp <id> | reload");
        }
        return true;
    }

    private Grave find(String id) {
        try {
            return graves.get(Long.parseLong(id.replace("#", "")));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (s.hasPermission("zentials.graves.admin")) {
            if (a.length == 1) out.addAll(List.of("list", "remove", "tp", "reload"));
            if (a.length == 2 && (a[0].equalsIgnoreCase("remove") || a[0].equalsIgnoreCase("tp"))) {
                for (Grave g : graves.values()) out.add(String.valueOf(g.id));
            }
            if (a.length == 2 && a[0].equalsIgnoreCase("list")) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
