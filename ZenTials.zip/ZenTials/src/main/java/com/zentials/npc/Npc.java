package com.zentials.npc;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** One NPC (saved in plugins/ZenTials/modules/npc/data.yml). The entity itself is respawned from this data. */
final class Npc {
    final String id;
    String name;
    String skin;
    Location loc;
    boolean look = true;
    boolean nameVisible = true;
    final List<String> actions = new ArrayList<>();
    final Map<EquipmentSlot, ItemStack> gear = new EnumMap<>(EquipmentSlot.class);

    UUID entityId;

    Npc(String id) {
        this.id = id;
        this.name = id;
    }

    Entity entity() {
        if (entityId == null) return null;
        Entity e = org.bukkit.Bukkit.getEntity(entityId);
        return e != null && e.isValid() ? e : null;
    }
}
