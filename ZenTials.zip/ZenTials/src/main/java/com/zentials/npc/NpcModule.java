package com.zentials.npc;

import com.zentials.ZenTials;
import com.zentials.core.Papi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Citizens-style NPCs built on the vanilla Mannequin entity (a player-looking entity with a skin).
 * No packets, no extra plugin. NPCs are saved in npcs.yml and respawned when their chunk loads.
 *
 * /npc create <id> [skinName]    /npc remove <id>    /npc list    /npc info <id>
 * /npc name <id> <text>          /npc skin <id> <player>        /npc nametag <id> on|off
 * /npc look <id> on|off          /npc move <id>      /npc tp <id>   /npc near
 * /npc equip <id> hand|offhand|head|chest|legs|feet|clear
 * /npc action add <id> <message|player|console|sound|actionbar> <value...>
 * /npc action list|clear <id>     /npc action remove <id> <number>
 * Action text accepts &colors, {player}, and PlaceholderAPI placeholders.
 */
public final class NpcModule implements ZModule, Listener, TabExecutor {
    private static final String TAG = "&8[&bNPC&8]&7 ";
    private static final String PERM = "zentials.npc";

    private final ZenTials plugin;
    private final Map<String, Npc> npcs = new LinkedHashMap<>();
    private final Map<UUID, Npc> byEntity = new ConcurrentHashMap<>();
    private final Map<UUID, Long> clickCooldown = new ConcurrentHashMap<>();
    private final List<BukkitTask> tasks = new ArrayList<>();
    private NamespacedKey tagKey;
    private File file;
    private boolean leftClick;
    private double lookRange;
    private long cooldownMs;

    public NpcModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "npc";
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void enable() {
        tagKey = new NamespacedKey(plugin, "npc");
        file = new File(plugin.getDataFolder(), "npcs.yml");
        readConfig();
        load();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        PluginCommand c = plugin.getCommand("npc");
        if (c != null) {
            c.setExecutor(this);
            c.setTabCompleter(this);
        }
        // worlds are ready by now, but give chunks a moment
        tasks.add(Bukkit.getScheduler().runTaskLater(plugin, () -> {
            purgeStale();
            spawnAll();
        }, 40L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::spawnAll, 200L, 200L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::lookTick, 20L, 4L));
    }

    @Override
    public void disable() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
        despawnAll();
    }

    @Override
    public void reload() {
        despawnAll();
        readConfig();
        load();
        purgeStale();
        spawnAll();
    }

    private void readConfig() {
        var cfg = plugin.getConfig();
        leftClick = cfg.getBoolean("npc.left-click", true);
        lookRange = cfg.getDouble("npc.look-range", 6.0);
        cooldownMs = (long) (cfg.getDouble("npc.click-cooldown-seconds", 1.0) * 1000);
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        npcs.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("npcs");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Npc n = new Npc(id);
            n.name = s.getString("name", id);
            n.skin = s.getString("skin", "");
            n.loc = s.getLocation("loc");
            n.look = s.getBoolean("look", true);
            n.nameVisible = s.getBoolean("nametag", true);
            n.actions.addAll(s.getStringList("actions"));
            ConfigurationSection g = s.getConfigurationSection("gear");
            if (g != null) {
                for (String k : g.getKeys(false)) {
                    try {
                        EquipmentSlot slot = EquipmentSlot.valueOf(k.toUpperCase(Locale.ROOT));
                        ItemStack it = g.getItemStack(k);
                        if (it != null) n.gear.put(slot, it);
                    } catch (IllegalArgumentException ignored) {
                        // unknown slot name
                    }
                }
            }
            if (n.loc == null) {
                plugin.getLogger().warning("NPC '" + id + "' has no valid location, skipped.");
                continue;
            }
            npcs.put(id, n);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Npc n : npcs.values()) {
            String p = "npcs." + n.id + ".";
            y.set(p + "name", n.name);
            y.set(p + "skin", n.skin);
            y.set(p + "loc", n.loc);
            y.set(p + "look", n.look);
            y.set(p + "nametag", n.nameVisible);
            y.set(p + "actions", n.actions);
            for (Map.Entry<EquipmentSlot, ItemStack> e : n.gear.entrySet()) {
                y.set(p + "gear." + e.getKey().name().toLowerCase(Locale.ROOT), e.getValue());
            }
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save npcs.yml: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------- spawning

    private void purgeStale() {
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e.getPersistentDataContainer().has(tagKey, PersistentDataType.STRING)) e.remove();
            }
        }
        byEntity.clear();
        for (Npc n : npcs.values()) n.entityId = null;
    }

    private void spawnAll() {
        for (Npc n : npcs.values()) spawn(n);
    }

    private void despawnAll() {
        for (Npc n : npcs.values()) {
            Entity e = n.entity();
            if (e != null) e.remove();
            n.entityId = null;
        }
        byEntity.clear();
    }

    private boolean chunkLoaded(Location l) {
        World w = l.getWorld();
        return w != null && w.isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4);
    }

    private void spawn(Npc n) {
        if (n.entity() != null) return;
        if (n.loc == null || !chunkLoaded(n.loc)) return;
        World w = n.loc.getWorld();
        Mannequin m = w.spawn(n.loc, Mannequin.class, ent -> {
            ent.setPersistent(false);
            ent.setInvulnerable(true);
            ent.setImmovable(true);
            ent.setGravity(false);
            ent.setSilent(true);
            ent.setCollidable(false);
            ent.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, n.id);
        });
        n.entityId = m.getUniqueId();
        byEntity.put(n.entityId, n);
        apply(n);
    }

    /** Pushes name, skin, gear to the live entity. */
    private void apply(Npc n) {
        Entity e = n.entity();
        if (!(e instanceof Mannequin m)) return;
        m.customName(Text.c(n.name));
        m.setCustomNameVisible(n.nameVisible);
        m.setDescription(Component.empty());
        String skin = n.skin == null || n.skin.isBlank() ? null : n.skin;
        if (skin != null) {
            try {
                m.setProfile(ResolvableProfile.resolvableProfile().name(skin).build());
            } catch (Exception ex) {
                plugin.getLogger().warning("NPC '" + n.id + "': could not set skin '" + skin + "': " + ex.getMessage());
            }
        }
        var eq = m.getEquipment();
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HAND, EquipmentSlot.OFF_HAND, EquipmentSlot.HEAD,
                EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack it = n.gear.get(s);
            eq.setItem(s, it == null ? new ItemStack(org.bukkit.Material.AIR) : it);
        }
    }

    private void respawn(Npc n) {
        Entity e = n.entity();
        if (e != null) {
            byEntity.remove(e.getUniqueId());
            e.remove();
        }
        n.entityId = null;
        spawn(n);
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        Chunk c = e.getChunk();
        for (Npc n : npcs.values()) {
            if (n.loc.getWorld() == c.getWorld() && (n.loc.getBlockX() >> 4) == c.getX()
                    && (n.loc.getBlockZ() >> 4) == c.getZ()) {
                Bukkit.getScheduler().runTask(plugin, () -> spawn(n));
            }
        }
    }

    // ---------------------------------------------------------------- look at players

    private void lookTick() {
        if (lookRange <= 0) return;
        double r2 = lookRange * lookRange;
        for (Npc n : npcs.values()) {
            if (!n.look) continue;
            Entity e = n.entity();
            if (e == null) continue;
            Location el = e.getLocation();
            Player best = null;
            double bd = r2;
            for (Player p : el.getWorld().getPlayers()) {
                double d = p.getLocation().distanceSquared(el);
                if (d < bd) {
                    bd = d;
                    best = p;
                }
            }
            if (best == null) continue;
            Location pl = best.getEyeLocation();
            double dx = pl.getX() - el.getX();
            double dz = pl.getZ() - el.getZ();
            double dy = pl.getY() - (el.getY() + 1.62);
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            if (Math.abs(yaw - el.getYaw()) < 1f && Math.abs(pitch - el.getPitch()) < 1f) continue;
            e.setRotation(yaw, pitch);
            if (e instanceof LivingEntity le) le.setBodyYaw(yaw);
        }
    }

    // ---------------------------------------------------------------- clicking

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Npc n = byEntity.get(e.getRightClicked().getUniqueId());
        if (n == null) return;
        e.setCancelled(true);
        click(e.getPlayer(), n);
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        Npc n = byEntity.get(e.getEntity().getUniqueId());
        if (n == null) return;
        e.setCancelled(true);
        if (leftClick && e.getDamager() instanceof Player p) click(p, n);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (byEntity.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        clickCooldown.remove(e.getPlayer().getUniqueId());
    }

    private void click(Player p, Npc n) {
        long now = System.currentTimeMillis();
        Long last = clickCooldown.get(p.getUniqueId());
        if (last != null && now - last < cooldownMs) return;
        clickCooldown.put(p.getUniqueId(), now);
        for (String a : n.actions) runAction(p, a);
    }

    private void runAction(Player p, String raw) {
        int sp = raw.indexOf(' ');
        String type = (sp < 0 ? raw : raw.substring(0, sp)).toLowerCase(Locale.ROOT);
        String val = sp < 0 ? "" : raw.substring(sp + 1);
        val = val.replace("{player}", p.getName());
        val = Papi.set(p, val);
        switch (type) {
            case "message" -> p.sendMessage(Text.c(val));
            case "actionbar" -> p.sendActionBar(Text.c(val));
            case "player" -> p.performCommand(val.startsWith("/") ? val.substring(1) : val);
            case "console" -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), val.startsWith("/") ? val.substring(1) : val);
            case "sound" -> {
                try {
                    p.playSound(net.kyori.adventure.sound.Sound.sound(net.kyori.adventure.key.Key.key(val.trim()),
                            net.kyori.adventure.sound.Sound.Source.MASTER, 1f, 1f));
                } catch (Exception ignored) {
                    // bad sound key
                }
            }
            default -> plugin.getLogger().warning("Unknown NPC action type: " + type);
        }
    }

    // ---------------------------------------------------------------- commands

    private void msg(CommandSender s, String m) {
        Text.send(s, TAG + m);
    }

    private Npc find(CommandSender s, String id) {
        Npc n = npcs.get(id.toLowerCase(Locale.ROOT));
        if (n == null) msg(s, "&cNo NPC with id &f" + id + "&c. See &f/npc list");
        return n;
    }

    private static String join(String[] a, int from) {
        return String.join(" ", java.util.Arrays.copyOfRange(a, from, a.length));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission(PERM)) {
            msg(s, "&cYou don't have permission.");
            return true;
        }
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> create(s, a);
            case "remove", "delete" -> {
                if (a.length < 2) {
                    msg(s, "&cUsage: /npc remove <id>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                Entity e = n.entity();
                if (e != null) {
                    byEntity.remove(e.getUniqueId());
                    e.remove();
                }
                npcs.remove(n.id);
                save();
                msg(s, "Removed NPC &f" + n.id + "&7.");
            }
            case "list" -> {
                if (npcs.isEmpty()) {
                    msg(s, "No NPCs yet. &f/npc create <id> [skin]");
                    return true;
                }
                msg(s, "NPCs (&f" + npcs.size() + "&7):");
                for (Npc n : npcs.values()) {
                    Text.send(s, " &8- &f" + n.id + " &7" + n.name + " &8| &7" + (n.loc.getWorld() == null ? "?" : n.loc.getWorld().getName()) + " "
                            + n.loc.getBlockX() + "," + n.loc.getBlockY() + "," + n.loc.getBlockZ()
                            + (n.entity() == null ? " &c(not spawned)" : ""));
                }
            }
            case "info" -> {
                if (a.length < 2) {
                    msg(s, "&cUsage: /npc info <id>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                msg(s, "&f" + n.id + " &8| &7name: &f" + n.name + " &8| &7skin: &f" + (n.skin.isBlank() ? "default" : n.skin)
                        + " &8| &7look: &f" + n.look + " &8| &7nametag: &f" + n.nameVisible);
                int i = 1;
                for (String act : n.actions) Text.send(s, " &8" + (i++) + ". &7" + act);
            }
            case "name" -> {
                if (a.length < 3) {
                    msg(s, "&cUsage: /npc name <id> <text>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                n.name = join(a, 2);
                save();
                apply(n);
                msg(s, "Name set.");
            }
            case "skin" -> {
                if (a.length < 3) {
                    msg(s, "&cUsage: /npc skin <id> <playerName>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                n.skin = a[2];
                save();
                respawn(n);
                msg(s, "Skin set to &f" + a[2] + "&7.");
            }
            case "nametag" -> toggle(s, a, true);
            case "look" -> toggle(s, a, false);
            case "move", "movehere" -> {
                if (!(s instanceof Player p) || a.length < 2) {
                    msg(s, "&cUsage (in game): /npc move <id>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                n.loc = p.getLocation();
                save();
                respawn(n);
                msg(s, "Moved &f" + n.id + " &7to you.");
            }
            case "tp" -> {
                if (!(s instanceof Player p) || a.length < 2) {
                    msg(s, "&cUsage (in game): /npc tp <id>");
                    return true;
                }
                Npc n = find(s, a[1]);
                if (n == null) return true;
                p.teleportAsync(n.loc);
            }
            case "near" -> {
                if (!(s instanceof Player p)) return true;
                Npc best = null;
                double bd = Double.MAX_VALUE;
                for (Npc n : npcs.values()) {
                    if (n.loc.getWorld() != p.getWorld()) continue;
                    double d = n.loc.distanceSquared(p.getLocation());
                    if (d < bd) {
                        bd = d;
                        best = n;
                    }
                }
                if (best == null) msg(s, "No NPCs in this world.");
                else msg(s, "Nearest: &f" + best.id + " &7(" + (int) Math.sqrt(bd) + " blocks)");
            }
            case "equip" -> equip(s, a);
            case "action", "actions" -> action(s, a);
            case "reload" -> {
                reload();
                msg(s, "NPCs reloaded.");
            }
            default -> {
                msg(s, "Commands:");
                for (String l : new String[]{
                        "/npc create <id> [skin]", "/npc remove <id>", "/npc list", "/npc info <id>",
                        "/npc name <id> <text>", "/npc skin <id> <player>", "/npc nametag <id> on|off",
                        "/npc look <id> on|off", "/npc move <id>", "/npc tp <id>", "/npc near",
                        "/npc equip <id> hand|offhand|head|chest|legs|feet|clear",
                        "/npc action add <id> <message|actionbar|player|console|sound> <value>",
                        "/npc action list|clear <id>", "/npc action remove <id> <number>", "/npc reload"}) {
                    Text.send(s, " &8- &f" + l);
                }
            }
        }
        return true;
    }

    private void create(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            msg(s, "&cRun this in game, the NPC spawns where you stand.");
            return;
        }
        if (a.length < 2) {
            msg(s, "&cUsage: /npc create <id> [skinName]");
            return;
        }
        String id = a[1].toLowerCase(Locale.ROOT);
        if (!id.matches("[a-z0-9_\\-]{1,32}")) {
            msg(s, "&cThe id can only use letters, numbers, _ and - (max 32).");
            return;
        }
        if (npcs.containsKey(id)) {
            msg(s, "&cAn NPC with that id already exists.");
            return;
        }
        Npc n = new Npc(id);
        n.skin = a.length > 2 ? a[2] : "";
        n.loc = p.getLocation();
        npcs.put(id, n);
        save();
        spawn(n);
        msg(s, "Created NPC &f" + id + "&7. Add actions with &f/npc action add " + id + " message Hello {player}!");
    }

    private void toggle(CommandSender s, String[] a, boolean nametag) {
        if (a.length < 3) {
            msg(s, "&cUsage: /npc " + a[0].toLowerCase(Locale.ROOT) + " <id> on|off");
            return;
        }
        Npc n = find(s, a[1]);
        if (n == null) return;
        boolean on = a[2].equalsIgnoreCase("on") || a[2].equalsIgnoreCase("true");
        if (nametag) {
            n.nameVisible = on;
            apply(n);
        } else {
            n.look = on;
        }
        save();
        msg(s, "Set to &f" + (on ? "on" : "off") + "&7.");
    }

    private void equip(CommandSender s, String[] a) {
        if (!(s instanceof Player p) || a.length < 3) {
            msg(s, "&cUsage (in game): /npc equip <id> hand|offhand|head|chest|legs|feet|clear");
            return;
        }
        Npc n = find(s, a[1]);
        if (n == null) return;
        String w = a[2].toLowerCase(Locale.ROOT);
        if (w.equals("clear")) {
            n.gear.clear();
            save();
            apply(n);
            msg(s, "Equipment cleared.");
            return;
        }
        EquipmentSlot slot = switch (w) {
            case "hand", "mainhand" -> EquipmentSlot.HAND;
            case "offhand" -> EquipmentSlot.OFF_HAND;
            case "head", "helmet" -> EquipmentSlot.HEAD;
            case "chest", "chestplate" -> EquipmentSlot.CHEST;
            case "legs", "leggings" -> EquipmentSlot.LEGS;
            case "feet", "boots" -> EquipmentSlot.FEET;
            default -> null;
        };
        if (slot == null) {
            msg(s, "&cSlot must be hand, offhand, head, chest, legs, feet or clear.");
            return;
        }
        ItemStack held = p.getInventory().getItemInMainHand();
        if (held.getType().isAir()) n.gear.remove(slot);
        else n.gear.put(slot, held.asOne());
        save();
        apply(n);
        msg(s, held.getType().isAir() ? "Slot cleared." : "Equipped &f" + held.getType().name().toLowerCase(Locale.ROOT) + "&7.");
    }

    private void action(CommandSender s, String[] a) {
        if (a.length < 3) {
            msg(s, "&cUsage: /npc action add|list|clear|remove <id> ...");
            return;
        }
        String op = a[1].toLowerCase(Locale.ROOT);
        Npc n = find(s, a[2]);
        if (n == null) return;
        switch (op) {
            case "add" -> {
                if (a.length < 5) {
                    msg(s, "&cUsage: /npc action add <id> <message|actionbar|player|console|sound> <value...>");
                    return;
                }
                String type = a[3].toLowerCase(Locale.ROOT);
                if (!Stream.of("message", "actionbar", "player", "console", "sound").anyMatch(type::equals)) {
                    msg(s, "&cType must be message, actionbar, player, console or sound.");
                    return;
                }
                n.actions.add(type + " " + join(a, 4));
                save();
                msg(s, "Action added (&f" + n.actions.size() + "&7).");
            }
            case "list" -> {
                if (n.actions.isEmpty()) msg(s, "No actions.");
                int i = 1;
                for (String act : n.actions) Text.send(s, " &8" + (i++) + ". &7" + act);
            }
            case "clear" -> {
                n.actions.clear();
                save();
                msg(s, "Actions cleared.");
            }
            case "remove" -> {
                int i;
                try {
                    i = Integer.parseInt(a.length > 3 ? a[3] : "0");
                } catch (NumberFormatException ex) {
                    i = 0;
                }
                if (i < 1 || i > n.actions.size()) {
                    msg(s, "&cGive the action number, see /npc action list " + n.id);
                    return;
                }
                n.actions.remove(i - 1);
                save();
                msg(s, "Action removed.");
            }
            default -> msg(s, "&cUse add, list, clear or remove.");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission(PERM)) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("create", "remove", "list", "info", "name", "skin", "nametag", "look", "move", "tp",
                    "near", "equip", "action", "reload"));
        } else if (a.length == 2 && a[0].equalsIgnoreCase("action")) {
            out.addAll(List.of("add", "list", "clear", "remove"));
        } else if (a.length == 2 && !a[0].equalsIgnoreCase("create") && !a[0].equalsIgnoreCase("list")) {
            out.addAll(npcs.keySet());
        } else if (a.length == 3 && a[0].equalsIgnoreCase("action")) {
            out.addAll(npcs.keySet());
        } else if (a.length == 3 && (a[0].equalsIgnoreCase("look") || a[0].equalsIgnoreCase("nametag"))) {
            out.addAll(List.of("on", "off"));
        } else if (a.length == 3 && a[0].equalsIgnoreCase("equip")) {
            out.addAll(List.of("hand", "offhand", "head", "chest", "legs", "feet", "clear"));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("action") && a[1].equalsIgnoreCase("add")) {
            out.addAll(List.of("message", "actionbar", "player", "console", "sound"));
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
