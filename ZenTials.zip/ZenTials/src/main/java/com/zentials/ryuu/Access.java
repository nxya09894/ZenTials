package com.zentials.ryuu;

import com.zentials.core.Text;
import net.kyori.adventure.title.Title;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Reading properties (a.b), indexing (a[i]) and calling methods (a.b()) on script values. */
final class Access {
    private static final Object NOPE = new Object();

    private Access() {
    }

    // ---------------------------------------------------------------- properties

    static Object get(Object t, String n) {
        if (t == null) throw new RyuuException(0, "Cannot read '" + n + "' of nothing (it is empty)");
        if (t instanceof Map<?, ?> m) return m.get(n);
        Object v = NOPE;
        if (t instanceof Player p) v = playerProp(p, n);
        else if (t instanceof OfflinePlayer op) v = offlineProp(op, n);
        else if (t instanceof Location l) v = locProp(l, n);
        else if (t instanceof Block b) v = blockProp(b, n);
        else if (t instanceof World w) v = n.equals("name") ? w.getName() : NOPE;
        else if (t instanceof ItemStack i) v = itemProp(i, n);
        else if (t instanceof Entity e) v = entityProp(e, n);
        else if (t instanceof List<?> l) v = listProp(l, n);
        else if (t instanceof String s) v = stringProp(s, n);
        if (v != NOPE) return v;
        return reflectGet(t, n);
    }

    private static Object playerProp(Player p, String n) {
        return switch (n) {
            case "name" -> p.getName();
            case "uuid" -> p.getUniqueId().toString();
            case "world" -> p.getWorld().getName();
            case "x" -> p.getLocation().getX();
            case "y" -> p.getLocation().getY();
            case "z" -> p.getLocation().getZ();
            case "bx" -> (double) p.getLocation().getBlockX();
            case "by" -> (double) p.getLocation().getBlockY();
            case "bz" -> (double) p.getLocation().getBlockZ();
            case "loc", "location" -> p.getLocation();
            case "health" -> p.getHealth();
            case "food" -> (double) p.getFoodLevel();
            case "level" -> (double) p.getLevel();
            case "gamemode" -> p.getGameMode().name();
            case "op" -> p.isOp();
            case "online" -> p.isOnline();
            case "ping" -> (double) p.getPing();
            case "hand" -> p.getInventory().getItemInMainHand();
            case "handtype" -> p.getInventory().getItemInMainHand().getType().name();
            case "handamount" -> {
                ItemStack h = p.getInventory().getItemInMainHand();
                yield h.getType().isAir() ? 0.0 : (double) h.getAmount();
            }
            case "block" -> p.getLocation().getBlock();
            default -> NOPE;
        };
    }

    private static Object offlineProp(OfflinePlayer p, String n) {
        return switch (n) {
            case "name" -> p.getName() == null ? p.getUniqueId().toString() : p.getName();
            case "uuid" -> p.getUniqueId().toString();
            case "online" -> p.isOnline();
            default -> NOPE;
        };
    }

    private static Object locProp(Location l, String n) {
        return switch (n) {
            case "x" -> l.getX();
            case "y" -> l.getY();
            case "z" -> l.getZ();
            case "bx" -> (double) l.getBlockX();
            case "by" -> (double) l.getBlockY();
            case "bz" -> (double) l.getBlockZ();
            case "yaw" -> (double) l.getYaw();
            case "pitch" -> (double) l.getPitch();
            case "world" -> l.getWorld() == null ? null : l.getWorld().getName();
            case "block" -> l.getBlock();
            default -> NOPE;
        };
    }

    private static Object blockProp(Block b, String n) {
        return switch (n) {
            case "type" -> b.getType().name();
            case "x" -> (double) b.getX();
            case "y" -> (double) b.getY();
            case "z" -> (double) b.getZ();
            case "world" -> b.getWorld().getName();
            case "loc", "location" -> b.getLocation();
            default -> NOPE;
        };
    }

    private static Object itemProp(ItemStack i, String n) {
        return switch (n) {
            case "type" -> i.getType().name();
            case "amount" -> (double) i.getAmount();
            default -> NOPE;
        };
    }

    private static Object entityProp(Entity e, String n) {
        return switch (n) {
            case "type" -> e.getType().name();
            case "name" -> e.getName();
            case "uuid" -> e.getUniqueId().toString();
            case "world" -> e.getWorld().getName();
            case "x" -> e.getLocation().getX();
            case "y" -> e.getLocation().getY();
            case "z" -> e.getLocation().getZ();
            case "loc", "location" -> e.getLocation();
            default -> NOPE;
        };
    }

    private static Object listProp(List<?> l, String n) {
        return switch (n) {
            case "size", "length" -> (double) l.size();
            case "first" -> l.isEmpty() ? null : l.get(0);
            case "last" -> l.isEmpty() ? null : l.get(l.size() - 1);
            case "empty" -> l.isEmpty();
            default -> NOPE;
        };
    }

    private static Object stringProp(String s, String n) {
        return switch (n) {
            case "length" -> (double) s.length();
            case "upper" -> s.toUpperCase(Locale.ROOT);
            case "lower" -> s.toLowerCase(Locale.ROOT);
            default -> NOPE;
        };
    }

    private static Object reflectGet(Object t, String n) {
        String cap = Character.toUpperCase(n.charAt(0)) + n.substring(1);
        for (String name : new String[]{"get" + cap, "is" + cap, "has" + cap, n}) {
            try {
                Method m = t.getClass().getMethod(name);
                if (m.getParameterCount() != 0) continue;
                return normalize(m.invoke(t));
            } catch (NoSuchMethodException ignored) {
                // try the next name
            } catch (ReflectiveOperationException e) {
                throw new RyuuException(0, "Cannot read '" + n + "': " + e.getMessage());
            }
        }
        throw new RyuuException(0, "Unknown property '" + n + "' on " + Values.typeName(t));
    }

    // ---------------------------------------------------------------- indexing

    @SuppressWarnings("unchecked")
    static Object index(Object t, Object i) {
        if (t == null) return null;
        if (t instanceof List<?> l) {
            int k = Values.intv(i);
            return k >= 0 && k < l.size() ? l.get(k) : null;
        }
        if (t instanceof Map<?, ?> m) return ((Map<Object, Object>) m).get(Values.str(i));
        if (t instanceof String s) {
            int k = Values.intv(i);
            return k >= 0 && k < s.length() ? String.valueOf(s.charAt(k)) : null;
        }
        throw new RyuuException(0, "Cannot use [ ] on " + Values.typeName(t));
    }

    // ---------------------------------------------------------------- methods

    static Object call(Object t, String name, List<Object> a, Ctx c) {
        if (t == null) throw new RyuuException(0, "Cannot call '" + name + "' on nothing (it is empty)");
        if (t instanceof Libs.Lib lib) return lib.call(name, a, c);
        String m = name.toLowerCase(Locale.ROOT);
        Object v = NOPE;
        if (t instanceof Player p) v = playerCall(p, m, a);
        if (v == NOPE && t instanceof CommandSender cs && (m.equals("send") || m.equals("message"))) {
            cs.sendMessage(Text.c(Values.str(arg(a, 0))));
            v = null;
        }
        if (v == NOPE && t instanceof Location l) v = locCall(l, m, a);
        if (v == NOPE && t instanceof List<?> l) v = listCall(l, m, a);
        if (v == NOPE && t instanceof String s) v = stringCall(s, m, a);
        if (v == NOPE && t instanceof Map<?, ?> mp) v = mapCall(mp, m, a);
        if (v != NOPE) return v;
        return reflectCall(t, name, a);
    }

    private static Object arg(List<Object> a, int i) {
        return i < a.size() ? a.get(i) : null;
    }

    private static Object playerCall(Player p, String m, List<Object> a) {
        switch (m) {
            case "send", "message" -> {
                p.sendMessage(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "title" -> {
                p.showTitle(Title.title(Text.c(Values.str(arg(a, 0))), Text.c(Values.str(arg(a, 1)))));
                return null;
            }
            case "actionbar" -> {
                p.sendActionBar(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "teleport", "tp" -> {
                if (!(arg(a, 0) instanceof Location l)) throw new RyuuException(0, "teleport needs a location");
                p.teleport(l);
                return null;
            }
            case "has" -> {
                return p.hasPermission(Values.str(arg(a, 0)));
            }
            case "give" -> {
                Material mat = Material.matchMaterial(Values.str(arg(a, 0)));
                if (mat == null) throw new RyuuException(0, "Unknown material '" + Values.str(arg(a, 0)) + "'");
                int amt = a.size() > 1 ? Values.intv(a.get(1)) : 1;
                var left = p.getInventory().addItem(new ItemStack(mat, Math.max(1, amt)));
                for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
                return null;
            }
            case "takehand" -> {
                ItemStack h = p.getInventory().getItemInMainHand();
                int n = Values.intv(arg(a, 0));
                if (h.getType().isAir()) return false;
                if (n >= h.getAmount()) p.getInventory().setItemInMainHand(null);
                else h.setAmount(h.getAmount() - n);
                return true;
            }
            case "sfx" -> {
                RyuuModule.plugin().sfx().play(p, Values.str(arg(a, 0)));
                return null;
            }
            case "sound" -> {
                float vol = a.size() > 1 ? (float) Values.num(a.get(1)) : 1f;
                float pitch = a.size() > 2 ? (float) Values.num(a.get(2)) : 1f;
                p.playSound(p.getLocation(), Values.str(arg(a, 0)), vol, pitch);
                return null;
            }
            case "heal" -> {
                var attr = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
                p.setHealth(attr == null ? 20.0 : attr.getValue());
                return null;
            }
            case "feed" -> {
                p.setFoodLevel(20);
                p.setSaturation(20f);
                return null;
            }
            case "kick" -> {
                p.kick(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "command" -> {
                return p.performCommand(Values.str(arg(a, 0)));
            }
            case "gamemode" -> {
                try {
                    p.setGameMode(GameMode.valueOf(Values.str(arg(a, 0)).toUpperCase(Locale.ROOT)));
                } catch (IllegalArgumentException e) {
                    throw new RyuuException(0, "Unknown gamemode '" + Values.str(arg(a, 0)) + "'");
                }
                return null;
            }
            case "closeinv" -> {
                p.closeInventory();
                return null;
            }
            default -> {
                return NOPE;
            }
        }
    }

    private static Object locCall(Location l, String m, List<Object> a) {
        switch (m) {
            case "add" -> {
                return l.clone().add(Values.num(arg(a, 0)), Values.num(arg(a, 1)), Values.num(arg(a, 2)));
            }
            case "distance" -> {
                if (!(arg(a, 0) instanceof Location o)) throw new RyuuException(0, "distance needs a location");
                if (l.getWorld() == null || !l.getWorld().equals(o.getWorld())) return Double.MAX_VALUE;
                return l.distance(o);
            }
            case "block" -> {
                return l.getBlock();
            }
            default -> {
                return NOPE;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Object listCall(List<?> l, String m, List<Object> a) {
        List<Object> list = (List<Object>) l;
        switch (m) {
            case "add" -> {
                list.add(arg(a, 0));
                return true;
            }
            case "remove" -> {
                for (int i = 0; i < list.size(); i++) {
                    if (Values.eq(list.get(i), arg(a, 0))) {
                        list.remove(i);
                        return true;
                    }
                }
                return false;
            }
            case "contains" -> {
                for (Object o : list) if (Values.eq(o, arg(a, 0))) return true;
                return false;
            }
            case "size" -> {
                return (double) list.size();
            }
            case "get" -> {
                return index(list, arg(a, 0));
            }
            case "join" -> {
                StringBuilder sb = new StringBuilder();
                String sep = a.isEmpty() ? ", " : Values.str(a.get(0));
                for (int i = 0; i < list.size(); i++) {
                    if (i > 0) sb.append(sep);
                    sb.append(Values.str(list.get(i)));
                }
                return sb.toString();
            }
            case "clear" -> {
                list.clear();
                return null;
            }
            case "indexof" -> {
                for (int i = 0; i < list.size(); i++) if (Values.eq(list.get(i), arg(a, 0))) return (double) i;
                return -1.0;
            }
            case "copy" -> {
                return new ArrayList<>(list);
            }
            case "isempty" -> {
                return list.isEmpty();
            }
            default -> {
                return NOPE;
            }
        }
    }

    private static Object stringCall(String s, String m, List<Object> a) {
        switch (m) {
            case "upper" -> {
                return s.toUpperCase(Locale.ROOT);
            }
            case "lower" -> {
                return s.toLowerCase(Locale.ROOT);
            }
            case "length" -> {
                return (double) s.length();
            }
            case "contains" -> {
                return s.contains(Values.str(arg(a, 0)));
            }
            case "startswith" -> {
                return s.startsWith(Values.str(arg(a, 0)));
            }
            case "endswith" -> {
                return s.endsWith(Values.str(arg(a, 0)));
            }
            case "replace" -> {
                return s.replace(Values.str(arg(a, 0)), Values.str(arg(a, 1)));
            }
            case "split" -> {
                List<Object> out = new ArrayList<>();
                for (String part : s.split(Pattern.quote(Values.str(arg(a, 0))))) out.add(part);
                return out;
            }
            case "trim" -> {
                return s.trim();
            }
            case "substring" -> {
                int from = Math.max(0, Math.min(s.length(), Values.intv(arg(a, 0))));
                int to = a.size() > 1 ? Math.max(from, Math.min(s.length(), Values.intv(a.get(1)))) : s.length();
                return s.substring(from, to);
            }
            case "isnumber" -> {
                try {
                    Double.parseDouble(s.trim());
                    return true;
                } catch (NumberFormatException e) {
                    return false;
                }
            }
            default -> {
                return NOPE;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Object mapCall(Map<?, ?> mp, String m, List<Object> a) {
        Map<Object, Object> map = (Map<Object, Object>) mp;
        switch (m) {
            case "get" -> {
                return map.get(Values.str(arg(a, 0)));
            }
            case "put", "set" -> {
                map.put(Values.str(arg(a, 0)), arg(a, 1));
                return null;
            }
            case "has" -> {
                return map.containsKey(Values.str(arg(a, 0)));
            }
            case "remove" -> {
                return map.remove(Values.str(arg(a, 0)));
            }
            case "keys" -> {
                return new ArrayList<>(map.keySet());
            }
            case "values" -> {
                return new ArrayList<>(map.values());
            }
            case "size" -> {
                return (double) map.size();
            }
            default -> {
                return NOPE;
            }
        }
    }

    // ---------------------------------------------------------------- reflection fallback

    private static Object reflectCall(Object t, String name, List<Object> args) {
        for (Method m : t.getClass().getMethods()) {
            if (!m.getName().equalsIgnoreCase(name) || m.getParameterCount() != args.size()) continue;
            Object[] conv = coerce(m.getParameterTypes(), args);
            if (conv == null) continue;
            try {
                try {
                    m.setAccessible(true);
                } catch (RuntimeException ignored) {
                    // not needed for public API methods
                }
                return normalize(m.invoke(t, conv));
            } catch (InvocationTargetException e) {
                Throwable cause = e.getCause() == null ? e : e.getCause();
                throw new RyuuException(0, name + "() failed: " + cause);
            } catch (IllegalAccessException e) {
                throw new RyuuException(0, name + "() is not accessible");
            }
        }
        throw new RyuuException(0, "Unknown method '" + name + "' with " + args.size()
                + " argument(s) on " + Values.typeName(t));
    }

    private static Object[] coerce(Class<?>[] types, List<Object> args) {
        Object[] out = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            Class<?> ty = types[i];
            Object a = args.get(i);
            if (a == null) {
                if (ty.isPrimitive()) return null;
                out[i] = null;
            } else if (ty == int.class || ty == Integer.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.intValue();
            } else if (ty == long.class || ty == Long.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.longValue();
            } else if (ty == double.class || ty == Double.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.doubleValue();
            } else if (ty == float.class || ty == Float.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.floatValue();
            } else if (ty == boolean.class || ty == Boolean.class) {
                if (!(a instanceof Boolean b)) return null;
                out[i] = b;
            } else if (ty == String.class) {
                out[i] = Values.str(a);
            } else if (ty == Material.class && a instanceof String s) {
                Material mat = Material.matchMaterial(s);
                if (mat == null) return null;
                out[i] = mat;
            } else if (ty.isInstance(a)) {
                out[i] = a;
            } else {
                return null;
            }
        }
        return out;
    }

    private static Object normalize(Object r) {
        if (r instanceof Number n && !(r instanceof Double)) return n.doubleValue();
        return r;
    }
}
