package com.zentials.ryuu;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns the text of a .ryu file into a Script. */
final class Parser {

    record Line(int no, int indent, String text, List<Line> kids) {
    }

    private interface LVal {
        Object get(Ctx c);

        void set(Ctx c, Object v);

        void del(Ctx c);
    }

    private static final Pattern LV = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)(?:\\[(.+)\\])?$");
    private static final Pattern IDENT = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");
    private static final Pattern META =
            Pattern.compile("^(permission message|permission|aliases|description|usage|cooldown|player-only|executable by)\\s*:\\s*(.*)$");
    private static final Pattern ARG =
            Pattern.compile("^([<\\[])([A-Za-z_][A-Za-z0-9_]*)(?::([A-Za-z]+))?(\\.\\.\\.)?([>\\]])$");
    private static final Pattern FUNC =
            Pattern.compile("^function\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\((.*)\\)\\s*:$");
    private static final Set<String> BLOCK_WORDS = Set.of("if", "loop", "repeat", "while", "later", "open", "ask", "slot");

    private final Script script;

    Parser(String fileName) {
        this.script = new Script(fileName);
    }

    Script parse(String content) {
        if (content.startsWith("\uFEFF")) content = content.substring(1);
        for (Line l : tree(content)) top(l);
        return script;
    }

    // ---------------------------------------------------------------- text helpers

    private static RyuuException err(Line l, String msg) {
        return new RyuuException(l.no(), msg);
    }

    static List<Line> tree(String content) {
        List<Line> root = new ArrayList<>();
        Deque<Line> stack = new ArrayDeque<>();
        String[] raw = content.split("\r?\n", -1);
        for (int i = 0; i < raw.length; i++) {
            String s = stripComment(raw[i].replace("\t", "    "));
            if (s.isBlank()) continue;
            int indent = 0;
            while (indent < s.length() && s.charAt(indent) == ' ') indent++;
            Line l = new Line(i + 1, indent, s.trim(), new ArrayList<>());
            while (!stack.isEmpty() && stack.peek().indent() >= indent) stack.pop();
            if (stack.isEmpty()) root.add(l);
            else stack.peek().kids().add(l);
            stack.push(l);
        }
        return root;
    }

    static String stripComment(String s) {
        boolean inQ = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
            } else if (c == '"' || c == '\'') {
                inQ = true;
                q = c;
            } else if (c == '#') {
                return s.substring(0, i);
            }
        }
        return s;
    }

    static String firstWord(String s) {
        int i = 0;
        while (i < s.length() && !Character.isWhitespace(s.charAt(i))) i++;
        return s.substring(0, i);
    }

    /** Position of the word kw (surrounded by spaces) outside quotes and brackets, or -1. */
    static int findKw(String s, String kw, boolean last) {
        int found = -1;
        boolean inQ = false;
        char q = 0;
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (c == '"' || c == '\'') {
                inQ = true;
                q = c;
            } else if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
            } else if (depth == 0 && c == ' ' && s.startsWith(kw, i + 1)) {
                int end = i + 1 + kw.length();
                if (end == s.length() || s.charAt(end) == ' ') {
                    found = i + 1;
                    if (!last) return found;
                }
            }
        }
        return found;
    }

    /** The line without its trailing colon. */
    private static String header(Line l) {
        String t = l.text();
        if (!t.endsWith(":")) throw err(l, "This line must end with ':'");
        return t.substring(0, t.length() - 1).trim();
    }

    private static String colonRest(Line l, String rest) {
        if (!rest.endsWith(":")) throw err(l, "This line must end with ':'");
        return rest.substring(0, rest.length() - 1).trim();
    }

    private static String unquote(String s) {
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    private static long ticksOf(String unit, Line l) {
        return switch (unit.toLowerCase(Locale.ROOT)) {
            case "tick", "ticks" -> 1;
            case "second", "seconds" -> 20;
            case "minute", "minutes" -> 1200;
            case "hour", "hours" -> 72000;
            default -> throw err(l, "Unknown time unit '" + unit + "'. Use ticks, seconds, minutes or hours");
        };
    }

    private static Expr expr(String text, Line l) {
        if (text.isBlank()) throw err(l, "Something is missing here");
        return ExprParser.compile(text, l.no());
    }

    // ---------------------------------------------------------------- top level

    /** First word of a block line, without a trailing colon: "options:" and "options" are the same block. */
    static String blockWord(String text) {
        int i = 0;
        while (i < text.length() && (Character.isLetterOrDigit(text.charAt(i)) || text.charAt(i) == '_' || text.charAt(i) == '-')) i++;
        return text.substring(0, i);
    }

    private void top(Line l) {
        String w = blockWord(l.text()).toLowerCase(Locale.ROOT);
        switch (w) {
            case "options" -> options(l);
            case "command" -> command(l);
            case "on" -> on(l);
            case "every" -> every(l);
            case "function" -> function(l);
            default -> throw err(l, "Unknown block '" + w + "'. A top-level line must start with: options, command, on, every or function"
                    + " (if this line belongs inside one of them, check its indentation)");
        }
    }

    private void options(Line l) {
        // Skript writes "options:", we also accept plain "options"
        String ot = l.text().endsWith(":") ? l.text().substring(0, l.text().length() - 1).trim() : l.text();
        if (!ot.equalsIgnoreCase("options")) throw err(l, "Write it like:  options:");
        Ctx c = new Ctx(script);
        for (Line k : l.kids()) {
            int i = k.text().indexOf(':');
            if (i <= 0) throw err(k, "Write it like:  name: value");
            String key = k.text().substring(0, i).trim();
            if (!IDENT.matcher(key).matches()) {
                throw err(k, "Option names can only use letters, numbers and _ (got '" + key + "')");
            }
            Expr e = expr(k.text().substring(i + 1).trim(), k);
            try {
                script.opt.put(key, e.eval(c));
            } catch (RyuuException ex) {
                throw new RyuuException(k.no(), ex.getMessage());
            }
        }
    }

    private void command(Line l) {
        String h = header(l);
        String[] parts = h.split("\\s+");
        if (parts.length < 2 || !parts[1].startsWith("/")) {
            throw err(l, "Write it like:  command /name <required> [optional]:");
        }
        Script.CommandDef d = new Script.CommandDef();
        d.name = parts[1].substring(1).toLowerCase(Locale.ROOT);
        if (!d.name.matches("[a-z0-9_\\-]+")) throw err(l, "Bad command name '" + parts[1] + "'");
        d.line = l.no();
        for (int i = 2; i < parts.length; i++) {
            Matcher m = ARG.matcher(parts[i]);
            if (!m.matches()) {
                throw err(l, "Bad argument '" + parts[i] + "'. Use <name> or [name], optionally name:type");
            }
            boolean req = m.group(1).equals("<");
            if (req != m.group(5).equals(">")) throw err(l, "Mismatched brackets in '" + parts[i] + "'");
            String type = m.group(3) == null ? "text" : m.group(3).toLowerCase(Locale.ROOT);
            if (!Set.of("text", "word", "number", "player").contains(type)) {
                throw err(l, "Unknown argument type '" + type + "'. Use text, word, number or player");
            }
            d.args.add(new Script.ArgSpec(m.group(2), req, type, m.group(4) != null));
        }
        List<Line> code = new ArrayList<>();
        for (Line k : l.kids()) {
            Matcher m = META.matcher(k.text());
            if (m.matches()) meta(d, m.group(1), m.group(2).trim(), k);
            else if (k.text().equals("trigger:")) code.addAll(k.kids()); // Skript style: code under "trigger:"
            else code.add(k);
        }
        d.body = block(code);
        script.commands.add(d);
    }

    private void meta(Script.CommandDef d, String key, String val, Line k) {
        switch (key) {
            case "permission" -> d.permission = unquote(val);
            case "description" -> d.description = unquote(val);
            case "usage" -> d.usage = unquote(val);
            case "player-only" -> d.playerOnly = val.equalsIgnoreCase("true");
            case "executable by" -> d.playerOnly = val.toLowerCase(Locale.ROOT).startsWith("player");
            case "permission message" -> {
                // accepted so Skript-style commands load; the plugin uses its own message
            }
            case "cooldown" -> {
                try {
                    d.cooldownSeconds = Integer.parseInt(val);
                } catch (NumberFormatException e) {
                    throw err(k, "cooldown must be a whole number of seconds");
                }
            }
            default -> {
                for (String a : val.split(",")) {
                    String n = a.trim().toLowerCase(Locale.ROOT);
                    if (!n.isEmpty()) d.aliases.add(n.startsWith("/") ? n.substring(1) : n);
                }
            }
        }
    }

    /** Skript-style names for events ("on player join", "on block break", ...). */
    private static final Map<String, String> EVENT_ALIASES = Map.ofEntries(
            Map.entry("player join", "join"), Map.entry("player quit", "quit"), Map.entry("player leave", "quit"),
            Map.entry("leave", "quit"), Map.entry("disconnect", "quit"), Map.entry("player respawn", "respawn"),
            Map.entry("block break", "break"), Map.entry("mine", "break"), Map.entry("block place", "place"),
            Map.entry("player death", "death"), Map.entry("entity death", "kill"), Map.entry("damage of entity", "damage-entity"),
            Map.entry("player move", "move"), Map.entry("player teleport", "teleport"), Map.entry("player drop", "drop"),
            Map.entry("item drop", "drop"), Map.entry("item pickup", "pickup"), Map.entry("player interact", "interact"),
            Map.entry("right click", "interact"), Map.entry("click", "interact"), Map.entry("entity explode", "explode"),
            Map.entry("world change", "world-change"), Map.entry("interact entity", "interact-entity"),
            Map.entry("damage entity", "damage-entity"), Map.entry("block explode", "block-explode"),
            Map.entry("player command", "command"), Map.entry("start", "load"), Map.entry("server load", "load"),
            Map.entry("stop", "unload"), Map.entry("server unload", "unload"));

    private void on(Line l) {
        String h = header(l);
        if (!blockWord(h).equalsIgnoreCase("on")) throw err(l, "Write it like:  on join:");
        String ev = h.substring(2).trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        ev = EVENT_ALIASES.getOrDefault(ev, ev);
        if (ev.equals("load")) {
            script.onLoad.add(block(l.kids()));
            return;
        }
        if (ev.equals("unload")) {
            script.onUnload.add(block(l.kids()));
            return;
        }
        if (!EventDefs.ALL.containsKey(ev)) {
            throw err(l, "Unknown event '" + ev + "'. Known events: load, unload, "
                    + String.join(", ", EventDefs.ALL.keySet()));
        }
        Script.EventDef d = new Script.EventDef();
        d.event = ev;
        d.line = l.no();
        d.body = block(l.kids());
        script.events.add(d);
    }

    private void every(Line l) {
        String rest = header(l).substring(5).trim();
        int sp = rest.lastIndexOf(' ');
        if (sp < 0) throw err(l, "Write it like:  every 5 seconds:");
        Script.TimerDef d = new Script.TimerDef();
        d.period = expr(rest.substring(0, sp).trim(), l);
        d.unitTicks = ticksOf(rest.substring(sp + 1).trim(), l);
        d.line = l.no();
        d.body = block(l.kids());
        script.timers.add(d);
    }

    private void function(Line l) {
        Matcher m = FUNC.matcher(l.text());
        if (!m.matches()) throw err(l, "Write it like:  function name(a, b):");
        Script.FuncDef f = new Script.FuncDef();
        f.name = m.group(1);
        f.script = script;
        f.line = l.no();
        String ps = m.group(2).trim();
        if (!ps.isEmpty()) {
            for (String p : ps.split(",")) {
                String n = p.trim();
                if (!IDENT.matcher(n).matches()) throw err(l, "Bad parameter name '" + n + "'");
                f.params.add(n);
            }
        }
        if (script.functions.containsKey(f.name)) throw err(l, "Function '" + f.name + "' is already defined in this file");
        f.body = block(l.kids());
        script.functions.put(f.name, f);
    }

    // ---------------------------------------------------------------- blocks and statements

    private Stmt[] block(List<Line> lines) {
        List<Stmt> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            String w = firstWord(l.text()).toLowerCase(Locale.ROOT);
            if (w.equals("if")) {
                List<Expr> conds = new ArrayList<>();
                List<Stmt[]> bodies = new ArrayList<>();
                Stmt[] elseBody = null;
                conds.add(expr(header(l).substring(2).trim(), l));
                bodies.add(block(l.kids()));
                while (i + 1 < lines.size()) {
                    Line n = lines.get(i + 1);
                    String t = n.text();
                    if (t.startsWith("else if ")) {
                        conds.add(expr(header(n).substring(7).trim(), n));
                        bodies.add(block(n.kids()));
                        i++;
                    } else if (t.replace(" ", "").equals("else:")) {
                        elseBody = block(n.kids());
                        i++;
                        break;
                    } else {
                        break;
                    }
                }
                final Stmt[] eb = elseBody;
                Stmt ifs = c -> {
                    for (int k = 0; k < conds.size(); k++) {
                        if (Values.truthy(conds.get(k).eval(c))) return Run.block(bodies.get(k), c);
                    }
                    return eb == null ? Run.NORMAL : Run.block(eb, c);
                };
                out.add(located(l.no(), ifs));
            } else if (w.equals("else")) {
                throw err(l, "'else' needs an 'if' right above it");
            } else {
                out.add(stmt(l));
            }
        }
        return out.toArray(new Stmt[0]);
    }

    private static Stmt located(int line, Stmt s) {
        return c -> {
            try {
                return s.run(c);
            } catch (RyuuException e) {
                if (e.line() > 0) throw e;
                throw new RyuuException(line, e.getMessage());
            } catch (RuntimeException e) {
                throw new RyuuException(line, e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        };
    }

    private Stmt stmt(Line l) {
        String t = l.text();
        String w = firstWord(t);
        String lw = w.toLowerCase(Locale.ROOT);
        String rest = t.substring(w.length()).trim();
        if (!l.kids().isEmpty() && !BLOCK_WORDS.contains(lw)) {
            throw err(l, "Lines indented under this line are not allowed here");
        }
        Stmt s;
        switch (lw) {
            case "set" -> s = set(l, rest);
            case "add" -> s = addRemove(l, rest, true);
            case "remove" -> s = addRemove(l, rest, false);
            case "delete" -> s = delete(l, rest);
            case "loop" -> s = loop(l, rest);
            case "repeat" -> s = repeat(l, rest);
            case "while" -> s = whileStmt(l, rest);
            case "break" -> s = c -> Run.BREAK;
            case "continue" -> s = c -> Run.CONTINUE;
            case "stop" -> s = c -> Run.STOP;
            case "cancel" -> s = c -> {
                c.cancel = true;
                return Run.NORMAL;
            };
            case "return" -> s = returnStmt(l, rest);
            case "send", "message" -> s = send(l, rest);
            case "broadcast" -> s = broadcast(l, rest);
            case "console" -> s = console(l, rest);
            case "log" -> s = log(l, rest);
            case "later" -> s = later(l, rest);
            case "open" -> s = openGui(l, rest);
            case "ask" -> s = ask(l, rest);
            case "slot" -> s = slot(l, rest);
            case "fill" -> s = fill(l, rest);
            default -> {
                Expr e = expr(t, l);
                s = c -> {
                    e.eval(c);
                    return Run.NORMAL;
                };
            }
        }
        return located(l.no(), s);
    }

    // ---------------------------------------------------------------- variables

    private LVal lval(String text, Line l) {
        Matcher m = LV.matcher(text);
        if (!m.matches()) throw err(l, "Cannot assign to '" + text + "'. Use a variable name, or name[index]");
        String name = m.group(1);
        Expr idx = m.group(2) == null ? null : expr(m.group(2), l);
        if (idx == null) {
            return new LVal() {
                @Override
                public Object get(Ctx c) {
                    return c.vars.get(name);
                }

                @Override
                public void set(Ctx c, Object v) {
                    c.vars.put(name, v);
                }

                @Override
                public void del(Ctx c) {
                    c.vars.remove(name);
                }
            };
        }
        return new LVal() {
            @Override
            public Object get(Ctx c) {
                return Access.index(c.vars.get(name), idx.eval(c));
            }

            @Override
            @SuppressWarnings("unchecked")
            public void set(Ctx c, Object v) {
                Object cont = c.vars.get(name);
                Object key = idx.eval(c);
                if (cont == null) {
                    Map<String, Object> created = new java.util.LinkedHashMap<>();
                    created.put(Values.str(key), v);
                    c.vars.put(name, created);
                } else if (cont instanceof List<?> list) {
                    List<Object> lo = (List<Object>) list;
                    int i = Values.intv(key);
                    if (i == lo.size()) lo.add(v);
                    else if (i >= 0 && i < lo.size()) lo.set(i, v);
                    else throw new RyuuException(0, "List index " + i + " is out of range (size " + lo.size() + ")");
                } else if (cont instanceof Map<?, ?> map) {
                    ((Map<String, Object>) map).put(Values.str(key), v);
                } else {
                    throw new RyuuException(0, "'" + name + "' is not a list or map");
                }
            }

            @Override
            @SuppressWarnings("unchecked")
            public void del(Ctx c) {
                Object cont = c.vars.get(name);
                Object key = idx.eval(c);
                if (cont instanceof List<?> list) {
                    int i = Values.intv(key);
                    if (i >= 0 && i < list.size()) ((List<Object>) list).remove(i);
                } else if (cont instanceof Map<?, ?> map) {
                    map.remove(Values.str(key));
                }
            }
        };
    }

    private Stmt set(Line l, String rest) {
        int k = findKw(rest, "to", false);
        if (k < 0) throw err(l, "Write it like:  set name to value");
        LVal lv = lval(rest.substring(0, k).trim(), l);
        Expr e = expr(rest.substring(k + 2).trim(), l);
        return c -> {
            lv.set(c, e.eval(c));
            return Run.NORMAL;
        };
    }

    private Stmt addRemove(Line l, String rest, boolean add) {
        String kw = add ? "to" : "from";
        int k = findKw(rest, kw, true);
        if (k < 0) throw err(l, "Write it like:  " + (add ? "add 5 to name" : "remove 5 from name"));
        Expr e = expr(rest.substring(0, k).trim(), l);
        LVal lv = lval(rest.substring(k + kw.length()).trim(), l);
        return c -> {
            Object cur = lv.get(c);
            Object v = e.eval(c);
            lv.set(c, add ? Values.plus(cur, v) : Values.minus(cur, v));
            return Run.NORMAL;
        };
    }

    private Stmt delete(Line l, String rest) {
        LVal lv = lval(rest.trim(), l);
        return c -> {
            lv.del(c);
            return Run.NORMAL;
        };
    }

    // ---------------------------------------------------------------- control flow

    private static List<Object> items(Object o) {
        if (o == null) return List.of();
        if (o instanceof Map<?, ?> m) return new ArrayList<>(m.keySet());
        if (o instanceof Collection<?> col) return new ArrayList<>(col);
        if (o instanceof Number n) {
            List<Object> out = new ArrayList<>();
            int max = (int) n.doubleValue();
            for (int i = 1; i <= max; i++) out.add((double) i);
            return out;
        }
        throw new RyuuException(0, "Cannot loop over " + Values.typeName(o));
    }

    private Stmt loop(Line l, String rest) {
        String h = colonRest(l, rest);
        int k = findKw(h, "in", false);
        if (k < 0) throw err(l, "Write it like:  loop item in list:");
        String varName = h.substring(0, k).trim();
        if (!IDENT.matcher(varName).matches()) throw err(l, "Bad loop variable name '" + varName + "'");
        Expr src = expr(h.substring(k + 2).trim(), l);
        Stmt[] body = block(l.kids());
        return c -> {
            for (Object it : items(src.eval(c))) {
                c.step();
                c.vars.put(varName, it);
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt repeat(Line l, String rest) {
        String h = colonRest(l, rest);
        int sp = h.lastIndexOf(' ');
        if (sp < 0 || !(h.endsWith(" times") || h.endsWith(" time"))) {
            throw err(l, "Write it like:  repeat 5 times:");
        }
        Expr n = expr(h.substring(0, sp).trim(), l);
        Stmt[] body = block(l.kids());
        return c -> {
            int count = Values.intv(n.eval(c));
            for (int i = 1; i <= count; i++) {
                c.step();
                c.vars.put("i", (double) i);
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt whileStmt(Line l, String rest) {
        Expr cond = expr(colonRest(l, rest), l);
        Stmt[] body = block(l.kids());
        return c -> {
            while (Values.truthy(cond.eval(c))) {
                c.step();
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt returnStmt(Line l, String rest) {
        if (rest.isEmpty()) {
            return c -> {
                c.ret = null;
                return Run.RETURN;
            };
        }
        Expr e = expr(rest, l);
        return c -> {
            c.ret = e.eval(c);
            return Run.RETURN;
        };
    }

    // ---------------------------------------------------------------- output

    private Stmt send(Line l, String rest) {
        int k = findKw(rest, "to", true);
        Expr msg = expr(k < 0 ? rest : rest.substring(0, k).trim(), l);
        Expr to = k < 0 ? null : expr(rest.substring(k + 2).trim(), l);
        return c -> {
            String m = Values.str(msg.eval(c));
            Values.deliver(to == null ? c.sender : to.eval(c), m);
            return Run.NORMAL;
        };
    }

    private Stmt broadcast(Line l, String rest) {
        Expr msg = expr(rest, l);
        return c -> {
            Bukkit.broadcast(Text.c(Values.str(msg.eval(c))));
            return Run.NORMAL;
        };
    }

    private Stmt console(Line l, String rest) {
        Expr cmd = expr(rest, l);
        return c -> {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Values.str(cmd.eval(c)));
            return Run.NORMAL;
        };
    }

    private Stmt log(Line l, String rest) {
        Expr msg = expr(rest, l);
        return c -> {
            RyuuModule.log(c.script.name, Values.str(msg.eval(c)));
            return Run.NORMAL;
        };
    }

    private Stmt later(Line l, String rest) {
        String h = colonRest(l, rest);
        int sp = h.lastIndexOf(' ');
        if (sp < 0) throw err(l, "Write it like:  later 5 seconds:");
        Expr n = expr(h.substring(0, sp).trim(), l);
        long unit = ticksOf(h.substring(sp + 1).trim(), l);
        Stmt[] body = block(l.kids());
        final int ln = l.no();
        return c -> {
            long ticks = Math.max(1, (long) (Values.num(n.eval(c)) * unit));
            Map<String, Object> snap = new HashMap<>(c.vars);
            Script sc = c.script;
            CommandSender snd = c.sender;
            Bukkit.getScheduler().runTaskLater(RyuuModule.plugin(), () -> {
                Ctx cc = new Ctx(sc, new HashMap<>(snap));
                cc.sender = snd;
                RyuuModule.safeRun(sc, ln, body, cc);
            }, ticks);
            return Run.NORMAL;
        };
    }

    // ---------------------------------------------------------------- GUI and chat input

    private Stmt openGui(Line l, String rest) {
        if (!rest.toLowerCase(Locale.ROOT).startsWith("gui ")) {
            throw err(l, "Write it like:  open gui \"Title\" rows 3:");
        }
        String h = colonRest(l, rest.substring(4).trim());
        int kr = findKw(h, "rows", false);
        if (kr < 0) throw err(l, "Missing 'rows'. Example:  open gui \"Title\" rows 3:");
        Expr title = expr(h.substring(0, kr).trim(), l);
        String after = h.substring(kr + 4).trim();
        int kf = findKw(after, "for", false);
        Expr rows = expr(kf < 0 ? after : after.substring(0, kf).trim(), l);
        Expr forE = kf < 0 ? null : expr(after.substring(kf + 3).trim(), l);
        Stmt[] body = block(l.kids());
        return c -> {
            Player p = forE == null ? c.player() : Values.player(forE.eval(c));
            if (p == null) throw new RyuuException(0, "open gui: there is no player to show it to");
            int r = Math.max(1, Math.min(6, Values.intv(rows.eval(c))));
            GuiBuild gb = new GuiBuild(new Gui(Text.c(Values.str(title.eval(c))), r), r);
            GuiBuild prev = c.gui;
            c.gui = gb;
            try {
                Run.block(body, c);
            } finally {
                c.gui = prev;
            }
            gb.finish();
            gb.gui.open(p);
            return Run.NORMAL;
        };
    }

    private Stmt slot(Line l, String rest) {
        boolean hasBody = !l.kids().isEmpty();
        String h = rest.endsWith(":") ? rest.substring(0, rest.length() - 1).trim() : rest;
        boolean glow = false;
        if (h.endsWith(" glow")) {
            glow = true;
            h = h.substring(0, h.length() - 5).trim();
        }
        int iItem = findKw(h, "item", false);
        int iHead = findKw(h, "head", false);
        boolean head = iItem < 0;
        int kType = head ? iHead : iItem;
        if (kType < 0) throw err(l, "slot needs 'item' or 'head'. Example:  slot 10 item EMERALD name \"Hi\":");
        List<int[]> ks = new ArrayList<>();
        ks.add(new int[]{kType, 0});
        int iName = findKw(h, "name", false);
        int iLore = findKw(h, "lore", false);
        if (iName >= 0) ks.add(new int[]{iName, 1});
        if (iLore >= 0) ks.add(new int[]{iLore, 2});
        ks.sort(Comparator.comparingInt(a -> a[0]));
        Expr slotE = expr(h.substring(0, ks.get(0)[0]).trim(), l);
        String[] seg = new String[3];
        for (int i = 0; i < ks.size(); i++) {
            int start = ks.get(i)[0];
            int end = i + 1 < ks.size() ? ks.get(i + 1)[0] : h.length();
            seg[ks.get(i)[1]] = h.substring(start + 4, end).trim();
        }
        Expr itemE = expr(seg[0], l);
        Expr nameE = seg[1] == null ? null : expr(seg[1], l);
        Expr loreE = seg[2] == null ? null : expr(seg[2], l);
        Stmt[] click = hasBody ? block(l.kids()) : null;
        final boolean fHead = head;
        final boolean fGlow = glow;
        final int ln = l.no();
        return c -> {
            if (c.gui == null) throw new RyuuException(0, "'slot' can only be used inside 'open gui'");
            int slot = Values.intv(slotE.eval(c));
            Object itemV = itemE.eval(c);
            String[] lore = new String[0];
            if (loreE != null) {
                Object lv = loreE.eval(c);
                if (lv instanceof List<?> ll) {
                    lore = new String[ll.size()];
                    for (int i = 0; i < ll.size(); i++) lore[i] = Values.str(ll.get(i));
                } else if (lv != null) {
                    lore = new String[]{Values.str(lv)};
                }
            }
            ItemStack it;
            if (fHead) {
                OfflinePlayer op = offline(itemV);
                String nm = nameE == null ? "&f" + Values.str(itemV) : Values.str(nameE.eval(c));
                it = op == null ? Items.of(Material.PLAYER_HEAD, nm, lore) : Items.head(op, nm, lore);
            } else {
                Material m = Material.matchMaterial(Values.str(itemV));
                if (m == null) throw new RyuuException(0, "Unknown material '" + Values.str(itemV) + "'");
                String nm = nameE == null ? "&f" + m.name() : Values.str(nameE.eval(c));
                it = Items.of(m, nm, lore);
            }
            if (fGlow) {
                ItemMeta im = it.getItemMeta();
                im.setEnchantmentGlintOverride(true);
                it.setItemMeta(im);
            }
            if (click == null) {
                c.gui.gui.set(slot, it);
            } else {
                Map<String, Object> snap = new HashMap<>(c.vars);
                Script sc = c.script;
                c.gui.gui.set(slot, it, e -> {
                    Player who = (Player) e.getWhoClicked();
                    Ctx cc = new Ctx(sc, new HashMap<>(snap));
                    cc.sender = who;
                    cc.vars.put("player", who);
                    cc.vars.put("click", e.getClick().name());
                    cc.vars.put("slot", (double) slot);
                    RyuuModule.safeRun(sc, ln, click, cc);
                });
            }
            return Run.NORMAL;
        };
    }

    private static OfflinePlayer offline(Object o) {
        if (o instanceof OfflinePlayer p) return p;
        if (o instanceof UUID u) return Bukkit.getOfflinePlayer(u);
        if (o instanceof String s) {
            try {
                return Bukkit.getOfflinePlayer(UUID.fromString(s));
            } catch (IllegalArgumentException e) {
                return Bukkit.getOfflinePlayerIfCached(s);
            }
        }
        return null;
    }

    private Stmt fill(Line l, String rest) {
        Expr e = expr(rest, l);
        return c -> {
            if (c.gui == null) throw new RyuuException(0, "'fill' can only be used inside 'open gui'");
            Material m = Material.matchMaterial(Values.str(e.eval(c)));
            if (m == null) throw new RyuuException(0, "Unknown material for fill");
            c.gui.fill = m;
            return Run.NORMAL;
        };
    }

    private Stmt ask(Line l, String rest) {
        String h = colonRest(l, rest);
        int ki = findKw(h, "into", true);
        if (ki < 0) throw err(l, "Write it like:  ask \"Type something\" into answer:");
        String varName = h.substring(ki + 4).trim();
        if (!IDENT.matcher(varName).matches()) throw err(l, "Bad variable name '" + varName + "'");
        String left = h.substring(0, ki).trim();
        int kf = findKw(left, "for", true);
        Expr prompt = expr(kf < 0 ? left : left.substring(0, kf).trim(), l);
        Expr forE = kf < 0 ? null : expr(left.substring(kf + 3).trim(), l);
        Stmt[] body = block(l.kids());
        final int ln = l.no();
        return c -> {
            Player p = forE == null ? c.player() : Values.player(forE.eval(c));
            if (p == null) throw new RyuuException(0, "ask: there is no player to ask");
            Values.deliver(p, Values.str(prompt.eval(c)));
            Map<String, Object> snap = new HashMap<>(c.vars);
            Script sc = c.script;
            java.util.function.Consumer<String> run = in -> {
                Ctx cc = new Ctx(sc, new HashMap<>(snap));
                cc.sender = p;
                cc.vars.put("player", p);
                cc.vars.put(varName, in);
                RyuuModule.safeRun(sc, ln, body, cc);
            };
            RyuuModule.plugin().prompts().ask(p, run, () -> run.accept("cancel"));
            return Run.NORMAL;
        };
    }
}
