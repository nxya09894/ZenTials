package com.zentials.ryuu;

import com.zentials.api.EconomyApi;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

/** Built-in namespaces (eco, data, shared, server, math, text, time) and global functions. */
final class Libs {

    interface Lib {
        Object call(String fn, List<Object> a, Ctx c);
    }

    private Libs() {
    }

    static final Lib ECO = new EcoLib();
    static final Lib SERVER = new ServerLib();
    static final Lib MATH = new MathLib();
    static final Lib TEXT = new TextLib();
    static final Lib TIME = new TimeLib();
    static final DataLib SHARED = new DataLib("ryu:shared");

    static Object global(String name, Script s) {
        return switch (name) {
            case "eco" -> ECO;
            case "server" -> SERVER;
            case "math" -> MATH;
            case "text" -> TEXT;
            case "time" -> TIME;
            case "shared" -> SHARED;
            case "data" -> s.data;
            case "opt" -> s.opt;
            default -> null;
        };
    }

    static Object arg(List<Object> a, int i) {
        return i < a.size() ? a.get(i) : null;
    }

    private static RyuuException unknown(String ns, String fn) {
        return new RyuuException(0, "Unknown function " + ns + "." + fn + "()");
    }

    // ---------------------------------------------------------------- user functions and builtins

    static Object callGlobal(String name, List<Object> a, Ctx c) {
        Script.FuncDef f = c.script.functions.get(name);
        if (f == null) f = RyuuModule.function(name);
        if (f != null) return invoke(f, a, c);
        switch (name) {
            case "len" -> {
                Object o = arg(a, 0);
                if (o instanceof List<?> l) return (double) l.size();
                if (o instanceof Map<?, ?> m) return (double) m.size();
                return (double) Values.str(o).length();
            }
            case "list" -> {
                return new ArrayList<>(a);
            }
            case "map" -> {
                Map<String, Object> m = new LinkedHashMap<>();
                for (int i = 0; i + 1 < a.size(); i += 2) m.put(Values.str(a.get(i)), a.get(i + 1));
                return m;
            }
            case "str" -> {
                return Values.str(arg(a, 0));
            }
            case "num" -> {
                return Values.num(arg(a, 0));
            }
            case "int" -> {
                return (double) (long) Values.num(arg(a, 0));
            }
            case "type" -> {
                return Values.typeName(arg(a, 0));
            }
            case "player" -> {
                return Values.player(arg(a, 0));
            }
            case "uuid" -> {
                return Values.uuid(arg(a, 0)).toString();
            }
            case "loc" -> {
                World w = Bukkit.getWorld(Values.str(arg(a, 0)));
                if (w == null) throw new RyuuException(0, "Unknown world '" + Values.str(arg(a, 0)) + "'");
                return new Location(w, Values.num(arg(a, 1)), Values.num(arg(a, 2)), Values.num(arg(a, 3)));
            }
            default -> throw new RyuuException(0, "Unknown function '" + name + "()'");
        }
    }

    static Object invoke(Script.FuncDef f, List<Object> args, Ctx caller) {
        if (caller.depth >= Ctx.MAX_DEPTH) {
            throw new RyuuException(0, "Too many nested calls in function '" + f.name + "'");
        }
        Ctx c = new Ctx(f.script);
        c.depth = caller.depth + 1;
        c.sender = caller.sender;
        c.gui = caller.gui;
        Object pl = caller.vars.get("player");
        if (pl != null) c.vars.put("player", pl);
        for (int i = 0; i < f.params.size(); i++) {
            c.vars.put(f.params.get(i), i < args.size() ? args.get(i) : null);
        }
        Run.block(f.body, c);
        if (c.cancel) caller.cancel = true;
        return c.ret;
    }

    // ---------------------------------------------------------------- economy

    private static final class EcoLib implements Lib {
        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            EconomyApi api = RyuuModule.economy();
            String reason = "Script: " + c.script.name;
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "balance" -> {
                    return api.balance(Values.uuid(arg(a, 0)));
                }
                case "bank" -> {
                    return api.bank(Values.uuid(arg(a, 0)));
                }
                case "has" -> {
                    return api.has(Values.uuid(arg(a, 0)), Values.num(arg(a, 1)));
                }
                case "add", "give", "deposit" -> {
                    return api.deposit(Values.uuid(arg(a, 0)), Values.num(arg(a, 1)),
                            a.size() > 2 ? Values.str(a.get(2)) : reason);
                }
                case "remove", "take", "withdraw" -> {
                    return api.withdraw(Values.uuid(arg(a, 0)), Values.num(arg(a, 1)),
                            a.size() > 2 ? Values.str(a.get(2)) : reason);
                }
                case "pay", "transfer" -> {
                    return api.transfer(Values.uuid(arg(a, 0)), Values.uuid(arg(a, 1)), Values.num(arg(a, 2)),
                            a.size() > 3 ? Values.str(a.get(3)) : reason);
                }
                case "set" -> {
                    return api.setBalance(Values.uuid(arg(a, 0)), Values.num(arg(a, 1)),
                            a.size() > 2 ? Values.str(a.get(2)) : reason);
                }
                case "exists" -> {
                    return api.exists(Values.uuid(arg(a, 0)));
                }
                case "format" -> {
                    return api.format(Values.num(arg(a, 0)));
                }
                case "short" -> {
                    return api.formatShort(Values.num(arg(a, 0)));
                }
                case "symbol" -> {
                    return api.symbol();
                }
                default -> throw unknown("eco", fn);
            }
        }
    }

    // ---------------------------------------------------------------- server

    private static final class ServerLib implements Lib {
        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "online" -> {
                    return new ArrayList<Object>(Bukkit.getOnlinePlayers());
                }
                case "count" -> {
                    return (double) Bukkit.getOnlinePlayers().size();
                }
                case "player" -> {
                    return Values.player(arg(a, 0));
                }
                case "broadcast" -> {
                    Bukkit.broadcast(com.zentials.core.Text.c(Values.str(arg(a, 0))));
                    return null;
                }
                case "console" -> {
                    return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Values.str(arg(a, 0)));
                }
                case "world" -> {
                    return Bukkit.getWorld(Values.str(arg(a, 0)));
                }
                default -> throw unknown("server", fn);
            }
        }
    }

    // ---------------------------------------------------------------- math

    private static final class MathLib implements Lib {
        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "floor" -> {
                    return Math.floor(Values.num(arg(a, 0)));
                }
                case "ceil" -> {
                    return Math.ceil(Values.num(arg(a, 0)));
                }
                case "round" -> {
                    double x = Values.num(arg(a, 0));
                    int places = a.size() > 1 ? Values.intv(a.get(1)) : 0;
                    double m = Math.pow(10, places);
                    return Math.round(x * m) / m;
                }
                case "abs" -> {
                    return Math.abs(Values.num(arg(a, 0)));
                }
                case "min" -> {
                    return Math.min(Values.num(arg(a, 0)), Values.num(arg(a, 1)));
                }
                case "max" -> {
                    return Math.max(Values.num(arg(a, 0)), Values.num(arg(a, 1)));
                }
                case "sqrt" -> {
                    return Math.sqrt(Values.num(arg(a, 0)));
                }
                case "pow" -> {
                    return Math.pow(Values.num(arg(a, 0)), Values.num(arg(a, 1)));
                }
                case "clamp" -> {
                    return Math.max(Values.num(arg(a, 1)), Math.min(Values.num(arg(a, 2)), Values.num(arg(a, 0))));
                }
                case "random" -> {
                    long lo = (long) Values.num(arg(a, 0));
                    long hi = (long) Values.num(arg(a, 1));
                    if (hi < lo) {
                        long t = lo;
                        lo = hi;
                        hi = t;
                    }
                    return (double) ThreadLocalRandom.current().nextLong(lo, hi + 1);
                }
                default -> throw unknown("math", fn);
            }
        }
    }

    // ---------------------------------------------------------------- text

    private static final class TextLib implements Lib {
        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            String s = Values.str(arg(a, 0));
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "lower" -> {
                    return s.toLowerCase(Locale.ROOT);
                }
                case "upper" -> {
                    return s.toUpperCase(Locale.ROOT);
                }
                case "len", "length" -> {
                    return (double) s.length();
                }
                case "trim" -> {
                    return s.trim();
                }
                case "contains" -> {
                    return s.contains(Values.str(arg(a, 1)));
                }
                case "replace" -> {
                    return s.replace(Values.str(arg(a, 1)), Values.str(arg(a, 2)));
                }
                case "repeat" -> {
                    return s.repeat(Math.max(0, Math.min(1000, Values.intv(arg(a, 1)))));
                }
                case "split" -> {
                    List<Object> out = new ArrayList<>();
                    for (String p : s.split(java.util.regex.Pattern.quote(Values.str(arg(a, 1))))) out.add(p);
                    return out;
                }
                case "join" -> {
                    Object l = arg(a, 0);
                    String sep = a.size() > 1 ? Values.str(a.get(1)) : ", ";
                    StringBuilder sb = new StringBuilder();
                    if (l instanceof List<?> list) {
                        for (int i = 0; i < list.size(); i++) {
                            if (i > 0) sb.append(sep);
                            sb.append(Values.str(list.get(i)));
                        }
                    }
                    return sb.toString();
                }
                case "commas" -> {
                    double d = Values.num(arg(a, 0));
                    if (d == Math.rint(d)) return String.format(Locale.US, "%,d", (long) d);
                    return String.format(Locale.US, "%,.2f", d);
                }
                case "strip" -> {
                    return s.replaceAll("(?i)[&\u00A7][0-9a-fk-or]", "");
                }
                case "color" -> {
                    return s;
                }
                default -> throw unknown("text", fn);
            }
        }
    }

    // ---------------------------------------------------------------- time

    private static final class TimeLib implements Lib {
        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "now" -> {
                    return (double) System.currentTimeMillis();
                }
                case "seconds" -> {
                    return (double) (System.currentTimeMillis() / 1000L);
                }
                case "format" -> {
                    long ms = (long) Values.num(arg(a, 0));
                    String pat = a.size() > 1 ? Values.str(a.get(1)) : "yyyy-MM-dd HH:mm";
                    try {
                        return DateTimeFormatter.ofPattern(pat).format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()));
                    } catch (IllegalArgumentException e) {
                        throw new RyuuException(0, "Bad time pattern '" + pat + "'");
                    }
                }
                case "since" -> {
                    long diff = Math.max(0, System.currentTimeMillis() - (long) Values.num(arg(a, 0)));
                    long min = diff / 60000;
                    if (min >= 1440) return (min / 1440) + "d " + ((min % 1440) / 60) + "h";
                    if (min >= 60) return (min / 60) + "h " + (min % 60) + "m";
                    return min + "m " + ((diff / 1000) % 60) + "s";
                }
                default -> throw unknown("time", fn);
            }
        }
    }

    // ---------------------------------------------------------------- persistent data

    /** data.* (per script) and shared.* (all scripts). Values survive restarts; stored in the ZenTials database. */
    static final class DataLib implements Lib {
        private final String ns;

        DataLib(String ns) {
            this.ns = ns;
        }

        private static String key(List<Object> a) {
            String k = Values.str(arg(a, 0));
            if (k.isEmpty()) throw new RyuuException(0, "data key cannot be empty");
            return k;
        }

        @Override
        public Object call(String fn, List<Object> a, Ctx c) {
            Kv kv = RyuuModule.kv();
            switch (fn.toLowerCase(Locale.ROOT)) {
                case "get" -> {
                    String raw = kv.get(ns, key(a));
                    if (raw == null) return a.size() > 1 ? a.get(1) : null;
                    return Codec.dec(raw);
                }
                case "set" -> {
                    String k = key(a);
                    Object v = arg(a, 1);
                    if (v == null) kv.delete(ns, k);
                    else kv.set(ns, k, Codec.enc(v));
                    return null;
                }
                case "del", "delete" -> {
                    kv.delete(ns, key(a));
                    return null;
                }
                case "has" -> {
                    return kv.get(ns, key(a)) != null;
                }
                case "incr" -> {
                    String k = key(a);
                    String raw = kv.get(ns, k);
                    double cur = 0;
                    if (raw != null && Codec.dec(raw) instanceof Double d) cur = d;
                    double next = cur + (a.size() > 1 ? Values.num(a.get(1)) : 1);
                    kv.set(ns, k, Codec.enc(next));
                    return next;
                }
                case "keys" -> {
                    try {
                        RyuuModule.plugin().db().flush().get(5, TimeUnit.SECONDS);
                    } catch (Exception ignored) {
                        // list whatever is committed
                    }
                    String prefix = a.isEmpty() ? "" : Values.str(a.get(0));
                    int limit = a.size() > 1 ? Values.intv(a.get(1)) : 1000;
                    return new ArrayList<Object>(kv.list(ns, prefix, limit).keySet());
                }
                default -> throw unknown("data", fn);
            }
        }
    }

    /** Typed encoding of script values into the text column of the key/value store. */
    static final class Codec {
        private Codec() {
        }

        static String numText(double d) {
            if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
            return Double.toString(d);
        }

        @SuppressWarnings("unchecked")
        static String enc(Object o) {
            if (o == null) return "s:";
            if (o instanceof Number n) return "n:" + numText(n.doubleValue());
            if (o instanceof Boolean b) return "b:" + b;
            if (o instanceof UUID u) return "u:" + u;
            if (o instanceof OfflinePlayer p) return "u:" + p.getUniqueId();
            if (o instanceof List<?> l) {
                StringBuilder sb = new StringBuilder("l:");
                for (Object item : l) {
                    String e = enc(item);
                    sb.append(e.length()).append(':').append(e);
                }
                return sb.toString();
            }
            if (o instanceof Map<?, ?> m) {
                StringBuilder sb = new StringBuilder("m:");
                for (Map.Entry<Object, Object> en : ((Map<Object, Object>) m).entrySet()) {
                    String k = enc(Values.str(en.getKey()));
                    String v = enc(en.getValue());
                    sb.append(k.length()).append(':').append(k).append(v.length()).append(':').append(v);
                }
                return sb.toString();
            }
            return "s:" + Values.str(o);
        }

        static Object dec(String s) {
            if (s.length() < 2 || s.charAt(1) != ':') return s;
            String body = s.substring(2);
            try {
                return switch (s.charAt(0)) {
                    case 'n' -> Double.parseDouble(body);
                    case 'b' -> body.equals("true");
                    case 's' -> body;
                    case 'u' -> UUID.fromString(body);
                    case 'l' -> decList(body);
                    case 'm' -> decMap(body);
                    default -> s;
                };
            } catch (RuntimeException e) {
                return body;
            }
        }

        private static List<Object> decList(String body) {
            List<Object> out = new ArrayList<>();
            int i = 0;
            while (i < body.length()) {
                int colon = body.indexOf(':', i);
                int len = Integer.parseInt(body.substring(i, colon));
                out.add(dec(body.substring(colon + 1, colon + 1 + len)));
                i = colon + 1 + len;
            }
            return out;
        }

        private static Map<String, Object> decMap(String body) {
            List<Object> flat = decList(body);
            Map<String, Object> out = new LinkedHashMap<>();
            for (int i = 0; i + 1 < flat.size(); i += 2) out.put(Values.str(flat.get(i)), flat.get(i + 1));
            return out;
        }
    }
}
