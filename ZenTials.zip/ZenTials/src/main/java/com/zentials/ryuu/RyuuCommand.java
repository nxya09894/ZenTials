package com.zentials.ryuu;

import com.zentials.core.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** A command created by a script. */
final class RyuuCommand extends Command {
    private final Script script;
    private final Script.CommandDef def;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    RyuuCommand(Script script, Script.CommandDef def) {
        super(def.name);
        this.script = script;
        this.def = def;
        setDescription(def.description);
        setAliases(def.aliases);
        setUsage(usage());
    }

    private String usage() {
        if (def.usage != null) return def.usage;
        StringBuilder sb = new StringBuilder("/").append(def.name);
        for (Script.ArgSpec a : def.args) {
            sb.append(' ').append(a.required() ? '<' : '[').append(a.name()).append(a.rest() ? "..." : "")
                    .append(a.required() ? '>' : ']');
        }
        return sb.toString();
    }

    @Override
    public boolean execute(CommandSender s, String label, String[] args) {
        if (def.permission != null && !s.hasPermission(def.permission)) {
            Text.send(s, "&cYou don't have permission to use this.");
            return true;
        }
        if (def.playerOnly && !(s instanceof Player)) {
            Text.send(s, "&cOnly players can use this command.");
            return true;
        }
        if (def.cooldownSeconds > 0 && s instanceof Player p) {
            long now = System.currentTimeMillis();
            Long until = cooldowns.get(p.getUniqueId());
            if (until != null && until > now) {
                Text.send(s, "&cPlease wait " + ((until - now) / 1000 + 1) + "s before using this again.");
                return true;
            }
            cooldowns.put(p.getUniqueId(), now + def.cooldownSeconds * 1000L);
        }
        Ctx c = new Ctx(script);
        c.sender = s;
        c.vars.put("sender", s);
        if (s instanceof Player p) c.vars.put("player", p);
        List<Object> raw = new ArrayList<>(List.of((Object[]) args));
        c.vars.put("args", raw);
        int i = 0;
        for (Script.ArgSpec spec : def.args) {
            if (spec.rest()) {
                if (i >= args.length) {
                    if (spec.required()) return usageError(s);
                    c.vars.put(spec.name(), null);
                } else {
                    c.vars.put(spec.name(), String.join(" ", List.of(args).subList(i, args.length)));
                    i = args.length;
                }
                continue;
            }
            if (i >= args.length) {
                if (spec.required()) return usageError(s);
                c.vars.put(spec.name(), null);
                continue;
            }
            String in = args[i++];
            switch (spec.type()) {
                case "number" -> {
                    try {
                        c.vars.put(spec.name(), Double.parseDouble(in));
                    } catch (NumberFormatException e) {
                        Text.send(s, "&c'" + in + "' is not a number.");
                        return true;
                    }
                }
                case "player" -> {
                    Player target = Bukkit.getPlayerExact(in);
                    if (target == null) {
                        Text.send(s, "&cPlayer '" + in + "' is not online.");
                        return true;
                    }
                    c.vars.put(spec.name(), target);
                }
                default -> c.vars.put(spec.name(), in);
            }
        }
        RyuuModule.safeRun(script, def.line, def.body, c);
        return true;
    }

    private boolean usageError(CommandSender s) {
        Text.send(s, "&cUsage: " + usage());
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender s, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        int idx = args.length - 1;
        if (idx < 0 || idx >= def.args.size()) return out;
        Script.ArgSpec spec = def.args.get(idx);
        String cur = args[idx].toLowerCase(Locale.ROOT);
        if (spec.type().equals("player")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(cur)) out.add(p.getName());
            }
        }
        return out;
    }
}
