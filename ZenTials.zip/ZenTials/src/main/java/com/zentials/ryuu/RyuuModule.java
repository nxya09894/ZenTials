package com.zentials.ryuu;

import com.zentials.ZenTials;
import com.zentials.api.EconomyApi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Ryuudules: the ZenTials scripting system. Loads every .ryu file under plugins/ZenTials/ryuudules/
 * (except the examples folder) and turns it into commands, event handlers, timers and functions.
 */
public final class RyuuModule implements ZModule, CommandExecutor, TabCompleter {

    private static RyuuModule inst;
    private static final Map<String, Script.FuncDef> FUNCS = new ConcurrentHashMap<>();

    private static final List<String> RESOURCES = List.of("README.md", "examples/hello.ryu",
            "examples/economy-shop.ryu", "examples/gui-menu.ryu", "examples/shared-data.ryu");

    private static final class Active {
        Script script;
        Listener listener = new Listener() {
        };
        final List<RyuuCommand> cmds = new ArrayList<>();
        final List<BukkitTask> tasks = new ArrayList<>();
    }

    private final ZenTials plugin;
    private File root;
    private final Map<String, Active> active = new LinkedHashMap<>();
    private final List<String> errors = new ArrayList<>();
    private final Map<String, Long> lastReport = new HashMap<>();

    public RyuuModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "ryuudules";
    }

    // ---------------------------------------------------------------- static helpers for the interpreter

    static ZenTials plugin() {
        return inst.plugin;
    }

    static Kv kv() {
        Kv kv = inst.plugin.kv();
        if (kv == null) throw new RyuuException(0, "The ZenTials database is not running");
        return kv;
    }

    static EconomyApi economy() {
        EconomyApi api = inst.plugin.economyApi();
        if (api == null) throw new RyuuException(0, "The economy module is not enabled");
        return api;
    }

    static UUID uuidOfName(String name) {
        EconomyApi api = inst == null ? null : inst.plugin.economyApi();
        return api == null ? null : api.uuidOf(name);
    }

    static Script.FuncDef function(String name) {
        return FUNCS.get(name);
    }

    static void log(String script, String msg) {
        inst.plugin.getLogger().info("[" + script + "] " + msg);
    }

    /** Runs a block, and reports (instead of throwing) any script error. */
    static void safeRun(Script s, int line, Stmt[] body, Ctx c) {
        try {
            Run.block(body, c);
        } catch (RyuuException e) {
            inst.report(s, e.line() > 0 ? e.line() : line, e.getMessage(), c.sender);
        } catch (Throwable t) {
            inst.report(s, line, t.toString(), c.sender);
        }
    }

    private void report(Script s, int line, String msg, CommandSender who) {
        String key = s.name + ":" + line + ":" + msg;
        long now = System.currentTimeMillis();
        Long last = lastReport.get(key);
        if (last == null || now - last > 5000) {
            lastReport.put(key, now);
            if (lastReport.size() > 500) lastReport.clear();
            plugin.getLogger().warning("[Ryuudules] " + s.name + ":" + line + "  " + msg);
        }
        if (who instanceof Player p) {
            if (p.hasPermission("zentials.admin")) Text.send(p, "&c[Ryuudules] " + s.name + ":" + line + "  " + msg);
            else Text.send(p, "&cSomething went wrong. Please tell an admin.");
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void enable() {
        inst = this;
        root = new File(plugin.getDataFolder(), "ryuudules");
        root.mkdirs();
        for (String r : RESOURCES) {
            try {
                plugin.saveResource("ryuudules/" + r, true);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Missing bundled file: ryuudules/" + r);
            }
        }
        PluginCommand cmd = plugin.getCommand("ryu");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        loadAll();
        syncCommands();
    }

    @Override
    public void disable() {
        unloadAll();
    }

    @Override
    public void reload() {
        unloadAll();
        loadAll();
        syncCommands();
    }

    private void addError(String msg) {
        errors.add(msg);
        plugin.getLogger().warning("[Ryuudules] " + msg);
    }

    private void loadAll() {
        errors.clear();
        List<Script> parsed = new ArrayList<>();
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            List<Path> files = w.filter(p -> p.toString().endsWith(".ryu"))
                    .filter(p -> !rootPath.relativize(p).startsWith("examples"))
                    .sorted().toList();
            for (Path f : files) {
                String rel = rootPath.relativize(f).toString().replace('\\', '/');
                try {
                    parsed.add(new Parser(rel).parse(Files.readString(f, StandardCharsets.UTF_8)));
                } catch (RyuuException e) {
                    addError(rel + ":" + e.line() + "  " + e.getMessage());
                } catch (IOException | RuntimeException e) {
                    addError(rel + "  " + e);
                }
            }
        } catch (IOException e) {
            addError("Cannot read the ryuudules folder: " + e.getMessage());
        }
        for (Script s : parsed) {
            for (Script.FuncDef f : s.functions.values()) {
                if (FUNCS.putIfAbsent(f.name, f) != null) {
                    addError(s.name + ":" + f.line + "  function '" + f.name
                            + "' already exists in another file (this one is only used inside its own file)");
                }
            }
        }
        int cmds = 0;
        int evs = 0;
        int tms = 0;
        for (Script s : parsed) {
            try {
                activate(s);
                cmds += s.commands.size();
                evs += s.events.size();
                tms += s.timers.size();
            } catch (RuntimeException e) {
                addError(s.name + "  failed to start: " + e);
            }
        }
        plugin.getLogger().info("Ryuudules: " + parsed.size() + " script(s) loaded - " + cmds + " command(s), "
                + evs + " event handler(s), " + tms + " timer(s)" + (errors.isEmpty() ? "" : ", " + errors.size()
                + " ERROR(S) (see /ryu errors)"));
    }

    private void activate(Script s) {
        Active a = new Active();
        a.script = s;
        active.put(s.name, a);

        for (Script.EventDef d : s.events) {
            EventDefs.Def def = EventDefs.ALL.get(d.event);
            Bukkit.getPluginManager().registerEvent(def.cls(), a.listener, EventPriority.NORMAL, (l, e) -> {
                if (def.cls().isInstance(e)) runEvent(s, d, def, e);
            }, plugin, false);
        }

        CommandMap cm = Bukkit.getCommandMap();
        for (Script.CommandDef d : s.commands) {
            RyuuCommand cmd = new RyuuCommand(s, d);
            cm.register("ryu", cmd);
            a.cmds.add(cmd);
        }

        for (Script.TimerDef d : s.timers) {
            double n = Values.num(d.period.eval(new Ctx(s)));
            long period = Math.max(1, (long) (n * d.unitTicks));
            a.tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> safeRun(s, d.line, d.body, new Ctx(s)),
                    period, period));
        }

        for (Stmt[] body : s.onLoad) safeRun(s, 0, body, new Ctx(s));
    }

    private void runEvent(Script s, Script.EventDef d, EventDefs.Def def, Event e) {
        Ctx c = new Ctx(s);
        c.vars.putAll(def.vars().apply(e));
        if (c.vars.get("player") instanceof Player p) c.sender = p;
        safeRun(s, d.line, d.body, c);
        if (c.cancel && e instanceof Cancellable ce) ce.setCancelled(true);
    }

    private void unloadAll() {
        CommandMap cm = Bukkit.getCommandMap();
        for (Active a : active.values()) {
            for (Stmt[] body : a.script.onUnload) safeRun(a.script, 0, body, new Ctx(a.script));
            HandlerList.unregisterAll(a.listener);
            for (BukkitTask t : a.tasks) t.cancel();
            for (RyuuCommand cmd : a.cmds) {
                cm.getKnownCommands().values().removeIf(v -> v == cmd);
                cmd.unregister(cm);
            }
        }
        active.clear();
        FUNCS.clear();
    }

    private void syncCommands() {
        try {
            Bukkit.getServer().getClass().getMethod("syncCommands").invoke(Bukkit.getServer());
        } catch (Exception ignored) {
            // older servers: players just need to rejoin for tab-completion
        }
    }

    // ---------------------------------------------------------------- /ryu

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                reload();
                Text.send(s, "&8[&bRyuudules&8]&7 Reloaded. Scripts: &f" + active.size()
                        + (errors.isEmpty() ? "" : " &8| &c" + errors.size() + " error(s) &7- /ryu errors"));
            }
            case "list" -> {
                if (active.isEmpty()) Text.send(s, "&8[&bRyuudules&8]&7 No scripts loaded. Put .ryu files in plugins/ZenTials/ryuudules/");
                for (Active x : active.values()) {
                    Script sc = x.script;
                    Text.send(s, "&8- &f" + sc.name + " &8| &7" + sc.commands.size() + " cmd, " + sc.events.size()
                            + " event, " + sc.timers.size() + " timer, " + sc.functions.size() + " function");
                }
            }
            case "errors" -> {
                if (errors.isEmpty()) Text.send(s, "&8[&bRyuudules&8]&a No errors.");
                for (String e : errors) Text.send(s, "&c" + e);
            }
            default -> Text.send(s, "&8[&bRyuudules&8]&7 &f/ryu reload &8| &f/ryu list &8| &f/ryu errors");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        return a.length == 1 ? List.of("reload", "list", "errors") : List.of();
    }
}
