package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One parsed .ryu file. */
final class Script {
    record ArgSpec(String name, boolean required, String type, boolean rest) {
    }

    static final class CommandDef {
        String name;
        List<ArgSpec> args = new ArrayList<>();
        String permission;
        String description = "";
        String usage;
        boolean playerOnly;
        int cooldownSeconds;
        List<String> aliases = new ArrayList<>();
        Stmt[] body = new Stmt[0];
        int line;
    }

    static final class EventDef {
        String event;
        Stmt[] body = new Stmt[0];
        int line;
    }

    static final class TimerDef {
        Expr period;
        long unitTicks;
        Stmt[] body = new Stmt[0];
        int line;
    }

    static final class FuncDef {
        String name;
        List<String> params = new ArrayList<>();
        Stmt[] body = new Stmt[0];
        Script script;
        int line;
    }

    final String name;
    final String namespace;
    final Map<String, Object> opt = new LinkedHashMap<>();
    final List<CommandDef> commands = new ArrayList<>();
    final List<EventDef> events = new ArrayList<>();
    final List<TimerDef> timers = new ArrayList<>();
    final Map<String, FuncDef> functions = new LinkedHashMap<>();
    final List<Stmt[]> onLoad = new ArrayList<>();
    final List<Stmt[]> onUnload = new ArrayList<>();
    final Libs.DataLib data;

    Script(String name) {
        this.name = name;
        String base = name.endsWith(".ryu") ? name.substring(0, name.length() - 4) : name;
        this.namespace = "ryu:" + base.replace('\\', '/');
        this.data = new Libs.DataLib(namespace);
    }
}
