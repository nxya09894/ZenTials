package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.List;

/** Compiles an expression into an Expr (a tree of small lambdas). */
final class ExprParser {
    private final List<Lexer.Tok> t;
    private final int line;
    private int p;

    private ExprParser(String src, int line) {
        this.t = Lexer.lex(src, line);
        this.line = line;
    }

    static Expr compile(String src, int line) {
        ExprParser ep = new ExprParser(src, line);
        Expr e = ep.or();
        if (ep.peek().t() != Lexer.T.EOF) {
            throw new RyuuException(line, "Unexpected '" + ep.peek().s() + "' in: " + src.trim());
        }
        return e;
    }

    // ---------------------------------------------------------------- token helpers

    private Lexer.Tok peek() {
        return t.get(p);
    }

    private Lexer.Tok next() {
        return t.get(p++);
    }

    private boolean isOp(String s) {
        Lexer.Tok k = peek();
        return k.t() == Lexer.T.OP && k.s().equals(s);
    }

    private boolean isId(String s) {
        Lexer.Tok k = peek();
        return k.t() == Lexer.T.ID && k.s().equals(s);
    }

    private void expectOp(String s) {
        if (!isOp(s)) throw new RyuuException(line, "Expected '" + s + "' but found '" + peek().s() + "'");
        p++;
    }

    // ---------------------------------------------------------------- grammar

    private Expr or() {
        Expr l = and();
        while (isId("or")) {
            p++;
            Expr a = l;
            Expr b = and();
            l = c -> Values.truthy(a.eval(c)) || Values.truthy(b.eval(c));
        }
        return l;
    }

    private Expr and() {
        Expr l = not();
        while (isId("and")) {
            p++;
            Expr a = l;
            Expr b = not();
            l = c -> Values.truthy(a.eval(c)) && Values.truthy(b.eval(c));
        }
        return l;
    }

    private Expr not() {
        if (isId("not")) {
            p++;
            Expr e = not();
            return c -> !Values.truthy(e.eval(c));
        }
        return cmp();
    }

    private Expr cmp() {
        Expr l = add();
        while (true) {
            Lexer.Tok k = peek();
            if (k.t() == Lexer.T.OP && (k.s().equals("==") || k.s().equals("!=") || k.s().equals("<")
                    || k.s().equals("<=") || k.s().equals(">") || k.s().equals(">="))) {
                p++;
                String op = k.s();
                Expr a = l;
                Expr b = add();
                l = switch (op) {
                    case "==" -> c -> Values.eq(a.eval(c), b.eval(c));
                    case "!=" -> c -> !Values.eq(a.eval(c), b.eval(c));
                    case "<" -> c -> Values.compare(a.eval(c), b.eval(c)) < 0;
                    case "<=" -> c -> Values.compare(a.eval(c), b.eval(c)) <= 0;
                    case ">" -> c -> Values.compare(a.eval(c), b.eval(c)) > 0;
                    default -> c -> Values.compare(a.eval(c), b.eval(c)) >= 0;
                };
            } else if (k.t() == Lexer.T.ID && k.s().equals("in")) {
                p++;
                Expr a = l;
                Expr b = add();
                l = c -> contains(b.eval(c), a.eval(c));
            } else {
                return l;
            }
        }
    }

    private static boolean contains(Object haystack, Object needle) {
        if (haystack instanceof List<?> list) {
            for (Object o : list) if (Values.eq(o, needle)) return true;
            return false;
        }
        if (haystack instanceof java.util.Map<?, ?> m) return m.containsKey(Values.str(needle));
        if (haystack instanceof String s) return s.contains(Values.str(needle));
        return false;
    }

    private Expr add() {
        Expr l = mul();
        while (isOp("+") || isOp("-")) {
            String op = next().s();
            Expr a = l;
            Expr b = mul();
            if (op.equals("+")) l = c -> Values.add(a.eval(c), b.eval(c));
            else l = c -> Values.num(a.eval(c)) - Values.num(b.eval(c));
        }
        return l;
    }

    private Expr mul() {
        Expr l = unary();
        while (isOp("*") || isOp("/") || isOp("%")) {
            String op = next().s();
            Expr a = l;
            Expr b = unary();
            l = switch (op) {
                case "*" -> c -> Values.num(a.eval(c)) * Values.num(b.eval(c));
                case "/" -> c -> {
                    double d = Values.num(b.eval(c));
                    if (d == 0) throw new RyuuException(0, "Division by zero");
                    return Values.num(a.eval(c)) / d;
                };
                default -> c -> {
                    double d = Values.num(b.eval(c));
                    if (d == 0) throw new RyuuException(0, "Division by zero");
                    return Values.num(a.eval(c)) % d;
                };
            };
        }
        return l;
    }

    private Expr unary() {
        if (isOp("-")) {
            p++;
            Expr e = unary();
            return c -> -Values.num(e.eval(c));
        }
        return postfix();
    }

    private List<Expr> args() {
        expectOp("(");
        List<Expr> out = new ArrayList<>();
        if (isOp(")")) {
            p++;
            return out;
        }
        while (true) {
            out.add(or());
            if (isOp(",")) {
                p++;
                continue;
            }
            expectOp(")");
            return out;
        }
    }

    private static List<Object> evalAll(List<Expr> args, Ctx c) {
        List<Object> out = new ArrayList<>(args.size());
        for (Expr a : args) out.add(a.eval(c));
        return out;
    }

    private Expr postfix() {
        Expr e = primary();
        while (true) {
            if (isOp(".")) {
                p++;
                Lexer.Tok name = next();
                if (name.t() != Lexer.T.ID) throw new RyuuException(line, "Expected a name after '.'");
                String n = name.s();
                Expr target = e;
                if (isOp("(")) {
                    List<Expr> a = args();
                    e = c -> Access.call(target.eval(c), n, evalAll(a, c), c);
                } else {
                    e = c -> Access.get(target.eval(c), n);
                }
            } else if (isOp("[")) {
                p++;
                Expr idx = or();
                expectOp("]");
                Expr target = e;
                e = c -> Access.index(target.eval(c), idx.eval(c));
            } else {
                return e;
            }
        }
    }

    private Expr primary() {
        Lexer.Tok k = next();
        switch (k.t()) {
            case NUM -> {
                Double d = k.n();
                return c -> d;
            }
            case STR -> {
                return text(k.s());
            }
            case ID -> {
                String n = k.s();
                switch (n) {
                    case "true" -> {
                        return c -> Boolean.TRUE;
                    }
                    case "false" -> {
                        return c -> Boolean.FALSE;
                    }
                    case "null", "none" -> {
                        return c -> null;
                    }
                    default -> {
                    }
                }
                if (isOp("(")) {
                    List<Expr> a = args();
                    return c -> Libs.callGlobal(n, evalAll(a, c), c);
                }
                return c -> c.get(n);
            }
            case OP -> {
                if (k.s().equals("(")) {
                    Expr e = or();
                    expectOp(")");
                    return e;
                }
                if (k.s().equals("[")) {
                    List<Expr> items = new ArrayList<>();
                    if (isOp("]")) {
                        p++;
                    } else {
                        while (true) {
                            items.add(or());
                            if (isOp(",")) {
                                p++;
                                continue;
                            }
                            expectOp("]");
                            break;
                        }
                    }
                    return c -> evalAll(items, c);
                }
                throw new RyuuException(line, "Unexpected '" + k.s() + "'");
            }
            default -> throw new RyuuException(line, "Unexpected end of expression");
        }
    }

    // ---------------------------------------------------------------- text with {expressions}

    private Expr text(String raw) {
        List<Object> parts = new ArrayList<>();
        StringBuilder lit = new StringBuilder();
        int i = 0;
        while (i < raw.length()) {
            char ch = raw.charAt(i);
            if (ch == '\\' && i + 1 < raw.length()) {
                char d = raw.charAt(i + 1);
                switch (d) {
                    case 'n' -> lit.append('\n');
                    case 't' -> lit.append('\t');
                    default -> lit.append(d);
                }
                i += 2;
                continue;
            }
            if (ch == '{') {
                int depth = 1;
                int j = i + 1;
                while (j < raw.length() && depth > 0) {
                    char d = raw.charAt(j);
                    if (d == '\\') {
                        j += 2;
                        continue;
                    }
                    if (d == '{') depth++;
                    else if (d == '}') depth--;
                    j++;
                }
                if (depth != 0) throw new RyuuException(line, "Missing } in text: " + raw);
                String inner = raw.substring(i + 1, j - 1);
                if (lit.length() > 0) {
                    parts.add(lit.toString());
                    lit.setLength(0);
                }
                parts.add(compile(inner, line));
                i = j;
                continue;
            }
            lit.append(ch);
            i++;
        }
        if (lit.length() > 0) parts.add(lit.toString());
        if (parts.isEmpty()) return c -> "";
        if (parts.size() == 1 && parts.get(0) instanceof String s) return c -> s;
        return c -> {
            StringBuilder sb = new StringBuilder();
            for (Object o : parts) {
                if (o instanceof String s) sb.append(s);
                else sb.append(Values.str(((Expr) o).eval(c)));
            }
            return sb.toString();
        };
    }
}
