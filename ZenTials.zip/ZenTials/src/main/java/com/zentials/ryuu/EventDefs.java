package com.zentials.ryuu;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/** Script event names and the variables each one gives to the script. */
final class EventDefs {
    record Def(Class<? extends Event> cls, Function<Event, Map<String, Object>> vars) {
    }

    static final Map<String, Def> ALL = new LinkedHashMap<>();

    private EventDefs() {
    }

    private static Map<String, Object> m(Object... kv) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) out.put((String) kv[i], kv[i + 1]);
        return out;
    }

    private static void put(String name, Class<? extends Event> cls, Function<Event, Map<String, Object>> f) {
        ALL.put(name, new Def(cls, f));
    }

    static {
        put("join", PlayerJoinEvent.class, e -> m("player", ((PlayerJoinEvent) e).getPlayer()));
        put("quit", PlayerQuitEvent.class, e -> m("player", ((PlayerQuitEvent) e).getPlayer()));
        put("respawn", PlayerRespawnEvent.class, e -> {
            PlayerRespawnEvent x = (PlayerRespawnEvent) e;
            return m("player", x.getPlayer(), "respawnloc", x.getRespawnLocation());
        });
        put("break", BlockBreakEvent.class, e -> {
            BlockBreakEvent x = (BlockBreakEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlock());
        });
        put("place", BlockPlaceEvent.class, e -> {
            BlockPlaceEvent x = (BlockPlaceEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlockPlaced());
        });
        put("interact", PlayerInteractEvent.class, e -> {
            PlayerInteractEvent x = (PlayerInteractEvent) e;
            return m("player", x.getPlayer(), "block", x.getClickedBlock(), "action", x.getAction().name(),
                    "item", x.getItem() == null ? null : x.getItem().getType().name(),
                    "itemname", Access.itemName(x.getItem()),
                    "hand", x.getHand() == null ? null : x.getHand().name());
        });
        put("interact-entity", PlayerInteractEntityEvent.class, e -> {
            PlayerInteractEntityEvent x = (PlayerInteractEntityEvent) e;
            return m("player", x.getPlayer(), "entity", x.getRightClicked());
        });
        put("death", PlayerDeathEvent.class, e -> {
            PlayerDeathEvent x = (PlayerDeathEvent) e;
            return m("player", x.getEntity(), "killer", x.getEntity().getKiller());
        });
        put("kill", EntityDeathEvent.class, e -> {
            EntityDeathEvent x = (EntityDeathEvent) e;
            return m("entity", x.getEntity(), "killer", x.getEntity().getKiller());
        });
        put("move", PlayerMoveEvent.class, e -> {
            PlayerMoveEvent x = (PlayerMoveEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom(), "to", x.getTo());
        });
        put("teleport", PlayerTeleportEvent.class, e -> {
            PlayerTeleportEvent x = (PlayerTeleportEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom(), "to", x.getTo());
        });
        put("damage", EntityDamageEvent.class, e -> {
            EntityDamageEvent x = (EntityDamageEvent) e;
            Entity en = x.getEntity();
            return m("entity", en, "player", en instanceof Player ? en : null, "damage", x.getDamage(),
                    "cause", x.getCause().name());
        });
        put("damage-entity", EntityDamageByEntityEvent.class, e -> {
            EntityDamageByEntityEvent x = (EntityDamageByEntityEvent) e;
            Entity d = x.getDamager();
            Entity v = x.getEntity();
            Object pl = d instanceof Player ? d : (v instanceof Player ? v : null);
            Object attacker = d;
            if (d instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Entity shooter) attacker = shooter;
            return m("damager", d, "attacker", attacker, "victim", v, "player", pl, "damage", x.getDamage(),
                    "cause", x.getCause().name());
        });
        put("command", PlayerCommandPreprocessEvent.class, e -> {
            PlayerCommandPreprocessEvent x = (PlayerCommandPreprocessEvent) e;
            String msg = x.getMessage();
            return m("player", x.getPlayer(), "message", msg, "command", msg.startsWith("/") ? msg.substring(1) : msg);
        });
        put("explode", EntityExplodeEvent.class, e -> {
            EntityExplodeEvent x = (EntityExplodeEvent) e;
            return m("entity", x.getEntity(), "blocks", new ArrayList<Object>(x.blockList()), "loc", x.getLocation());
        });
        put("block-explode", BlockExplodeEvent.class, e -> {
            BlockExplodeEvent x = (BlockExplodeEvent) e;
            List<Object> blocks = new ArrayList<>(x.blockList());
            return m("block", x.getBlock(), "blocks", blocks);
        });
        put("drop", PlayerDropItemEvent.class, e -> {
            PlayerDropItemEvent x = (PlayerDropItemEvent) e;
            return m("player", x.getPlayer(), "item", x.getItemDrop().getItemStack().getType().name(),
                    "itemname", Access.itemName(x.getItemDrop().getItemStack()));
        });
        put("pickup", EntityPickupItemEvent.class, e -> {
            EntityPickupItemEvent x = (EntityPickupItemEvent) e;
            Entity en = x.getEntity();
            return m("entity", en, "player", en instanceof Player ? en : null,
                    "item", x.getItem().getItemStack().getType().name());
        });
        put("bucket", PlayerBucketEmptyEvent.class, e -> {
            PlayerBucketEmptyEvent x = (PlayerBucketEmptyEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlock());
        });
        put("spawn", CreatureSpawnEvent.class, e -> {
            CreatureSpawnEvent x = (CreatureSpawnEvent) e;
            return m("entity", x.getEntity(), "loc", x.getLocation(), "reason", x.getSpawnReason().name());
        });
        put("target", EntityTargetLivingEntityEvent.class, e -> {
            EntityTargetLivingEntityEvent x = (EntityTargetLivingEntityEvent) e;
            return m("entity", x.getEntity(), "target", x.getTarget(), "player",
                    x.getTarget() instanceof Player ? x.getTarget() : null);
        });
        put("world-change", PlayerChangedWorldEvent.class, e -> {
            PlayerChangedWorldEvent x = (PlayerChangedWorldEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom().getName());
        });
    }
}
