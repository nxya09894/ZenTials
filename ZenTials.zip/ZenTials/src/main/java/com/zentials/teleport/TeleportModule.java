package com.zentials.teleport;

import com.zentials.ZenTials;
import com.zentials.api.EconomyApi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Native port of teleport.ryu: /tp menu (warps, public warps, player requests, random teleport,
 * saved places, death location, settings, staff panel), plus /spawn /back /rtp /warps /places /tpa /tpahere.
 * Staff permission: tp.admin (same as the old script). Staff keep the vanilla /tp for coordinates.
 * Data: plugins/ZenTials/modules/teleport/data.yml. Prices and limits are edited in the staff panel.
 */
public final class TeleportModule implements ZModule, Listener, TabExecutor {
    static final String TAG = "&d[TP]&f ";

    record Req(String mode, String name, long stamp) {
    }

    private static final class Warm {
        Location dest;
        String label;
        double fee;
        UUID payee;
        int cd;
        String wid;
        UUID refundU;
        double refundAmt;
        Location start;
        double hp;
        int left;
        BukkitTask task;
    }

    final ZenTials plugin;
    final TeleportData data;
    private TeleportGui gui;

    final Map<UUID, Map<UUID, Req>> requests = new ConcurrentHashMap<>();
    final Set<UUID> bypass = ConcurrentHashMap.newKeySet();
    final Map<UUID, String> mode = new ConcurrentHashMap<>();
    final Map<UUID, String> filter = new ConcurrentHashMap<>();
    private final Map<UUID, Warm> warming = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Location> lastLoc = new ConcurrentHashMap<>();
    private final Set<UUID> searching = ConcurrentHashMap.newKeySet();
    private final Queue<Location> pool = new ConcurrentLinkedQueue<>();
    private boolean poolBusy;
    private BukkitTask poolTask;

    public TeleportModule(ZenTials plugin) {
        this.plugin = plugin;
        this.data = new TeleportData(plugin);
    }

    @Override
    public String id() {
        return "teleport";
    }

    @Override
    public void enable() {
        data.load();
        gui = new TeleportGui(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (String n : new String[]{"tp", "warps", "pwarps", "rtp", "places", "tpaccept", "tpdeny", "tpa", "tpahere",
                "spawn", "setspawn", "back", "warp", "death", "tptoggle"}) {
            PluginCommand c = plugin.getCommand(n);
            if (c != null) {
                c.setExecutor(this);
                c.setTabCompleter(this);
            }
        }
        poolTask = Bukkit.getScheduler().runTaskTimer(plugin, this::fillPool, 100L, 40L);
    }

    @Override
    public void disable() {
        if (poolTask != null) poolTask.cancel();
        for (Warm w : warming.values()) if (w.task != null) w.task.cancel();
        warming.clear();
        data.saveNow();
    }

    @Override
    public void reload() {
        data.saveNow();
        data.load();
    }

    // ---------------------------------------------------------------- small helpers

    EconomyApi eco() {
        return plugin.economyApi();
    }

    String money(double v) {
        return eco() == null ? String.valueOf((long) v) : eco().format(v);
    }

    double balance(Player p) {
        return eco() == null ? Double.MAX_VALUE : eco().balance(p.getUniqueId());
    }

    boolean withdraw(Player p, double amt, String why) {
        return eco() == null || eco().withdraw(p.getUniqueId(), amt, why);
    }

    void deposit(UUID u, double amt, String why) {
        if (eco() != null && amt > 0) eco().deposit(u, amt, why);
    }

    String price(double n) {
        return n <= 0 ? "&aFree" : "&a" + money(n);
    }

    boolean staff(Player p) {
        return p.hasPermission("tp.admin");
    }

    boolean bypassOn(Player p) {
        return staff(p) && bypass.contains(p.getUniqueId());
    }

    void msg(Player p, String m) {
        Text.send(p, TAG + m);
    }

    void err(Player p, String m) {
        Text.send(p, TAG + "&c" + m);
        plugin.sfx().play(p, "error");
    }

    void sfx(Player p, String k) {
        plugin.sfx().play(p, k);
    }

    Player findPlayer(String n) {
        String low = n.toLowerCase(Locale.ROOT);
        for (Player q : Bukkit.getOnlinePlayers()) if (q.getName().equalsIgnoreCase(low)) return q;
        for (Player q : Bukkit.getOnlinePlayers()) if (q.getName().toLowerCase(Locale.ROOT).startsWith(low)) return q;
        return null;
    }

    private long cdLeft(UUID u, String key) {
        Map<String, Long> m = cooldowns.get(u);
        Long t = m == null ? null : m.get(key);
        if (t == null) return 0;
        long left = (t - System.currentTimeMillis() + 999) / 1000;
        return Math.max(0, left);
    }

    private void cdUse(UUID u, String key, int secs) {
        cooldowns.computeIfAbsent(u, k -> new ConcurrentHashMap<>()).put(key, System.currentTimeMillis() + secs * 1000L);
    }

    private void cdReset(UUID u, String key) {
        Map<String, Long> m = cooldowns.get(u);
        if (m != null) m.remove(key);
    }

    World overworld() {
        for (World w : Bukkit.getWorlds()) if (w.getEnvironment() == World.Environment.NORMAL) return w;
        return Bukkit.getWorlds().get(0);
    }

    // ---------------------------------------------------------------- teleport engine

    boolean canGo(Player p) {
        if (warming.containsKey(p.getUniqueId())) {
            err(p, "You are already teleporting.");
            return false;
        }
        long left = cdLeft(p.getUniqueId(), "tp");
        if (left > 0 && !bypassOn(p)) {
            err(p, "Teleport cooldown: &f" + left + "s&c left.");
            return false;
        }
        return true;
    }

    private void refund(UUID u, double amt) {
        if (u != null && amt > 0) deposit(u, amt, "Teleport request refund");
    }

    void goSimple(Player p, Location dest, String label, double fee, UUID payee, int cd) {
        go(p, dest, label, fee, payee, cd, "", null, 0);
    }

    void go(Player p, Location dest, String label, double fee, UUID payee, int cd, String wid, UUID refundU, double refundAmt) {
        UUID u = p.getUniqueId();
        if (dest == null || dest.getWorld() == null) {
            err(p, "That place isn't available (its world isn't loaded).");
            refund(refundU, refundAmt);
            return;
        }
        if (!canGo(p)) {
            refund(refundU, refundAmt);
            return;
        }
        if (fee > 0 && balance(p) < fee) {
            err(p, "Insufficient funds. You need &e" + money(fee) + "&c.");
            refund(refundU, refundAmt);
            return;
        }
        Warm w = new Warm();
        w.dest = dest;
        w.label = label;
        w.fee = fee;
        w.payee = payee;
        w.cd = cd;
        w.wid = wid;
        w.refundU = refundU;
        w.refundAmt = refundAmt;
        w.start = p.getLocation();
        w.hp = p.getHealth();
        warming.put(u, w);
        int wu = (int) Math.round(data.cfg("warmup"));
        if (wu <= 0) {
            finish(p);
            return;
        }
        w.left = wu;
        msg(p, "&eTeleporting to &b" + label + "&e in &f" + wu + "&es. &7Don't move or take damage!");
        sfx(p, "click");
        bar(p, w);
        w.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(p, w), 20L, 20L);
    }

    private void bar(Player p, Warm w) {
        p.sendActionBar(Text.c("&eTeleporting to &b" + w.label + " &7in &f" + w.left + "s &8| &7Don't move"));
        sfx(p, "tick");
    }

    private void tick(Player p, Warm w) {
        UUID u = p.getUniqueId();
        if (warming.get(u) != w) {
            w.task.cancel();
            return;
        }
        boolean ok = p.isOnline();
        if (ok) {
            Location now = p.getLocation();
            if (now.getWorld() != w.start.getWorld() || now.distance(w.start) > 1.5) ok = false;
            else if (p.getHealth() < w.hp) ok = false;
        }
        if (!ok) {
            cancelWarm(u);
            if (p.isOnline()) {
                msg(p, "&cTeleport cancelled.");
                sfx(p, "error");
            }
            refund(w.refundU, w.refundAmt);
            return;
        }
        if (w.left <= 1) {
            w.task.cancel();
            finish(p);
        } else {
            w.left--;
            bar(p, w);
        }
    }

    private void cancelWarm(UUID u) {
        Warm w = warming.remove(u);
        if (w != null && w.task != null) w.task.cancel();
    }

    private void finish(Player p) {
        UUID u = p.getUniqueId();
        Warm w = warming.get(u);
        if (w == null) return;
        if (w.fee > 0) {
            boolean paid;
            if (w.payee != null && eco() != null) {
                paid = eco().transfer(u, w.payee, w.fee, "Warp visit: " + w.label);
                if (paid) {
                    Player owner = Bukkit.getPlayer(w.payee);
                    if (owner != null) {
                        msg(owner, "&a" + p.getName() + " paid &e" + money(w.fee) + " &ato visit &f" + w.label + "&a.");
                        sfx(owner, "cash");
                    }
                }
            } else {
                paid = withdraw(p, w.fee, "Teleport: " + w.label);
            }
            if (!paid) {
                warming.remove(u);
                err(p, "Payment failed. Teleport cancelled.");
                refund(w.refundU, w.refundAmt);
                return;
            }
            msg(p, "&7Paid &e" + money(w.fee) + "&7.");
            sfx(p, "cash");
        }
        Location from = p.getLocation();
        p.teleportAsync(w.dest).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            warming.remove(u);
            if (!ok) {
                err(p, "Teleport failed.");
                return;
            }
            lastLoc.put(u, from);
            sfx(p, "tp");
            p.showTitle(Title.title(Text.c("&b" + w.label), Text.c("&7Teleported")));
            arriveBar(p, w.label, 3);
            if (!w.wid.isEmpty()) {
                TeleportData.Warp wp = data.warps.get(w.wid);
                if (wp != null) {
                    wp.visits++;
                    data.markDirty();
                }
            }
            if (w.cd > 0) cdUse(u, "tp", w.cd);
        }));
    }

    private void arriveBar(Player p, String label, int n) {
        if (n <= 0 || !p.isOnline()) return;
        p.sendActionBar(Text.c("&aTeleported to &b" + label));
        Bukkit.getScheduler().runTaskLater(plugin, () -> arriveBar(p, label, n - 1), 20L);
    }

    void staffGo(Player p, Player t) {
        if (!staff(p)) return;
        if (t.getUniqueId().equals(p.getUniqueId())) {
            msg(p, "&cYou can't teleport to yourself.");
            return;
        }
        Location from = p.getLocation();
        p.teleportAsync(t.getLocation()).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!ok) return;
            lastLoc.put(p.getUniqueId(), from);
            sfx(p, "tp");
            msg(p, "&aTeleported to &b" + t.getName() + "&a. &7(staff bypass)");
        }));
    }

    int cdSecs() {
        return (int) Math.round(data.cfg("tp_cd"));
    }

    // ---------------------------------------------------------------- warps, death, spawn, back

    void visitWarp(Player p, String id) {
        TeleportData.Warp w = data.warps.get(id);
        if (w == null) {
            err(p, "That warp no longer exists.");
            return;
        }
        Location dest = w.loc.loc();
        if (dest == null) {
            err(p, "That warp's world isn't loaded.");
            return;
        }
        double fee = w.price;
        UUID payee = null;
        if (w.type.equals("player")) {
            try {
                payee = UUID.fromString(w.owner);
            } catch (IllegalArgumentException ignored) {
                payee = null;
            }
            if (p.getUniqueId().equals(payee)) fee = 0;
        }
        if (staff(p)) fee = 0;
        go(p, dest, w.name, fee, payee, cdSecs(), id, null, 0);
    }

    boolean canEdit(Player p, String id) {
        TeleportData.Warp w = data.warps.get(id);
        if (w == null) return false;
        if (staff(p)) return true;
        return w.type.equals("player") && w.owner.equals(p.getUniqueId().toString());
    }

    /** Public entry for other modules (graves): warm-up, cooldown and fee like every other teleport. */
    public void goTo(Player p, Location dest, String label, double fee) {
        goSimple(p, dest, label, bypassOn(p) ? 0 : fee, null, cdSecs());
    }

    void deathBack(Player p) {
        var gm = plugin.graves();
        if (gm != null) {
            Location spot = gm.teleportSpot(p.getUniqueId());
            if (spot != null) {
                goSimple(p, spot, "Your Grave", 0, null, cdSecs());
                return;
            }
        }
        TeleportData.Pos d = data.deaths.get(p.getUniqueId());
        Location l = d == null ? null : d.loc();
        if (l == null) {
            err(p, "You have no death location yet.");
            return;
        }
        if (gm != null) {
            Location safe = gm.safeSpot(l);
            l = new Location(safe.getWorld(), safe.getBlockX() + 0.5, safe.getBlockY(), safe.getBlockZ() + 0.5);
        }
        goSimple(p, l, "Last Death Location", 0, null, cdSecs());
    }

    void lastBack(Player p) {
        Location l = lastLoc.get(p.getUniqueId());
        if (l == null) {
            err(p, "Nothing to go back to yet.");
            return;
        }
        goSimple(p, l, "Previous Location", 0, null, cdSecs());
    }

    void spawn(Player p) {
        Location l = data.spawn == null ? null : data.spawn.loc();
        if (l == null) l = overworld().getSpawnLocation().add(0.5, 0, 0.5);
        goSimple(p, l, "Spawn", 0, null, cdSecs());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getPlayer();
        data.deaths.put(p.getUniqueId(), TeleportData.Pos.of(p.getLocation()));
        lastLoc.put(p.getUniqueId(), p.getLocation());
        data.markDirty();
    }

    /** Vanilla /teleport is registered before plugins, so aliases can't take it. Route it to /tp here. */
    @EventHandler(priority = org.bukkit.event.EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleportCommand(PlayerCommandPreprocessEvent e) {
        String raw = e.getMessage().trim();
        String low = raw.toLowerCase(Locale.ROOT);
        if (!low.equals("/teleport") && !low.startsWith("/teleport ")) return;
        e.setCancelled(true);
        String rest = raw.length() > 9 ? raw.substring(9).trim() : "";
        tp(e.getPlayer(), rest.isEmpty() ? new String[0] : rest.split("\\s+"));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        cancelWarm(u);
        searching.remove(u);
        bypass.remove(u);
        mode.remove(u);
        filter.remove(u);
        requests.remove(u);
        lastLoc.remove(u);
        cooldowns.remove(u);
    }

    // ---------------------------------------------------------------- random teleport

    private void fillPool() {
        if (poolBusy || Bukkit.getOnlinePlayers().isEmpty() || pool.size() >= 4) return;
        World w = overworld();
        int r = (int) Math.max(100, Math.min(10000, Math.round(data.cfg("rtp_radius"))));
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int x = rnd.nextInt(-r, r + 1);
        int z = rnd.nextInt(-r, r + 1);
        poolBusy = true;
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(plugin, () -> {
            poolBusy = false;
            Location l = safeSpot(w, x, z);
            if (l != null) pool.add(l);
        })).exceptionally(t -> {
            poolBusy = false;
            return null;
        });
    }

    private Location safeSpot(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z);
        if (y <= w.getMinHeight()) return null;
        Material g = w.getBlockAt(x, y, z).getType();
        if (!g.isSolid() || g == Material.CACTUS || g == Material.MAGMA_BLOCK || g == Material.POWDER_SNOW
                || g == Material.SWEET_BERRY_BUSH || g == Material.CAMPFIRE || g == Material.SOUL_CAMPFIRE) {
            return null;
        }
        if (!w.getBlockAt(x, y + 1, z).isPassable() || !w.getBlockAt(x, y + 2, z).isPassable()) return null;
        if (w.getBlockAt(x, y + 1, z).isLiquid()) return null;
        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }

    void doRandom(Player p) {
        UUID u = p.getUniqueId();
        if (searching.contains(u)) {
            msg(p, "&cAlready searching for a spot.");
            return;
        }
        if (!canGo(p)) return;
        long rcd = cdLeft(u, "rtp");
        if (rcd > 0 && !bypassOn(p)) {
            err(p, "Random teleport cooldown: &f" + rcd + "s&c left.");
            return;
        }
        double cost = Math.round(data.cfg("rtp_cost"));
        if (bypassOn(p)) cost = 0;
        if (cost > 0 && balance(p) < cost) {
            err(p, "Insufficient funds. You need &e" + money(cost) + "&c.");
            return;
        }
        searching.add(u);
        msg(p, "&7Searching for a safe spot...");
        rtpWait(p, 30, cost);
    }

    private void rtpWait(Player p, int tries, double cost) {
        UUID u = p.getUniqueId();
        if (!p.isOnline()) {
            searching.remove(u);
            return;
        }
        Location dest = pool.poll();
        if (dest != null) {
            searching.remove(u);
            int rcd = (int) Math.round(data.cfg("rtp_cd"));
            if (!bypassOn(p) && rcd > 0) cdUse(u, "rtp", rcd);
            goSimple(p, dest, "Random Spot (" + dest.getWorld().getName() + ")", cost, null, cdSecs());
            return;
        }
        if (tries <= 0) {
            searching.remove(u);
            err(p, "Couldn't find a safe spot. Try again.");
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> rtpWait(p, tries - 1, cost), 10L);
    }

    // ---------------------------------------------------------------- player requests

    void sendRequest(Player p, UUID tu, String rmode) {
        UUID u = p.getUniqueId();
        Player t = Bukkit.getPlayer(tu);
        if (t == null) {
            err(p, "That player is no longer online.");
            return;
        }
        if (tu.equals(u)) {
            msg(p, "&cYou can't request yourself.");
            return;
        }
        if (cdLeft(u, "tpreq") > 0) {
            err(p, "Slow down before sending another request.");
            return;
        }
        if (data.noReq.contains(tu)) {
            err(p, t.getName() + " isn't accepting teleport requests.");
            return;
        }
        Map<UUID, String> ign = data.ignore.get(tu);
        if (ign != null && ign.containsKey(u)) {
            msg(p, "&aTeleport request sent to &e" + t.getName() + "&a."); // ignored players are not told
            return;
        }
        Map<UUID, Req> rq = requests.computeIfAbsent(tu, k -> new LinkedHashMap<>());
        if (rq.containsKey(u)) {
            err(p, "You already have a pending request to that player.");
            return;
        }
        double fee = data.cfg("tpa_cost");
        if (fee > 0 && balance(p) < fee) {
            err(p, "Insufficient funds. You need &e" + money(fee) + "&c.");
            return;
        }
        long stamp = System.currentTimeMillis();
        rq.put(u, new Req(rmode, p.getName(), stamp));
        cdUse(u, "tpreq", 10);
        int ex = (int) Math.round(data.cfg("req_expire"));
        String what = rmode.equals("here") ? "wants you to teleport to them" : "wants to teleport to you";
        msg(p, "&aTeleport request sent to &e" + t.getName() + "&a. &7Expires in " + ex + "s.");
        sfx(p, "click");
        msg(t, "&e" + p.getName() + " &7" + what + ". &7Choose in the menu, or use &a/tpaccept &7| &c/tpdeny");
        sfx(t, "confirm");
        String title = PlainTextComponentSerializer.plainText().serialize(t.getOpenInventory().title());
        if (!title.contains("REQUEST")) gui.openRequest(t, u);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Map<UUID, Req> m = requests.get(tu);
            Req r = m == null ? null : m.get(u);
            if (r == null || r.stamp() != stamp) return;
            m.remove(u);
            cdReset(u, "tpreq");
            Player pl = Bukkit.getPlayer(u);
            if (pl != null) msg(pl, "&cYour teleport request expired.");
        }, ex * 20L);
    }

    void respond(Player t, UUID ru, String action) {
        UUID tu = t.getUniqueId();
        Map<UUID, Req> rq = requests.get(tu);
        Req r = rq == null ? null : rq.get(ru);
        if (r == null) {
            err(t, "That request has expired.");
            nextRequest(t);
            return;
        }
        rq.remove(ru);
        cdReset(ru, "tpreq");
        Player req = Bukkit.getPlayer(ru);
        if (action.equals("accept")) {
            if (req == null) {
                err(t, "That player is no longer online.");
                nextRequest(t);
                return;
            }
            msg(req, "&a" + t.getName() + " accepted your teleport request.");
            sfx(req, "success");
            t.closeInventory();
            double fee = data.cfg("tpa_cost");
            if (r.mode().equals("to")) {
                goSimple(req, t.getLocation(), t.getName(), fee, null, cdSecs());
            } else {
                if (fee > 0) {
                    if (!withdraw(req, fee, "Teleport request")) {
                        err(req, "You can't afford the &e" + money(fee) + " &cteleport fee.");
                        msg(t, "&c" + req.getName() + " can't afford the teleport fee.");
                        return;
                    }
                    msg(req, "&7Paid &e" + money(fee) + "&7.");
                }
                go(t, req.getLocation(), req.getName(), 0, null, cdSecs(), "", ru, fee);
            }
            return;
        }
        if (action.equals("ignore")) {
            data.ignore.computeIfAbsent(tu, k -> new LinkedHashMap<>()).put(ru, r.name());
            data.markDirty();
            msg(t, "&7You are now ignoring requests from &f" + r.name() + "&7. Undo it in &f/tp settings&7.");
        } else {
            msg(t, "&7Request denied.");
            if (req != null) msg(req, "&c" + t.getName() + " denied your teleport request.");
        }
        sfx(t, "back");
        nextRequest(t);
    }

    void nextRequest(Player t) {
        Map<UUID, Req> rq = requests.get(t.getUniqueId());
        if (rq != null && !rq.isEmpty()) {
            gui.openRequest(t, rq.keySet().iterator().next());
        } else {
            t.closeInventory();
            msg(t, "&7You have no pending requests.");
        }
    }

    private void answerFirst(Player p, String action) {
        Map<UUID, Req> rq = requests.get(p.getUniqueId());
        if (rq == null || rq.isEmpty()) {
            msg(p, "&7You have no pending requests.");
            return;
        }
        respond(p, rq.keySet().iterator().next(), action);
    }

    int pending(Player p) {
        Map<UUID, Req> rq = requests.get(p.getUniqueId());
        return rq == null ? 0 : rq.size();
    }

    // ---------------------------------------------------------------- commands

    private static String join(String[] a, int from) {
        return String.join(" ", java.util.Arrays.copyOfRange(a, from, a.length));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String cmd = c.getName().toLowerCase(Locale.ROOT);
        if (!(s instanceof Player p)) {
            if (cmd.equals("tp") && a.length > 0) {
                Bukkit.dispatchCommand(s, "minecraft:tp " + join(a, 0));
            } else {
                s.sendMessage(Text.c(TAG + "&cOnly players can use this."));
            }
            return true;
        }
        switch (cmd) {
            case "tp" -> tp(p, a);
            case "warps" -> gui.openWarpList(p, "player", 1);
            case "pwarps" -> gui.openWarpList(p, "server", 1);
            case "rtp" -> doRandom(p); // direct, no menu
            case "warp" -> {
                if (a.length < 1) {
                    gui.openWarpList(p, "player", 1);
                    return true;
                }
                String q = join(a, 0);
                TeleportData.Warp best = null;
                for (TeleportData.Warp w : data.warps.values()) {
                    if (!w.isPublic && !staff(p) && !w.owner.equals(p.getUniqueId().toString())) continue;
                    if (w.name.equalsIgnoreCase(q)) {
                        best = w;
                        break;
                    }
                    if (best == null && w.name.toLowerCase(Locale.ROOT).startsWith(q.toLowerCase(Locale.ROOT))) best = w;
                }
                if (best == null) err(p, "No warp named &f" + q + "&c. Open &f/warps &cto browse.");
                else visitWarp(p, best.id);
            }
            case "death" -> deathBack(p);
            case "tptoggle" -> {
                boolean off = data.noReq.add(p.getUniqueId());
                if (!off) data.noReq.remove(p.getUniqueId());
                data.markDirty();
                msg(p, off ? "&cTeleport requests: OFF" : "&aTeleport requests: ON");
            }
            case "places" -> {
                if (a.length < 1) {
                    gui.openPlaces(p);
                    return true;
                }
                var pl = data.placesOf(p.getUniqueId());
                String q = join(a, 0);
                TeleportData.Place hit = null;
                try {
                    hit = pl.get(Integer.parseInt(q));
                } catch (NumberFormatException ignored) {
                    for (TeleportData.Place x : pl.values()) if (x.name.equalsIgnoreCase(q)) hit = x;
                }
                if (hit == null) err(p, "No saved place &f" + q + "&c. Open &f/places&c.");
                else goSimple(p, hit.loc.loc(), hit.name, 0, null, cdSecs());
            }
            case "tpaccept" -> answerFirst(p, "accept");
            case "tpdeny" -> answerFirst(p, "deny");
            case "tpa", "tpahere" -> {
                if (a.length < 1) {
                    gui.openPlayerPicker(p);
                    return true;
                }
                Player t = findPlayer(a[0]);
                if (t == null) err(p, "That player is not online.");
                else sendRequest(p, t.getUniqueId(), cmd.equals("tpahere") ? "here" : "to");
            }
            case "spawn" -> spawn(p);
            case "back" -> lastBack(p);
            case "setspawn" -> {
                if (!p.hasPermission("zentials.spawn.set") && !staff(p)) {
                    err(p, "You don't have permission.");
                    return true;
                }
                data.spawn = TeleportData.Pos.of(p.getLocation());
                data.markDirty();
                msg(p, "&aSpawn saved.");
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private void tp(Player p, String[] a) {
        if (a.length == 0) {
            gui.openMain(p);
            return;
        }
        String k = a[0].toLowerCase(Locale.ROOT);
        switch (k) {
            case "warps" -> gui.openWarpList(p, "player", 1);
            case "pwarps" -> gui.openWarpList(p, "server", 1);
            case "player" -> gui.openPlayerPicker(p);
            case "random" -> gui.openRandom(p);
            case "places" -> gui.openPlaces(p);
            case "back" -> deathBack(p);
            case "settings" -> gui.openSettings(p);
            case "requests" -> nextRequest(p);
            case "accept" -> answerFirst(p, "accept");
            case "deny" -> answerFirst(p, "deny");
            case "admin" -> {
                if (!staff(p)) {
                    err(p, "You don't have permission.");
                    return;
                }
                if (a.length > 1) {
                    Player t = findPlayer(a[1]);
                    if (t == null) err(p, "That player is not online.");
                    else staffGo(p, t);
                    return;
                }
                gui.openAdmin(p);
            }
            default -> {
                if (staff(p)) Bukkit.dispatchCommand(p, "minecraft:tp " + join(a, 0)); // vanilla /tp for staff
                else gui.openMain(p);
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String cmd = c.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("tp") && a.length == 1) {
            out.addAll(List.of("warps", "pwarps", "player", "random", "places", "back", "settings", "requests"));
            if (s.hasPermission("tp.admin")) out.add("admin");
        }
        if ((cmd.equals("tpa") || cmd.equals("tpahere") || cmd.equals("tp")) && a.length >= 1) {
            if (a.length == 1 || (a[0].equalsIgnoreCase("admin") && a.length == 2)) {
                for (Player o : Bukkit.getOnlinePlayers()) out.add(o.getName());
            }
        }
        if (a.length == 1 && cmd.equals("warp")) {
            for (TeleportData.Warp w : data.warps.values()) if (w.isPublic) out.add(w.name);
        }
        if (a.length == 1 && cmd.equals("places") && s instanceof Player pp) {
            for (TeleportData.Place x : data.placesOf(pp.getUniqueId()).values()) out.add(x.name);
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
