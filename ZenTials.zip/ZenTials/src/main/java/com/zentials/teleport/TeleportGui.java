package com.zentials.teleport;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Consumer;

/** All GUI screens of the teleport module (port of teleport.ryu). */
final class TeleportGui {
    private static final int MAX_PLACES = 10;
    private static final int SELL_PCT = 30;
    private static final int PAGE = 45;

    private final TeleportModule m;
    private final TeleportData d;

    TeleportGui(TeleportModule m) {
        this.m = m;
        this.d = m.data;
    }

    private static Gui gui(String title, int rows) {
        return new Gui(Text.c(title), rows);
    }

    private void fill(Gui g, int rows) {
        for (int i = 0; i < rows * 9; i++) g.set(i, Items.of(Material.GRAY_STAINED_GLASS_PANE, " "), e -> {
        });
    }

    private void click(Player p, String k) {
        m.sfx(p, k);
    }

    private void ask(Player p, String prompt, Consumer<String> ok, Runnable back) {
        p.closeInventory();
        m.msg(p, prompt + " &7(type &ccancel&7 to stop)");
        m.plugin.prompts().ask(p, s -> Bukkit.getScheduler().runTask(m.plugin, () -> ok.accept(s.trim())),
                () -> Bukkit.getScheduler().runTask(m.plugin, back));
    }

    private static Material catIcon(String c) {
        return switch (c) {
            case "Farm" -> Material.WHEAT;
            case "Mob Farm" -> Material.BONE;
            case "Shop" -> Material.EMERALD;
            case "Build" -> Material.BRICKS;
            case "Resources" -> Material.IRON_PICKAXE;
            case "PvP" -> Material.IRON_SWORD;
            case "Event" -> Material.NETHER_STAR;
            default -> Material.ENDER_PEARL;
        };
    }

    private static Double parse(String s) {
        try {
            double v = Double.parseDouble(s.replace(",", ""));
            return Double.isNaN(v) || Double.isInfinite(v) ? null : v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- main hub

    void openMain(Player p) {
        Gui g = gui("&5&lTELEPORT", 4);
        fill(g, 4);
        int pend = m.pending(p);
        g.set(10, Items.of(Material.COMPASS, "&bWarps", "&7Player-made warps", "&eClick to browse"), e -> {
            click(p, "click");
            openWarpList(p, "player", 1);
        });
        g.set(11, Items.of(Material.BEACON, "&6Public Warps", "&7Official server warps", "&eClick to browse"), e -> {
            click(p, "click");
            openWarpList(p, "server", 1);
        });
        g.set(12, Items.of(Material.PLAYER_HEAD, "&aTeleport to Player", "&7Send a request to someone", "&eClick to choose"), e -> {
            click(p, "click");
            openPlayerPicker(p);
        });
        g.set(13, Items.of(Material.ENDER_EYE, "&dRandom Teleport", "&7Cost: " + m.price(d.cfg("rtp_cost")), "&eClick to open"), e -> {
            click(p, "click");
            openRandom(p);
        });
        g.set(14, Items.of(Material.RED_BED, "&eSaved Places", "&7Your personal spots", "&eClick to open"), e -> {
            click(p, "click");
            openPlaces(p);
        });
        g.set(15, Items.of(Material.SKELETON_SKULL, "&cLast Death Location", "&7Teleports on top of your grave", "&eClick to go back"), e -> {
            click(p, "click");
            p.closeInventory();
            m.deathBack(p);
        });
        g.set(16, Items.of(Material.WRITABLE_BOOK, "&fSettings", "&7Request & ignore options"), e -> {
            click(p, "click");
            openSettings(p);
        });
        g.set(19, Items.of(Material.NETHER_STAR, "&bSpawn", "&7/spawn"), e -> {
            click(p, "click");
            p.closeInventory();
            m.spawn(p);
        });
        g.set(20, Items.of(Material.CLOCK, "&bPrevious Location", "&7/back"), e -> {
            click(p, "click");
            p.closeInventory();
            m.lastBack(p);
        });
        if (pend > 0) {
            g.set(22, Items.of(Material.PAPER, "&e" + pend + " Pending Request(s)", "&eClick to answer"), e -> m.nextRequest(p));
        }
        if (m.plugin.graves() != null) {
            g.set(21, Items.of(Material.PLAYER_HEAD, "&cMy Graves", "&7All your graves"), e -> {
                click(p, "click");
                p.closeInventory();
                Bukkit.dispatchCommand(p, "graves");
            });
        }
        g.set(24, Items.of(Material.BOOK, "&fAll Commands", "&7Quick command panel"), e -> {
            click(p, "click");
            p.closeInventory();
            Bukkit.dispatchCommand(p, "menu");
        });
        if (m.staff(p)) {
            g.set(25, Items.of(Material.COMMAND_BLOCK, "&cStaff Panel", "&7Settings, warps, stats"), e -> {
                click(p, "click");
                openAdmin(p);
            });
        }
        g.set(31, Items.of(Material.BARRIER, "&cClose"), e -> p.closeInventory());
        g.open(p);
        click(p, "open");
    }

    // ---------------------------------------------------------------- warp list

    void openWarpList(Player p, String md, int page) {
        UUID u = p.getUniqueId();
        m.mode.put(u, md);
        String flt = m.filter.getOrDefault(u, "All");
        boolean mine = md.equals("mine");
        boolean admin = md.startsWith("admin");
        String type = md.equals("server") || md.equals("adminserver") ? "server" : "player";
        List<TeleportData.Warp> list = new ArrayList<>();
        for (TeleportData.Warp w : d.warps.values()) {
            if (mine) {
                if (!w.type.equals("player") || !w.owner.equals(u.toString())) continue;
            } else {
                if (!w.type.equals(type)) continue;
                if (!admin && !w.isPublic) continue;
            }
            if (!flt.equals("All") && !w.cat.equals(flt)) continue;
            list.add(w);
        }
        list.sort((a, b) -> Integer.compare(b.visits, a.visits));
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        int pg = Math.max(1, Math.min(page, pages));
        String title = switch (md) {
            case "server" -> "&6&lPUBLIC WARPS";
            case "mine" -> "&b&lMY WARPS";
            case "adminserver" -> "&c&lSERVER WARPS (STAFF)";
            case "adminplayer" -> "&c&lPLAYER WARPS (STAFF)";
            default -> "&b&lWARPS";
        };
        Gui g = gui(title + " &8" + pg + "/" + pages, 6);
        for (int i = 0; i < PAGE; i++) {
            int idx = (pg - 1) * PAGE + i;
            if (idx >= list.size()) break;
            TeleportData.Warp w = list.get(idx);
            List<String> lore = new ArrayList<>();
            lore.add("&7" + w.desc);
            lore.add("&7Category: &f" + w.cat);
            lore.add("&7By: &f" + w.ownerName);
            lore.add("&7Price: " + m.price(w.price));
            lore.add("&7Visits: &f" + w.visits);
            if (!w.isPublic) lore.add("&cHidden (not public)");
            boolean edit = m.canEdit(p, w.id) && (mine || admin);
            lore.add(edit ? "&eLeft-click: go  &8|  &eRight-click: edit" : "&eClick to teleport");
            g.set(i, Items.of(catIcon(w.cat), "&b" + w.name, lore.toArray(new String[0])), e -> {
                if (e.isRightClick() && edit) {
                    click(p, "click");
                    openWarpEdit(p, w.id);
                } else {
                    p.closeInventory();
                    m.visitWarp(p, w.id);
                }
            });
        }
        if (pg > 1) g.set(45, Items.of(Material.ARROW, "&ePrevious"), e -> openWarpList(p, md, pg - 1));
        if (pg < pages) g.set(53, Items.of(Material.ARROW, "&eNext"), e -> openWarpList(p, md, pg + 1));
        g.set(46, Items.of(Material.HOPPER, "&fFilter: &e" + flt, "&7Click to cycle"), e -> {
            m.filter.put(u, TeleportData.nextFilter(flt));
            click(p, "click");
            openWarpList(p, md, 1);
        });
        if (!admin) {
            g.set(47, Items.of(Material.CHEST, mine ? "&bAll Warps" : "&bMy Warps", "&7Warps you created"), e -> {
                click(p, "click");
                openWarpList(p, mine ? "player" : "mine", 1);
            });
            double cost = d.cfg("warp_create_cost");
            g.set(48, Items.of(Material.LIME_DYE, "&aCreate Warp Here", "&7Cost: " + m.price(cost),
                    "&7Limit: &f" + d.countOwned(u) + "/" + (int) d.cfg("warp_max")), e -> createWarp(p));
        } else {
            g.set(48, Items.of(Material.LIME_DYE, "&aCreate Server Warp Here"), e -> createServerWarp(p));
        }
        g.set(49, Items.of(Material.BARRIER, "&cBack"), e -> {
            click(p, "back");
            if (admin) openAdmin(p);
            else openMain(p);
        });
        g.open(p);
        click(p, "open");
    }

    private void createWarp(Player p) {
        UUID u = p.getUniqueId();
        if (!m.staff(p) && d.countOwned(u) >= (int) d.cfg("warp_max")) {
            m.err(p, "You reached the warp limit (&f" + (int) d.cfg("warp_max") + "&c).");
            return;
        }
        double cost = m.staff(p) ? 0 : d.cfg("warp_create_cost");
        if (cost > 0 && m.balance(p) < cost) {
            m.err(p, "Insufficient funds. You need &e" + m.money(cost) + "&c.");
            return;
        }
        ask(p, "&eType a name for your warp.", s -> {
            if (s.isEmpty() || s.length() > 24) {
                m.err(p, "Name must be 1-24 characters.");
                openWarpList(p, "mine", 1);
                return;
            }
            if (cost > 0 && !m.withdraw(p, cost, "Warp creation")) {
                m.err(p, "Payment failed.");
                return;
            }
            TeleportData.Warp w = d.newWarp(u.toString(), p.getName(), s, p.getLocation(), "player");
            m.msg(p, "&aWarp &f" + w.name + " &acreated.");
            m.sfx(p, "success");
            openWarpEdit(p, w.id);
        }, () -> openWarpList(p, "mine", 1));
    }

    private void createServerWarp(Player p) {
        ask(p, "&eType a name for the server warp.", s -> {
            if (s.isEmpty() || s.length() > 24) {
                m.err(p, "Name must be 1-24 characters.");
                return;
            }
            TeleportData.Warp w = d.newWarp("server", "Server", s, p.getLocation(), "server");
            m.msg(p, "&aServer warp &f" + w.name + " &acreated.");
            m.sfx(p, "success");
            openWarpEdit(p, w.id);
        }, () -> openWarpList(p, "adminserver", 1));
    }

    void openWarpEdit(Player p, String id) {
        TeleportData.Warp w = d.warps.get(id);
        if (w == null || !m.canEdit(p, id)) {
            m.err(p, "You can't edit that warp.");
            return;
        }
        boolean server = w.type.equals("server");
        String back = m.staff(p) && !w.owner.equals(p.getUniqueId().toString()) ? (server ? "adminserver" : "adminplayer") : (server ? "adminserver" : "mine");
        Gui g = gui("&6&lEDIT: &f" + w.name, 3);
        fill(g, 3);
        g.set(10, Items.of(Material.NAME_TAG, "&eRename", "&7Current: &f" + w.name), e -> ask(p, "&eNew name?", s -> {
            if (s.isEmpty() || s.length() > 24) m.err(p, "Name must be 1-24 characters.");
            else {
                w.name = s;
                d.markDirty();
            }
            openWarpEdit(p, id);
        }, () -> openWarpEdit(p, id)));
        g.set(11, Items.of(Material.PAPER, "&eDescription", "&7" + w.desc), e -> ask(p, "&eNew description?", s -> {
            if (s.isEmpty() || s.length() > 60) m.err(p, "Description must be 1-60 characters.");
            else {
                w.desc = s;
                d.markDirty();
            }
            openWarpEdit(p, id);
        }, () -> openWarpEdit(p, id)));
        g.set(12, Items.of(catIcon(w.cat), "&eCategory: &f" + w.cat, "&7Click to cycle"), e -> {
            w.cat = TeleportData.nextCat(w.cat);
            d.markDirty();
            click(p, "click");
            openWarpEdit(p, id);
        });
        g.set(13, Items.of(Material.GOLD_INGOT, "&eVisit Price: " + m.price(w.price), "&7Cap: " + (long) d.cfg("warp_visit_cap")), e -> ask(p, "&eNew price? (0 = free)", s -> {
            Double v = parse(s);
            double cap = m.staff(p) ? 1_000_000_000 : d.cfg("warp_visit_cap");
            if (v == null || v < 0 || v > cap) m.err(p, "Price must be 0 - " + (long) cap + ".");
            else {
                w.price = Math.round(v);
                d.markDirty();
            }
            openWarpEdit(p, id);
        }, () -> openWarpEdit(p, id)));
        g.set(14, Items.of(w.isPublic ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
                w.isPublic ? "&aPublic" : "&cHidden", "&7Click to toggle"), e -> {
            w.isPublic = !w.isPublic;
            d.markDirty();
            click(p, w.isPublic ? "on" : "off");
            openWarpEdit(p, id);
        });
        g.set(15, Items.of(Material.ENDER_PEARL, "&eMove Here", "&7Set location to where you stand"), e -> {
            w.loc = TeleportData.Pos.of(p.getLocation());
            d.markDirty();
            m.msg(p, "&aWarp moved to your location.");
            click(p, "success");
        });
        g.set(16, Items.of(Material.TNT, "&cDelete Warp", "&7Click to delete"), e -> openConfirm(p, "warp", id, 0));
        g.set(22, Items.of(Material.BARRIER, "&cBack"), e -> openWarpList(p, back, 1));
        g.open(p);
        click(p, "open");
    }

    // ---------------------------------------------------------------- confirm

    void openConfirm(Player p, String kind, String ref, int n) {
        Gui g = gui("&c&lCONFIRM", 3);
        fill(g, 3);
        String what = switch (kind) {
            case "warp" -> "Delete this warp?";
            case "placesell" -> "Sell this place for " + m.money(refundOf(p.getUniqueId(), n)) + "?";
            default -> "Overwrite this place with your location?";
        };
        g.set(4, Items.of(Material.PAPER, "&e" + what));
        g.set(11, Items.of(Material.LIME_CONCRETE, "&aConfirm"), e -> {
            UUID u = p.getUniqueId();
            switch (kind) {
                case "warp" -> {
                    d.warps.remove(ref);
                    d.markDirty();
                    m.msg(p, "&7Warp deleted.");
                    m.sfx(p, "delete");
                    openWarpList(p, m.mode.getOrDefault(u, "mine"), 1);
                }
                case "placesell" -> {
                    double r = refundOf(u, n);
                    d.placesOf(u).remove(n);
                    d.markDirty();
                    m.deposit(u, r, "Sold saved place");
                    m.msg(p, "&7Place sold for &e" + m.money(r) + "&7.");
                    m.sfx(p, "cash");
                    openPlaces(p);
                }
                default -> {
                    TeleportData.Place pl = d.placesOf(u).get(n);
                    if (pl != null) {
                        pl.loc = TeleportData.Pos.of(p.getLocation());
                        d.markDirty();
                        m.msg(p, "&aPlace moved here.");
                        m.sfx(p, "success");
                    }
                    openPlaceView(p, n);
                }
            }
        });
        g.set(15, Items.of(Material.RED_CONCRETE, "&cCancel"), e -> {
            click(p, "back");
            if (kind.equals("warp")) openWarpEdit(p, ref);
            else openPlaceView(p, n);
        });
        g.open(p);
    }

    // ---------------------------------------------------------------- player picker / requests

    void openPlayerPicker(Player p) {
        List<Player> list = new ArrayList<>();
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.getUniqueId().equals(p.getUniqueId())) list.add(o);
        Gui g = gui("&a&lTELEPORT TO PLAYER", 6);
        for (int i = 0; i < Math.min(list.size(), 45); i++) {
            Player o = list.get(i);
            g.set(i, Items.head(o, "&a" + o.getName(), "&eClick to choose"), e -> {
                click(p, "click");
                openRequestType(p, o.getUniqueId());
            });
        }
        if (list.isEmpty()) g.set(22, Items.of(Material.BARRIER, "&cNo other players online"));
        g.set(49, Items.of(Material.BARRIER, "&cBack"), e -> openMain(p));
        g.open(p);
        click(p, "open");
    }

    void openRequestType(Player p, UUID tu) {
        Player t = Bukkit.getPlayer(tu);
        if (t == null) {
            m.err(p, "That player is no longer online.");
            return;
        }
        if (m.staff(p)) {
            Gui g = gui("&a&l" + t.getName(), 3);
            fill(g, 3);
            g.set(11, Items.of(Material.ENDER_PEARL, "&bTeleport (Staff)", "&7Instant, no request"), e -> {
                p.closeInventory();
                m.staffGo(p, t);
            });
            g.set(15, Items.of(Material.PAPER, "&eSend Request", "&7Normal request"), e -> openRequestType2(p, tu));
            g.set(22, Items.of(Material.BARRIER, "&cBack"), e -> openPlayerPicker(p));
            g.open(p);
            return;
        }
        openRequestType2(p, tu);
    }

    private void openRequestType2(Player p, UUID tu) {
        Player t = Bukkit.getPlayer(tu);
        if (t == null) return;
        double fee = d.cfg("tpa_cost");
        Gui g = gui("&a&l" + t.getName(), 3);
        fill(g, 3);
        g.set(11, Items.of(Material.ENDER_PEARL, "&aGo to " + t.getName(), "&7You teleport to them", "&7Cost: " + m.price(fee)), e -> {
            p.closeInventory();
            m.sendRequest(p, tu, "to");
        });
        g.set(15, Items.of(Material.ENDER_EYE, "&dBring " + t.getName() + " to me", "&7They teleport to you", "&7Cost: " + m.price(fee)), e -> {
            p.closeInventory();
            m.sendRequest(p, tu, "here");
        });
        g.set(22, Items.of(Material.BARRIER, "&cBack"), e -> openPlayerPicker(p));
        g.open(p);
    }

    void openRequest(Player t, UUID ru) {
        TeleportModule.Req r = null;
        Map<UUID, TeleportModule.Req> rq = m.requests.get(t.getUniqueId());
        if (rq != null) r = rq.get(ru);
        if (r == null) {
            m.nextRequest(t);
            return;
        }
        OfflinePlayer op = Bukkit.getOfflinePlayer(ru);
        String what = r.mode().equals("here") ? "wants you to teleport to them" : "wants to teleport to you";
        Gui g = gui("&e&lTELEPORT REQUEST", 3);
        fill(g, 3);
        g.set(4, Items.head(op, "&e" + r.name(), "&7" + what, "&7Pending: &f" + m.pending(t)));
        g.set(11, Items.of(Material.LIME_CONCRETE, "&aAccept"), e -> m.respond(t, ru, "accept"));
        g.set(13, Items.of(Material.RED_CONCRETE, "&cDeny"), e -> m.respond(t, ru, "deny"));
        g.set(15, Items.of(Material.BARRIER, "&4Deny & Ignore", "&7Stop requests from this player"), e -> m.respond(t, ru, "ignore"));
        g.open(t);
        m.sfx(t, "open");
    }

    // ---------------------------------------------------------------- random

    void openRandom(Player p) {
        Gui g = gui("&d&lRANDOM TELEPORT", 3);
        fill(g, 3);
        g.set(11, Items.of(Material.ENDER_EYE, "&dTeleport Now", "&7Cost: " + m.price(d.cfg("rtp_cost")),
                "&7Radius: &f" + (long) d.cfg("rtp_radius"), "&7Cooldown: &f" + (long) d.cfg("rtp_cd") + "s"), e -> {
            p.closeInventory();
            m.doRandom(p);
        });
        g.set(15, Items.of(Material.BARRIER, "&cBack"), e -> openMain(p));
        g.open(p);
        click(p, "open");
    }

    // ---------------------------------------------------------------- places

    private static int slotOf(int n) {
        return n <= 5 ? n + 1 : n + 5;
    }

    private double refundOf(UUID u, int n) {
        TeleportData.Place pl = d.placesOf(u).get(n);
        double paid = pl == null || pl.paid <= 0 ? d.cfg("place_base") : pl.paid;
        return Math.round(paid * SELL_PCT / 100.0);
    }

    private double placeCost(UUID u) {
        return Math.round(d.cfg("place_base") + d.placesOf(u).size() * d.cfg("place_inc"));
    }

    void openPlaces(Player p) {
        UUID u = p.getUniqueId();
        TreeMap<Integer, TeleportData.Place> pl = d.placesOf(u);
        Gui g = gui("&e&lSAVED PLACES &8" + pl.size() + "/" + MAX_PLACES, 3);
        fill(g, 3);
        for (int n = 1; n <= MAX_PLACES; n++) {
            int slot = slotOf(n);
            TeleportData.Place x = pl.get(n);
            int num = n;
            if (x != null) {
                g.set(slot, Items.of(Material.RED_BED, "&e" + x.name, "&7Slot #" + n, "&eLeft-click: teleport", "&eRight-click: manage"), e -> {
                    if (e.isRightClick()) openPlaceView(p, num);
                    else {
                        p.closeInventory();
                        goPlace(p, num);
                    }
                });
            } else {
                g.set(slot, Items.of(Material.LIGHT_GRAY_DYE, "&7Empty Slot #" + n, "&7Save here for &a" + m.money(placeCost(u)), "&eClick to save"), e -> savePlace(p, num));
            }
        }
        g.set(22, Items.of(Material.BARRIER, "&cBack"), e -> openMain(p));
        g.open(p);
        click(p, "open");
    }

    private void goPlace(Player p, int n) {
        TeleportData.Place x = d.placesOf(p.getUniqueId()).get(n);
        if (x == null) return;
        m.goSimple(p, x.loc.loc(), x.name, 0, null, m.cdSecs());
    }

    private void savePlace(Player p, int n) {
        UUID u = p.getUniqueId();
        double cost = m.staff(p) ? 0 : placeCost(u);
        if (cost > 0 && m.balance(p) < cost) {
            m.err(p, "Insufficient funds. You need &e" + m.money(cost) + "&c.");
            return;
        }
        ask(p, "&eType a name for this place.", s -> {
            if (s.isEmpty() || s.length() > 20) {
                m.err(p, "Name must be 1-20 characters.");
                openPlaces(p);
                return;
            }
            if (d.placesOf(u).containsKey(n)) {
                openPlaces(p);
                return;
            }
            if (cost > 0 && !m.withdraw(p, cost, "Saved place")) {
                m.err(p, "Payment failed.");
                return;
            }
            TeleportData.Place x = new TeleportData.Place();
            x.name = s;
            x.loc = TeleportData.Pos.of(p.getLocation());
            x.paid = cost;
            d.placesOf(u).put(n, x);
            d.markDirty();
            m.msg(p, "&aPlace &f" + s + " &asaved.");
            m.sfx(p, "success");
            openPlaces(p);
        }, () -> openPlaces(p));
    }

    void openPlaceView(Player p, int n) {
        UUID u = p.getUniqueId();
        TeleportData.Place x = d.placesOf(u).get(n);
        if (x == null) {
            openPlaces(p);
            return;
        }
        Gui g = gui("&e&l" + x.name, 3);
        fill(g, 3);
        g.set(10, Items.of(Material.ENDER_PEARL, "&aTeleport"), e -> {
            p.closeInventory();
            goPlace(p, n);
        });
        g.set(11, Items.of(Material.NAME_TAG, "&eRename"), e -> ask(p, "&eNew name?", s -> {
            if (s.isEmpty() || s.length() > 20) m.err(p, "Name must be 1-20 characters.");
            else {
                x.name = s;
                d.markDirty();
            }
            openPlaceView(p, n);
        }, () -> openPlaceView(p, n)));
        g.set(14, Items.of(Material.COMPASS, "&eMove Here", "&7Overwrite with your location"), e -> openConfirm(p, "placemove", "", n));
        g.set(16, Items.of(Material.GOLD_INGOT, "&cSell", "&7Refund: &e" + m.money(refundOf(u, n))), e -> openConfirm(p, "placesell", "", n));
        g.set(22, Items.of(Material.BARRIER, "&cBack"), e -> openPlaces(p));
        g.open(p);
    }

    // ---------------------------------------------------------------- settings

    void openSettings(Player p) {
        UUID u = p.getUniqueId();
        boolean off = d.noReq.contains(u);
        Gui g = gui("&f&lTELEPORT SETTINGS", 3);
        fill(g, 3);
        g.set(11, Items.of(off ? Material.RED_CONCRETE : Material.LIME_CONCRETE,
                off ? "&cRequests: OFF" : "&aRequests: ON", "&7Click to toggle"), e -> {
            if (off) d.noReq.remove(u);
            else d.noReq.add(u);
            d.markDirty();
            click(p, off ? "on" : "off");
            openSettings(p);
        });
        int n = d.ignore.getOrDefault(u, Map.of()).size();
        g.set(15, Items.of(Material.BARRIER, "&cIgnored Players: &f" + n, "&7Click to manage"), e -> openIgnoreList(p));
        g.set(22, Items.of(Material.ARROW, "&cBack"), e -> openMain(p));
        g.open(p);
    }

    void openIgnoreList(Player p) {
        UUID u = p.getUniqueId();
        Map<UUID, String> ig = d.ignore.getOrDefault(u, Map.of());
        Gui g = gui("&c&lIGNORED PLAYERS", 6);
        int i = 0;
        for (Map.Entry<UUID, String> en : ig.entrySet()) {
            if (i >= 45) break;
            UUID k = en.getKey();
            g.set(i++, Items.head(Bukkit.getOfflinePlayer(k), "&f" + en.getValue(), "&eClick to unignore"), e -> {
                Map<UUID, String> mm = d.ignore.get(u);
                if (mm != null) mm.remove(k);
                d.markDirty();
                click(p, "delete");
                openIgnoreList(p);
            });
        }
        g.set(49, Items.of(Material.ARROW, "&cBack"), e -> openSettings(p));
        g.open(p);
    }

    // ---------------------------------------------------------------- staff

    void openAdmin(Player p) {
        if (!m.staff(p)) return;
        UUID u = p.getUniqueId();
        boolean by = m.bypass.contains(u);
        Gui g = gui("&c&lTELEPORT STAFF", 3);
        fill(g, 3);
        g.set(10, Items.of(by ? Material.LIME_CONCRETE : Material.RED_CONCRETE, "&fBypass: " + (by ? "&aON" : "&cOFF"),
                "&7Skip cooldowns, warmup costs"), e -> {
            if (by) m.bypass.remove(u);
            else m.bypass.add(u);
            click(p, by ? "off" : "on");
            openAdmin(p);
        });
        g.set(11, Items.of(Material.BEACON, "&6Server Warps"), e -> openWarpList(p, "adminserver", 1));
        g.set(12, Items.of(Material.COMPASS, "&bPlayer Warps"), e -> openWarpList(p, "adminplayer", 1));
        g.set(13, Items.of(Material.COMPARATOR, "&eSettings", "&7Prices, limits, cooldowns"), e -> openAdminSettings(p));
        g.set(14, Items.of(Material.MAP, "&fStatistics"), e -> openStats(p));
        g.set(15, Items.of(Material.PLAYER_HEAD, "&aTeleport to Player", "&7Instant"), e -> openPlayerPicker(p));
        g.set(22, Items.of(Material.ARROW, "&cBack"), e -> openMain(p));
        g.open(p);
    }

    void openAdminSettings(Player p) {
        Gui g = gui("&e&lTELEPORT SETTINGS (STAFF)", 3);
        fill(g, 3);
        int i = 0;
        for (String k : TeleportData.SETTING_KEYS) {
            int slot = i < 7 ? 10 + i : 19 + (i - 7);
            i++;
            g.set(slot, Items.of(Material.PAPER, "&e" + TeleportData.label(k), "&7Value: &f" + (long) d.cfg(k),
                    "&7Max: &f" + (long) TeleportData.cfgMax(k), "&eClick to change"), e -> ask(p, "&eNew value for &f" + TeleportData.label(k) + "&e?", s -> {
                Double v = parse(s);
                if (v == null || v < 0 || v > TeleportData.cfgMax(k)) m.err(p, "Enter a number from 0 to " + (long) TeleportData.cfgMax(k) + ".");
                else {
                    d.settings.put(k, (double) Math.round(v));
                    d.markDirty();
                    m.msg(p, "&aUpdated.");
                    m.sfx(p, "success");
                }
                openAdminSettings(p);
            }, () -> openAdminSettings(p)));
        }
        g.set(26, Items.of(Material.ARROW, "&cBack"), e -> openAdmin(p));
        g.open(p);
    }

    void openStats(Player p) {
        int pw = 0, sw = 0, visits = 0, places = 0;
        for (TeleportData.Warp w : d.warps.values()) {
            if (w.type.equals("server")) sw++;
            else pw++;
            visits += w.visits;
        }
        for (TreeMap<Integer, TeleportData.Place> t : d.places.values()) places += t.size();
        Gui g = gui("&f&lTELEPORT STATS", 3);
        fill(g, 3);
        g.set(10, Items.of(Material.BEACON, "&6Server Warps: &f" + sw));
        g.set(11, Items.of(Material.COMPASS, "&bPlayer Warps: &f" + pw));
        g.set(12, Items.of(Material.RED_BED, "&eSaved Places: &f" + places));
        g.set(13, Items.of(Material.SKELETON_SKULL, "&cDeath Points: &f" + d.deaths.size()));
        g.set(14, Items.of(Material.EMERALD, "&aTotal Warp Visits: &f" + visits));
        g.set(15, Items.of(Material.BARRIER, "&cIgnore Entries: &f" + d.ignore.size()));
        g.set(22, Items.of(Material.ARROW, "&cBack"), e -> openAdmin(p));
        g.open(p);
    }
}
