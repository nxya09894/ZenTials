package com.zentials.teleport;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Consumer;

/** Every screen of teleport.ryu (same titles, slots, items and texts), plus the extra buttons. */
final class TeleportGui {
    private static final int MAX_PLACES = 10;
    private static final int SELL_PCT = 30;
    private static final String P = "&5&lTELEPORT GUI &8» ";
    private static final String A = "&c&lTELEPORT GUI &8» &4&lADMIN";

    private final TeleportModule m;
    private final TeleportData d;

    TeleportGui(TeleportModule m) {
        this.m = m;
        this.d = m.data;
    }

    // ---------------------------------------------------------------- helpers

    private static Gui gui(String title, int rows) {
        return new Gui(Text.c(title), rows);
    }

    private static void set(Gui g, int slot, Material mat, String name, List<String> lore, Consumer<InventoryClickEvent> act) {
        var it = Items.of(mat, name, lore.toArray(new String[0]));
        if (act == null) g.set(slot, it);
        else g.set(slot, it, act);
    }

    private static List<String> l(String... s) {
        return List.of(s);
    }

    private void back(Gui g, int slot, Runnable r, Player p) {
        set(g, slot, Material.ARROW, "&c&l← BACK", l("&7Return to the previous menu"), e -> {
            m.sfx(p, "back");
            r.run();
        });
    }

    private static Material catIcon(String c) {
        return switch (c) {
            case "Farm" -> Material.WHEAT;
            case "Mob Farm" -> Material.BONE;
            case "Shop" -> Material.EMERALD;
            case "Build" -> Material.BRICKS;
            case "Resources" -> Material.IRON_PICKAXE;
            case "PvP" -> Material.IRON_SWORD;
            case "Event" -> Material.NETHER_STAR;
            default -> Material.ENDER_PEARL;
        };
    }

    private static Double num(String s) {
        try {
            double v = Double.parseDouble(s.trim().replace(",", ""));
            return Double.isNaN(v) || Double.isInfinite(v) ? null : v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Chat prompt. "cancel" prints the same message as the script. */
    private void ask(Player p, String prompt, Consumer<String> onAnswer) {
        m.sfx(p, "click");
        p.closeInventory();
        Text.send(p, TeleportModule.TAG + prompt + " &7(or &fcancel&7)");
        m.plugin.prompts().ask(p, s -> Bukkit.getScheduler().runTask(m.plugin, () -> {
            String msg = s.replace("&", "").replace("|", "").trim();
            onAnswer.accept(msg);
        }), () -> Bukkit.getScheduler().runTask(m.plugin, () -> {
            m.msg(p, "&7Cancelled.");
            m.sfx(p, "back");
        }));
    }

    private int maxPlaces() {
        return MAX_PLACES;
    }

    // ---------------------------------------------------------------- main hub

    void openMain(Player p) {
        UUID u = p.getUniqueId();
        int pend = m.pending(p);
        int places = d.placesOf(u).size();
        int owned = d.countOwned(u);
        int mx = (int) Math.round(d.cfg("warp_max"));
        double rc = d.cfg("rtp_cost");
        double tc = d.cfg("tpa_cost");
        Gui g = gui("&5&lTELEPORT GUI", 4);
        set(g, 0, Material.PAPER, "&d&lTeleport Hub", l("&7Balance: &a" + m.money(m.balance(p)),
                "&7Saved Places: &f" + places + "&7/" + maxPlaces(), "&7Your Warps: &f" + owned + "&7/" + mx), null);
        set(g, 10, Material.ENDER_PEARL, "&b&lWarps", l("&7Public places made by players", "&e▶ Click to browse"), e -> openWarpList(p, "player", 1));
        set(g, 12, Material.NETHER_STAR, "&e&lPublic Warps", l("&7Official places and farms", "&7set by the staff", "&e▶ Click to browse"), e -> openWarpList(p, "server", 1));
        set(g, 14, Material.PLAYER_HEAD, "&a&lPlayer Teleport", l("&7Request to teleport to", "&7another player", "&7Cost: " + m.price(tc), "&e▶ Click to select"), e -> openPlayerPicker(p));
        set(g, 16, Material.COMPASS, "&6&lRandom Teleport", l("&7Explore the overworld", "&7Cost: " + m.price(rc), "&e▶ Click to open"), e -> openRandom(p));
        set(g, 19, Material.ENDER_CHEST, "&d&lSaved Places", l("&7Your personal teleport spots", "&7Saved: &f" + places + "&7/" + maxPlaces(), "&e▶ Click to open"), e -> openPlaces(p));
        List<String> death = new ArrayList<>(l("&7Return to the place", "&7where you last died"));
        if (m.plugin.graves() != null) death.add("&7(on top of your grave)");
        set(g, 21, Material.SKELETON_SKULL, "&f&lLast Death Location", death, e -> {
            p.closeInventory();
            m.deathBack(p);
        });
        if (pend > 0) set(g, 23, Material.LIME_WOOL, "&a&lIncoming Requests &f(" + pend + ")", l("&e▶ Click to answer"), e -> m.nextRequest(p));
        set(g, 25, Material.REDSTONE_TORCH, "&c&lSettings", l("&7Request privacy and ignore list"), e -> openSettings(p));
        // extra row
        set(g, 28, Material.RESPAWN_ANCHOR, "&b&lSpawn", l("&7Go to the server spawn", "&7/spawn", "&e▶ Click to teleport"), e -> {
            p.closeInventory();
            m.spawn(p);
        });
        set(g, 29, Material.CLOCK, "&b&lPrevious Location", l("&7Go back to where you were", "&7before your last teleport", "&7/back", "&e▶ Click to teleport"), e -> {
            p.closeInventory();
            m.lastBack(p);
        });
        if (m.plugin.graves() != null) {
            set(g, 30, Material.PLAYER_HEAD, "&c&lMy Graves", l("&7Your graves and where they are", "&7/graves", "&e▶ Click to open"), e -> {
                p.closeInventory();
                Bukkit.dispatchCommand(p, "graves");
            });
        }
        set(g, 31, Material.BOOK, "&f&lQuick Commands", l("&7/rtp /spawn /back /warp /death", "&7and more shortcuts", "&e▶ Click to open"), e -> {
            p.closeInventory();
            Bukkit.dispatchCommand(p, "tpcmds");
        });
        if (m.staff(p)) {
            set(g, 34, Material.COMMAND_BLOCK, "&c&lStaff Panel", l("&7Settings, warps, statistics", "&e▶ Click to open"), e -> openAdmin(p));
        }
        g.open(p);
        m.sfx(p, "open");
    }

    // ---------------------------------------------------------------- warp list

    void openWarpList(Player p, String mode, int page) {
        UUID u = p.getUniqueId();
        m.mode.put(u, mode);
        String filter = m.filter.getOrDefault(u, "All");
        String title = switch (mode) {
            case "server" -> P + "&d&lPUBLIC WARPS";
            case "mine" -> P + "&d&lMY WARPS";
            case "adminserver" -> A + " &8» &e&lSERVER WARPS";
            case "adminplayer" -> A + " &8» &e&lPLAYER WARPS";
            default -> P + "&d&lWARPS";
        };
        List<TeleportData.Warp> shown = new ArrayList<>();
        for (TeleportData.Warp w : d.warps.values()) {
            boolean show = switch (mode) {
                case "player" -> w.type.equals("player") && w.isPublic;
                case "server" -> w.type.equals("server") && w.isPublic;
                case "mine" -> w.type.equals("player") && w.owner.equals(u.toString());
                case "adminserver" -> w.type.equals("server");
                case "adminplayer" -> w.type.equals("player");
                default -> false;
            };
            if (show && !filter.equals("All") && !w.cat.equals(filter)) show = false;
            if (show) shown.add(w);
        }
        int total = shown.size();
        int pages = Math.max(1, (total + 44) / 45);
        int pg = Math.max(1, Math.min(page, pages));
        int start = (pg - 1) * 45;
        double cost = Math.round(d.cfg("warp_create_cost"));
        Gui g = gui(title, 6);
        boolean editMode = mode.equals("mine") || mode.equals("adminserver") || mode.equals("adminplayer");
        int slot = 0;
        for (int n = 0; n < shown.size(); n++) {
            if (n < start || slot >= 45) continue;
            TeleportData.Warp w = shown.get(n);
            String hint = editMode ? "&e▶ Click to edit" : "&e▶ Click to teleport";
            String vis = w.isPublic ? "&aPublic" : "&cPrivate";
            set(g, slot, catIcon(w.cat), "&b&l" + w.name, l("&7Owner: &f" + w.ownerName, "&7Category: &e" + w.cat, "&7" + w.desc,
                    "&7Price: " + m.price(w.price), "&7Visits: &f" + w.visits + "  &7Status: " + vis, hint), e -> {
                if (editMode) openWarpEdit(p, w.id);
                else {
                    p.closeInventory();
                    m.visitWarp(p, w.id);
                }
            });
            slot++;
        }
        back(g, 45, () -> {
            if (mode.equals("mine")) openWarpList(p, "player", 1);
            else if (mode.equals("adminserver") || mode.equals("adminplayer")) openAdmin(p);
            else openMain(p);
        }, p);
        set(g, 47, Material.HOPPER, "&b&lFilter: &f" + filter, l("&e▶ Click to change category"), e -> {
            m.filter.put(u, TeleportData.nextFilter(filter));
            openWarpList(p, mode, 1);
        });
        if (pg > 1) set(g, 48, Material.SPECTRAL_ARROW, "&e&l« PREVIOUS PAGE", l(), e -> openWarpList(p, mode, pg - 1));
        set(g, 49, Material.BOOK, "&7Page &f" + pg + "&7/&f" + pages, l(), null);
        if (pg < pages) set(g, 50, Material.SPECTRAL_ARROW, "&e&lNEXT PAGE »", l(), e -> openWarpList(p, mode, pg + 1));
        if (mode.equals("player")) set(g, 52, Material.CHEST, "&6&lMy Warps", l("&7Manage the warps you own"), e -> openWarpList(p, "mine", 1));
        if (mode.equals("player") || mode.equals("mine")) {
            set(g, 53, Material.EMERALD, "&a&lCreate Warp", l("&7Cost: &a" + m.money(cost), "&7Created at your current location", "&e▶ Click to create"), e -> createWarp(p, false));
        }
        if (mode.equals("adminserver")) {
            set(g, 53, Material.EMERALD, "&a&lCreate Server Warp Here", l("&7Created at your current location", "&e▶ Click to create"), e -> createWarp(p, true));
        }
        g.open(p);
        m.sfx(p, "click");
    }

    private void createWarp(Player p, boolean server) {
        UUID u = p.getUniqueId();
        TeleportData.Pos pend = TeleportData.Pos.of(p.getLocation());
        if (server) {
            if (!m.staff(p)) return;
            ask(p, "&aType a name for the server warp:", s -> {
                if (!m.staff(p) || !validName(p, s, 24)) return;
                TeleportData.Warp w = d.newWarp("server", "Server", s, pend.loc(), "server");
                m.msg(p, "&aServer warp &e" + s + "&a created.");
                m.sfx(p, "success");
                m.mode.put(u, "adminserver");
                openWarpEdit(p, w.id);
            });
            return;
        }
        if (d.countOwned(u) >= (int) Math.round(d.cfg("warp_max"))) {
            m.err(p, "&cYou reached your warp limit.");
            return;
        }
        double cost = Math.round(d.cfg("warp_create_cost"));
        if (m.balance(p) < cost) {
            m.err(p, "&cInsufficient funds. You need &e" + m.money(cost) + "&c.");
            return;
        }
        ask(p, "&aType a name for your warp &7(max 24 characters):", s -> {
            if (!validName(p, s, 24)) return;
            if (d.countOwned(u) >= (int) Math.round(d.cfg("warp_max"))) {
                m.err(p, "&cYou reached your warp limit.");
                return;
            }
            if (cost > 0 && !m.withdraw(p, cost, "Warp Creation")) {
                m.err(p, "&cInsufficient funds. You need &e" + m.money(cost) + "&c.");
                return;
            }
            TeleportData.Warp w = d.newWarp(u.toString(), p.getName(), s, pend.loc(), "player");
            m.msg(p, "&aWarp &e" + s + "&a created for &e" + m.money(cost) + "&a.");
            m.sfx(p, "success");
            m.mode.put(u, "mine");
            openWarpEdit(p, w.id);
        });
    }

    private boolean validName(Player p, String s, int max) {
        if (s.length() > max) {
            m.err(p, "&cName is too long (max " + max + " characters).");
            return false;
        }
        return !s.isEmpty();
    }

    // ---------------------------------------------------------------- warp editor

    void openWarpEdit(Player p, String id) {
        if (!m.canEdit(p, id)) {
            m.err(p, "&cYou can't edit that warp.");
            return;
        }
        TeleportData.Warp w = d.warps.get(id);
        String vis = w.isPublic ? "&aPUBLIC" : "&cPRIVATE";
        Material visItem = w.isPublic ? Material.LIME_DYE : Material.RED_DYE;
        UUID u = p.getUniqueId();
        Gui g = gui(P + "&d&lEDIT WARP", 3);
        set(g, 0, catIcon(w.cat), "&b&l" + w.name, l("&7Owner: &f" + w.ownerName, "&7Type: &f" + w.type, "&7Visits: &f" + w.visits), null);
        set(g, 4, Material.ENDER_PEARL, "&b&lTeleport To Warp", l(), e -> {
            if (m.canEdit(p, id)) {
                p.closeInventory();
                m.visitWarp(p, id);
            }
        });
        set(g, 10, Material.NAME_TAG, "&e&lRename", l("&7Current: &f" + w.name, "&e▶ Click, then type in chat"), e -> ask(p, "&eType the new name:", s -> {
            if (!m.canEdit(p, id) || !validName(p, s, 24)) return;
            TeleportData.Warp x = d.warps.get(id);
            if (x == null) return;
            x.name = s;
            d.markDirty();
            m.msg(p, "&aWarp renamed to &e" + s + "&a.");
            m.sfx(p, "success");
            openWarpEdit(p, id);
        }));
        set(g, 12, Material.BOOK, "&e&lEdit Description", l("&7Current: &f" + w.desc, "&e▶ Click, then type in chat"), e -> ask(p, "&eType the new description &7(max 60 characters):", s -> {
            if (!m.canEdit(p, id)) return;
            if (s.length() > 60) {
                m.err(p, "&cDescription is too long (max 60 characters).");
                return;
            }
            if (s.isEmpty()) return;
            TeleportData.Warp x = d.warps.get(id);
            if (x == null) return;
            x.desc = s;
            d.markDirty();
            m.msg(p, "&aDescription updated.");
            m.sfx(p, "success");
            openWarpEdit(p, id);
        }));
        set(g, 14, Material.GOLD_INGOT, "&e&lSet Price", l("&7Current: " + m.price(w.price), "&e▶ Click, then type a number"), e -> ask(p, "&eType the visit price &7(0 for free):", s -> {
            if (!m.canEdit(p, id)) return;
            Double v = num(s);
            if (v == null) {
                m.err(p, "&cInvalid number.");
                return;
            }
            double n = round2(v);
            if (n < 0) {
                m.err(p, "&cInvalid number.");
                return;
            }
            if (!m.staff(p)) {
                double cap = d.cfg("warp_visit_cap");
                if (n > cap) {
                    m.err(p, "&cThe maximum visit price is &e" + m.money(cap) + "&c.");
                    return;
                }
            }
            TeleportData.Warp x = d.warps.get(id);
            if (x == null) return;
            x.price = n;
            d.markDirty();
            m.msg(p, "&aPrice set to &e" + m.money(n) + "&a.");
            m.sfx(p, "success");
            openWarpEdit(p, id);
        }));
        set(g, 16, catIcon(w.cat), "&e&lCategory: &f" + w.cat, l("&e▶ Click to change"), e -> {
            if (!m.canEdit(p, id)) return;
            w.cat = TeleportData.nextCat(w.cat);
            d.markDirty();
            openWarpEdit(p, id);
        });
        back(g, 18, () -> openWarpList(p, m.mode.getOrDefault(u, "mine"), 1), p);
        set(g, 20, visItem, "&e&lVisibility: " + vis, l("&e▶ Click to toggle"), e -> {
            if (!m.canEdit(p, id)) return;
            w.isPublic = !w.isPublic;
            d.markDirty();
            m.sfx(p, w.isPublic ? "on" : "off");
            openWarpEdit(p, id);
        });
        set(g, 22, Material.COMPASS, "&e&lMove Here", l("&7Sets this warp to your", "&7current location"), e -> {
            if (!m.canEdit(p, id)) return;
            w.loc = TeleportData.Pos.of(p.getLocation());
            d.markDirty();
            m.msg(p, "&aWarp moved to your current location.");
            m.sfx(p, "success");
            openWarpEdit(p, id);
        });
        set(g, 24, Material.TNT, "&4&lDelete Warp", l("&7Asks for confirmation"), e -> {
            if (m.canEdit(p, id)) openConfirm(p, "warp", id);
        });
        g.open(p);
        m.sfx(p, "click");
    }

    // ---------------------------------------------------------------- confirm (warp | placesell | placemove)

    void openConfirm(Player p, String kind, String id) {
        UUID u = p.getUniqueId();
        String label = "?";
        if (kind.equals("warp")) {
            TeleportData.Warp w = d.warps.get(id);
            if (w != null) label = w.name;
        } else {
            TeleportData.Place pl = d.placesOf(u).get(Integer.parseInt(id));
            if (pl != null) label = pl.name;
        }
        Gui g = gui(P + "&d&lCONFIRM", 3);
        switch (kind) {
            case "placesell" -> {
                set(g, 0, Material.PAPER, "&6&lSell: &f" + label, l("&7Refund: &a" + m.money(refund(u, Integer.parseInt(id))) + " &7(" + SELL_PCT + "% of the price paid)", "&7This can't be undone"), null);
                set(g, 11, Material.GOLD_INGOT, "&a&lYES, SELL", l(), e -> confirmYes(p, kind, id));
            }
            case "placemove" -> {
                set(g, 0, Material.PAPER, "&e&lReplace: &f" + label, l("&7The saved location becomes", "&7where you are standing now"), null);
                set(g, 11, Material.ENDER_PEARL, "&a&lYES, REPLACE", l(), e -> confirmYes(p, kind, id));
            }
            default -> {
                set(g, 0, Material.PAPER, "&c&lDelete: &f" + label, l("&7This can't be undone", "&7and nothing is refunded"), null);
                set(g, 11, Material.TNT, "&c&lYES, DELETE", l(), e -> confirmYes(p, kind, id));
            }
        }
        set(g, 15, Material.LIME_WOOL, "&a&lNO, GO BACK", l(), e -> {
            m.sfx(p, "back");
            if (kind.equals("warp")) openWarpEdit(p, id);
            else openPlaceView(p, Integer.parseInt(id));
        });
        g.open(p);
        m.sfx(p, "warn");
    }

    private void confirmYes(Player p, String kind, String id) {
        UUID u = p.getUniqueId();
        switch (kind) {
            case "warp" -> {
                if (m.canEdit(p, id)) {
                    d.warps.remove(id);
                    d.markDirty();
                    m.msg(p, "&cWarp deleted.");
                    m.sfx(p, "delete");
                }
                openWarpList(p, m.mode.getOrDefault(u, "mine"), 1);
            }
            case "placesell" -> {
                int n = Integer.parseInt(id);
                TreeMap<Integer, TeleportData.Place> pls = d.placesOf(u);
                TeleportData.Place pl = pls.get(n);
                if (pl != null) {
                    double r = refund(u, n);
                    pls.remove(n);
                    d.markDirty();
                    m.deposit(u, r, "Saved Place Sold");
                    m.msg(p, "&aSold &e" + pl.name + " &afor &e" + m.money(r) + "&a.");
                    m.sfx(p, "cash");
                }
                openPlaces(p);
            }
            case "placemove" -> {
                int n = Integer.parseInt(id);
                TeleportData.Place pl = d.placesOf(u).get(n);
                if (pl != null) {
                    pl.loc = TeleportData.Pos.of(p.getLocation());
                    d.markDirty();
                    m.msg(p, "&aSaved place &e" + pl.name + " &anow points to your current location.");
                    m.sfx(p, "success");
                    openPlaceView(p, n);
                } else {
                    openPlaces(p);
                }
            }
            default -> p.closeInventory();
        }
    }

    // ---------------------------------------------------------------- player picker / requests

    void openPlayerPicker(Player p) {
        UUID u = p.getUniqueId();
        boolean bypass = m.bypassOn(p);
        String hint = bypass ? "&e▶ Click to teleport &7(bypass)" : "&e▶ Click to select";
        Gui g = gui(P + "&d&lPLAYERS", 3);
        int slot = 0;
        for (Player q : Bukkit.getOnlinePlayers()) {
            if (q.getUniqueId().equals(u)) continue;
            if (slot == 18) slot++;
            if (slot < 27) {
                UUID qu = q.getUniqueId();
                g.set(slot, Items.head(q, "&b" + q.getName(), hint), e -> {
                    Player t = Bukkit.getPlayer(qu);
                    if (t == null) {
                        m.err(p, "&cThat player is no longer online.");
                        openPlayerPicker(p);
                        return;
                    }
                    if (m.bypassOn(p)) {
                        p.closeInventory();
                        m.staffGo(p, t);
                        return;
                    }
                    openRequestType(p, qu);
                });
                slot++;
            }
        }
        if (slot == 0) set(g, 13, Material.GRAY_DYE, "&7No other players are online", l(), null);
        back(g, 18, () -> openMain(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    void openRequestType(Player p, UUID tu) {
        Player t = Bukkit.getPlayer(tu);
        if (t == null) {
            m.err(p, "&cThat player is no longer online.");
            openPlayerPicker(p);
            return;
        }
        double tc = d.cfg("tpa_cost");
        Gui g = gui(P + "&d&lREQUEST TYPE", 3);
        g.set(0, Items.head(t, "&b&l" + t.getName(), "&7Cost: " + m.price(tc), "&7Paid by you, the requester"), e -> openPlayerPicker(p));
        set(g, 11, Material.ENDER_PEARL, "&b&lGo To Them", l("&7You teleport to them", "&7once they accept"), e -> {
            p.closeInventory();
            m.sendRequest(p, tu, "to");
        });
        set(g, 15, Material.ENDER_EYE, "&d&lBring Them To Me", l("&7They teleport to you", "&7once they accept"), e -> {
            p.closeInventory();
            m.sendRequest(p, tu, "here");
        });
        back(g, 18, () -> openPlayerPicker(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    void openRequest(Player t, UUID ru) {
        Map<UUID, TeleportModule.Req> rq = m.requests.get(t.getUniqueId());
        TeleportModule.Req r = rq == null ? null : rq.get(ru);
        if (r == null) {
            m.nextRequest(t);
            return;
        }
        String what = r.mode().equals("here") ? "wants you to teleport to them" : "wants to teleport to you";
        Gui g = gui(P + "&d&lREQUEST", 3);
        g.set(0, Items.head(Bukkit.getOfflinePlayer(ru), "&b&l" + r.name(), "&7" + what, "&7Pending requests: &f" + rq.size()));
        set(g, 11, Material.LIME_WOOL, "&a&lACCEPT", l(), e -> m.respond(t, ru, "accept"));
        set(g, 15, Material.RED_WOOL, "&c&lDENY", l(), e -> m.respond(t, ru, "deny"));
        set(g, 22, Material.INK_SAC, "&4&lIGNORE PLAYER", l("&7Blocks all future requests", "&7from this player"), e -> m.respond(t, ru, "ignore"));
        g.open(t);
        m.sfx(t, "confirm");
    }

    // ---------------------------------------------------------------- random

    void openRandom(Player p) {
        double cost = Math.round(d.cfg("rtp_cost"));
        long r = Math.round(d.cfg("rtp_radius"));
        long cdr = Math.round(d.cfg("rtp_cd"));
        Gui g = gui(P + "&d&lRANDOM TELEPORT", 3);
        set(g, 0, Material.PAPER, "&d&lRandom Teleport", l("&7World: &fOverworld", "&7Range: &f" + r + " blocks", "&7Cooldown: &f" + cdr + "s"), null);
        set(g, 13, Material.COMPASS, "&6&lTELEPORT NOW", l("&7Teleports you to a safe spot", "&7in the overworld", "&7Cost: " + m.price(cost), "&e▶ Click to teleport"), e -> {
            p.closeInventory();
            m.doRandom(p);
        });
        back(g, 18, () -> openMain(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    // ---------------------------------------------------------------- saved places

    private static int slotOf(int n) {
        return n <= 5 ? 1 + n : 5 + n;
    }

    private double cost(UUID u) {
        return Math.round(d.cfg("place_base") + d.placesOf(u).size() * d.cfg("place_inc"));
    }

    private double refund(UUID u, int n) {
        TeleportData.Place pl = d.placesOf(u).get(n);
        double paid = pl == null || pl.paid <= 0 ? d.cfg("place_base") : pl.paid;
        return Math.round(paid * SELL_PCT / 100.0);
    }

    void openPlaces(Player p) {
        UUID u = p.getUniqueId();
        TreeMap<Integer, TeleportData.Place> pls = d.placesOf(u);
        double cost = cost(u);
        Gui g = gui(P + "&d&lSAVED PLACES", 3);
        set(g, 0, Material.PAPER, "&d&lSaved Places", l("&7Saved: &f" + pls.size() + "&7/" + maxPlaces(), "&7Next save costs: &a" + m.money(cost)), null);
        for (int n = 1; n <= maxPlaces(); n++) {
            int num = n;
            TeleportData.Place pl = pls.get(n);
            if (pl != null) {
                TeleportData.Pos l = pl.loc;
                set(g, slotOf(n), Material.ENDER_PEARL, "&b&l" + pl.name, l("&7World: &f" + l.world(), "&7X: &f" + Math.round(l.x()) + " &7Y: &f" + Math.round(l.y()) + " &7Z: &f" + Math.round(l.z()),
                        "&e▶ Click for options"), e -> openPlaceView(p, num));
            } else {
                set(g, slotOf(n), Material.GRAY_DYE, "&7Empty Slot", l("&7Save here for &a" + m.money(cost), "&e▶ Click to save your location"), e -> savePlace(p, num));
            }
        }
        back(g, 18, () -> openMain(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    private void savePlace(Player p, int n) {
        UUID u = p.getUniqueId();
        if (d.placesOf(u).containsKey(n)) {
            openPlaceView(p, n);
            return;
        }
        double c = cost(u);
        if (m.balance(p) < c) {
            m.err(p, "&cInsufficient funds. You need &e" + m.money(c) + "&c.");
            return;
        }
        TeleportData.Pos pend = TeleportData.Pos.of(p.getLocation());
        ask(p, "&aType a name for this place &7(max 24 characters). Cost: &e" + m.money(c), s -> {
            TreeMap<Integer, TeleportData.Place> pls = d.placesOf(u);
            if (pls.size() >= maxPlaces()) {
                m.err(p, "&cYou reached the limit of " + maxPlaces() + " saved places.");
                return;
            }
            if (pls.containsKey(n)) {
                m.msg(p, "&cThat slot is already used.");
                return;
            }
            if (!validName(p, s, 24)) return;
            double cost = cost(u);
            if (cost > 0 && !m.withdraw(p, cost, "Saved Place")) {
                m.err(p, "&cInsufficient funds. You need &e" + m.money(cost) + "&c.");
                return;
            }
            TeleportData.Place x = new TeleportData.Place();
            x.name = s;
            x.loc = pend;
            x.paid = cost;
            pls.put(n, x);
            d.markDirty();
            m.msg(p, "&aSaved place &e" + s + "&a for &e" + m.money(cost) + "&a.");
            m.sfx(p, "success");
            openPlaces(p);
        });
    }

    void openPlaceView(Player p, int n) {
        UUID u = p.getUniqueId();
        TeleportData.Place x = d.placesOf(u).get(n);
        if (x == null) {
            openPlaces(p);
            return;
        }
        Gui g = gui(P + "&d&lPLACE", 3);
        set(g, 0, Material.PAPER, "&b&l" + x.name, l(), null);
        set(g, 10, Material.ENDER_PEARL, "&b&lTeleport", l(), e -> {
            p.closeInventory();
            TeleportData.Place pl = d.placesOf(u).get(n);
            if (pl == null) return;
            org.bukkit.Location dest = pl.loc.loc();
            if (dest == null) {
                m.err(p, "&cThat place's world isn't loaded.");
                return;
            }
            m.goSimple(p, dest, pl.name, 0, null, m.cdSecs());
        });
        set(g, 12, Material.NAME_TAG, "&e&lRename", l("&e▶ Click, then type in chat"), e -> ask(p, "&eType the new name:", s -> {
            TeleportData.Place pl = d.placesOf(u).get(n);
            if (pl == null || !validName(p, s, 24)) return;
            pl.name = s;
            d.markDirty();
            m.msg(p, "&aPlace renamed to &e" + s + "&a.");
            m.sfx(p, "success");
            openPlaceView(p, n);
        }));
        set(g, 14, Material.COMPASS, "&d&lReplace Location", l("&7Save the spot you are standing on", "&7instead of this one. Free.", "&e▶ Click, asks for confirmation"), e -> openConfirm(p, "placemove", String.valueOf(n)));
        set(g, 16, Material.GOLD_INGOT, "&6&lSell", l("&7Refund: &a" + m.money(refund(u, n)) + " &7(" + SELL_PCT + "% of the price paid)", "&e▶ Click, asks for confirmation"), e -> openConfirm(p, "placesell", String.valueOf(n)));
        back(g, 18, () -> openPlaces(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    // ---------------------------------------------------------------- settings

    void openSettings(Player p) {
        UUID u = p.getUniqueId();
        boolean noreq = d.noReq.contains(u);
        Gui g = gui(P + "&d&lSETTINGS", 3);
        set(g, 11, noreq ? Material.RED_DYE : Material.LIME_DYE, "&e&lAccept Requests: " + (noreq ? "&cOFF" : "&aON"),
                l("&7Turn off to stop receiving", "&7teleport requests", "&e▶ Click to toggle"), e -> {
                    if (d.noReq.contains(u)) {
                        d.noReq.remove(u);
                        m.sfx(p, "on");
                    } else {
                        d.noReq.add(u);
                        m.sfx(p, "off");
                    }
                    d.markDirty();
                    openSettings(p);
                });
        set(g, 15, Material.INK_SAC, "&c&lIgnore List", l("&7Players whose requests are blocked", "&e▶ Click to manage"), e -> openIgnoreList(p));
        back(g, 18, () -> openMain(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    void openIgnoreList(Player p) {
        UUID u = p.getUniqueId();
        Map<UUID, String> ign = d.ignore.getOrDefault(u, Map.of());
        Gui g = gui(P + "&d&lIGNORE LIST", 3);
        int slot = 0;
        for (Map.Entry<UUID, String> en : ign.entrySet()) {
            if (slot >= 18) break;
            UUID k = en.getKey();
            g.set(slot, Items.head(Bukkit.getOfflinePlayer(k), "&c" + en.getValue(), "&e▶ Click to stop ignoring"), e -> {
                Map<UUID, String> mm = d.ignore.get(u);
                if (mm != null) mm.remove(k);
                d.markDirty();
                m.sfx(p, "success");
                openIgnoreList(p);
            });
            slot++;
        }
        if (slot == 0) set(g, 13, Material.GRAY_DYE, "&7You aren't ignoring anyone", l(), null);
        back(g, 18, () -> openSettings(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    // ---------------------------------------------------------------- staff panel

    void openAdmin(Player p) {
        if (!m.staff(p)) return;
        UUID u = p.getUniqueId();
        boolean on = m.bypassOn(p);
        Gui g = gui("&c&lTELEPORT GUI &8» &4&lADMIN PANEL", 3);
        set(g, 10, Material.EMERALD, "&a&lCreate Server Warp Here", l("&7Creates a public warp at", "&7your current location", "&e▶ Click, then type a name"), e -> createWarp(p, true));
        set(g, 12, Material.NETHER_STAR, "&e&lServer Warps", l("&7Edit, hide or delete", "&7official warps"), e -> openWarpList(p, "adminserver", 1));
        set(g, 14, Material.PLAYER_HEAD, "&b&lPlayer Warps", l("&7Moderate warps made by", "&7players"), e -> openWarpList(p, "adminplayer", 1));
        set(g, 16, Material.REDSTONE_TORCH, "&c&lSettings", l("&7Prices, limits and cooldowns"), e -> openAdminSettings(p));
        set(g, 21, Material.BOOK, "&d&lStatistics", l("&7Warps, saved places and more"), e -> openStats(p));
        set(g, 23, on ? Material.LIME_DYE : Material.GRAY_DYE, on ? "&a&lBypass Mode: ON" : "&7&lBypass Mode: OFF",
                l("&7While ON, picking a player in the", "&7player list teleports you instantly.", "&7No request, cost or cooldown.", "", on ? "&e▶ Click to turn off" : "&e▶ Click to turn on"), e -> {
                    if (m.bypass.contains(u)) {
                        m.bypass.remove(u);
                        m.msg(p, "&7Bypass mode &cOFF&7.");
                        m.sfx(p, "off");
                    } else {
                        m.bypass.add(u);
                        m.msg(p, "&7Bypass mode &aON&7. Picking a player teleports you instantly.");
                        m.sfx(p, "on");
                    }
                    openAdmin(p);
                });
        back(g, 18, () -> p.closeInventory(), p);
        g.open(p);
        m.sfx(p, "open");
    }

    void openAdminSettings(Player p) {
        if (!m.staff(p)) return;
        Gui g = gui(A + " &8» &e&lSETTINGS", 6);
        String[] keys = TeleportData.SETTING_KEYS;
        for (int i = 0; i < keys.length; i++) {
            String key = keys[i];
            int row = i / 4;
            int col = i - row * 4;
            int slot = 10 + row * 9 + col * 2;
            set(g, slot, Material.REPEATER, "&e&l" + TeleportData.label(key), l("&7Current: &f" + (long) d.cfg(key), "&e▶ Click, then type a number"), e -> {
                if (!m.staff(p)) return;
                ask(p, "&eType a new value for &f" + TeleportData.label(key) + "&e:", s -> {
                    if (!m.staff(p)) return;
                    Double v = num(s);
                    if (v == null) {
                        m.err(p, "&cInvalid number.");
                        return;
                    }
                    long n = Math.round(v);
                    if (n < 0) {
                        m.err(p, "&cInvalid number.");
                        return;
                    }
                    double mx = TeleportData.cfgMax(key);
                    if (n > mx) {
                        m.err(p, "&cThe maximum for this setting is &e" + (long) mx + "&c.");
                        return;
                    }
                    d.settings.put(key, (double) n);
                    d.markDirty();
                    m.msg(p, "&a" + TeleportData.label(key) + " set to &e" + (long) d.cfg(key) + "&a.");
                    m.sfx(p, "success");
                    openAdminSettings(p);
                });
            });
        }
        back(g, 45, () -> openAdmin(p), p);
        g.open(p);
        m.sfx(p, "click");
    }

    void openStats(Player p) {
        if (!m.staff(p)) return;
        int sn = 0;
        int pn = 0;
        int visits = 0;
        for (TeleportData.Warp w : d.warps.values()) {
            visits += w.visits;
            if (w.type.equals("server")) sn++;
            else pn++;
        }
        Gui g = gui(A + " &8» &e&lSTATISTICS", 3);
        set(g, 11, Material.NETHER_STAR, "&e&lServer Warps", l("&7Total: &f" + sn), null);
        set(g, 13, Material.PLAYER_HEAD, "&b&lPlayer Warps", l("&7Total: &f" + pn), null);
        set(g, 15, Material.BOOK, "&d&lTotal Warp Visits", l("&7Visits: &f" + visits), null);
        back(g, 18, () -> openAdmin(p), p);
        g.open(p);
        m.sfx(p, "click");
    }
}
