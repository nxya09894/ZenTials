package com.zentials;

import com.zentials.core.Sfx;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.economy.EconomyModule;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public final class ZenTials extends JavaPlugin implements TabExecutor {

    private final List<ZModule> modules = new ArrayList<>();
    private Sfx sfx;

    public Sfx sfx() {
        return sfx;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        sfx = new Sfx(this);
        sfx.load();

        if (getConfig().getBoolean("modules.economy", true)) {
            modules.add(new EconomyModule(this));
        }

        for (ZModule m : modules) {
            try {
                m.enable();
                getLogger().info("Module enabled: " + m.id());
            } catch (Exception ex) {
                getLogger().log(Level.SEVERE, "Module failed: " + m.id(), ex);
            }
        }

        PluginCommand cmd = getCommand("zentials");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("ZenTials ready. Modules loaded: " + modules.size());
    }

    @Override
    public void onDisable() {
        for (int i = modules.size() - 1; i >= 0; i--) {
            try {
                modules.get(i).disable();
            } catch (Exception ex) {
                getLogger().log(Level.SEVERE, "Module disable failed", ex);
            }
        }
        modules.clear();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sfx.load();
            for (ZModule m : modules) {
                try {
                    m.reload();
                } catch (Exception ex) {
                    getLogger().log(Level.SEVERE, "Reload failed: " + m.id(), ex);
                }
            }
            Text.send(s, "&8[&bZenTials&8]&7 Reloaded.");
            return true;
        }
        List<String> ids = new ArrayList<>();
        for (ZModule m : modules) ids.add(m.id());
        Text.send(s, "&8[&bZenTials&8]&7 v" + getPluginMeta().getVersion()
                + " &8| &7Modules: &f" + ids + " &8| &7/zentials reload");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        return a.length == 1 ? List.of("reload") : List.of();
    }
}
