package com.zentials.tab;

import com.zentials.ZenTials;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tab module (like the TAB plugin, built in). All files live in plugins/ZenTials/tab/:
 * config.yml, groups.yml, animations.yml, scoreboard.yml, tags.yml, data.yml.
 * Features: tab list header/footer + names, name tags, below-name number, ping column, sidebar scoreboards,
 * chat format with hover/click, chat tags (/tag), groups, animations and rainbow / gradient effects.
 */
public final class TabModule implements ZModule, Listener, TabExecutor {
    private static final String T = "&8[&bTab&8]&7 ";
    private static final Pattern SLOT = Pattern.compile("\\{(name|message)}");

    final ZenTials plugin;
    final TabConfig cfg;
    final TabText text;
    private final TabBoards boards;
    private final TabTagGui tagGui;

    private boolean tablistOn;
    private boolean tagsOn;
    private boolean belowOn;
    private boolean pingOn;
    private boolean sidebarOn;
    private boolean chatOn;
    private Set<String> disabledWorlds = Set.of();

    private final List<BukkitTask> tasks = new ArrayList<>();
    private final Map<UUID, String[]> tabCache = new ConcurrentHashMap<>();

    public TabModule(ZenTials plugin) {
        this.plugin = plugin;
        this.cfg = new TabConfig(plugin);
        this.text = new TabText(plugin, cfg);
        this.boards = new TabBoards(plugin, cfg, text);
        this.tagGui = new TabTagGui(this);
    }

    @Override
    public String id() {
        return "tab";
    }

    long now() {
        return Bukkit.getCurrentTick();
    }

    /** True when this module formats public chat (the old chat module then only does join/quit and /msg). */
    public boolean ownsChat() {
        return chatOn;
    }

    /** True when this module draws the sidebar (the old chat module then keeps its scoreboard off). */
    public boolean ownsScoreboard() {
        return sidebarOn;
    }

    @Override
    public void enable() {
        readAll();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (String n : new String[]{"ztab", "tag", "scoreboard"}) {
            PluginCommand c = plugin.getCommand(n);
            if (c != null) {
                c.setExecutor(this);
                c.setTabCompleter(this);
            }
        }
        start();
    }

    @Override
    public void disable() {
        stop();
        cfg.saveData();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playerListName(null);
            p.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
        }
        boards.releaseAll();
    }

    @Override
    public void reload() {
        stop();
        for (Player p : Bukkit.getOnlinePlayers()) p.playerListName(null);
        boards.releaseAll();
        tabCache.clear();
        readAll();
        start();
    }

    private void readAll() {
        cfg.load();
        text.reload();
        var c = cfg.main;
        tablistOn = c.getBoolean("tablist.enabled", true);
        tagsOn = c.getBoolean("nametag.enabled", true);
        belowOn = c.getBoolean("nametag.below-name.enabled", false);
        pingOn = c.getBoolean("tablist.ping-column", false);
        sidebarOn = cfg.boardsYml.getBoolean("enabled", true);
        chatOn = c.getBoolean("chat.enabled", true);
        Set<String> dw = new HashSet<>();
        for (String w : c.getStringList("disabled-worlds")) dw.add(w.toLowerCase(Locale.ROOT));
        disabledWorlds = dw;
    }

    private void start() {
        var c = cfg.main;
        if (tablistOn) {
            tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> tickTablist(now()), 20L, Math.max(1, c.getInt("tablist.interval", 2))));
        }
        if (tagsOn || belowOn || pingOn) {
            tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> tickTags(now()), 20L, Math.max(1, c.getInt("nametag.interval", 5))));
        }
        if (sidebarOn) {
            tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> tickSidebar(now()), 20L, Math.max(1, cfg.boardsYml.getInt("interval", 4))));
        }
        refreshNow();
    }

    private void stop() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
    }

    private boolean off(Player p) {
        return disabledWorlds.contains(p.getWorld().getName().toLowerCase(Locale.ROOT));
    }

    /** Re-draws everything right now (after a join, a tag change, a world change ...). */
    void refreshNow() {
        long n = now();
        if (tablistOn) tickTablist(n);
        if (tagsOn || belowOn || pingOn) tickTags(n);
        if (sidebarOn) tickSidebar(n);
    }

    // ---------------------------------------------------------------- tick tasks

    private void tickTablist(long now) {
        var c = cfg.main;
        List<String> head = c.getStringList("tablist.header");
        List<String> foot = c.getStringList("tablist.footer");
        String fmt = c.getString("tablist.name-format", "{tabprefix}{name}{tabsuffix}");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (off(p)) continue;
            String[] last = tabCache.computeIfAbsent(p.getUniqueId(), k -> new String[3]);
            String h = renderLines(p, head, now);
            String f = renderLines(p, foot, now);
            if (!h.equals(last[0]) || !f.equals(last[1])) {
                last[0] = h;
                last[1] = f;
                p.sendPlayerListHeaderAndFooter(Text.c(h), Text.c(f));
            }
            String nm = text.render(p, fmt, now);
            if (!nm.equals(last[2])) {
                last[2] = nm;
                p.playerListName(Text.c(nm));
            }
        }
    }

    private String renderLines(Player p, List<String> lines, long now) {
        List<String> out = new ArrayList<>(lines.size());
        for (String l : lines) out.add(text.render(p, l, now));
        return String.join("\n", out);
    }

    private Set<Player> eligible() {
        Set<Player> s = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) if (!off(p)) s.add(p);
        return s;
    }

    private void tickTags(long now) {
        boards.updateTags(eligible(), now, tagsOn, belowOn, pingOn);
    }

    private void tickSidebar(long now) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (off(p)) {
                boards.release(p);
                continue;
            }
            boards.updateSidebar(p, now);
        }
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, this::refreshNow, 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        tabCache.remove(u);
        boards.forget(u);
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, this::refreshNow, 2L);
    }

    // ---------------------------------------------------------------- chat

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!chatOn) return;
        Player p = e.getPlayer();
        if (off(p)) return;
        long now = now();
        String body = PlainTextComponentSerializer.plainText().serialize(e.message());
        if (!(p.hasPermission("zentials.chat.color") || p.hasPermission("zentials.tab.chat.color"))) body = TabText.stripColors(body);
        if (p.hasPermission("zentials.tab.chat.effects")) body = text.effects(body, now);
        TabConfig.Group g = cfg.groupOf(p);
        String format = g.chatFormat.isBlank() ? cfg.main.getString("chat.format", "{tag}{prefix}{name}{suffix} &8» &f{message}") : g.chatFormat;
        Component built = build(p, format, body, g, now);
        e.renderer((source, display, message, viewer) -> built);
    }

    private Component build(Player p, String format, String body, TabConfig.Group g, long now) {
        String rendered = text.render(p, format, now, Set.of("name", "message"));
        Component out = Component.empty();
        String carry = "";
        int last = 0;
        Matcher m = SLOT.matcher(rendered);
        while (m.find()) {
            String seg = rendered.substring(last, m.start());
            if (!seg.isEmpty()) out = out.append(Text.c(carry + seg));
            carry = TabText.carry(carry + seg);
            if (m.group(1).equals("name")) out = out.append(nameComponent(p, carry, now));
            else out = out.append(Text.c(carry + g.chatColor + body));
            last = m.end();
        }
        String tail = rendered.substring(last);
        if (!tail.isEmpty()) out = out.append(Text.c(carry + tail));
        return out;
    }

    private Component nameComponent(Player p, String carry, long now) {
        Component c = Text.c(carry + p.getName());
        List<String> hover = cfg.main.getStringList("chat.hover");
        if (!hover.isEmpty()) {
            List<String> lines = new ArrayList<>();
            for (String h : hover) lines.add(text.render(p, h, now));
            c = c.hoverEvent(HoverEvent.showText(Text.c(String.join("\n", lines))));
        }
        String click = cfg.main.getString("chat.click", "");
        if (click != null && !click.isBlank()) {
            String v = click.replace("{name}", p.getName());
            if (v.startsWith("suggest:")) c = c.clickEvent(ClickEvent.suggestCommand(v.substring(8)));
            else if (v.startsWith("run:")) c = c.clickEvent(ClickEvent.runCommand(v.substring(4)));
            else if (v.startsWith("url:")) c = c.clickEvent(ClickEvent.openUrl(v.substring(4)));
            else if (v.startsWith("copy:")) c = c.clickEvent(ClickEvent.copyToClipboard(v.substring(5)));
        }
        return c;
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase(Locale.ROOT)) {
            case "scoreboard" -> {
                if (!(s instanceof Player p)) return true;
                if (!sidebarOn) {
                    Text.send(s, T + "The scoreboard is turned off on this server.");
                    return true;
                }
                boolean wantOff;
                if (a.length > 0 && a[0].equalsIgnoreCase("on")) wantOff = false;
                else if (a.length > 0 && a[0].equalsIgnoreCase("off")) wantOff = true;
                else wantOff = !cfg.sbOff.contains(p.getUniqueId());
                if (wantOff) cfg.sbOff.add(p.getUniqueId());
                else cfg.sbOff.remove(p.getUniqueId());
                cfg.saveData();
                refreshNow();
                Text.send(s, T + "Scoreboard: " + (wantOff ? "&cOFF" : "&aON"));
            }
            case "tag" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length == 0) {
                    tagGui.open(p, 1);
                    return true;
                }
                String k = a[0].toLowerCase(Locale.ROOT);
                if (k.equals("clear") || k.equals("off") || k.equals("none")) {
                    cfg.playerTag.remove(p.getUniqueId());
                    cfg.saveData();
                    refreshNow();
                    Text.send(s, T + "Tag removed.");
                    return true;
                }
                TabConfig.TagDef t = cfg.tags.get(k);
                if (t == null) {
                    Text.send(s, T + "&cNo tag named &f" + k + "&c. Use &f/tag &cto see them.");
                } else if (!cfg.canUse(p, t)) {
                    Text.send(s, T + "&cYou don't have that tag.");
                } else {
                    cfg.playerTag.put(p.getUniqueId(), t.id);
                    cfg.saveData();
                    refreshNow();
                    Text.send(s, T + "Tag set: " + text.render(p, t.display, now()));
                }
            }
            default -> admin(s, a);
        }
        return true;
    }

    private void admin(CommandSender s, String[] a) {
        if (!s.hasPermission("zentials.tab.admin")) {
            Text.send(s, T + "&cNo permission.");
            return;
        }
        String k = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (k) {
            case "reload" -> {
                reload();
                Text.send(s, T + "&aReloaded &7(groups: " + cfg.groups.size() + ", boards: " + cfg.boards.size()
                        + ", tags: " + cfg.tags.size() + ", animations: " + text.animNames().size() + ")");
            }
            case "group" -> {
                if (a.length < 3) {
                    Text.send(s, T + "Usage: /ztab group <player> <group|clear>");
                    return;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    Text.send(s, T + "&cThat player is not online.");
                    return;
                }
                if (a[2].equalsIgnoreCase("clear")) cfg.groupOverride.remove(t.getUniqueId());
                else if (cfg.groups.containsKey(a[2].toLowerCase(Locale.ROOT))) cfg.groupOverride.put(t.getUniqueId(), a[2].toLowerCase(Locale.ROOT));
                else {
                    Text.send(s, T + "&cUnknown group. Groups: &f" + String.join(", ", cfg.groups.keySet()));
                    return;
                }
                cfg.saveData();
                refreshNow();
                Text.send(s, T + "&f" + t.getName() + " &7is now in group &f" + cfg.groupOf(t).id + "&7.");
            }
            case "preview" -> {
                if (a.length < 2) {
                    Text.send(s, T + "Usage: /ztab preview <text with <rainbow>..</rainbow> or %anim:name%>");
                    return;
                }
                Player p = s instanceof Player pl ? pl : null;
                String msg = String.join(" ", java.util.Arrays.copyOfRange(a, 1, a.length));
                if (p == null) {
                    s.sendMessage(Text.c(text.render(null, msg, now())));
                    return;
                }
                final int[] left = {60};
                Bukkit.getScheduler().runTaskTimer(plugin, task -> {
                    if (!p.isOnline() || left[0]-- <= 0) {
                        task.cancel();
                        return;
                    }
                    p.sendActionBar(text.comp(p, msg, now()));
                }, 0L, 2L);
                Text.send(s, T + "Preview in your action bar for 6 seconds.");
            }
            case "info" -> {
                if (!(s instanceof Player p)) return;
                TabConfig.BoardDef b = cfg.boardFor(p);
                Text.send(s, T + "Group: &f" + cfg.groupOf(p).id + " &7| Board: &f" + (b == null ? "none" : b.id)
                        + " &7| Tag: &f" + (cfg.playerTag.getOrDefault(p.getUniqueId(), "none")));
            }
            case "anims" -> Text.send(s, T + "Animations: &f" + String.join(", ", text.animNames()));
            default -> {
                Text.send(s, T + "&f/ztab reload &8| &f/ztab group <player> <group|clear> &8| &f/ztab preview <text> &8| &f/ztab info &8| &f/ztab anims");
                Text.send(s, T + "&7Players: &f/tag &8| &f/sb [on|off]");
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String name = c.getName().toLowerCase(Locale.ROOT);
        if (name.equals("scoreboard") && a.length == 1) out.addAll(List.of("on", "off"));
        if (name.equals("tag") && a.length == 1 && s instanceof Player p) {
            out.add("clear");
            for (TabConfig.TagDef t : cfg.tags.values()) if (cfg.canUse(p, t)) out.add(t.id);
        }
        if (name.equals("ztab") && s.hasPermission("zentials.tab.admin")) {
            if (a.length == 1) out.addAll(List.of("reload", "group", "preview", "info", "anims"));
            if (a.length == 2 && a[0].equalsIgnoreCase("group")) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            if (a.length == 3 && a[0].equalsIgnoreCase("group")) {
                out.addAll(cfg.groups.keySet());
                out.add("clear");
            }
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
