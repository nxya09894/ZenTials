package com.zentials.tab;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** /tag menu: pick the chat tag that shows in chat, tab list and above your head. */
final class TabTagGui {
    private static final int PAGE = 45;

    private final TabModule m;

    TabTagGui(TabModule m) {
        this.m = m;
    }

    void open(Player p, int page) {
        List<TabConfig.TagDef> all = new ArrayList<>(m.cfg.tags.values());
        int pages = Math.max(1, (all.size() + PAGE - 1) / PAGE);
        int pg = Math.max(1, Math.min(page, pages));
        UUID u = p.getUniqueId();
        String cur = m.cfg.playerTag.get(u);
        Gui g = new Gui(Text.c("&d&lCHAT TAGS &8" + pg + "/" + pages), 6);
        long now = m.now();
        for (int i = 0; i < PAGE; i++) {
            int idx = (pg - 1) * PAGE + i;
            if (idx >= all.size()) break;
            TabConfig.TagDef t = all.get(idx);
            boolean ok = m.cfg.canUse(p, t);
            boolean sel = t.id.equals(cur);
            Material mat = ok ? Material.matchMaterial(t.material) : Material.BARRIER;
            if (mat == null) mat = Material.NAME_TAG;
            List<String> lore = new ArrayList<>(t.description);
            lore.add("");
            lore.add("&7Preview: " + m.text.render(p, t.display, now));
            lore.add(sel ? "&a&lSELECTED" : ok ? "&eClick to use" : "&cLocked");
            g.set(i, Items.of(mat, m.text.render(p, t.display, now), lore.toArray(new String[0])), e -> {
                if (!ok) {
                    m.plugin.sfx().play(p, "error");
                    return;
                }
                m.cfg.playerTag.put(u, t.id);
                m.cfg.saveData();
                m.plugin.sfx().play(p, "success");
                m.refreshNow();
                open(p, pg);
            });
        }
        if (pg > 1) g.set(45, Items.of(Material.ARROW, "&ePrevious"), e -> open(p, pg - 1));
        if (pg < pages) g.set(53, Items.of(Material.ARROW, "&eNext"), e -> open(p, pg + 1));
        g.set(48, Items.of(Material.BARRIER, "&cRemove tag", "&7Show no tag"), e -> {
            m.cfg.playerTag.remove(u);
            m.cfg.saveData();
            m.plugin.sfx().play(p, "back");
            m.refreshNow();
            open(p, pg);
        });
        g.set(49, Items.of(Material.OAK_DOOR, "&cClose"), e -> p.closeInventory());
        g.open(p);
        m.plugin.sfx().play(p, "open");
    }
}
