# ZenTials Tab

All files in this folder are yours to edit. After editing run `/ztab reload`.

| File | What it does |
|---|---|
| `config.yml` | Tab list header/footer, name tags, chat format. The top of the file lists every placeholder and colour effect. |
| `groups.yml` | Ranks: prefix, suffix, colour, chat format. Give a rank with the permission `zentials.tab.group.<name>`. |
| `animations.yml` | Named animations. Use anywhere as `%anim:name%`. |
| `scoreboard.yml` | Sidebar boards (per permission / world). |
| `tags.yml` | Chat tags players pick with `/tag`. |
| `data.yml` | Saved choices of players. Do not edit. |

Effects: `<rainbow>`, `<rainbow:6>`, `<gradient:#ff0000:#0000ff>`, `<gradient:#ff0000:#0000ff:5>` (moving), `<pulse:#ffffff:#ff5555:3>`, `<blink:#ffffff:#555555:10>`.

Commands: `/ztab reload` · `/ztab group <player> <group|clear>` · `/ztab preview <text>` · `/ztab info` · `/tag` · `/sb`.
Permissions: `zentials.tab.admin` (admin commands), `zentials.tab.chat.effects` (use effects in chat).
