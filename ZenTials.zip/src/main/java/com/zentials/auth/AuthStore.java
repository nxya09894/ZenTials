package com.zentials.auth;

import com.zentials.core.db.Database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Account storage in ZenTials' SQLite database (table auth_accounts). Accounts are keyed by the lower-case name,
 * so "Steve" and "steve" can never be two different accounts.
 * A small in-memory cache makes logins fast; every change is written through to the database.
 * get() and the count methods may touch the disk: call them from a background thread (or for one player at join).
 */
final class AuthStore {

    record Account(String name, String hash, String regIp, String lastIp, long registered, long lastLogin,
                   long logins, String platform) {
        String key() {
            return name.toLowerCase(Locale.ROOT);
        }

        Account withHash(String h) {
            return new Account(name, h, regIp, lastIp, registered, lastLogin, logins, platform);
        }

        Account withLogin(String ip, long now) {
            return new Account(name, hash, regIp, ip, registered, now, logins + 1, platform);
        }
    }

    private static final String COLS = "name,hash,reg_ip,last_ip,registered,last_login,logins,platform";

    private final Database db;
    private final Map<String, Account> cache = new ConcurrentHashMap<>();
    private final Object createLock = new Object();

    AuthStore(Database db) throws SQLException {
        this.db = db;
        db.execNow("CREATE TABLE IF NOT EXISTS auth_accounts ("
                + "name_lower TEXT PRIMARY KEY, name TEXT NOT NULL, hash TEXT NOT NULL, reg_ip TEXT, last_ip TEXT, "
                + "registered INTEGER NOT NULL, last_login INTEGER NOT NULL DEFAULT 0, logins INTEGER NOT NULL DEFAULT 0, "
                + "platform TEXT NOT NULL DEFAULT 'java') WITHOUT ROWID");
        db.execNow("CREATE INDEX IF NOT EXISTS idx_auth_reg_ip ON auth_accounts(reg_ip)");
    }

    private static Account map(ResultSet rs) throws SQLException {
        return new Account(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                rs.getLong(5), rs.getLong(6), rs.getLong(7), rs.getString(8));
    }

    /** The account, or null if the name is not registered. Throws if the database cannot be read (never treat that as "not registered"). */
    Account get(String key) throws SQLException {
        Account a = cache.get(key);
        if (a != null) return a;
        a = db.query("SELECT " + COLS + " FROM auth_accounts WHERE name_lower=?", rs -> rs.next() ? map(rs) : null, key);
        if (a != null) cache.putIfAbsent(key, a);
        return a;
    }

    /** Creates the account and waits until it is committed. Returns false if the name is already taken. */
    boolean create(Account a) throws SQLException {
        synchronized (createLock) {
            String key = a.key();
            if (get(key) != null) return false;
            try {
                db.submit("INSERT INTO auth_accounts(name_lower," + COLS + ") VALUES(?,?,?,?,?,?,?,?,?)",
                        key, a.name(), a.hash(), a.regIp(), a.lastIp(), a.registered(), a.lastLogin(), a.logins(),
                        a.platform()).get(15, TimeUnit.SECONDS);
            } catch (ExecutionException | TimeoutException e) {
                throw new SQLException("Could not save the account", e);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new SQLException(e);
            }
            cache.put(key, a);
            return true;
        }
    }

    /** Replaces the password hash of an existing account. */
    void setHash(String key, String hash) throws SQLException {
        Account a = get(key);
        if (a == null) return;
        cache.put(key, a.withHash(hash));
        db.exec("UPDATE auth_accounts SET hash=? WHERE name_lower=?", hash, key);
    }

    void recordLogin(String key, String ip) {
        long now = System.currentTimeMillis();
        cache.computeIfPresent(key, (k, a) -> a.withLogin(ip, now));
        db.exec("UPDATE auth_accounts SET last_ip=?, last_login=?, logins=logins+1 WHERE name_lower=?", ip, now, key);
    }

    void delete(String key) {
        cache.remove(key);
        db.exec("DELETE FROM auth_accounts WHERE name_lower=?", key);
    }

    void evict(String key) {
        cache.remove(key);
    }

    int countByRegIp(String ip) throws SQLException {
        return db.query("SELECT COUNT(*) FROM auth_accounts WHERE reg_ip=?", rs -> rs.next() ? rs.getInt(1) : 0, ip);
    }

    long total() throws SQLException {
        return db.query("SELECT COUNT(*) FROM auth_accounts", rs -> rs.next() ? rs.getLong(1) : 0L);
    }

    /** True if any stored hash needs the pepper file to be checked. */
    boolean hasPepperedAccounts() throws SQLException {
        return db.query("SELECT 1 FROM auth_accounts WHERE hash LIKE '$zt$p$%' LIMIT 1", ResultSet::next);
    }
}
