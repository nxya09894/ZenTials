package com.zentials.auth;

import com.zentials.ZenTials;
import com.zentials.auth.AuthStore.Account;
import com.zentials.core.Cfg;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Auth: an AuthMe-style login system for offline-mode (cracked) servers. OFF by default (config.yml -> modules.auth).
 * Java and Bedrock (Geyser + Floodgate) players are both supported.
 *
 * Security in short: PBKDF2-HMAC-SHA512 + salt + pepper, hashing on background threads, wrong-password limits per
 * player and per IP, connection flood limit, exact name case, one login per name, nothing allowed before login,
 * passwords hidden from the server log. Settings: modules/auth/config.yml, texts: modules/auth/messages.yml.
 */
public final class AuthModule implements ZModule, Listener {

    /** Login state of ONE connection. Compared by identity, so an old connection can never unlock or lock a new one. */
    static final class Sess {
        final Player player;
        final String key;
        final String ip;
        final AtomicInteger attempts = new AtomicInteger();
        final AtomicBoolean busy = new AtomicBoolean();
        volatile boolean authed;
        volatile boolean registered;
        volatile boolean blinded;
        volatile boolean noSession;
        volatile boolean dialogShown;
        volatile long lockedAt = System.currentTimeMillis();
        volatile long lastCmd;
        volatile String platform = "java";
        volatile PlayerAuthEvent.Via via;
        volatile Component joinMsg;

        Sess(Player player, String key, String ip) {
            this.player = player;
            this.key = key;
            this.ip = ip;
        }

        /** Logged in with a password (so an account exists and /logout, /changepassword, sessions make sense). */
        boolean hasAccount() {
            return via == PlayerAuthEvent.Via.LOGIN || via == PlayerAuthEvent.Via.REGISTER
                    || via == PlayerAuthEvent.Via.SESSION;
        }
    }

    private record Session(UUID id, String ip, long expires) {
    }

    /** A command that is registered at runtime (no plugin.yml entry needed). */
    private static final class Cmd extends Command {
        private final TabExecutor handler;

        Cmd(String name, String desc, List<String> aliases, String perm, TabExecutor handler) {
            super(name, desc, "/" + name, aliases);
            if (perm != null) setPermission(perm);
            this.handler = handler;
        }

        @Override
        public boolean execute(CommandSender s, String label, String[] args) {
            if (getPermission() != null && !testPermission(s)) return true;
            return handler.onCommand(s, this, label, args);
        }

        @Override
        public List<String> tabComplete(CommandSender s, String alias, String[] args) {
            List<String> l = handler.onTabComplete(s, this, alias, args);
            return l == null ? List.of() : l;
        }
    }

    private static final String NS = "zentials:";

    private final ZenTials plugin;
    private final Map<UUID, Sess> state = new ConcurrentHashMap<>();
    private final Map<String, Sess> online = new ConcurrentHashMap<>();
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final Throttle ipFails = new Throttle();
    private final Throttle ipLocks = new Throttle();
    private final Throttle connections = new Throttle();
    private final List<Command> registered = new ArrayList<>();

    private AuthStore store;
    private volatile PasswordHasher hasher;
    private volatile PasswordPolicy policy;
    private Bedrock bedrock = Bedrock.detect(".");
    private ThreadPoolExecutor pool;
    private AuthGuard guard;
    private AuthLogFilter logFilter;
    private byte[] pepper;
    private BukkitTask tickTask;
    private BukkitTask maintTask;
    private volatile boolean broken;

    // settings (volatile: the pre-login check runs on another thread)
    private volatile YamlConfiguration msgs;
    private volatile String prefix = "&8[&bAuth&8]&7 ";
    private volatile int timeoutSec = 60;
    private volatile int remindSec = 10;
    private volatile int maxAttempts = 5;
    private volatile long cooldownMs = 1500;
    private volatile boolean blindness = true;
    private volatile boolean hideChat = true;
    private volatile boolean hideJoin = true;
    private volatile int iterations = 210_000;
    private volatile boolean pepperOn = true;
    private volatile int hashThreads = 2;
    private volatile int sessionMinutes = 5;
    private volatile int ipMaxFail = 10;
    private volatile int failWindowSec = 600;
    private volatile int lockSec = 600;
    private volatile int connMax = 8;
    private volatile int maxPerIp = 3;
    private volatile boolean exactCase = true;
    private volatile boolean blockDup = true;
    private volatile boolean allowUnregister = true;
    private volatile boolean trustBedrock = false;
    private volatile boolean failClosed = true;
    private volatile boolean dialogOn = true;
    private volatile boolean bedrockDialog = true;
    private volatile Pattern namePattern = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private volatile Set<String> trustedIps = Set.of("127.0.0.1", "0:0:0:0:0:0:0:1", "::1");
    private volatile Set<String> allowedCmds = Set.of("login", "l", "register", "reg");
    private String fallbackPrefix = ".";

    public AuthModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "auth";
    }

    // ================================================================ public API

    /** True once the player has logged in (or was let in by Bedrock trust, a session or the bypass permission). */
    public boolean isAuthenticated(Player p) {
        Sess s = state.get(p.getUniqueId());
        return s != null && s.authed;
    }

    /** True while the player has joined but not logged in yet. */
    public boolean isLocked(UUID id) {
        Sess s = state.get(id);
        return s != null && !s.authed;
    }

    boolean hideChat() {
        return hideChat;
    }

    boolean isTrusted(String ip) {
        return trustedIps.contains(ip);
    }

    AuthStore store() {
        return store;
    }

    PasswordHasher hasher() {
        return hasher;
    }

    PasswordPolicy policy() {
        return policy;
    }

    Sess sess(Player p) {
        Sess s = state.get(p.getUniqueId());
        return s != null && s.player == p ? s : null;
    }

    int lockedCount() {
        int n = 0;
        for (Sess s : state.values()) if (!s.authed) n++;
        return n;
    }

    int sessionCount() {
        return sessions.size();
    }

    int ipLockCount() {
        return ipLocks.lockCount();
    }

    boolean floodgate() {
        return bedrock.available();
    }

    String bedrockPrefix() {
        return bedrock.prefix();
    }

    boolean allowUnregister() {
        return allowUnregister;
    }

    Pattern namePattern() {
        return namePattern;
    }

    /** /login /register and any command listed in config. Also accepts "zentials:login". */
    boolean commandAllowed(String raw) {
        String s = raw.startsWith("/") ? raw.substring(1) : raw;
        int sp = s.indexOf(' ');
        String label = (sp < 0 ? s : s.substring(0, sp)).toLowerCase(Locale.ROOT);
        int c = label.indexOf(':');
        if (c >= 0) {
            if (!label.startsWith(NS)) return false;
            label = label.substring(c + 1);
        }
        return allowedCmds.contains(label);
    }

    // ================================================================ texts

    String m(String key, Object... kv) {
        String s = msgs.getString(key);
        if (s == null) s = "&c[missing text: " + key + "]";
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        return s;
    }

    Component msg(String key, Object... kv) {
        return Text.c(prefix + m(key, kv));
    }

    Component plain(String key, Object... kv) {
        return Text.c(m(key, kv));
    }

    static String fmtTime(long ms) {
        long s = Math.max(1, ms / 1000);
        return s >= 120 ? (s / 60) + "m" : s + "s";
    }

    // ================================================================ lifecycle

    @Override
    public void enable() throws Exception {
        readConfig();
        try {
            if (plugin.db() == null) throw new IllegalStateException("the ZenTials database is not running");
            store = new AuthStore(plugin.db());
            if (pepperOn) {
                Path file = new File(plugin.getDataFolder(), "data/auth-pepper.key").toPath();
                if (!Files.exists(file) && store.hasPepperedAccounts()) {
                    throw new IllegalStateException("data/auth-pepper.key is missing, but existing passwords need it. "
                            + "Put the file back from your backup (do not create a new one).");
                }
                pepper = PasswordHasher.loadOrCreatePepper(file);
            }
            hasher = new PasswordHasher(iterations, pepper);
            int n = Math.max(1, hashThreads);
            pool = new ThreadPoolExecutor(n, n, 30, TimeUnit.SECONDS, new ArrayBlockingQueue<>(64), r -> {
                Thread t = new Thread(r, "ZenTials-Auth-Hash");
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            }, new ThreadPoolExecutor.AbortPolicy());
            bedrock = Bedrock.detect(fallbackPrefix);
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "[Auth] Could not start: " + ex.getMessage(), ex);
            if (!failClosed) throw ex;
            broken = true;
            plugin.getLogger().severe("[Auth] LOCKDOWN: nobody can join until this is fixed (security.fail-closed is on).");
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
        if (broken) {
            for (Player p : Bukkit.getOnlinePlayers()) p.kick(plain("kick-unavailable"));
            return;
        }
        guard = new AuthGuard(this);
        Bukkit.getPluginManager().registerEvents(guard, plugin);

        // Commands exist only while this module is on, so they never steal /login from another plugin.
        AuthCommands cmds = new AuthCommands(this, plugin);
        CommandMap map = Bukkit.getCommandMap();
        for (String[] c : new String[][]{
                {"login", "Log in to your account", "l"},
                {"register", "Create your account", "reg"},
                {"changepassword", "Change your password", "changepass"},
                {"logout", "Log out (you have to log in again)", ""},
                {"unregister", "Delete your account", "unreg"},
                {"auth", "Auth admin: register, unregister, changepassword, forcelogin, info, status, unlock, reload", "authadmin"}}) {
            Cmd cmd = new Cmd(c[0], c[1], c[2].isEmpty() ? List.of() : List.of(c[2]),
                    c[0].equals("auth") ? "zentials.auth.admin" : null, cmds);
            map.register("zentials", cmd);
            registered.add(cmd);
        }

        try {
            logFilter = AuthLogFilter.install();
        } catch (Throwable t) {
            plugin.getLogger().warning("[Auth] Could not hide passwords from the server log (" + t + "). "
                    + "Passwords typed in /login may show in latest.log.");
        }

        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
        maintTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::maintenance, 1200L, 1200L);

        if (Bukkit.getOnlineMode()) {
            plugin.getLogger().warning("[Auth] online-mode is TRUE: Java players are already verified by Mojang. "
                    + "This module is meant for online-mode=false servers.");
        }
        plugin.getLogger().info("[Auth] Ready. Floodgate: " + (bedrock.available() ? "found (prefix '" + bedrock.prefix() + "')" : "not found")
                + ", pepper: " + (pepper != null ? "on" : "off") + ", hash: PBKDF2-SHA512 x" + iterations);

        // Enabled while players are online (plugin reload): everybody has to log in.
        for (Player p : Bukkit.getOnlinePlayers()) handleJoin(p);
    }

    @Override
    public void disable() {
        if (tickTask != null) tickTask.cancel();
        if (maintTask != null) maintTask.cancel();
        HandlerList.unregisterAll(this);
        if (guard != null) HandlerList.unregisterAll(guard);
        if (pool != null) pool.shutdownNow();
        if (logFilter != null) logFilter.uninstall();
        CommandMap map = Bukkit.getCommandMap();
        for (Command c : registered) {
            c.unregister(map);
            map.getKnownCommands().values().removeIf(x -> x == c);
        }
        registered.clear();
        for (Sess s : state.values()) {
            if (s.blinded) s.player.removePotionEffect(PotionEffectType.BLINDNESS);
        }
        state.clear();
        online.clear();
        sessions.clear();
    }

    @Override
    public void reload() {
        readConfig();
        if (!broken && pool != null) hasher = new PasswordHasher(iterations, pepper);
    }

    private void readConfig() {
        YamlConfiguration c = plugin.moduleConfig("auth");
        msgs = Cfg.yamlWithDefaults(plugin, "modules/auth/messages.yml");
        prefix = msgs.getString("prefix", "&8[&bAuth&8]&7 ");

        timeoutSec = Math.max(15, Math.min(600, c.getInt("login.timeout-seconds", 60)));
        remindSec = Math.max(0, c.getInt("login.remind-seconds", 10));
        maxAttempts = Math.max(1, Math.min(20, c.getInt("login.max-attempts", 5)));
        cooldownMs = Math.max(0, c.getLong("login.attempt-cooldown-ms", 1500));
        blindness = c.getBoolean("login.blindness", true);
        hideChat = c.getBoolean("login.hide-chat-from-unlogged", true);
        hideJoin = c.getBoolean("login.hide-join-message", true);
        dialogOn = c.getBoolean("login.dialog", true);
        Set<String> cmds = new HashSet<>(List.of("login", "l", "register", "reg"));
        for (String s : c.getStringList("login.allowed-commands")) {
            String t = s.trim().toLowerCase(Locale.ROOT);
            if (t.startsWith("/")) t = t.substring(1);
            if (!t.isEmpty()) cmds.add(t);
        }
        allowedCmds = Set.copyOf(cmds);

        policy = new PasswordPolicy(c.getInt("password.min-length", 8), c.getInt("password.max-length", 64),
                c.getBoolean("password.require-letter-and-digit", true), c.getStringList("password.blocked-passwords"));

        iterations = Math.max(100_000, c.getInt("security.hash-iterations", 210_000));
        pepperOn = c.getBoolean("security.pepper", true);
        hashThreads = Math.max(1, Math.min(8, c.getInt("security.hash-threads", 2)));
        sessionMinutes = Math.max(0, c.getInt("security.session.minutes", 5));
        if (!c.getBoolean("security.session.enabled", true)) sessionMinutes = 0;
        ipMaxFail = Math.max(3, c.getInt("security.brute-force.ip-max-failures", 10));
        failWindowSec = Math.max(30, c.getInt("security.brute-force.window-seconds", 600));
        lockSec = Math.max(30, c.getInt("security.brute-force.lock-seconds", 600));
        connMax = Math.max(2, c.getInt("security.connection-throttle.max-per-10s", 8));
        maxPerIp = Math.max(0, c.getInt("security.max-accounts-per-ip", 3));
        exactCase = c.getBoolean("security.enforce-exact-case", true);
        blockDup = c.getBoolean("security.block-duplicate-session", true);
        allowUnregister = c.getBoolean("security.allow-unregister", true);
        failClosed = c.getBoolean("security.fail-closed", true);
        bedrockDialog = c.getBoolean("bedrock.dialog", true);
        trustBedrock = c.getBoolean("bedrock.trust-floodgate", false);
        fallbackPrefix = c.getString("bedrock.prefix", ".");
        try {
            namePattern = Pattern.compile(c.getString("security.name-regex", "^[A-Za-z0-9_]{3,16}$"));
        } catch (PatternSyntaxException ex) {
            plugin.getLogger().warning("[Auth] security.name-regex is not valid, using the default.");
            namePattern = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
        }
        Set<String> ips = new HashSet<>(List.of("127.0.0.1", "0:0:0:0:0:0:0:1", "::1"));
        ips.addAll(c.getStringList("security.trusted-ips"));
        trustedIps = Set.copyOf(ips);
    }

    // ================================================================ helpers

    private static String lower(String s) {
        return s.toLowerCase(Locale.ROOT);
    }

    private static String ipOf(Player p) {
        var a = p.getAddress();
        return a == null || a.getAddress() == null ? "unknown" : a.getAddress().getHostAddress();
    }

    /** Runs a slow job (hashing) on the small auth thread pool. False if the pool is full (server is busy). */
    boolean runHash(Runnable r) {
        try {
            pool.execute(r);
            return true;
        } catch (RejectedExecutionException ex) {
            return false;
        }
    }

    void async(Runnable r) {
        if (plugin.isEnabled()) Bukkit.getScheduler().runTaskAsynchronously(plugin, r);
    }

    void sync(Runnable r) {
        if (plugin.isEnabled()) Bukkit.getScheduler().runTask(plugin, r);
    }

    void forgetSession(String key) {
        sessions.remove(key);
    }

    void unlockIp(String ip) {
        ipLocks.unlock(ip);
        ipFails.reset("f:" + ip);
    }

    // ================================================================ before the player is in the world

    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (e.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) return;
        if (broken) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-unavailable"));
            return;
        }
        String name = e.getName();
        String key = lower(name);
        String ip = e.getAddress().getHostAddress();
        boolean trusted = trustedIps.contains(ip);

        if (!trusted) {
            long left = ipLocks.lockedFor(ip);
            if (left > 0) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-ip-locked", "time", fmtTime(left)));
                return;
            }
            if (connections.hit("c:" + ip, 10_000L) > connMax) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-too-many-connections"));
                return;
            }
        }
        // Names that start with the Floodgate prefix are checked after join (Floodgate has to confirm them).
        if (!bedrock.hasPrefix(name) && !namePattern.matcher(name).matches()) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-invalid-name"));
            return;
        }
        // Somebody who is already logged in under this name cannot be kicked off by a stranger from another IP.
        Sess other = online.get(key);
        if (blockDup && other != null && other.authed && !other.ip.equals(ip)) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-already-online"));
            return;
        }
        try {
            Account a = store.get(key);
            if (a != null && exactCase && !a.name().equals(name)) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-wrong-case", "name", a.name()));
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "[Auth] Database read failed during login of " + name, ex);
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plain("kick-unavailable"));
        }
    }

    // ================================================================ join / quit

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        handleJoin(e.getPlayer());
    }

    /** Runs after the Chat module: the join message is held back until the player has logged in. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoinMessage(PlayerJoinEvent e) {
        Sess s = sess(e.getPlayer());
        if (s == null || s.authed || !hideJoin) return;
        s.joinMsg = e.joinMessage();
        e.joinMessage(null);
    }

    private void handleJoin(Player p) {
        if (broken) {
            p.kick(plain("kick-unavailable"));
            return;
        }
        UUID id = p.getUniqueId();
        String key = lower(p.getName());
        Sess s = new Sess(p, key, ipOf(p));
        state.put(id, s);          // from this moment the player counts as NOT logged in
        online.put(key, s);

        boolean isBedrock = bedrock.isBedrock(id);
        s.platform = isBedrock ? "bedrock" : "java";
        if (bedrock.available() && bedrock.hasPrefix(p.getName()) && !isBedrock) {
            p.kick(plain("kick-prefix"));   // a Java player pretending to be a Bedrock player
            return;
        }
        if (p.hasPermission("zentials.auth.bypass")) {
            authenticate(p, s, PlayerAuthEvent.Via.BYPASS);
            return;
        }
        if (isBedrock && trustBedrock) {
            authenticate(p, s, PlayerAuthEvent.Via.BEDROCK);
            return;
        }
        Account acc;
        try {
            acc = store.get(s.key);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "[Auth] Database read failed for " + p.getName(), ex);
            p.kick(plain("kick-unavailable"));
            return;
        }
        Session ss = sessions.remove(key);
        if (acc != null && sessionMinutes > 0 && ss != null && ss.id().equals(id) && ss.ip().equals(s.ip)
                && ss.expires() > System.currentTimeMillis()) {
            s.registered = true;
            authenticate(p, s, PlayerAuthEvent.Via.SESSION);
            return;
        }
        s.registered = acc != null;
        lock(p, s, false);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && state.get(id) == s && !s.authed) prompt(p, s);
        }, 10L);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Sess s = state.get(p.getUniqueId());
        if (s == null || s.player != p) return;   // an older connection that was replaced
        state.remove(p.getUniqueId(), s);
        online.remove(s.key, s);
        if (!s.authed) {
            if (s.blinded) p.removePotionEffect(PotionEffectType.BLINDNESS);
            if (hideJoin) e.quitMessage(null);
        } else if (sessionMinutes > 0 && s.hasAccount() && !s.noSession
                && e.getReason() != PlayerQuitEvent.QuitReason.KICKED) {
            sessions.put(s.key, new Session(p.getUniqueId(), s.ip, System.currentTimeMillis() + sessionMinutes * 60_000L));
        }
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> {
                if (!online.containsKey(s.key)) store.evict(s.key);
            }, 1200L);
        }
    }

    // ================================================================ lock / unlock

    private void lock(Player p, Sess s, boolean refreshCommands) {
        s.authed = false;
        s.dialogShown = false;
        s.via = null;
        s.lockedAt = System.currentTimeMillis();
        s.attempts.set(0);
        if (blindness) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, (timeoutSec + 10) * 20, 0, false, false, false));
            s.blinded = true;
        }
        if (refreshCommands) {
            prompt(p, s);
            p.updateCommands();
        }
    }

    /** Shows the login/register window (Java 1.21.6+) or, if that is off or not possible, the chat + title prompt. */
    private void prompt(Player p, Sess s) {
        if (s.dialogShown) return;   // the window is already open; reopening it would wipe what the player typed
        if (openDialog(p, s, null)) return;
        String k = s.registered ? "login" : "register";
        tell(p, msg(k + "-prompt"));
        p.showTitle(Title.title(plain("title-" + k), plain("subtitle-" + k),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(4), Duration.ofMillis(500))));
    }

    /** Java and Bedrock (Geyser translates the window) both get it. */
    private boolean openDialog(Player p, Sess s, Component error) {
        if (!dialogOn || (!bedrockDialog && "bedrock".equals(s.platform))) return false;
        try {
            AuthDialog.show(this, p, !s.registered, error);
            s.dialogShown = true;
            return true;
        } catch (Throwable t) {
            dialogOn = false;
            plugin.getLogger().warning("[Auth] The login window is not available on this server (" + t
                    + "). Using chat commands instead. Set login.dialog: false to hide this message.");
            return false;
        }
    }

    /** Sends a message. While the window is open the message goes into the window (chat is hidden behind it). */
    void tell(Player p, Component c) {
        p.sendMessage(c);
        Sess s = sess(p);
        if (s != null && !s.authed && s.dialogShown) openDialog(p, s, c);
    }

    void authenticate(Player p, Sess s, PlayerAuthEvent.Via via) {
        s.authed = true;
        if (s.dialogShown) {
            s.dialogShown = false;
            p.closeDialog();
        }
        s.via = via;
        s.attempts.set(0);
        if (s.blinded) {
            p.removePotionEffect(PotionEffectType.BLINDNESS);
            s.blinded = false;
        }
        switch (via) {
            case LOGIN -> tell(p, msg("login-success"));
            case REGISTER -> tell(p, msg("register-success"));
            case SESSION -> tell(p, msg("session-resumed"));
            case BEDROCK -> tell(p, msg("bedrock-auto"));
            case ADMIN -> tell(p, msg("admin-forced"));
            case BYPASS -> {
            }
        }
        if (s.hasAccount()) {
            store.recordLogin(s.key, s.ip);
            p.showTitle(Title.title(plain("title-success"), plain("subtitle-success"),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))));
        }
        if (via != PlayerAuthEvent.Via.BYPASS) plugin.sfx().play(p, "success");
        Component jm = s.joinMsg;
        if (jm != null) {
            s.joinMsg = null;
            Bukkit.broadcast(jm);
        }
        p.updateCommands();
        Bukkit.getPluginManager().callEvent(new PlayerAuthEvent(p, via));
    }

    // ================================================================ commands (called from AuthCommands, main thread)

    /** Cooldown and "one check at a time per player". Hashing is expensive, so spamming it must not work. */
    private boolean ready(Player p, Sess s) {
        long now = System.currentTimeMillis();
        if (now - s.lastCmd < cooldownMs || !s.busy.compareAndSet(false, true)) {
            tell(p, msg("slow-down"));
            return false;
        }
        s.lastCmd = now;
        return true;
    }

    void doLogin(Player p, String pw) {
        Sess s = sess(p);
        if (s == null) return;
        if (s.authed) {
            tell(p, msg("already-logged-in"));
            return;
        }
        if (!s.registered) {
            tell(p, msg("not-registered"));
            return;
        }
        if (!isTrusted(s.ip) && ipLocks.lockedFor(s.ip) > 0) {
            p.kick(plain("kick-ip-locked", "time", fmtTime(ipLocks.lockedFor(s.ip))));
            return;
        }
        if (!ready(p, s)) return;
        final PasswordHasher hs = hasher;
        boolean queued = runHash(() -> {
            boolean ok = false;
            boolean err = false;
            String upgraded = null;
            try {
                Account a = store.get(s.key);
                if (a != null && hs.verify(pw, a.hash())) {
                    ok = true;
                    if (hs.needsRehash(a.hash())) upgraded = hs.hash(pw);
                }
            } catch (Exception ex) {
                err = true;
                plugin.getLogger().log(Level.WARNING, "[Auth] Login check failed for " + s.key, ex);
            }
            final boolean fOk = ok;
            final boolean fErr = err;
            final String up = upgraded;
            sync(() -> {
                s.busy.set(false);
                if (state.get(p.getUniqueId()) != s || !p.isOnline() || s.authed) return;
                if (fErr) {
                    tell(p, msg("error"));
                } else if (fOk) {
                    if (up != null) {
                        try {
                            store.setHash(s.key, up);
                        } catch (SQLException ex) {
                            plugin.getLogger().log(Level.WARNING, "[Auth] Could not upgrade the hash of " + s.key, ex);
                        }
                    }
                    authenticate(p, s, PlayerAuthEvent.Via.LOGIN);
                } else {
                    wrongPassword(p, s);
                }
            });
        });
        if (!queued) {
            s.busy.set(false);
            tell(p, msg("busy"));
        }
    }

    void doRegister(Player p, String pw, String confirm) {
        Sess s = sess(p);
        if (s == null) return;
        if (s.authed) {
            tell(p, msg("already-logged-in"));
            return;
        }
        if (s.registered) {
            tell(p, msg("already-registered"));
            return;
        }
        if (!pw.equals(confirm)) {
            tell(p, msg("pw-mismatch"));
            return;
        }
        String bad = policy.check(pw, p.getName());
        if (bad != null) {
            tell(p, msg(bad, "min", policy.min(), "max", policy.max()));
            return;
        }
        if (!ready(p, s)) return;
        final boolean ipExempt = isTrusted(s.ip) || p.hasPermission("zentials.auth.ip.bypass");
        final PasswordHasher hs = hasher;
        final String name = p.getName();
        final String platform = s.platform;
        boolean queued = runHash(() -> {
            int result;   // 0 created, 1 name taken, 2 too many accounts on this IP, 3 error
            try {
                if (store.get(s.key) != null) {
                    result = 1;
                } else if (!ipExempt && maxPerIp > 0 && store.countByRegIp(s.ip) >= maxPerIp) {
                    result = 2;
                } else {
                    long now = System.currentTimeMillis();
                    result = store.create(new Account(name, hs.hash(pw), s.ip, s.ip, now, now, 1, platform)) ? 0 : 1;
                }
            } catch (Exception ex) {
                result = 3;
                plugin.getLogger().log(Level.WARNING, "[Auth] Register failed for " + s.key, ex);
            }
            final int r = result;
            sync(() -> {
                s.busy.set(false);
                if (state.get(p.getUniqueId()) != s || !p.isOnline() || s.authed) return;
                switch (r) {
                    case 0 -> {
                        s.registered = true;
                        authenticate(p, s, PlayerAuthEvent.Via.REGISTER);
                    }
                    case 1 -> {
                        s.registered = true;
                        tell(p, msg("already-registered"));
                    }
                    case 2 -> tell(p, msg("reg-ip-limit", "max", maxPerIp));
                    default -> tell(p, msg("error"));
                }
            });
        });
        if (!queued) {
            s.busy.set(false);
            tell(p, msg("busy"));
        }
    }

    void doChangePassword(Player p, String oldPw, String newPw) {
        Sess s = sess(p);
        if (s == null || !s.authed || !s.hasAccount()) {
            tell(p, msg(s != null && s.authed ? "no-account" : "login-first"));
            return;
        }
        if (oldPw.equals(newPw)) {
            tell(p, msg("same-password"));
            return;
        }
        String bad = policy.check(newPw, p.getName());
        if (bad != null) {
            tell(p, msg(bad, "min", policy.min(), "max", policy.max()));
            return;
        }
        if (!ready(p, s)) return;
        final PasswordHasher hs = hasher;
        boolean queued = runHash(() -> {
            int result = 0;   // 0 ok, 1 wrong old password, 2 error
            try {
                Account a = store.get(s.key);
                if (a == null || !hs.verify(oldPw, a.hash())) result = 1;
                else store.setHash(s.key, hs.hash(newPw));
            } catch (Exception ex) {
                result = 2;
                plugin.getLogger().log(Level.WARNING, "[Auth] Password change failed for " + s.key, ex);
            }
            final int r = result;
            sync(() -> {
                s.busy.set(false);
                if (state.get(p.getUniqueId()) != s || !p.isOnline()) return;
                if (r == 0) {
                    forgetSession(s.key);
                    tell(p, msg("password-changed"));
                    plugin.sfx().play(p, "success");
                } else if (r == 1) {
                    wrongPassword(p, s);
                } else {
                    tell(p, msg("error"));
                }
            });
        });
        if (!queued) {
            s.busy.set(false);
            tell(p, msg("busy"));
        }
    }

    void doUnregister(Player p, String pw) {
        Sess s = sess(p);
        if (s == null || !s.authed || !s.hasAccount()) {
            tell(p, msg(s != null && s.authed ? "no-account" : "login-first"));
            return;
        }
        if (!allowUnregister) {
            tell(p, msg("unregister-disabled"));
            return;
        }
        if (!ready(p, s)) return;
        final PasswordHasher hs = hasher;
        boolean queued = runHash(() -> {
            int result = 0;   // 0 deleted, 1 wrong password, 2 error
            try {
                Account a = store.get(s.key);
                if (a == null || !hs.verify(pw, a.hash())) result = 1;
            } catch (Exception ex) {
                result = 2;
                plugin.getLogger().log(Level.WARNING, "[Auth] Unregister check failed for " + s.key, ex);
            }
            final int r = result;
            sync(() -> {
                s.busy.set(false);
                if (state.get(p.getUniqueId()) != s || !p.isOnline()) return;
                if (r == 0) {
                    s.noSession = true;
                    store.delete(s.key);
                    forgetSession(s.key);
                    plugin.getLogger().info("[Auth] " + p.getName() + " deleted their account.");
                    p.kick(plain("kick-unregistered"));
                } else if (r == 1) {
                    wrongPassword(p, s);
                } else {
                    tell(p, msg("error"));
                }
            });
        });
        if (!queued) {
            s.busy.set(false);
            tell(p, msg("busy"));
        }
    }

    void doLogout(Player p) {
        Sess s = sess(p);
        if (s == null || !s.authed) {
            tell(p, msg("login-first"));
            return;
        }
        if (!s.hasAccount()) {
            tell(p, msg("logout-unavailable"));
            return;
        }
        forgetSession(s.key);
        s.registered = true;
        lock(p, s, true);
        tell(p, msg("logout-success"));
    }

    /** Wrong password: count it for the player and for the IP, kick or lock the IP when the limits are reached. */
    private void wrongPassword(Player p, Sess s) {
        int n = s.attempts.incrementAndGet();
        plugin.getLogger().warning("[Auth] Wrong password for " + p.getName() + " from " + s.ip + " (" + n + "/" + maxAttempts + ")");
        plugin.sfx().play(p, "error");
        if (!isTrusted(s.ip)) {
            int ipn = ipFails.hit("f:" + s.ip, failWindowSec * 1000L);
            if (ipn >= ipMaxFail) {
                ipLocks.lock(s.ip, lockSec * 1000L);
                plugin.getLogger().warning("[Auth] " + s.ip + " is locked for " + fmtTime(lockSec * 1000L) + " (" + ipn + " wrong passwords).");
                p.kick(plain("kick-ip-locked", "time", fmtTime(lockSec * 1000L)));
                return;
            }
        }
        if (n >= maxAttempts) {
            p.kick(plain("kick-too-many-attempts"));
            return;
        }
        tell(p, msg("wrong-password", "left", maxAttempts - n));
    }

    /** Admin: let an online, not yet logged in player in. */
    boolean forceLogin(Player p) {
        Sess s = sess(p);
        if (s == null || s.authed) return false;
        authenticate(p, s, PlayerAuthEvent.Via.ADMIN);
        return true;
    }

    /** Admin created an account for a player who is online and waiting at /register: switch them to the login prompt. */
    void accountCreatedFor(String key) {
        Sess s = online.get(key);
        if (s != null && !s.authed && !s.registered) {
            s.registered = true;
            if (s.player.isOnline()) prompt(s.player, s);
        }
    }

    /** Admin deleted an account: a logged-in owner is removed from the server. */
    void accountDeletedFor(String key) {
        sessions.remove(key);
        Sess s = online.get(key);
        if (s == null) return;
        s.noSession = true;
        s.registered = false;
        if (s.authed && s.hasAccount()) s.player.kick(plain("kick-unregistered"));
    }

    // ================================================================ timers

    private void tick() {
        if (state.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (Sess s : state.values()) {
            if (s.authed) continue;
            Player p = s.player;
            if (!p.isOnline()) continue;
            long elapsed = (now - s.lockedAt) / 1000L;
            long left = timeoutSec - elapsed;
            if (left <= 0) {
                p.kick(plain("kick-timeout"));
                continue;
            }
            p.sendActionBar(plain("actionbar", "seconds", left));
            if (remindSec > 0 && elapsed > 0 && elapsed % remindSec == 0) prompt(p, s);
        }
    }

    private void maintenance() {
        long now = System.currentTimeMillis();
        sessions.values().removeIf(x -> x.expires() <= now);
        ipFails.purge(failWindowSec * 1000L);
        ipLocks.purge(0);
        connections.purge(10_000L);
    }
}
