package com.zentials.auth;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.apache.logging.log4j.message.Message;

import java.util.Locale;
import java.util.Set;

/**
 * Keeps passwords out of latest.log and the console. The server writes "<name> issued server command: /login <password>"
 * BEFORE any plugin can stop it, so the only way to hide it is to filter that log line.
 */
final class AuthLogFilter extends AbstractFilter {
    private static final String MARK = "issued server command: /";
    private static final Set<String> PLAYER_CMDS = Set.of("login", "l", "register", "reg", "changepassword",
            "changepass", "unregister", "unreg");
    private static final Set<String> ADMIN_SUBS = Set.of("register", "reg", "changepassword", "changepass");

    @Override
    public Result filter(LogEvent event) {
        if (event == null || event.getMessage() == null) return Result.NEUTRAL;
        return check(event.getMessage().getFormattedMessage());
    }

    @Override
    public Result filter(Logger logger, Level level, Marker marker, Message msg, Throwable t) {
        return msg == null ? Result.NEUTRAL : check(msg.getFormattedMessage());
    }

    private static Result check(String text) {
        if (text == null) return Result.NEUTRAL;
        int i = text.indexOf(MARK);
        if (i < 0) return Result.NEUTRAL;
        String[] t = text.substring(i + MARK.length()).trim().split("\\s+", 3);
        String cmd = t[0].toLowerCase(Locale.ROOT);
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (PLAYER_CMDS.contains(cmd)) return Result.DENY;
        if ((cmd.equals("auth") || cmd.equals("authadmin")) && t.length > 1
                && ADMIN_SUBS.contains(t[1].toLowerCase(Locale.ROOT))) return Result.DENY;
        return Result.NEUTRAL;
    }

    static AuthLogFilter install() {
        AuthLogFilter f = new AuthLogFilter();
        ((Logger) LogManager.getRootLogger()).addFilter(f);
        return f;
    }

    void uninstall() {
        try {
            ((Logger) LogManager.getRootLogger()).get().removeFilter(this);
        } catch (Throwable ignored) {
            // shutting down anyway
        }
    }
}
