package com.zentials.auth;

import com.destroystokyo.paper.event.player.PlayerConnectionCloseEvent;
import com.destroystokyo.paper.profile.PlayerProfile;
import io.papermc.paper.connection.PlayerConfigurationConnection;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.event.connection.configuration.AsyncPlayerConnectionConfigureEvent;
import io.papermc.paper.event.player.PlayerCustomClickEvent;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.net.InetSocketAddress;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * The window BEFORE the player enters the world (configuration phase). The player is held here until the password
 * is right (or the account is created); a wrong password, a timeout or the Leave button means they never spawn.
 * The result is handed to AuthModule, which lets the player straight in after join.
 * This runs on Paper's async connection thread, so waiting here does not lag the server.
 */
final class AuthPreJoin implements Listener {
    private record Resp(boolean cancel, String pw, String pw2) {
    }

    private final AuthModule a;
    private final Map<PlayerConfigurationConnection, CompletableFuture<Resp>> waiting = new ConcurrentHashMap<>();

    AuthPreJoin(AuthModule a) {
        this.a = a;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onConfigure(AsyncPlayerConnectionConfigureEvent e) {
        PlayerConfigurationConnection conn = e.getConnection();
        PlayerProfile prof = conn.getProfile();
        String name = prof.getName();
        UUID id = prof.getId();
        InetSocketAddress sa = conn.getClientAddress();
        if (name == null || id == null || sa == null || sa.getAddress() == null) return;
        String ip = sa.getAddress().getHostAddress();
        if (!a.prejoinApplies(name, id, ip)) return;

        String key = name.toLowerCase(Locale.ROOT);
        long deadline = System.currentTimeMillis() + a.timeoutSeconds() * 1000L;
        try {
            AuthStore.Account acc = a.store().get(key);
            boolean register = acc == null;
            Component error = null;
            int tries = 0;
            while (true) {
                long left = deadline - System.currentTimeMillis();
                if (left <= 0) {
                    a.preDeny(key, id, a.plain("kick-timeout"));
                    return;
                }
                if (!conn.isConnected()) return;

                CompletableFuture<Resp> f = new CompletableFuture<>();
                waiting.put(conn, f);
                Resp r;
                try {
                    conn.getAudience().showDialog(AuthDialog.preJoin(a, register, error, a.cancelButton()));
                    r = f.get(left, TimeUnit.MILLISECONDS);
                } catch (TimeoutException ex) {
                    a.preDeny(key, id, a.plain("kick-timeout"));
                    return;
                } finally {
                    waiting.remove(conn);
                }
                if (r == null) return;   // the connection closed
                if (r.cancel()) {
                    a.preDeny(key, id, a.plain("kick-dialog-quit"));
                    return;
                }
                String pw = r.pw() == null ? "" : r.pw();

                if (!register) {
                    switch (a.checkPasswordBlocking(key, pw)) {
                        case OK -> {
                            a.preApprove(key, id, ip, PlayerAuthEvent.Via.LOGIN);
                            conn.getAudience().closeDialog();
                            return;
                        }
                        case WRONG -> {
                            tries++;
                            if (a.noteWrong(name, ip, tries)) {
                                a.preDeny(key, id, a.plain("kick-ip-locked", "time", a.lockTime()));
                                return;
                            }
                            if (tries >= a.maxAttempts()) {
                                a.preDeny(key, id, a.plain("kick-too-many-attempts"));
                                return;
                            }
                            error = a.plain("wrong-password", "left", a.maxAttempts() - tries);
                        }
                        case BUSY -> error = a.plain("busy");
                        default -> error = a.plain("error");
                    }
                } else {
                    String pw2 = r.pw2() == null ? "" : r.pw2();
                    String bad = pw.equals(pw2) ? a.policy().check(pw, name) : "pw-mismatch";
                    if (bad != null) {
                        error = a.plain(bad, "min", a.policy().min(), "max", a.policy().max());
                        continue;
                    }
                    switch (a.registerBlocking(name, ip, pw, a.platformOf(id))) {
                        case CREATED -> {
                            a.preApprove(key, id, ip, PlayerAuthEvent.Via.REGISTER);
                            conn.getAudience().closeDialog();
                            return;
                        }
                        case TAKEN -> register = false;   // somebody registered this name a moment ago: ask for the password
                        case LIMIT -> error = a.plain("reg-ip-limit", "max", a.maxAccountsPerIp());
                        case BUSY -> error = a.plain("busy");
                        default -> error = a.plain("error");
                    }
                }
            }
        } catch (Exception ex) {
            if (ex instanceof InterruptedException) Thread.currentThread().interrupt();
            a.logError("Pre-join window failed for " + name, ex);
            a.preDeny(key, id, a.plain("kick-unavailable"));
        }
    }

    /** The player pressed a button in the window. */
    @EventHandler
    public void onClick(PlayerCustomClickEvent e) {
        Key k = e.getIdentifier();
        boolean cancel = k.equals(AuthDialog.CANCEL);
        if (!cancel && !k.equals(AuthDialog.SUBMIT)) return;
        if (!(e.getCommonConnection() instanceof PlayerConfigurationConnection conn)) return;
        CompletableFuture<Resp> f = waiting.get(conn);
        if (f == null) return;
        DialogResponseView v = e.getDialogResponseView();
        f.complete(new Resp(cancel, v == null ? null : v.getText("pw"), v == null ? null : v.getText("pw2")));
    }

    /** The player left while the window was open: stop waiting. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(PlayerConnectionCloseEvent e) {
        String n = e.getPlayerName();
        if (n == null) return;
        for (Map.Entry<PlayerConfigurationConnection, CompletableFuture<Resp>> en : waiting.entrySet()) {
            String w = en.getKey().getProfile().getName();
            if (w != null && w.equalsIgnoreCase(n)) en.getValue().complete(null);
        }
    }
}
