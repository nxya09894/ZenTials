package com.zentials.auth;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Rules for new passwords. check() returns the message key of the first broken rule, or null if the password is fine. */
final class PasswordPolicy {
    private static final Set<String> COMMON = Set.copyOf(List.of(
            "password", "password1", "password12", "password123", "passw0rd", "p@ssw0rd", "12345678", "123456789",
            "1234567890", "123123123", "987654321", "11111111", "00000000", "qwertyui", "qwertyuiop", "qwerty12",
            "qwerty123", "qwerty1234", "asdfghjk", "asdfghjkl", "asdf1234", "zxcvbnm1", "zxcvbnm123", "1q2w3e4r",
            "1q2w3e4r5t", "qazwsxedc", "zaq12wsx", "abcd1234", "abc12345", "iloveyou", "iloveyou1", "admin123",
            "administrator", "letmein1", "letmein123", "welcome1", "welcome123", "minecraft", "minecraft1",
            "minecraft123", "survival", "skyblock", "creeper1", "herobrine", "diamond1", "football", "baseball",
            "superman", "dragon123", "master123", "sunshine", "princess", "whatever", "trustno1", "starwars",
            "monkey123", "shadow123", "michael1", "jessica1", "charlie1", "server123", "playerone", "pogiako",
            "mahalkita", "kumusta1", "philippines", "pilipinas", "bahalakana"));

    private final int min;
    private final int max;
    private final boolean needMixed;
    private final Set<String> extra = new HashSet<>();

    PasswordPolicy(int min, int max, boolean needLetterAndDigit, List<String> extraCommon) {
        this.min = Math.max(6, min);
        this.max = Math.max(this.min, Math.min(128, max));
        this.needMixed = needLetterAndDigit;
        for (String s : extraCommon) extra.add(s.toLowerCase(Locale.ROOT));
    }

    int min() {
        return min;
    }

    int max() {
        return max;
    }

    String check(String pw, String name) {
        if (pw.length() < min) return "pw-too-short";
        if (pw.length() > max) return "pw-too-long";
        boolean letter = false;
        boolean digit = false;
        for (int i = 0; i < pw.length(); i++) {
            char c = pw.charAt(i);
            if (c <= ' ' || c == 127) return "pw-chars";
            if (Character.isLetter(c)) letter = true;
            if (Character.isDigit(c)) digit = true;
        }
        String low = pw.toLowerCase(Locale.ROOT);
        String n = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (n.length() >= 3 && low.contains(n)) return "pw-is-name";
        if (COMMON.contains(low) || extra.contains(low) || low.chars().distinct().count() == 1) return "pw-common";
        if (needMixed && !(letter && digit)) return "pw-weak";
        return null;
    }
}
