package com.zentials.auth;

import com.destroystokyo.paper.event.server.AsyncTabCompleteEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityMountEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.List;

/**
 * Everything a player who has not logged in yet is NOT allowed to do.
 * Every handler starts with one map lookup, so it costs almost nothing for players who are logged in.
 */
final class AuthGuard implements Listener {
    private final AuthModule auth;

    AuthGuard(AuthModule auth) {
        this.auth = auth;
    }

    private boolean locked(Entity e) {
        return e instanceof Player p && auth.isLocked(p.getUniqueId());
    }

    // ---------------------------------------------------------------- movement

    /** Standing still, but falling and looking around are allowed (no floating in the air, no frozen camera). */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null || !auth.isLocked(e.getPlayer().getUniqueId())) return;
        Location from = e.getFrom();
        boolean sideways = from.getX() != to.getX() || from.getZ() != to.getZ();
        boolean up = to.getY() > from.getY();
        if (!sideways && !up) return;
        Location fixed = from.clone();
        fixed.setY(Math.min(from.getY(), to.getY()));
        fixed.setYaw(to.getYaw());
        fixed.setPitch(to.getPitch());
        e.setTo(fixed);
    }

    // ---------------------------------------------------------------- chat and commands

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        if (!auth.isLocked(e.getPlayer().getUniqueId())) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(auth.msg("chat-blocked"));
    }

    /** Players who are logged in do not see what unlogged players could type. Unlogged players see no chat either. */
    @EventHandler(priority = EventPriority.HIGH)
    public void hideChat(AsyncChatEvent e) {
        if (!auth.hideChat()) return;
        e.viewers().removeIf(v -> v instanceof Player p && auth.isLocked(p.getUniqueId()));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!auth.isLocked(e.getPlayer().getUniqueId())) return;
        if (auth.commandAllowed(e.getMessage())) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(auth.msg("cmd-blocked"));
    }

    /** The command list the client shows (tab completion) only contains /login and /register. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommandSend(PlayerCommandSendEvent e) {
        if (!auth.isLocked(e.getPlayer().getUniqueId())) return;
        e.getCommands().removeIf(c -> !auth.commandAllowed(c));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onTab(AsyncTabCompleteEvent e) {
        if (e.getSender() instanceof Player p && auth.isLocked(p.getUniqueId())) {
            e.setCompletions(List.of());
            e.setHandled(true);
        }
    }

    // ---------------------------------------------------------------- world and items

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlace(BlockPlaceEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPickup(EntityPickupItemEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onConsume(PlayerItemConsumeEvent e) {
        if (auth.isLocked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInvClick(InventoryClickEvent e) {
        if (locked(e.getWhoClicked())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInvOpen(InventoryOpenEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onMount(EntityMountEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- combat and survival

    /** Nothing can hurt a player who is still logging in. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamage(EntityDamageEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamageDealt(EntityDamageByEntityEvent e) {
        if (locked(e.getDamager())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onTarget(EntityTargetEvent e) {
        if (e.getTarget() != null && locked(e.getTarget())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onFood(FoodLevelChangeEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }
}
