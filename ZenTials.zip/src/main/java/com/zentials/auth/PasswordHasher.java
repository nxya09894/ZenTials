package com.zentials.auth;

import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

/**
 * Password hashing with nothing but the JDK: PBKDF2-HMAC-SHA512, a random 16 byte salt per password and an
 * optional server-side "pepper" (a secret key kept in a file next to, not inside, the database).
 * Stored format: $zt$<p|n>$<iterations>$<salt>$<hash>   (p = peppered, n = not peppered)
 * The iteration count is stored in each hash, so it can be raised later and old hashes are upgraded at the next login.
 * This is slow on purpose: always call it from a background thread, never from the main thread.
 */
public final class PasswordHasher {
    private static final String ALGO = "PBKDF2WithHmacSHA512";
    private static final int SALT_BYTES = 16;
    private static final int KEY_BITS = 512;
    private static final int MIN_ITER = 1_000;
    private static final int MAX_ITER = 5_000_000;
    private static final SecureRandom RNG = new SecureRandom();

    private final int iterations;
    private final byte[] pepper; // null = no pepper

    public PasswordHasher(int iterations, byte[] pepper) {
        this.iterations = Math.max(10_000, Math.min(MAX_ITER, iterations));
        this.pepper = pepper;
    }

    public int iterations() {
        return iterations;
    }

    public boolean peppered() {
        return pepper != null;
    }

    public String hash(String password) {
        byte[] salt = new byte[SALT_BYTES];
        RNG.nextBytes(salt);
        boolean usePepper = pepper != null;
        byte[] dk = derive(password, salt, iterations, usePepper);
        Base64.Encoder b64 = Base64.getEncoder();
        return "$zt$" + (usePepper ? "p" : "n") + "$" + iterations + "$" + b64.encodeToString(salt) + "$" + b64.encodeToString(dk);
    }

    /** Constant-time check. Returns false for anything malformed. */
    public boolean verify(String password, String stored) {
        if (password == null || stored == null) return false;
        String[] p = stored.split("\\$");
        if (p.length != 6 || !p[1].equals("zt")) return false;
        boolean usePepper = p[2].equals("p");
        if (!usePepper && !p[2].equals("n")) return false;
        if (usePepper && pepper == null) return false;
        int iter;
        byte[] salt;
        byte[] want;
        try {
            iter = Integer.parseInt(p[3]);
            salt = Base64.getDecoder().decode(p[4]);
            want = Base64.getDecoder().decode(p[5]);
        } catch (IllegalArgumentException e) {
            return false;
        }
        if (iter < MIN_ITER || iter > MAX_ITER || want.length == 0) return false;
        byte[] got = derive(password, salt, iter, usePepper);
        return MessageDigest.isEqual(got, want);
    }

    /** True if this hash is weaker than the current settings (fewer iterations, or no pepper while one is set now). */
    public boolean needsRehash(String stored) {
        String[] p = stored.split("\\$");
        if (p.length != 6) return true;
        try {
            return Integer.parseInt(p[3]) < iterations || (pepper != null && !p[2].equals("p"));
        } catch (NumberFormatException e) {
            return true;
        }
    }

    private byte[] derive(String password, byte[] salt, int iter, boolean usePepper) {
        char[] chars = usePepper ? pre(password) : password.toCharArray();
        PBEKeySpec spec = new PBEKeySpec(chars, salt, iter, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance(ALGO).generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("PBKDF2 is not available on this JVM", e);
        } finally {
            spec.clearPassword();
            Arrays.fill(chars, '\0');
        }
    }

    /** HMAC the password with the pepper first, so a stolen database alone is not enough to crack anything. */
    private char[] pre(String password) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(pepper, "HmacSHA256"));
            byte[] d = mac.doFinal(password.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().withoutPadding().encodeToString(d).toCharArray();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("HmacSHA256 is not available on this JVM", e);
        }
    }

    /** Reads the pepper file, or creates it (32 random bytes, owner-only permissions where the OS supports it). */
    public static byte[] loadOrCreatePepper(Path file) throws IOException {
        if (Files.exists(file)) {
            byte[] b;
            try {
                b = Base64.getDecoder().decode(Files.readString(file, StandardCharsets.UTF_8).trim());
            } catch (IllegalArgumentException e) {
                throw new IOException("The pepper file is damaged: " + file.getFileName());
            }
            if (b.length < 16) throw new IOException("The pepper file is too short: " + file.getFileName());
            return b;
        }
        Path dir = file.toAbsolutePath().getParent();
        if (dir != null) Files.createDirectories(dir);
        byte[] b = new byte[32];
        RNG.nextBytes(b);
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        Files.writeString(tmp, Base64.getEncoder().encodeToString(b), StandardCharsets.UTF_8);
        try {
            Files.setPosixFilePermissions(tmp, PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException ignored) {
            // Windows: the folder permissions apply
        }
        try {
            Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, file);
        }
        return b;
    }
}
