package com.zentials.auth;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * The login / register window (Minecraft dialog screen, Java 1.21.6+).
 * This is the ONLY class that uses Paper's dialog API. If a server cannot show it, Auth turns the window off by
 * itself and everybody uses /login and /register in chat instead.
 */
final class AuthDialog {
    private AuthDialog() {
    }

    static void show(AuthModule a, Player p, boolean register, Component error) {
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogBody.plainMessage(a.plain(register ? "dialog-body-register" : "dialog-body-login")));
        if (error != null) body.add(DialogBody.plainMessage(error));

        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(DialogInput.text("pw", a.plain(register ? "dialog-label-set" : "dialog-label-password"))
                .width(300).maxLength(64).build());
        if (register) {
            inputs.add(DialogInput.text("pw2", a.plain("dialog-label-confirm")).width(300).maxLength(64).build());
        }

        ClickCallback.Options opts = ClickCallback.Options.builder()
                .uses(ClickCallback.UNLIMITED_USES).lifetime(Duration.ofMinutes(15)).build();

        ActionButton ok = ActionButton.builder(a.plain(register ? "dialog-btn-register" : "dialog-btn-login"))
                .width(300)
                .action(DialogAction.customClick((view, audience) -> {
                    String pw = view.getText("pw");
                    String pw2 = register ? view.getText("pw2") : "";
                    a.sync(() -> {
                        if (!p.isOnline()) return;
                        if (register) a.doRegister(p, pw == null ? "" : pw, pw2 == null ? "" : pw2);
                        else a.doLogin(p, pw == null ? "" : pw);
                    });
                }, opts))
                .build();
        ActionButton quit = ActionButton.builder(a.plain("dialog-btn-quit"))
                .width(300)
                .action(DialogAction.customClick((view, audience) ->
                        a.sync(() -> p.kick(a.plain("kick-dialog-quit"))), opts))
                .build();

        Dialog d = Dialog.create(f -> f.empty()
                .base(DialogBase.builder(a.plain(register ? "dialog-title-register" : "dialog-title-login"))
                        .canCloseWithEscape(false)
                        .afterAction(DialogBase.DialogAfterAction.NONE)
                        .body(body)
                        .inputs(inputs)
                        .build())
                .type(DialogType.multiAction(List.of(ok, quit), null, 1)));
        p.showDialog(d);
    }
}
