package com.zentials.auth;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The login / register windows (Minecraft dialog screens, Java 1.21.6+, shown to Bedrock players by Geyser).
 * Together with AuthPreJoin this is the only code that touches Paper's dialog API. If a server cannot show
 * the windows, Auth turns them off by itself and everybody uses /login and /register in chat instead.
 *
 * Two kinds:
 *  - pre-join: shown while the player is still connecting (before they exist in the world). Buttons send a custom
 *    click that AuthPreJoin receives.
 *  - in-game: shown after join. Buttons run /login or /register for the player ("command template"),
 *    so all the normal checks apply.
 *
 * Two looks (all texts are in messages.yml, the dialog-* keys):
 *  - Java: a card. Player name + one line of help, a rule hint when registering, the error (if any) in red,
 *    full-width inputs, a big primary button with a tooltip and a quiet "Leave server" button under it.
 *  - Bedrock (Geyser turns a window with 2+ buttons into a dropdown + submit, which is clumsy): a slim form with
 *    ONE button, fewer text blocks, no "Leave" entry. Switch off with bedrock.compact-dialog: false in config.yml.
 */
final class AuthDialog {
    static final Key SUBMIT = Key.key("zentials:auth/submit");
    static final Key CANCEL = Key.key("zentials:auth/cancel");

    private static final int WIDTH = 250;

    private AuthDialog() {
    }

    // ---------------------------------------------------------------- parts

    private static List<DialogInput> inputs(AuthModule a, boolean register) {
        List<DialogInput> in = new ArrayList<>();
        in.add(DialogInput.text("pw", a.plain(register ? "dialog-label-set" : "dialog-label-password"))
                .width(WIDTH).maxLength(64).build());
        if (register) {
            in.add(DialogInput.text("pw2", a.plain("dialog-label-confirm")).width(WIDTH).maxLength(64).build());
        }
        return in;
    }

    /** The red line shown above the inputs after a mistake (wrong password, passwords not the same, ...). */
    private static Component errorLine(Component error) {
        return Component.empty()
                .append(Component.text("! ", NamedTextColor.RED, TextDecoration.BOLD))
                .append(error);
    }

    private static List<DialogBody> body(AuthModule a, String name, boolean register, boolean slim, Component error) {
        String mode = register ? "register" : "login";
        List<DialogBody> body = new ArrayList<>();
        if (slim) {
            // Bedrock: every text block becomes its own label, so keep it to one block + the error.
            Component head = a.plain("dialog-head-" + mode, "name", name);
            if (register) head = head.append(Component.newline()).append(a.plain("dialog-hint-register", "min", a.policy().min()));
            body.add(DialogBody.plainMessage(head));
            if (error != null) body.add(DialogBody.plainMessage(errorLine(error)));
            return body;
        }
        body.add(DialogBody.plainMessage(a.plain("dialog-head-" + mode, "name", name), WIDTH));
        if (error != null) body.add(DialogBody.plainMessage(errorLine(error), WIDTH));
        if (register) {
            body.add(DialogBody.plainMessage(a.plain("dialog-hint-register", "min", a.policy().min()), WIDTH));
        }
        return body;
    }

    private static DialogType type(List<ActionButton> buttons) {
        return buttons.size() == 1 ? DialogType.notice(buttons.get(0)) : DialogType.multiAction(buttons, null, 1);
    }

    private static Dialog build(AuthModule a, String name, boolean register, boolean slim, Component error,
                                List<ActionButton> buttons, DialogBase.DialogAfterAction after) {
        return Dialog.create(f -> f.empty()
                .base(DialogBase.builder(a.plain(register ? "dialog-title-register" : "dialog-title-login"))
                        .canCloseWithEscape(false)
                        .afterAction(after)
                        .body(body(a, name, register, slim, error))
                        .inputs(inputs(a, register))
                        .build())
                .type(type(buttons)));
    }

    private static ActionButton primary(AuthModule a, boolean register, DialogAction action) {
        String mode = register ? "register" : "login";
        return ActionButton.create(a.plain("dialog-btn-" + mode), a.plain("dialog-tip-" + mode), WIDTH, action);
    }

    // ---------------------------------------------------------------- windows

    /** Window for a player who is still connecting. */
    static Dialog preJoin(AuthModule a, String name, UUID id, boolean register, Component error, boolean cancelButton) {
        boolean slim = a.compactWindow(id);
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(primary(a, register, DialogAction.customClick(SUBMIT, null)));
        if (cancelButton && !slim) {
            buttons.add(ActionButton.create(a.plain("dialog-btn-quit"), a.plain("dialog-tip-quit"), WIDTH,
                    DialogAction.customClick(CANCEL, null)));
        }
        return build(a, name, register, slim, error, buttons, DialogBase.DialogAfterAction.WAIT_FOR_RESPONSE);
    }

    /** Window for a player who is already in the game: the button runs /login or /register. */
    static void show(AuthModule a, Player p, boolean register, Component error) {
        String cmd = register ? "register $(pw) $(pw2)" : "login $(pw)";
        boolean slim = a.compactWindow(p.getUniqueId());
        List<ActionButton> buttons = List.of(primary(a, register, DialogAction.commandTemplate(cmd)));
        p.showDialog(build(a, p.getName(), register, slim, error, buttons, DialogBase.DialogAfterAction.CLOSE));
    }
}
