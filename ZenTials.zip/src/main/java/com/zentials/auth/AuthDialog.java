package com.zentials.auth;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * The login / register windows (Minecraft dialog screens, Java 1.21.6+, shown to Bedrock players by Geyser).
 * Together with AuthPreJoin this is the only code that touches Paper's dialog API. If a server cannot show
 * the windows, Auth turns them off by itself and everybody uses /login and /register in chat instead.
 *
 * Two kinds:
 *  - pre-join: shown while the player is still connecting (before they exist in the world). Buttons send a custom
 *    click that AuthPreJoin receives.
 *  - in-game: shown after join. Buttons run /login or /register for the player ("command template"),
 *    so all the normal checks apply.
 */
final class AuthDialog {
    static final Key SUBMIT = Key.key("zentials:auth/submit");
    static final Key CANCEL = Key.key("zentials:auth/cancel");

    private AuthDialog() {
    }

    private static List<DialogInput> inputs(AuthModule a, boolean register) {
        List<DialogInput> in = new ArrayList<>();
        in.add(DialogInput.text("pw", a.plain(register ? "dialog-label-set" : "dialog-label-password"))
                .maxLength(64).build());
        if (register) in.add(DialogInput.text("pw2", a.plain("dialog-label-confirm")).maxLength(64).build());
        return in;
    }

    private static List<DialogBody> body(AuthModule a, boolean register, Component error) {
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogBody.plainMessage(a.plain(register ? "dialog-body-register" : "dialog-body-login")));
        if (error != null) body.add(DialogBody.plainMessage(error));
        return body;
    }

    private static Dialog build(AuthModule a, boolean register, Component error, List<ActionButton> buttons,
                                DialogBase.DialogAfterAction after) {
        return Dialog.create(f -> f.empty()
                .base(DialogBase.builder(a.plain(register ? "dialog-title-register" : "dialog-title-login"))
                        .canCloseWithEscape(false)
                        .afterAction(after)
                        .body(body(a, register, error))
                        .inputs(inputs(a, register))
                        .build())
                .type(DialogType.multiAction(buttons).build()));
    }

    /** Window for a player who is still connecting. */
    static Dialog preJoin(AuthModule a, boolean register, Component error, boolean cancelButton) {
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(ActionButton.builder(a.plain(register ? "dialog-btn-register" : "dialog-btn-login"))
                .action(DialogAction.customClick(SUBMIT, null)).build());
        if (cancelButton) {
            buttons.add(ActionButton.builder(a.plain("dialog-btn-quit"))
                    .action(DialogAction.customClick(CANCEL, null)).build());
        }
        return build(a, register, error, buttons, DialogBase.DialogAfterAction.WAIT_FOR_RESPONSE);
    }

    /** Window for a player who is already in the game: the button runs /login or /register. */
    static void show(AuthModule a, Player p, boolean register, Component error) {
        String cmd = register ? "register $(pw) $(pw2)" : "login $(pw)";
        List<ActionButton> buttons = List.of(
                ActionButton.builder(a.plain(register ? "dialog-btn-register" : "dialog-btn-login"))
                        .action(DialogAction.commandTemplate(cmd)).build());
        p.showDialog(build(a, register, error, buttons, DialogBase.DialogAfterAction.CLOSE));
    }
}
