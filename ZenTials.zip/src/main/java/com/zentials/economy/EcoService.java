package com.zentials.economy;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import com.zentials.core.db.Database;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The economy engine, backed by the ZenTials database.
 * Only online players (and recently used accounts) live in memory. Everything else stays on disk,
 * so the number of accounts is limited by disk space, not RAM.
 */
final class EcoService {
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("MM/dd HH:mm");
    private static final ZoneId ZONE = ZoneId.systemDefault();

    private static final String UPSERT = "INSERT INTO eco_accounts(uuid,name,name_lower,balance,bank,last_interest,"
            + "frozen,s_public,s_notify,s_sound,s_confirm) VALUES(?,?,?,?,?,?,?,?,?,?,?) "
            + "ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,name_lower=excluded.name_lower,"
            + "balance=excluded.balance,bank=excluded.bank,last_interest=excluded.last_interest,"
            + "frozen=excluded.frozen,s_public=excluded.s_public,s_notify=excluded.s_notify,"
            + "s_sound=excluded.s_sound,s_confirm=excluded.s_confirm";

    private static final String HIST_INSERT = "INSERT INTO eco_history(uuid,ts,type,amount,note) VALUES(?,?,?,?,?)";
    private static final String HIST_PRUNE = "DELETE FROM eco_history WHERE uuid=? AND id NOT IN "
            + "(SELECT id FROM eco_history WHERE uuid=? ORDER BY id DESC LIMIT ?)";

    private final EconomyModule mod;
    private final ZenTials plugin;
    private Database db;
    private Kv kv;

    /** Cache of loaded accounts (online players are always here). */
    final Map<UUID, Account> accounts = new ConcurrentHashMap<>();
    final ArrayDeque<String> globalLog = new ArrayDeque<>();
    private final List<Database.Stmt> pend = new ArrayList<>();

    volatile boolean lockdown;

    String symbol = "\u20B1";
    String nameSingular = "peso";
    String namePlural = "pesos";
    long startBalance;
    long maxAmount;
    long payMin;
    long payMax;
    long payCooldownMs;
    long bankCap;
    long interestMax;
    long interestCooldownMs;
    double interestRate;
    int histMax = 20;
    int globalMax = 30;
    int keepHistory = 100;
    int keepLog = 5000;
    private volatile List<Tier> tiers = List.of();
    volatile List<TopEntry> top = List.of();

    record Tier(String perm, long cap) {
    }

    record TopEntry(String name, long balance) {
    }

    record Stats(long count, long wallet, long bank, long frozen) {
    }

    private long bankCapCfg;
    private double rateCfg;
    private long capOverride = -1;
    private double rateOverride = -1;

    EcoService(EconomyModule mod) {
        this.mod = mod;
        this.plugin = mod.plugin;
    }

    static long cents(double d) {
        return Math.round(d * 100.0);
    }

    // ---------------------------------------------------------------- setup

    void init() throws SQLException {
        db = plugin.db();
        kv = plugin.kv();
        if (db == null || kv == null) throw new SQLException("The ZenTials database is not running");

        db.execNow("CREATE TABLE IF NOT EXISTS eco_accounts (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, "
                + "name_lower TEXT NOT NULL, balance INTEGER NOT NULL, bank INTEGER NOT NULL DEFAULT 0, "
                + "last_interest INTEGER NOT NULL DEFAULT 0, frozen INTEGER NOT NULL DEFAULT 0, "
                + "s_public INTEGER NOT NULL DEFAULT 1, s_notify INTEGER NOT NULL DEFAULT 1, "
                + "s_sound INTEGER NOT NULL DEFAULT 1, s_confirm INTEGER NOT NULL DEFAULT 1) WITHOUT ROWID");
        db.execNow("CREATE INDEX IF NOT EXISTS idx_eco_balance ON eco_accounts(balance)");
        db.execNow("CREATE INDEX IF NOT EXISTS idx_eco_name ON eco_accounts(name_lower)");
        db.execNow("CREATE TABLE IF NOT EXISTS eco_history (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "uuid TEXT NOT NULL, ts INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT)");
        db.execNow("CREATE INDEX IF NOT EXISTS idx_eco_hist ON eco_history(uuid, id)");
        db.execNow("CREATE TABLE IF NOT EXISTS eco_log (id INTEGER PRIMARY KEY AUTOINCREMENT, line TEXT NOT NULL)");

        migrateYaml();

        lockdown = kv.getBoolean("eco", "lockdown", false);
        capOverride = kv.getLong("eco", "bank-cap-override", -1);
        rateOverride = kv.getDouble("eco", "interest-rate-override", -1);
        applyLive();

        List<String> lines = db.list("SELECT line FROM eco_log ORDER BY id DESC LIMIT ?",
                rs -> rs.getString(1), globalMax);
        for (int i = lines.size() - 1; i >= 0; i--) globalLog.addLast(lines.get(i));
        pruneLog();
    }

    void loadConfig() {
        YamlConfiguration y = Cfg.yamlWithDefaults(plugin, "modules/economy/economy.yml");
        symbol = y.getString("currency.symbol", "\u20B1");
        nameSingular = y.getString("currency.name", "peso");
        namePlural = y.getString("currency.name-plural", "pesos");
        startBalance = cents(y.getDouble("starting-balance", 3000));
        maxAmount = cents(y.getDouble("max-amount", 10000000));
        payMin = cents(y.getDouble("pay.min", 1));
        payMax = cents(y.getDouble("pay.max", 100000));
        payCooldownMs = y.getLong("pay.cooldown-seconds", 3) * 1000L;
        bankCapCfg = cents(y.getDouble("bank.cap", 100000));
        rateCfg = y.getDouble("bank.interest-rate", 0.002);
        interestMax = cents(y.getDouble("bank.interest-max", 200));
        interestCooldownMs = y.getLong("bank.interest-cooldown-hours", 24) * 3600000L;
        histMax = y.getInt("history.player-entries", 20);
        globalMax = y.getInt("history.global-entries", 30);
        keepHistory = Math.max(histMax, y.getInt("history.keep-entries", 100));
        keepLog = Math.max(globalMax, y.getInt("history.keep-log-entries", 5000));
        List<Tier> tl = new ArrayList<>();
        for (Map<?, ?> m : y.getMapList("bank.cap-tiers")) {
            Object perm = m.get("permission");
            Object cap = m.get("cap");
            if (perm != null && cap instanceof Number n) tl.add(new Tier(String.valueOf(perm), cents(n.doubleValue())));
        }
        tiers = tl;
        applyLive();
    }

    private void applyLive() {
        bankCap = capOverride >= 0 ? capOverride : bankCapCfg;
        interestRate = rateOverride >= 0 ? rateOverride : rateCfg;
    }

    // ---------------------------------------------------------------- formatting

    String fmt(long cents) {
        long a = Math.abs(cents);
        return (cents < 0 ? "-" : "") + symbol + String.format(Locale.US, "%,d", a / 100)
                + "." + String.format(Locale.US, "%02d", a % 100);
    }

    /** Short form: 3K, 1.2M, 4B. */
    String fmtShort(long cents) {
        double v = cents / 100.0;
        double abs = Math.abs(v);
        String suf = "";
        if (abs >= 1_000_000_000d) {
            v /= 1_000_000_000d;
            suf = "B";
        } else if (abs >= 1_000_000d) {
            v /= 1_000_000d;
            suf = "M";
        } else if (abs >= 1_000d) {
            v /= 1_000d;
            suf = "K";
        }
        String num;
        if (suf.isEmpty()) {
            num = v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.2f", v);
        } else {
            num = String.format(Locale.US, "%.1f", v);
            if (num.endsWith(".0")) num = num.substring(0, num.length() - 2);
        }
        return symbol + num + suf;
    }

    /** Bank cap for this player: base cap, or the highest cap-tier permission they have (LuckPerms groups). */
    long capFor(Account a) {
        long cap = bankCap;
        List<Tier> t = tiers;
        if (t.isEmpty()) return cap;
        Player p = Bukkit.getPlayer(a.id);
        if (p == null) return cap;
        for (Tier x : t) {
            if (x.cap() > cap && p.hasPermission(x.perm())) cap = x.cap();
        }
        return cap;
    }

    // ---------------------------------------------------------------- accounts

    /** Cached account, or loaded from the database. Null if the player has no account. */
    Account get(UUID id) {
        Account a = accounts.get(id);
        if (a != null) {
            a.lastUsed = System.currentTimeMillis();
            return a;
        }
        a = loadAccount(id);
        if (a != null) {
            Account prev = accounts.putIfAbsent(id, a);
            if (prev != null) a = prev;
        }
        return a;
    }

    Account ensure(UUID id, String name) {
        Account a = get(id);
        if (a != null) return a;
        synchronized (this) {
            a = accounts.get(id);
            if (a != null) return a;
            a = new Account(id);
            a.name = name == null ? "?" : name;
            a.balance = startBalance;
            accounts.put(id, a);
            persist(a);
            commit();
            return a;
        }
    }

    /** Finds an account by player name (case-insensitive), even for players who never joined since a restart. */
    Account findByName(String name) {
        for (Account a : accounts.values()) {
            if (a.name.equalsIgnoreCase(name)) return a;
        }
        try {
            String uuid = db.query("SELECT uuid FROM eco_accounts WHERE name_lower=? LIMIT 1",
                    rs -> rs.next() ? rs.getString(1) : null, name.toLowerCase(Locale.ROOT));
            return uuid == null ? null : get(UUID.fromString(uuid));
        } catch (SQLException | IllegalArgumentException e) {
            return null;
        }
    }

    private Account loadAccount(UUID id) {
        try {
            String key = id.toString();
            Account a = db.query("SELECT name,balance,bank,last_interest,frozen,s_public,s_notify,s_sound,s_confirm "
                    + "FROM eco_accounts WHERE uuid=?", rs -> {
                if (!rs.next()) return null;
                Account x = new Account(id);
                x.name = rs.getString(1);
                x.balance = rs.getLong(2);
                x.bank = rs.getLong(3);
                x.lastInterest = rs.getLong(4);
                x.frozen = rs.getInt(5) == 1;
                x.pub = rs.getInt(6) == 1;
                x.notify = rs.getInt(7) == 1;
                x.sound = rs.getInt(8) == 1;
                x.confirm = rs.getInt(9) == 1;
                return x;
            }, key);
            if (a == null) return null;
            List<String> h = db.list("SELECT ts,type,amount,note FROM eco_history WHERE uuid=? ORDER BY id DESC LIMIT ?",
                    rs -> render(rs.getLong(1), rs.getString(2), rs.getLong(3), rs.getString(4)), key, histMax);
            for (int i = h.size() - 1; i >= 0; i--) a.history.addLast(h.get(i));
            return a;
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to load account " + id + ": " + e.getMessage());
            return null;
        }
    }

    /** Player left: trim their stored history and drop them from memory. */
    void release(UUID id) {
        Account a = accounts.remove(id);
        if (a != null) db.exec(HIST_PRUNE, id.toString(), id.toString(), keepHistory);
    }

    /** Drops idle offline accounts from the cache. Run on the main thread. */
    void cleanup() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Account> e : accounts.entrySet()) {
            Account a = e.getValue();
            if (now - a.lastUsed > 300_000L && Bukkit.getPlayer(e.getKey()) == null) {
                accounts.remove(e.getKey(), a);
            }
        }
    }

    void pruneLog() {
        db.exec("DELETE FROM eco_log WHERE id NOT IN (SELECT id FROM eco_log ORDER BY id DESC LIMIT ?)", keepLog);
    }

    // ---------------------------------------------------------------- write helpers (hold the lock)

    private void emit(String sql, Object... p) {
        pend.add(new Database.Stmt(sql, p));
    }

    /** Sends everything emitted so far to the database as one atomic group. */
    private void commit() {
        if (pend.isEmpty()) return;
        Database.Stmt[] arr = pend.toArray(new Database.Stmt[0]);
        pend.clear();
        db.submitGroup(arr);
    }

    private void persist(Account a) {
        emit(UPSERT, a.id.toString(), a.name, a.name.toLowerCase(Locale.ROOT), a.balance, a.bank, a.lastInterest,
                a.frozen ? 1 : 0, a.pub ? 1 : 0, a.notify ? 1 : 0, a.sound ? 1 : 0, a.confirm ? 1 : 0);
    }

    /** Updates the stored name if it changed (called on join). */
    void touchName(Account a, String name) {
        if (name == null || name.equals(a.name)) return;
        synchronized (this) {
            a.name = name;
            persist(a);
            commit();
        }
    }

    // ---------------------------------------------------------------- money ops

    boolean add(UUID id, long c, String reason, boolean announce) {
        if (c <= 0) return false;
        Account a = get(id);
        if (a == null) return false;
        long bal;
        synchronized (this) {
            a.balance += c;
            bal = a.balance;
            log(a, "add", c, reason);
            persist(a);
            commit();
        }
        if (announce) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                if (a.notify) mod.msg(p, "received", "amount", fmt(c), "reason", reason, "balance", fmt(bal));
                mod.sfx(p, "cash");
            }
        }
        return true;
    }

    boolean remove(UUID id, long c, String reason, boolean announce) {
        if (c <= 0) return false;
        Account a = get(id);
        if (a == null) return false;
        long bal;
        boolean ok;
        synchronized (this) {
            ok = a.balance >= c;
            if (ok) {
                a.balance -= c;
                log(a, "remove", c, reason);
                persist(a);
                commit();
            }
            bal = a.balance;
        }
        Player p = announce ? Bukkit.getPlayer(id) : null;
        if (!ok) {
            if (p != null) {
                mod.msg(p, "insufficient", "need", fmt(c - bal));
                mod.sfx(p, "error");
            }
            return false;
        }
        if (p != null) {
            if (a.notify) mod.msg(p, "removed", "amount", fmt(c), "reason", reason, "balance", fmt(bal));
            mod.sfx(p, "warn");
        }
        return true;
    }

    boolean pay(Player from, Account to, long c) {
        Account fa = ensure(from.getUniqueId(), from.getName());
        if (fa.id.equals(to.id)) {
            mod.msg(from, "pay-self");
            mod.sfx(from, "error");
            return false;
        }
        if (c < payMin) {
            mod.msg(from, "pay-min", "amount", fmt(payMin));
            mod.sfx(from, "error");
            return false;
        }
        if (c > payMax) {
            mod.msg(from, "pay-max", "amount", fmt(payMax));
            mod.sfx(from, "error");
            return false;
        }
        String err;
        long need = 0;
        synchronized (this) {
            if (lockdown) err = "lockdown";
            else if (fa.frozen) err = "frozen-self";
            else if (to.frozen) err = "frozen-target";
            else if (fa.balance < c) {
                err = "insufficient";
                need = c - fa.balance;
            } else {
                fa.balance -= c;
                log(fa, "pay_out", c, "To " + to.name);
                to.balance += c;
                log(to, "add", c, "From " + fa.name);
                persist(fa);
                persist(to);
                commit();
                err = null;
            }
        }
        if (err != null) {
            mod.msg(from, err, "need", fmt(need));
            mod.sfx(from, "error");
            return false;
        }
        mod.msg(from, "pay-sent", "amount", fmt(c), "player", to.name);
        mod.sfx(from, "success");
        Player tp = Bukkit.getPlayer(to.id);
        if (tp != null) {
            if (to.notify) mod.msg(tp, "pay-received", "amount", fmt(c), "player", fa.name);
            mod.sfx(tp, "cash");
        }
        return true;
    }

    /** Silent atomic transfer used by the API and scripts. */
    boolean transferQuiet(UUID from, UUID to, long c, String note) {
        if (c <= 0) return false;
        Account fa = get(from);
        Account ta = get(to);
        if (fa == null || ta == null || fa.id.equals(ta.id)) return false;
        synchronized (this) {
            if (lockdown || fa.frozen || ta.frozen || fa.balance < c) return false;
            fa.balance -= c;
            log(fa, "pay_out", c, "To " + ta.name + " (" + note + ")");
            ta.balance += c;
            log(ta, "add", c, "From " + fa.name + " (" + note + ")");
            persist(fa);
            persist(ta);
            commit();
            return true;
        }
    }

    // ---------------------------------------------------------------- admin ops

    synchronized void adminOp(Account a, String op, long c) {
        switch (op) {
            case "set" -> {
                a.balance = c;
                log(a, "admin_set", c, "Set by admin");
            }
            case "add" -> {
                a.balance += c;
                log(a, "admin_add", c, "Added by admin");
            }
            case "remove" -> {
                long took = Math.min(c, a.balance);
                a.balance -= took;
                log(a, "admin_remove", took, "Removed by admin");
            }
            case "bankset" -> {
                a.bank = Math.min(c, capFor(a));
                log(a, "admin_bank_set", a.bank, "Bank set by admin");
            }
            case "bankadd" -> {
                a.bank = Math.min(a.bank + c, capFor(a));
                log(a, "admin_bank_add", c, "Bank added by admin");
            }
            case "bankremove" -> {
                long took = Math.min(c, a.bank);
                a.bank -= took;
                log(a, "admin_bank_remove", took, "Bank removed by admin");
            }
            default -> {
                return;
            }
        }
        persist(a);
        commit();
    }

    synchronized void setFrozen(Account a, boolean frozen) {
        a.frozen = frozen;
        persist(a);
        commit();
    }

    void setLockdown(boolean on) {
        lockdown = on;
        kv.setBoolean("eco", "lockdown", on);
    }

    synchronized void wipeHistory(Account a) {
        a.history.clear();
        emit("DELETE FROM eco_history WHERE uuid=?", a.id.toString());
        commit();
    }

    // ---------------------------------------------------------------- bank

    synchronized String bankDeposit(Account a, long c) {
        if (lockdown) return "lockdown-bank";
        if (a.frozen) return "frozen-bank";
        if (a.balance < c) return "insufficient";
        if (a.bank + c > capFor(a)) return "bank-full";
        a.balance -= c;
        a.bank += c;
        log(a, "bank_deposit", c, "Deposit");
        persist(a);
        commit();
        return null;
    }

    synchronized String bankWithdraw(Account a, long c) {
        if (lockdown) return "lockdown-bank";
        if (a.frozen) return "frozen-bank";
        if (a.bank < c) return "bank-insufficient";
        a.bank -= c;
        a.balance += c;
        log(a, "bank_withdraw", c, "Withdraw");
        persist(a);
        commit();
        return null;
    }

    long interestAmount(Account a) {
        long i = Math.round(a.bank * interestRate);
        if (i > interestMax) i = interestMax;
        long room = capFor(a) - a.bank;
        if (i > room) i = room;
        return Math.max(i, 0);
    }

    long interestWait(Account a) {
        if (a.lastInterest == 0) return 0;
        long left = interestCooldownMs - (System.currentTimeMillis() - a.lastInterest);
        return Math.max(left, 0);
    }

    /** Returns amount claimed, -1 cooldown, 0 nothing to claim, -2 lockdown, -3 frozen. */
    synchronized long claimInterest(Account a) {
        if (lockdown) return -2;
        if (a.frozen) return -3;
        if (interestWait(a) > 0) return -1;
        long amt = interestAmount(a);
        if (amt <= 0) return 0;
        a.bank += amt;
        a.lastInterest = System.currentTimeMillis();
        log(a, "interest", amt, "Bank interest");
        persist(a);
        commit();
        return amt;
    }

    // ---------------------------------------------------------------- history

    static String typeLabel(String t) {
        return switch (t) {
            case "add" -> "Received";
            case "remove" -> "Spent";
            case "pay_out" -> "Payment";
            case "bank_deposit" -> "Bank Deposit";
            case "bank_withdraw" -> "Bank Withdraw";
            case "interest" -> "Interest";
            case "admin_set" -> "Admin Set";
            case "admin_add" -> "Admin Add";
            case "admin_remove" -> "Admin Remove";
            case "admin_bank_set" -> "Admin Bank Set";
            case "admin_bank_add" -> "Admin Bank Add";
            case "admin_bank_remove" -> "Admin Bank Remove";
            default -> t;
        };
    }

    private String render(long ts, String type, long cents, String note) {
        String when = TS.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(ts), ZONE));
        return when + "|" + type + "|" + fmt(cents) + "|" + note;
    }

    /** Caller must hold the lock. Adds to memory and emits the database rows. */
    private void log(Account a, String type, long cents, String note) {
        long now = System.currentTimeMillis();
        a.history.addLast(render(now, type, cents, note));
        while (a.history.size() > histMax) a.history.pollFirst();
        emit(HIST_INSERT, a.id.toString(), now, type, cents, note);

        String ts = TS.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(now), ZONE));
        String line = "&8[&7" + ts + "&8] &f" + a.name + " &7\u00BB " + typeLabel(type)
                + " &f" + fmt(cents) + " &8(&7" + note + "&8)";
        globalLog.addLast(line);
        while (globalLog.size() > globalMax) globalLog.pollFirst();
        emit("INSERT INTO eco_log(line) VALUES(?)", line);
    }

    String renderHistory(String raw) {
        String[] p = raw.split("\\|", 4);
        if (p.length < 4) return "&7" + raw;
        return "&8[&7" + p[0] + "&8] &f" + typeLabel(p[1]) + " &f" + p[2] + " &8(&7" + p[3] + "&8)";
    }

    synchronized List<String> historyOf(Account a) {
        List<String> out = new ArrayList<>();
        for (String h : a.history) out.add(renderHistory(h));
        return out;
    }

    synchronized List<String> globalLogCopy() {
        return new ArrayList<>(globalLog);
    }

    synchronized List<String> rawHistory(Account a) {
        return new ArrayList<>(a.history);
    }

    // ---------------------------------------------------------------- ranks, top, stats

    /** Recomputes the top 10 and the rank of every online player, off the main thread. */
    void refreshRanks() {
        List<Account> online = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Account a = accounts.get(p.getUniqueId());
            if (a != null) online.add(a);
        }
        Bukkit.getAsyncScheduler().runNow(plugin, t -> {
            try {
                List<TopEntry> tl = db.list("SELECT name, balance FROM eco_accounts ORDER BY balance DESC LIMIT 10",
                        rs -> new TopEntry(rs.getString(1), rs.getLong(2)));
                top = List.copyOf(tl);
                for (Account a : online) {
                    long bal = a.balance;
                    Integer ahead = db.query("SELECT COUNT(*) FROM eco_accounts WHERE balance > ?",
                            rs -> rs.next() ? rs.getInt(1) : 0, bal);
                    a.rank = (ahead == null ? 0 : ahead) + 1;
                }
            } catch (SQLException e) {
                plugin.getLogger().warning("Rank refresh failed: " + e.getMessage());
            }
        });
    }

    /** Whole-economy totals. Scans the table, so call it off the main thread. */
    Stats stats() {
        try {
            Stats s = db.query("SELECT COUNT(*), COALESCE(SUM(balance),0), COALESCE(SUM(bank),0), "
                    + "COALESCE(SUM(frozen),0) FROM eco_accounts", rs -> {
                rs.next();
                return new Stats(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getLong(4));
            });
            return s == null ? new Stats(0, 0, 0, 0) : s;
        } catch (SQLException e) {
            plugin.getLogger().warning("Stats failed: " + e.getMessage());
            return new Stats(0, 0, 0, 0);
        }
    }

    // ---------------------------------------------------------------- settings flags

    boolean flag(Account a, String key) {
        return switch (key) {
            case "public" -> a.pub;
            case "notify" -> a.notify;
            case "sound" -> a.sound;
            default -> a.confirm;
        };
    }

    synchronized boolean flip(Account a, String key) {
        switch (key) {
            case "public" -> a.pub = !a.pub;
            case "notify" -> a.notify = !a.notify;
            case "sound" -> a.sound = !a.sound;
            default -> a.confirm = !a.confirm;
        }
        persist(a);
        commit();
        return flag(a, key);
    }

    // ---------------------------------------------------------------- live settings and resets

    void setBankCap(long c) {
        capOverride = c;
        kv.setLong("eco", "bank-cap-override", c);
        applyLive();
    }

    void setInterestRate(double r) {
        rateOverride = r;
        kv.setDouble("eco", "interest-rate-override", r);
        applyLive();
    }

    void resetLive() {
        capOverride = -1;
        rateOverride = -1;
        kv.delete("eco", "bank-cap-override");
        kv.delete("eco", "interest-rate-override");
        applyLive();
    }

    synchronized void resetEconomy() {
        for (Account a : accounts.values()) {
            a.balance = startBalance;
            a.bank = 0;
            a.lastInterest = 0;
        }
        emit("UPDATE eco_accounts SET balance=?, bank=0, last_interest=0", startBalance);
        commit();
        refreshRanks();
    }

    synchronized void wipeAllHistories() {
        for (Account a : accounts.values()) a.history.clear();
        globalLog.clear();
        emit("DELETE FROM eco_history");
        emit("DELETE FROM eco_log");
        commit();
    }

    void adminLog(String text) {
        plugin.getLogger().info("[ADMIN] " + text);
    }

    // ---------------------------------------------------------------- one-time import of the old YAML data

    private void migrateYaml() {
        File f = new File(plugin.getDataFolder(), "data/economy.yml");
        if (!f.exists()) return;
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            int n = 0;
            ConfigurationSection ps = y.getConfigurationSection("players");
            if (ps != null) {
                for (String k : ps.getKeys(false)) {
                    UUID id;
                    try {
                        id = UUID.fromString(k);
                    } catch (IllegalArgumentException e) {
                        continue;
                    }
                    ConfigurationSection s = ps.getConfigurationSection(k);
                    if (s == null) continue;
                    String name = s.getString("name", "?");
                    db.exec(UPSERT, k, name, name.toLowerCase(Locale.ROOT), s.getLong("balance"), s.getLong("bank"),
                            s.getLong("last-interest"), s.getBoolean("frozen") ? 1 : 0,
                            s.getBoolean("settings.public", true) ? 1 : 0,
                            s.getBoolean("settings.notify", true) ? 1 : 0,
                            s.getBoolean("settings.sound", true) ? 1 : 0,
                            s.getBoolean("settings.confirm", true) ? 1 : 0);
                    for (String h : s.getStringList("history")) {
                        String[] p = h.split("\\|", 4);
                        if (p.length < 4) continue;
                        db.exec(HIST_INSERT, k, parseOldTime(p[0]), p[1], parseOldAmount(p[2]), p[3]);
                    }
                    n++;
                }
            }
            for (String line : y.getStringList("global.log")) {
                db.exec("INSERT INTO eco_log(line) VALUES(?)", line);
            }
            kv.setBoolean("eco", "lockdown", y.getBoolean("global.lockdown", false));
            long cap = y.getLong("global.bank-cap-override", -1);
            double rate = y.getDouble("global.interest-rate-override", -1);
            if (cap >= 0) kv.setLong("eco", "bank-cap-override", cap);
            if (rate >= 0) kv.setDouble("eco", "interest-rate-override", rate);
            db.flush().join();
            File done = new File(f.getParentFile(), "economy.yml.migrated");
            if (!f.renameTo(done)) plugin.getLogger().warning("Could not rename economy.yml after migration.");
            plugin.getLogger().info("Economy: migrated " + n + " accounts from YAML into the database.");
        } catch (Exception e) {
            plugin.getLogger().severe("Economy YAML migration failed: " + e);
        }
    }

    private static long parseOldTime(String s) {
        try {
            LocalDateTime t = LocalDateTime.parse(LocalDate.now().getYear() + "/" + s,
                    DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"));
            return t.atZone(ZONE).toInstant().toEpochMilli();
        } catch (Exception e) {
            return System.currentTimeMillis();
        }
    }

    private static long parseOldAmount(String s) {
        try {
            String digits = s.replaceAll("[^0-9.]", "");
            return new BigDecimal(digits).movePointRight(2).longValue();
        } catch (Exception e) {
            return 0;
        }
    }
}
