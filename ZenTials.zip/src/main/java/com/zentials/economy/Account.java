package com.zentials.economy;

import java.util.ArrayDeque;
import java.util.UUID;

/** Money is stored in cents (long) to avoid floating point errors. */
final class Account {
    final UUID id;
    String name = "?";
    long balance;
    long bank;
    long lastInterest;
    boolean frozen;
    boolean pub = true;
    boolean notify = true;
    boolean sound = true;
    boolean confirm = true;
    volatile int rank = 1;
    volatile long lastUsed = System.currentTimeMillis();
    final ArrayDeque<String> history = new ArrayDeque<>();

    Account(UUID id) {
        this.id = id;
    }
}
