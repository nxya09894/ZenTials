package com.zentials.economy;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** All economy chest menus. Layout mirrors the old Skript GUI. */
final class EcoGui {
    private static final String ADMIN = "economy.admin";
    private static final DateTimeFormatter NEXT = DateTimeFormatter.ofPattern("MMM dd, hh:mm a");

    private final EconomyModule mod;
    private final Map<String, Long> armed = new HashMap<>();
    private final Map<UUID, UUID> adminTarget = new HashMap<>();

    EcoGui(EconomyModule mod) {
        this.mod = mod;
    }

    // ---------------------------------------------------------------- helpers

    private EcoService svc() {
        return mod.svc;
    }

    private Gui gui(String titleKey, int rows) {
        return new Gui(Text.c(mod.lang.raw(titleKey)), rows);
    }

    private static Player who(InventoryClickEvent e) {
        return (Player) e.getWhoClicked();
    }

    private Account acc(Player p) {
        return svc().ensure(p.getUniqueId(), p.getName());
    }

    private void show(Player p, Gui g, String sfx) {
        g.open(p);
        mod.sfx(p, sfx);
    }

    private void back(Gui g, int slot, Consumer<Player> to) {
        g.set(slot, Items.of(Material.ARROW, "&c&l\u2190 BACK", "&7Return to the previous menu"), e -> {
            Player p = who(e);
            mod.sfx(p, "back");
            to.accept(p);
        });
    }

    private boolean can(Player p, String node) {
        if (p.hasPermission(node)) return true;
        mod.msg(p, "no-permission");
        mod.sfx(p, "error");
        return false;
    }

    private boolean adminOk(Player p) {
        if (p.hasPermission(ADMIN)) return true;
        mod.msg(p, "no-permission");
        mod.sfx(p, "error");
        p.closeInventory();
        return false;
    }

    private String key(Player p, String k) {
        return p.getUniqueId() + ":" + k;
    }

    private boolean isArmed(Player p, String k) {
        Long t = armed.get(key(p, k));
        return t != null && t > System.currentTimeMillis();
    }

    private boolean consumeArm(Player p, String k) {
        Long t = armed.remove(key(p, k));
        return t != null && t > System.currentTimeMillis();
    }

    private void arm(Player p, String k) {
        armed.put(key(p, k), System.currentTimeMillis() + 10000L);
    }

    private ItemStack tg(boolean on, Material onMat, String title, String onWord, String offWord,
                         String[] desc, String actOn, String actOff) {
        List<String> l = new ArrayList<>(List.of(desc));
        l.add("");
        l.add(on ? actOn : actOff);
        return Items.of(on ? onMat : Material.GRAY_DYE,
                on ? "&a&l" + title + " &8\u00bb &a" + onWord : "&7&l" + title + " &8\u00bb &c" + offWord,
                l.toArray(new String[0]));
    }

    private ItemStack toggle(Account a, String k) {
        boolean on = svc().flag(a, k);
        return switch (k) {
            case "public" -> tg(on, Material.LIME_DYE, "BALANCE VISIBILITY", "PUBLIC", "PRIVATE",
                    on ? new String[]{"&7Others can see your wallet", "&7using &f/balance <player>"}
                            : new String[]{"&7Only you and admins can", "&7see your wallet"},
                    "&eClick to make private", "&eClick to make public");
            case "notify" -> tg(on, Material.LIME_DYE, "CHAT NOTIFICATIONS", "ON", "OFF",
                    new String[]{"&7Messages when money is", "&7received or removed"},
                    "&eClick to turn off", "&eClick to turn on");
            case "sound" -> tg(on, Material.NOTE_BLOCK, "SOUND EFFECTS", "ON", "OFF",
                    new String[]{"&7GUI and payment sounds"}, "&eClick to turn off", "&eClick to turn on");
            default -> tg(on, Material.LIME_DYE, "CONFIRM PAYMENTS", "ON", "OFF",
                    new String[]{"&7Ask before sending money"}, "&eClick to turn off", "&eClick to turn on");
        };
    }

    /** Puts a toggle in a slot that flips itself on click. */
    private void putToggle(Gui g, Player p, int slot, String k) {
        g.set(slot, toggle(acc(p), k), e -> {
            Player q = who(e);
            Account qa = acc(q);
            boolean on = svc().flip(qa, k);
            mod.sfx(q, on ? "on" : "off");
            putToggle(g, q, slot, k);
        });
    }

    // ---------------------------------------------------------------- player menus

    void main(Player p) {
        adminTarget.remove(p.getUniqueId());
        EcoService s = svc();
        Account a = acc(p);
        Gui g = gui("t-main", 3);
        String fl = a.frozen ? "&c&lACCOUNT FROZEN" : "&8Account in good standing";
        g.set(4, Items.head(p, "&6&l" + p.getName(), "&7Wallet: &f" + s.fmt(a.balance),
                "&7Bank: &f" + s.fmt(a.bank), "&7Rank: &e#" + a.rank, "", fl));
        g.set(10, Items.of(Material.EMERALD, "&a&lBALANCE", "&7Wallet, bank and net worth", "", "&eClick to open"),
                e -> balance(who(e)));
        g.set(12, Items.of(Material.GOLD_INGOT, "&e&lPAY PLAYER", "&7Send money to an online player",
                "&7Minimum: &f" + s.fmt(s.payMin), "", "&eClick to open"), e -> pay(who(e), 1));
        g.set(14, Items.of(Material.CHEST, "&6&lBANK", "&7Deposit, withdraw and earn interest",
                "&7Saved: &f" + s.fmt(a.bank), "", "&eClick to open"), e -> bank(who(e)));
        g.set(16, Items.of(Material.NAME_TAG, "&d&lHISTORY", "&7Your last " + s.histMax + " transactions", "",
                "&eClick to open"), e -> history(who(e), acc(who(e)), false));
        g.set(22, Items.of(Material.COMPASS, "&f&lSETTINGS", "&7Notifications, sounds, privacy", "",
                "&eClick to open"), e -> settings(who(e)));
        show(p, g, "open");
    }

    void balance(Player p) {
        EcoService s = svc();
        Account a = acc(p);
        Gui g = gui("t-balance", 3);
        g.set(11, Items.of(Material.EMERALD, "&a&lWALLET", "&f" + s.fmt(a.balance)));
        g.set(13, Items.of(Material.GOLD_BLOCK, "&6&lNET WORTH", "&f" + s.fmt(a.balance + a.bank), "",
                "&7Rank: &e#" + a.rank));
        g.set(15, Items.of(Material.CHEST, "&6&lBANK", "&f" + s.fmt(a.bank)));
        putToggle(g, p, 22, "public");
        back(g, 18, this::main);
        show(p, g, "click");
    }

    void pay(Player p, int page) {
        if (!can(p, "economy.pay")) return;
        List<Player> list = new ArrayList<>();
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (!o.getUniqueId().equals(p.getUniqueId())) list.add(o);
        }
        int pages = Math.max(1, (list.size() + 44) / 45);
        final int pg = Math.min(Math.max(page, 1), pages);
        Gui g = gui("t-pay", 6);
        if (list.isEmpty()) {
            g.set(22, Items.of(Material.PAPER, "&c&lNO PLAYERS ONLINE", "&7There is nobody to pay right now"));
        }
        int slot = 0;
        for (int i = (pg - 1) * 45; i < Math.min(list.size(), pg * 45); i++) {
            Player t = list.get(i);
            UUID tid = t.getUniqueId();
            g.set(slot++, Items.head(t, "&b&l" + t.getName(), "&7Click to pay this player"),
                    e -> askPay(who(e), tid));
        }
        if (pages > 1) {
            g.set(49, Items.of(Material.PAPER, "&e&lPAGE " + pg + "/" + pages));
            if (pg > 1) g.set(48, Items.of(Material.SPECTRAL_ARROW, "&e&l\u00ab PREVIOUS PAGE"),
                    e -> pay(who(e), pg - 1));
            if (pg < pages) g.set(50, Items.of(Material.SPECTRAL_ARROW, "&e&lNEXT PAGE \u00bb"),
                    e -> pay(who(e), pg + 1));
        }
        back(g, 45, this::main);
        show(p, g, "click");
    }

    private void askPay(Player p, UUID targetId) {
        Account ta = svc().get(targetId);
        if (ta == null) {
            mod.msg(p, "no-account");
            mod.sfx(p, "error");
            main(p);
            return;
        }
        mod.msg(p, "prompt-pay", "player", ta.name);
        mod.plugin.prompts().ask(p, in -> payAmount(p, ta, in), () -> {
            mod.sfx(p, "back");
            main(p);
        });
    }

    private void payAmount(Player p, Account ta, String in) {
        EcoService s = svc();
        Account a = acc(p);
        long c = Money.parse(in, false, s.maxAmount);
        String err = null;
        String[] kv = new String[0];
        if (c < 0) err = "invalid-amount";
        else if (c < s.payMin) {
            err = "pay-min";
            kv = new String[]{"amount", s.fmt(s.payMin)};
        } else if (c > s.payMax) {
            err = "pay-max";
            kv = new String[]{"amount", s.fmt(s.payMax)};
        } else if (a.balance < c) {
            err = "insufficient";
            kv = new String[]{"need", s.fmt(c - a.balance)};
        }
        if (err != null) {
            mod.msg(p, err, kv);
            mod.sfx(p, "error");
            main(p);
            return;
        }
        if (a.confirm) {
            payConfirm(p, ta, c);
        } else {
            s.pay(p, ta, c);
            main(p);
        }
    }

    void payConfirm(Player p, Account ta, long c) {
        EcoService s = svc();
        Account a = acc(p);
        Gui g = gui("t-confirm", 3);
        g.set(11, Items.of(Material.LIME_DYE, "&a&lCONFIRM", "&7Send &f" + s.fmt(c) + " &7to &f" + ta.name, "",
                "&eClick to send"), e -> {
            Player q = who(e);
            s.pay(q, ta, c);
            main(q);
        });
        g.set(13, Items.of(Material.PAPER, "&e&lPAYMENT SUMMARY", "&7To: &f" + ta.name,
                "&7Amount: &a" + s.fmt(c), "&7Your balance: &f" + s.fmt(a.balance)));
        g.set(15, Items.of(Material.RED_DYE, "&c&lCANCEL", "&7Do not send this payment"), e -> {
            mod.sfx(who(e), "back");
            main(who(e));
        });
        back(g, 18, this::main);
        show(p, g, "confirm");
    }

    void bank(Player p) {
        if (!can(p, "economy.bank")) return;
        EcoService s = svc();
        Account a = acc(p);
        Gui g = gui("t-bank", 3);
        g.set(0, Items.of(Material.CHEST, "&6&lYOUR BANK", "&7Saved: &f" + s.fmt(a.bank),
                "&7Cap: &f" + s.fmt(s.capFor(a))));
        g.set(10, Items.of(Material.LIME_DYE, "&a&lDEPOSIT", "&7Move money from wallet to bank", "",
                "&eClick, then type an amount"), e -> askBank(who(e), true));
        g.set(12, Items.of(Material.RED_DYE, "&c&lWITHDRAW", "&7Move money from bank to wallet", "",
                "&eClick, then type an amount"), e -> askBank(who(e), false));
        g.set(14, Items.of(Material.SUNFLOWER, "&e&lINTEREST INFO",
                "&7Rate: &f" + Money.pct(s.interestRate) + "% &7per claim",
                "&7Max per claim: &f" + s.fmt(s.interestMax),
                "&7Claim every: &f" + (s.interestCooldownMs / 3600000L) + " hours"));
        if (s.interestWait(a) <= 0) {
            g.set(16, Items.of(Material.CLOCK, "&a&lCLAIM INTEREST",
                    "&7Available: &a" + s.fmt(s.interestAmount(a)), "", "&eClick to claim"), e -> claim(who(e)));
        } else {
            String next = NEXT.format(Instant.ofEpochMilli(a.lastInterest + s.interestCooldownMs)
                    .atZone(ZoneId.systemDefault()));
            g.set(16, Items.of(Material.CLOCK, "&7&lINTEREST ON COOLDOWN", "&7Next claim: &f" + next));
        }
        back(g, 18, this::main);
        show(p, g, "click");
    }

    private void claim(Player p) {
        EcoService s = svc();
        Account a = acc(p);
        long got = s.claimInterest(a);
        if (got == -2 || got == -3) {
            mod.msg(p, got == -2 ? "lockdown-bank" : "frozen-bank");
            mod.sfx(p, "error");
        } else if (got < 0) {
            mod.msg(p, "interest-wait", "time", Money.duration(s.interestWait(a)));
            mod.sfx(p, "error");
        } else if (got == 0) {
            mod.msg(p, "interest-none");
            mod.sfx(p, "error");
        } else {
            mod.msg(p, "interest-claimed", "amount", s.fmt(got), "bank", s.fmt(a.bank));
            mod.sfx(p, "claim");
        }
        bank(p);
    }

    private void askBank(Player p, boolean dep) {
        mod.msg(p, dep ? "prompt-deposit" : "prompt-withdraw");
        mod.plugin.prompts().ask(p, in -> bankAction(p, dep, in), () -> {
            mod.sfx(p, "back");
            bank(p);
        });
    }

    private void bankAction(Player p, boolean dep, String in) {
        EcoService s = svc();
        Account a = acc(p);
        long c = Money.parse(in, false, s.maxAmount);
        if (c < 0) {
            mod.msg(p, "invalid-amount");
            mod.sfx(p, "error");
        } else {
            String err = dep ? s.bankDeposit(a, c) : s.bankWithdraw(a, c);
            if (err != null) {
                mod.msg(p, err, "need", s.fmt(Math.max(0, c - a.balance)),
                        "room", s.fmt(Math.max(0, s.capFor(a) - a.bank)));
                mod.sfx(p, "error");
            } else {
                mod.msg(p, dep ? "bank-deposit" : "bank-withdraw", "amount", s.fmt(c),
                        "bank", s.fmt(a.bank), "balance", s.fmt(a.balance));
                mod.sfx(p, "success");
            }
        }
        bank(p);
    }

    void history(Player viewer, Account target, boolean admin) {
        EcoService s = svc();
        Gui g = gui("t-history", 6);
        List<String> raw = s.rawHistory(target);
        int total = raw.size();
        if (total == 0) {
            g.set(22, Items.of(Material.PAPER, "&c&lNO TRANSACTIONS", "&7Nothing recorded yet"));
        }
        for (int k = 1; k <= total; k++) {
            String[] f = raw.get(k - 1).split("\\|", 4);
            if (f.length < 4) continue;
            Material m = switch (f[1]) {
                case "add", "interest" -> Material.EMERALD;
                case "remove", "pay_out" -> Material.REDSTONE;
                default -> Material.PAPER;
            };
            int slot = 9 + total - k;
            if (slot > 53) continue;
            g.set(slot, Items.of(m, "&f" + EcoService.typeLabel(f[1]) + " &f" + f[2], "&7" + f[3], "&8" + f[0]));
        }
        if (admin) back(g, 45, q -> adminPlayer(q, target));
        else back(g, 45, this::main);
        show(viewer, g, "click");
    }

    void settings(Player p) {
        Gui g = gui("t-settings", 3);
        putToggle(g, p, 11, "notify");
        putToggle(g, p, 13, "sound");
        putToggle(g, p, 15, "confirm");
        back(g, 18, this::main);
        show(p, g, "click");
    }

    // ---------------------------------------------------------------- admin menus

    void admin(Player p) {
        if (!adminOk(p)) return;
        adminTarget.remove(p.getUniqueId());
        EcoService s = svc();
        Gui g = gui("t-admin", 3);
        String lock = s.lockdown ? "&c&lLOCKDOWN" : "&aActive";
        g.set(4, Items.of(Material.BEACON, "&c&lADMIN PANEL", "&7Logged in as: &f" + p.getName(),
                "&7Online now: &f" + Bukkit.getOnlinePlayers().size(), "&7Economy: " + lock));
        g.set(10, Items.of(Material.NETHER_STAR, "&b&lMANAGE PLAYER", "&7Pick an online player to edit",
                "&7balance, bank, freeze, history", "", "&eClick to open"), e -> adminPicker(who(e), 1));
        g.set(12, Items.of(Material.PAPER, "&f&lSERVER STATS", "&7Economy-wide overview", "", "&eClick to open"),
                e -> adminStats(who(e)));
        g.set(14, Items.of(Material.WRITTEN_BOOK, "&d&lSERVER LOG", "&7Last " + s.globalMax + " economy actions", "",
                "&eClick to open"), e -> adminLog(who(e)));
        g.set(16, Items.of(Material.WRITABLE_BOOK, "&e&lLIVE SETTINGS", "&7Bank cap and interest rate",
                "&7without a restart", "", "&eClick to open"), e -> adminLive(who(e)));
        g.set(19, Items.of(Material.GOLD_BLOCK, "&6&lGIVE ALL ONLINE", "&7Pay every online player", "",
                "&eClick, then type an amount"), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            mod.msg(q, "prompt-giveall");
            mod.plugin.prompts().ask(q, in -> giveAll(q, in), () -> {
                mod.sfx(q, "back");
                admin(q);
            });
        });
        g.set(21, Items.of(Material.OBSIDIAN, "&4&lLOCKDOWN MODE &8\u00bb " + lock, "&7Freezes all payments and",
                "&7bank actions server-wide", "", "&eClick to toggle"), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            svc().setLockdown(!svc().lockdown);
            if (svc().lockdown) {
                mod.msg(q, "admin-lockdown-banner-on");
                mod.sfx(q, "warn");
            } else {
                mod.msg(q, "admin-lockdown-off");
                mod.sfx(q, "success");
            }
            svc().adminLog(q.getName() + (svc().lockdown ? " ENABLED" : " disabled") + " Lockdown Mode.");
            admin(q);
        });
        if (isArmed(p, "reset")) {
            g.set(23, Items.of(Material.TNT, "&4&lCLICK AGAIN TO CONFIRM", "&cResets ALL balances and banks"),
                    e -> resetClick(who(e)));
        } else {
            g.set(23, Items.of(Material.TNT, "&4&lRESET ECONOMY", "&7Click twice within 10s to confirm",
                    "&cResets ALL balances and banks"), e -> resetClick(who(e)));
        }
        if (isArmed(p, "wipeall")) {
            g.set(25, Items.of(Material.LAVA_BUCKET, "&4&lCLICK AGAIN TO CONFIRM", "&cWipes every transaction log"),
                    e -> wipeAllClick(who(e)));
        } else {
            g.set(25, Items.of(Material.LAVA_BUCKET, "&4&lWIPE ALL HISTORIES", "&7Click twice within 10s to confirm",
                    "&cClears every transaction log", "&7Balances are untouched"), e -> wipeAllClick(who(e)));
        }
        show(p, g, "open");
    }

    private void resetClick(Player q) {
        if (!adminOk(q)) return;
        if (consumeArm(q, "reset")) {
            svc().resetEconomy();
            mod.msg(q, "admin-reset-done");
            mod.sfx(q, "success");
            svc().adminLog(q.getName() + " RESET THE ECONOMY.");
        } else {
            arm(q, "reset");
            mod.msg(q, "admin-arm-reset");
            mod.sfx(q, "warn");
        }
        admin(q);
    }

    private void wipeAllClick(Player q) {
        if (!adminOk(q)) return;
        if (consumeArm(q, "wipeall")) {
            svc().wipeAllHistories();
            mod.msg(q, "admin-wipeall-done");
            mod.sfx(q, "success");
            svc().adminLog(q.getName() + " WIPED ALL HISTORIES.");
        } else {
            arm(q, "wipeall");
            mod.msg(q, "admin-arm-wipeall");
            mod.sfx(q, "warn");
        }
        admin(q);
    }

    private void giveAll(Player q, String in) {
        if (adminOk(q)) {
            long c = Money.parse(in, false, svc().maxAmount);
            if (c < 0) {
                mod.msg(q, "invalid-amount");
                mod.sfx(q, "error");
            } else {
                int n = 0;
                for (Player o : Bukkit.getOnlinePlayers()) {
                    if (svc().add(o.getUniqueId(), c, "Admin give-all by " + q.getName(), true)) n++;
                }
                mod.msg(q, "admin-giveall", "amount", svc().fmt(c), "count", String.valueOf(n));
                mod.sfx(q, "success");
                svc().adminLog(q.getName() + " gave " + svc().fmt(c) + " to all online players.");
            }
        }
        admin(q);
    }

    void adminPicker(Player p, int page) {
        if (!adminOk(p)) return;
        EcoService s = svc();
        List<Player> list = new ArrayList<>(Bukkit.getOnlinePlayers());
        int pages = Math.max(1, (list.size() + 44) / 45);
        final int pg = Math.min(Math.max(page, 1), pages);
        Gui g = gui("t-picker", 6);
        int slot = 0;
        for (int i = (pg - 1) * 45; i < Math.min(list.size(), pg * 45); i++) {
            Player t = list.get(i);
            Account ta = acc(t);
            UUID tid = t.getUniqueId();
            String fl = ta.frozen ? "&c&lFROZEN" : "&7Not frozen";
            g.set(slot++, Items.head(t, "&b&l" + t.getName(), "&7Wallet: &f" + s.fmt(ta.balance),
                    "&7Bank: &f" + s.fmt(ta.bank), fl, "", "&eClick to manage"), e -> {
                Account x = svc().get(tid);
                if (x != null && adminOk(who(e))) adminPlayer(who(e), x);
            });
        }
        if (pages > 1) {
            g.set(49, Items.of(Material.PAPER, "&e&lPAGE " + pg + "/" + pages));
            if (pg > 1) g.set(48, Items.of(Material.SPECTRAL_ARROW, "&e&l\u00ab PREVIOUS PAGE"),
                    e -> adminPicker(who(e), pg - 1));
            if (pg < pages) g.set(50, Items.of(Material.SPECTRAL_ARROW, "&e&lNEXT PAGE \u00bb"),
                    e -> adminPicker(who(e), pg + 1));
        }
        back(g, 45, this::admin);
        show(p, g, "click");
    }

    void adminPlayer(Player p, Account t) {
        if (!adminOk(p)) return;
        adminTarget.put(p.getUniqueId(), t.id);
        EcoService s = svc();
        OfflinePlayer op = Bukkit.getOfflinePlayer(t.id);
        Gui g = gui("t-player", 3);
        String fl = t.frozen ? "&c&lFROZEN" : "&7Not frozen";
        g.set(0, Items.head(op, "&6&l" + t.name, "&7Wallet: &f" + s.fmt(t.balance), "&7Bank: &f" + s.fmt(t.bank), fl));
        edit(g, 10, Material.GOLD_INGOT, "&e&lSET BALANCE", "&7Type the new amount in chat", t, "set", "set the balance to");
        edit(g, 11, Material.EMERALD, "&a&lADD BALANCE", "&7Type the amount in chat", t, "add", "add to the balance");
        edit(g, 12, Material.REDSTONE, "&c&lREMOVE BALANCE", "&7Type the amount in chat", t, "remove", "remove from the balance");
        edit(g, 14, Material.GOLD_NUGGET, "&6&lSET BANK", "&7Type the new amount in chat", t, "bankset", "set the bank to");
        edit(g, 15, Material.EMERALD_BLOCK, "&a&lADD BANK", "&7Type the amount in chat", t, "bankadd", "add to the bank");
        edit(g, 16, Material.REDSTONE_BLOCK, "&c&lREMOVE BANK", "&7Type the amount in chat", t, "bankremove", "remove from the bank");
        if (t.frozen) {
            g.set(20, Items.of(Material.ICE, "&b&lUNFREEZE ACCOUNT", "&7Click to unfreeze"), e -> freeze(who(e), t));
        } else {
            g.set(20, Items.of(Material.SNOWBALL, "&b&lFREEZE ACCOUNT", "&7Click to freeze"), e -> freeze(who(e), t));
        }
        g.set(22, Items.of(Material.NAME_TAG, "&d&lVIEW HISTORY", "&7Last " + s.histMax + " transactions"),
                e -> {
                    if (adminOk(who(e))) history(who(e), t, true);
                });
        if (isArmed(p, "wipe")) {
            g.set(24, Items.of(Material.TNT, "&4&lCLICK AGAIN TO CONFIRM", "&cPermanently wipes this history"),
                    e -> wipeClick(who(e), t));
        } else {
            g.set(24, Items.of(Material.BOOK, "&4&lWIPE HISTORY", "&7Click twice within 10s to confirm"),
                    e -> wipeClick(who(e), t));
        }
        back(g, 18, this::adminPicker0);
        show(p, g, "click");
    }

    private void adminPicker0(Player p) {
        adminPicker(p, 1);
    }

    private void edit(Gui g, int slot, Material m, String name, String lore, Account t, String op, String action) {
        g.set(slot, Items.of(m, name, lore), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            mod.msg(q, "prompt-admin-amount", "action", action);
            mod.plugin.prompts().ask(q, in -> adminEdit(q, t, op, in), () -> {
                mod.sfx(q, "back");
                adminPlayer(q, t);
            });
        });
    }

    private void adminEdit(Player q, Account t, String op, String in) {
        if (adminOk(q)) {
            boolean zero = op.equals("set") || op.equals("bankset");
            long c = Money.parse(in, zero, svc().maxAmount);
            if (c < 0) {
                mod.msg(q, "invalid-amount");
                mod.sfx(q, "error");
            } else {
                svc().adminOp(t, op, c);
                mod.msg(q, "admin-done", "player", t.name, "amount", svc().fmt(t.balance), "bank", svc().fmt(t.bank));
                mod.sfx(q, "success");
                svc().adminLog(q.getName() + " " + op + " " + svc().fmt(c) + " on " + t.name);
            }
        }
        adminPlayer(q, t);
    }

    private void freeze(Player q, Account t) {
        if (!adminOk(q)) return;
        svc().setFrozen(t, !t.frozen);
        mod.msg(q, t.frozen ? "admin-freeze-on" : "admin-freeze-off", "player", t.name);
        mod.sfx(q, t.frozen ? "warn" : "success");
        svc().adminLog(q.getName() + (t.frozen ? " froze " : " unfroze ") + t.name);
        adminPlayer(q, t);
    }

    private void wipeClick(Player q, Account t) {
        if (!adminOk(q)) return;
        if (consumeArm(q, "wipe")) {
            svc().wipeHistory(t);
            mod.msg(q, "admin-wiped", "player", t.name);
            mod.sfx(q, "success");
            svc().adminLog(q.getName() + " wiped the history of " + t.name);
        } else {
            arm(q, "wipe");
            mod.msg(q, "admin-arm-wipe");
            mod.sfx(q, "warn");
        }
        adminPlayer(q, t);
    }

    void adminLive(Player p) {
        if (!adminOk(p)) return;
        EcoService s = svc();
        Gui g = gui("t-live", 3);
        g.set(10, Items.of(Material.SUNFLOWER, "&e&lSET BANK CAP", "&7Current: &f" + s.fmt(s.bankCap), "",
                "&eClick, then type an amount"), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            mod.msg(q, "prompt-bankcap");
            mod.plugin.prompts().ask(q, in -> {
                long c = Money.parse(in, false, svc().maxAmount);
                if (c < 0) {
                    mod.msg(q, "invalid-amount");
                    mod.sfx(q, "error");
                } else {
                    svc().setBankCap(c);
                    mod.msg(q, "bank-cap-set", "amount", svc().fmt(c));
                    mod.sfx(q, "success");
                    svc().adminLog(q.getName() + " set the bank cap to " + svc().fmt(c));
                }
                adminLive(q);
            }, () -> {
                mod.sfx(q, "back");
                adminLive(q);
            });
        });
        g.set(12, Items.of(Material.CLOCK, "&e&lSET INTEREST RATE", "&7Current: &f" + Money.pct(s.interestRate) + "%", "",
                "&eClick, then type e.g. 0.005 for 0.5%"), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            mod.msg(q, "prompt-interest");
            mod.plugin.prompts().ask(q, in -> {
                double r = -1;
                try {
                    r = Double.parseDouble(in);
                } catch (NumberFormatException ignored) {
                    // handled below
                }
                if (Double.isNaN(r) || r < 0 || r > 1) {
                    mod.msg(q, "rate-invalid");
                    mod.sfx(q, "error");
                } else {
                    svc().setInterestRate(r);
                    mod.msg(q, "interest-rate-set", "rate", Money.pct(r));
                    mod.sfx(q, "success");
                    svc().adminLog(q.getName() + " set the interest rate to " + Money.pct(r) + "%");
                }
                adminLive(q);
            }, () -> {
                mod.sfx(q, "back");
                adminLive(q);
            });
        });
        g.set(14, Items.of(Material.TNT, "&c&lRESET TO DEFAULTS", "&7Clears overrides and uses",
                "&7the config values again"), e -> {
            Player q = who(e);
            if (!adminOk(q)) return;
            svc().resetLive();
            mod.msg(q, "live-reset");
            mod.sfx(q, "success");
            adminLive(q);
        });
        back(g, 18, this::admin);
        show(p, g, "click");
    }

    void adminStats(Player p) {
        if (!adminOk(p)) return;
        Bukkit.getAsyncScheduler().runNow(mod.plugin, t -> {
            EcoService.Stats st = svc().stats();
            Bukkit.getScheduler().runTask(mod.plugin, () -> showStats(p, st));
        });
    }

    private void showStats(Player p, EcoService.Stats st) {
        if (!p.isOnline()) return;
        EcoService s = svc();
        String richest = "&7(nobody online)";
        long best = -1;
        for (Player o : Bukkit.getOnlinePlayers()) {
            Account a = s.get(o.getUniqueId());
            if (a != null && a.balance > best) {
                best = a.balance;
                richest = o.getName() + " &7(" + s.fmt(a.balance) + ")";
            }
        }
        String lock = s.lockdown ? "&c&lLOCKDOWN" : "&aActive";
        Gui g = gui("t-stats", 3);
        g.set(10, Items.of(Material.PLAYER_HEAD, "&b&lONLINE PLAYERS", "&f" + Bukkit.getOnlinePlayers().size()));
        g.set(11, Items.of(Material.PAPER, "&f&lACCOUNTS", "&f" + st.count()));
        g.set(12, Items.of(Material.EMERALD, "&a&lTOTAL WALLET FUNDS", "&f" + s.fmt(st.wallet())));
        g.set(13, Items.of(Material.CHEST, "&6&lTOTAL BANK FUNDS", "&f" + s.fmt(st.bank())));
        g.set(14, Items.of(Material.GOLD_BLOCK, "&e&lMONEY SUPPLY", "&f" + s.fmt(st.wallet() + st.bank())));
        g.set(15, Items.of(Material.SNOWBALL, "&b&lFROZEN ACCOUNTS", "&f" + st.frozen()));
        g.set(16, Items.of(Material.NETHER_STAR, "&6&lRICHEST ONLINE", "&f" + richest));
        g.set(20, Items.of(Material.OBSIDIAN, "&4&lLOCKDOWN", lock));
        g.set(21, Items.of(Material.SUNFLOWER, "&e&lBANK CAP", "&f" + s.fmt(s.bankCap)));
        g.set(23, Items.of(Material.CLOCK, "&e&lINTEREST RATE", "&f" + Money.pct(s.interestRate) + "%"));
        back(g, 18, this::admin);
        show(p, g, "click");
    }

    void adminLog(Player p) {
        if (!adminOk(p)) return;
        Gui g = gui("t-log", 6);
        List<String> lines = svc().globalLogCopy();
        int total = lines.size();
        if (total == 0) g.set(22, Items.of(Material.PAPER, "&c&lNO ACTIVITY", "&7Nothing recorded yet"));
        for (int k = 1; k <= total; k++) {
            int slot = 9 + total - k;
            if (slot > 53) continue;
            g.set(slot, Items.of(Material.PAPER, lines.get(k - 1)));
        }
        back(g, 45, this::admin);
        show(p, g, "click");
    }
}
