package com.zentials.economy;

import com.zentials.ZenTials;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.ServicePriority;
import com.zentials.api.EconomyApi;

public final class EconomyModule implements ZModule, Listener {
    final ZenTials plugin;
    Lang lang;
    EcoService svc;
    EcoGui gui;

    public EconomyModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "economy";
    }

    @Override
    public void enable() throws Exception {
        lang = new Lang(plugin);
        svc = new EcoService(this);
        svc.loadConfig();
        svc.init();
        gui = new EcoGui(this);

        EcoApiImpl api = new EcoApiImpl(svc);
        plugin.setEconomyApi(api);
        Bukkit.getServicesManager().register(EconomyApi.class, api, plugin, ServicePriority.Normal);

        PluginManager pm = Bukkit.getPluginManager();
        pm.registerEvents(this, plugin);

        EcoCommands cmds = new EcoCommands(this);
        for (String n : new String[]{"economy", "pay", "bank"}) {
            PluginCommand c = plugin.getCommand(n);
            if (c != null) {
                c.setExecutor(cmds);
                c.setTabCompleter(cmds);
            }
        }

        hooks(pm);

        Bukkit.getScheduler().runTaskTimer(plugin, svc::refreshRanks, 100L, 600L);
        Bukkit.getScheduler().runTaskTimer(plugin, svc::cleanup, 1200L, 1200L);
        Bukkit.getScheduler().runTaskTimer(plugin, svc::pruneLog, 72000L, 72000L);
    }

    private void hooks(PluginManager pm) {
        if (pm.getPlugin("Vault") != null) {
            try {
                VaultHook.register(plugin, svc);
                plugin.getLogger().info("Vault: connected (ZenTials is now the economy provider).");
            } catch (Throwable t) {
                plugin.getLogger().warning("Vault: link failed - " + t);
            }
        } else {
            plugin.getLogger().info("Vault: not installed, skipped.");
        }
        if (pm.getPlugin("PlaceholderAPI") != null) {
            try {
                PapiHook.register(plugin, svc);
                plugin.getLogger().info("PlaceholderAPI: connected (%zen_balance%, %zen_bank%, %zen_rank%, ...). TAB can use these directly.");
            } catch (Throwable t) {
                plugin.getLogger().warning("PlaceholderAPI: link failed - " + t);
            }
        } else {
            plugin.getLogger().info("PlaceholderAPI: not installed, skipped.");
        }
        plugin.getLogger().info("LuckPerms: use the economy.* permission nodes (see plugin.yml / README).");
    }

    @Override
    public void disable() {
        // Writes are already queued; ZenTials flushes the database when it shuts down.
    }

    @Override
    public void reload() {
        lang.load();
        svc.loadConfig();
    }

    // ---------------------------------------------------------------- helpers

    void msg(CommandSender to, String key, String... kv) {
        to.sendMessage(Text.c(lang.raw(key, kv)));
    }

    void sfx(Player p, String key) {
        Account a = svc.get(p.getUniqueId());
        if (a != null && !a.sound) return;
        plugin.sfx().play(p, key);
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        boolean created = svc.get(p.getUniqueId()) == null;
        Account a = svc.ensure(p.getUniqueId(), p.getName());
        svc.touchName(a, p.getName());
        svc.refreshRanks();
        if (created) {
            msg(p, "account-created", "amount", svc.fmt(a.balance));
            sfx(p, "success");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        svc.release(e.getPlayer().getUniqueId());
    }
}
