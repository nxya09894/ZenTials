package com.zentials.economy;

import com.zentials.core.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

final class EcoCommands implements TabExecutor {
    private static final String ADMIN = "economy.admin";
    private static final List<String> ADMIN_SUBS = List.of("set", "add", "remove", "bankset", "bankadd",
            "bankremove", "freeze", "lockdown", "giveall", "history", "wipehistory", "log", "reload");

    private final EconomyModule mod;
    private final Map<UUID, Long> payCd = new HashMap<>();

    EcoCommands(EconomyModule mod) {
        this.mod = mod;
    }

    private EcoService svc() {
        return mod.svc;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "economy" -> economy(s, a, label);
            case "pay" -> pay(s, a);
            case "bank" -> bank(s, a);
            default -> {
            }
        }
        return true;
    }

    private Account target(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return svc().get(online.getUniqueId());
        return svc().findByName(name);
    }

    // ---------------------------------------------------------------- /economy

    private void economy(CommandSender s, String[] a, String label) {
        if (a.length == 0) {
            if (s instanceof Player p) {
                if (label.equalsIgnoreCase("economy") || label.equalsIgnoreCase("eco")) mod.gui.main(p);
                else showSelf(p);
            } else Text.send(s, "Players only.");
            return;
        }
        if (a[0].equalsIgnoreCase("admin")) {
            admin(s, a);
            return;
        }
        Account t = target(a[0]);
        if (t == null) {
            mod.msg(s, "no-account");
            return;
        }
        if (s instanceof Player p && p.getUniqueId().equals(t.id)) {
            showSelf(p);
            return;
        }
        if (!s.hasPermission("economy.balance.others")) {
            mod.msg(s, "no-permission");
            return;
        }
        if (t.pub) {
            mod.msg(s, "balance-other", "player", t.name, "amount", svc().fmt(t.balance));
        } else if (s.hasPermission(ADMIN)) {
            mod.msg(s, "balance-other-private", "player", t.name, "amount", svc().fmt(t.balance));
        } else {
            mod.msg(s, "balance-private");
        }
        if (s instanceof Player p) mod.sfx(p, "click");
    }

    private void showSelf(Player p) {
        Account a = svc().ensure(p.getUniqueId(), p.getName());
        mod.msg(p, "balance-self", "amount", svc().fmt(a.balance), "bank", svc().fmt(a.bank),
                "rank", String.valueOf(a.rank));
        mod.sfx(p, "click");
    }

    // ---------------------------------------------------------------- /pay

    private void pay(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            Text.send(s, "Players only.");
            return;
        }
        if (a.length < 2) {
            mod.msg(p, "pay-usage");
            return;
        }
        long now = System.currentTimeMillis();
        Long last = payCd.get(p.getUniqueId());
        if (last != null && now - last < svc().payCooldownMs) {
            mod.msg(p, "pay-cooldown");
            mod.sfx(p, "error");
            return;
        }
        Account t = target(a[0]);
        if (t == null) {
            mod.msg(p, "no-account");
            mod.sfx(p, "error");
            return;
        }
        long c = Money.parse(a[1], false, svc().maxAmount);
        if (c < 0) {
            mod.msg(p, "invalid-amount");
            mod.sfx(p, "error");
            return;
        }
        payCd.put(p.getUniqueId(), now);
        svc().pay(p, t, c);
    }

    // ---------------------------------------------------------------- /bank

    private void bank(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            Text.send(s, "Players only.");
            return;
        }
        EcoService svc = svc();
        Account acc = svc.ensure(p.getUniqueId(), p.getName());
        String sub = a.length == 0 ? "info" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "info" -> {
                long wait = svc.interestWait(acc);
                long amt = svc.interestAmount(acc);
                String status = wait > 0 ? "&eInterest in " + Money.duration(wait)
                        : amt > 0 ? "&aInterest ready (+" + svc.fmt(amt) + ")" : "&7No interest yet";
                mod.msg(p, "bank-info", "bank", svc.fmt(acc.bank), "cap", svc.fmt(svc.capFor(acc)),
                        "rate", Money.pct(svc.interestRate), "status", status);
                mod.sfx(p, "click");
            }
            case "deposit", "withdraw" -> {
                boolean dep = sub.equals("deposit");
                if (a.length < 2) {
                    mod.msg(p, "bank-usage");
                    return;
                }
                long c;
                if (a[1].equalsIgnoreCase("all")) {
                    c = dep ? Math.min(acc.balance, svc.capFor(acc) - acc.bank) : acc.bank;
                } else {
                    c = Money.parse(a[1], false, svc.maxAmount);
                }
                if (c <= 0) {
                    mod.msg(p, dep && a[1].equalsIgnoreCase("all") ? "bank-full" : "invalid-amount",
                            "room", svc.fmt(Math.max(0, svc.capFor(acc) - acc.bank)));
                    mod.sfx(p, "error");
                    return;
                }
                String err = dep ? svc.bankDeposit(acc, c) : svc.bankWithdraw(acc, c);
                if (err != null) {
                    mod.msg(p, err, "need", svc.fmt(Math.max(0, c - acc.balance)),
                            "room", svc.fmt(Math.max(0, svc.capFor(acc) - acc.bank)));
                    mod.sfx(p, "error");
                    return;
                }
                mod.msg(p, dep ? "bank-deposit" : "bank-withdraw", "amount", svc.fmt(c),
                        "bank", svc.fmt(acc.bank), "balance", svc.fmt(acc.balance));
                mod.sfx(p, dep ? "cash" : "buy");
            }
            case "interest" -> {
                long got = svc.claimInterest(acc);
                if (got == -2 || got == -3) {
                    mod.msg(p, got == -2 ? "lockdown-bank" : "frozen-bank");
                    mod.sfx(p, "error");
                } else if (got < 0) {
                    mod.msg(p, "interest-wait", "time", Money.duration(svc.interestWait(acc)));
                    mod.sfx(p, "error");
                } else if (got == 0) {
                    mod.msg(p, "interest-none");
                    mod.sfx(p, "error");
                } else {
                    mod.msg(p, "interest-claimed", "amount", svc.fmt(got), "bank", svc.fmt(acc.bank));
                    mod.sfx(p, "claim");
                }
            }
            default -> mod.msg(p, "bank-usage");
        }
    }

    // ---------------------------------------------------------------- /economy admin

    private void admin(CommandSender s, String[] a) {
        if (!s.hasPermission(ADMIN)) {
            mod.msg(s, "no-permission");
            if (s instanceof Player p) mod.sfx(p, "error");
            return;
        }
        EcoService svc = svc();
        if (a.length < 2) {
            if (s instanceof Player p) mod.gui.admin(p);
            else mod.msg(s, "admin-help");
            return;
        }
        String sub = a[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "set", "add", "remove", "bankset", "bankadd", "bankremove" -> {
                if (a.length < 4) {
                    mod.msg(s, "admin-help");
                    return;
                }
                Account t = target(a[2]);
                if (t == null) {
                    mod.msg(s, "no-account");
                    return;
                }
                long c = Money.parse(a[3], sub.equals("set") || sub.equals("bankset"), svc.maxAmount);
                if (c < 0) {
                    mod.msg(s, "invalid-amount");
                    return;
                }
                svc.adminOp(t, sub, c);
                mod.msg(s, "admin-done", "player", t.name, "amount", svc.fmt(t.balance), "bank", svc.fmt(t.bank));
            }
            case "freeze" -> {
                Account t = a.length > 2 ? target(a[2]) : null;
                if (t == null) {
                    mod.msg(s, "no-account");
                    return;
                }
                svc.setFrozen(t, !t.frozen);
                mod.msg(s, t.frozen ? "admin-freeze-on" : "admin-freeze-off", "player", t.name);
            }
            case "lockdown" -> {
                svc.setLockdown(!svc.lockdown);
                mod.msg(s, svc.lockdown ? "admin-lockdown-on" : "admin-lockdown-off");
            }
            case "giveall" -> {
                long c = a.length > 2 ? Money.parse(a[2], false, svc.maxAmount) : -1;
                if (c < 0) {
                    mod.msg(s, "invalid-amount");
                    return;
                }
                int n = 0;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (svc.add(p.getUniqueId(), c, "Admin gift", true)) n++;
                }
                mod.msg(s, "admin-giveall", "amount", svc.fmt(c), "count", String.valueOf(n));
            }
            case "history" -> {
                Account t = a.length > 2 ? target(a[2]) : null;
                if (t == null) {
                    mod.msg(s, "no-account");
                    return;
                }
                List<String> lines = svc.historyOf(t);
                if (lines.isEmpty()) mod.msg(s, "admin-empty");
                for (String l : lines) Text.send(s, l);
            }
            case "wipehistory" -> {
                Account t = a.length > 2 ? target(a[2]) : null;
                if (t == null) {
                    mod.msg(s, "no-account");
                    return;
                }
                svc.wipeHistory(t);
                mod.msg(s, "admin-wiped", "player", t.name);
            }
            case "log" -> {
                List<String> lines = svc.globalLogCopy();
                if (lines.isEmpty()) mod.msg(s, "admin-empty");
                for (String l : lines) Text.send(s, l);
            }
            case "reload" -> {
                mod.reload();
                mod.msg(s, "admin-reloaded");
            }
            default -> mod.msg(s, "admin-help");
        }
    }

    // ---------------------------------------------------------------- tab

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        String cur = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        switch (name) {
            case "pay" -> {
                if (a.length == 1) players(out, cur);
            }
            case "bank" -> {
                if (a.length == 1) addAll(out, List.of("info", "deposit", "withdraw", "interest"), cur);
                else if (a.length == 2 && !a[0].equalsIgnoreCase("info") && !a[0].equalsIgnoreCase("interest"))
                    addAll(out, List.of("all"), cur);
            }
            case "economy" -> {
                if (a.length == 1) {
                    players(out, cur);
                    if (s.hasPermission(ADMIN)) addAll(out, List.of("admin"), cur);
                } else if (s.hasPermission(ADMIN) && a[0].equalsIgnoreCase("admin")) {
                    if (a.length == 2) addAll(out, ADMIN_SUBS, cur);
                    else if (a.length == 3) players(out, cur);
                }
            }
            default -> {
            }
        }
        return out;
    }

    private static void players(List<String> out, String cur) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase(Locale.ROOT).startsWith(cur)) out.add(p.getName());
        }
    }

    private static void addAll(List<String> out, List<String> opts, String cur) {
        for (String o : opts) if (o.startsWith(cur)) out.add(o);
    }
}
