package com.zentials.core;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Reads a player's main LuckPerms group without needing PlaceholderAPI or the LuckPerms API at compile time.
 * Returns null whenever LuckPerms is not there (or not ready), so callers can fall back to something else.
 */
public final class LuckPermsLink {
    private static volatile boolean broken;
    private static Method provider;
    private static Method userManager;
    private static Method getUser;
    private static Method primaryGroup;

    private LuckPermsLink() {
    }

    private static synchronized void init() throws ReflectiveOperationException {
        if (primaryGroup != null) return;
        Class<?> prov = Class.forName("net.luckperms.api.LuckPermsProvider");
        Class<?> lp = Class.forName("net.luckperms.api.LuckPerms");
        Class<?> um = Class.forName("net.luckperms.api.model.user.UserManager");
        Class<?> user = Class.forName("net.luckperms.api.model.user.User");
        provider = prov.getMethod("get");
        userManager = lp.getMethod("getUserManager");
        getUser = um.getMethod("getUser", UUID.class);
        primaryGroup = user.getMethod("getPrimaryGroup");
    }

    /** The LuckPerms group id (like "default" or "vip"), or null. */
    public static String primaryGroup(Player p) {
        if (broken || !Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) return null;
        try {
            if (primaryGroup == null) init();
            Object lp = provider.invoke(null);
            Object user = getUser.invoke(userManager.invoke(lp), p.getUniqueId());
            if (user == null) return null;
            Object g = primaryGroup.invoke(user);
            return g == null ? null : g.toString();
        } catch (ReflectiveOperationException | LinkageError e) {
            if (primaryGroup == null) broken = true; // the API classes are not there: stop trying
            return null;
        } catch (RuntimeException e) {
            return null; // LuckPerms not loaded yet
        }
    }
}
