package com.zentials.core;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Saves YAML data files without lagging the server and without corrupting them:
 * the text is built on the calling (main) thread, written by one background thread to a temp file,
 * then moved over the real file in one step. Several saves of the same file in a row collapse into one write.
 */
public final class DataFile {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ZenTials-DataWriter");
        t.setDaemon(false);
        return t;
    });
    private static final Map<File, String> PENDING = new ConcurrentHashMap<>();

    private DataFile() {
    }

    public static void write(JavaPlugin plugin, File file, YamlConfiguration y) {
        PENDING.put(file, y.saveToString());
        try {
            EX.execute(() -> flush(plugin, file));
        } catch (RejectedExecutionException e) {
            flush(plugin, file); // already shutting down: write right now
        }
    }

    private static void flush(JavaPlugin plugin, File file) {
        String s = PENDING.remove(file);
        if (s == null) return; // an earlier task already wrote the newest text
        try {
            File dir = file.getParentFile();
            if (dir != null) dir.mkdirs();
            File tmp = new File(file.getPath() + ".tmp");
            Files.writeString(tmp.toPath(), s, StandardCharsets.UTF_8);
            try {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save " + file.getName() + ": " + e.getMessage());
        }
    }

    /** Waits until every queued save is on disk (call when the plugin shuts down). */
    public static void shutdown() {
        EX.shutdown();
        try {
            if (!EX.awaitTermination(15, TimeUnit.SECONDS)) EX.shutdownNow();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
