package com.zentials.core;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

/** PlaceholderAPI bridge that is safe when PlaceholderAPI is not installed. */
public final class Papi {
    private Papi() {
    }

    /** Replaces %placeholders%. player may be null for global placeholders. */
    public static String set(OfflinePlayer p, String s) {
        if (s == null || s.indexOf('%') < 0) return s;
        if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) return s;
        try {
            return PapiImpl.apply(p, s);
        } catch (Throwable t) {
            return s;
        }
    }
}
