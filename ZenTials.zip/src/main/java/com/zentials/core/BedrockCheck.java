package com.zentials.core;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

/** Is this player on Bedrock? Asks Floodgate by reflection. False if Floodgate is missing. */
public final class BedrockCheck {
    private static Object api;
    private static Method is;

    private BedrockCheck() {
    }

    private static synchronized boolean load() {
        if (api != null) return true;
        Plugin fg = Bukkit.getPluginManager().getPlugin("floodgate");
        if (fg == null || !fg.isEnabled()) return false;
        try {
            Class<?> cls = Class.forName("org.geysermc.floodgate.api.FloodgateApi", true, fg.getClass().getClassLoader());
            api = cls.getMethod("getInstance").invoke(null);
            is = cls.getMethod("isFloodgatePlayer", UUID.class);
            return true;
        } catch (Throwable t) {
            api = null;
            return false;
        }
    }

    public static boolean is(UUID id) {
        if (!load()) return false;
        try {
            return (boolean) is.invoke(api, id);
        } catch (Throwable t) {
            return false;
        }
    }
}
