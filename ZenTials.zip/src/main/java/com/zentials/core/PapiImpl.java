package com.zentials.core;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.OfflinePlayer;

/** Only loaded when PlaceholderAPI is present (see Papi). */
final class PapiImpl {
    private PapiImpl() {
    }

    static String apply(OfflinePlayer p, String s) {
        return PlaceholderAPI.setPlaceholders(p, s);
    }
}
