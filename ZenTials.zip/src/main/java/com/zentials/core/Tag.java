package com.zentials.core;

/** Chat prefix of every module: [NAME] in capitals, colored. Use these everywhere so all messages look the same. */
public final class Tag {
    public static final String ZENTIALS = of("ZENTIALS", 'b');
    public static final String SECURITY = of("SECURITY", 'a');
    public static final String RANKS = of("RANKS", '6');
    public static final String AURA = of("AURA", '5');
    public static final String CHAT = of("CHAT", '9');
    public static final String TELEPORT = of("TELEPORT", 'd');
    public static final String ECONOMY = of("ECONOMY", 'e');
    public static final String GRAVES = of("GRAVES", 'c');
    public static final String HOLOGRAM = of("HOLOGRAM", '3');
    public static final String NPC = of("NPC", '2');
    public static final String RYUUDULES = of("RYUUDULES", 'b');

    private Tag() {
    }

    /** "&8[&6&lNAME&8]&7 " */
    public static String of(String name, char color) {
        return "&8[&" + color + "&l" + name.toUpperCase(java.util.Locale.ROOT) + "&8]&7 ";
    }
}
