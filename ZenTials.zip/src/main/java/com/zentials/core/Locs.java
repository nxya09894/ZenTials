package com.zentials.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Locale;

/** Location <-> "world;x;y;z;yaw;pitch" text, for the key/value store. */
public final class Locs {
    private Locs() {
    }

    public static String enc(Location l) {
        return l.getWorld().getName() + ";" + String.format(Locale.US, "%.3f;%.3f;%.3f;%.1f;%.1f",
                l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
    }

    /** Returns null if the text is bad or the world is not loaded. */
    public static Location dec(String s) {
        if (s == null) return null;
        String[] p = s.split(";");
        if (p.length < 6) return null;
        World w = Bukkit.getWorld(p[0]);
        if (w == null) return null;
        try {
            return new Location(w, Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                    Float.parseFloat(p[4]), Float.parseFloat(p[5]));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String pretty(Location l) {
        return l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }
}
