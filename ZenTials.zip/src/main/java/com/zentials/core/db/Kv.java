package com.zentials.core.db;

import java.sql.SQLException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Namespaced key/value store on top of Database (the replacement for Skript variables).
 * Writes hit an LRU cache instantly and reach disk in batches.
 */
public final class Kv {
    private static final String DELETED = "\u0000deleted";

    private final Database db;
    private final Map<String, String> cache;

    public Kv(Database db, int cacheEntries) throws SQLException {
        this.db = db;
        final int max = Math.max(1000, cacheEntries);
        this.cache = Collections.synchronizedMap(new LinkedHashMap<String, String>(2048, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, String> e) {
                return size() > max;
            }
        });
        db.execNow("CREATE TABLE IF NOT EXISTS kv (ns TEXT NOT NULL, k TEXT NOT NULL, v TEXT, "
                + "PRIMARY KEY (ns, k)) WITHOUT ROWID");
    }

    private static String ck(String ns, String k) {
        return ns + "\u0000" + k;
    }

    public String get(String ns, String k) {
        String ck = ck(ns, k);
        String c = cache.get(ck);
        if (c != null) return c.equals(DELETED) ? null : c;
        try {
            String v = db.query("SELECT v FROM kv WHERE ns=? AND k=?",
                    rs -> rs.next() ? rs.getString(1) : null, ns, k);
            if (v != null) cache.put(ck, v);
            return v;
        } catch (SQLException e) {
            return null;
        }
    }

    public void set(String ns, String k, String v) {
        if (v == null) {
            delete(ns, k);
            return;
        }
        cache.put(ck(ns, k), v);
        db.exec("INSERT OR REPLACE INTO kv(ns,k,v) VALUES(?,?,?)", ns, k, v);
    }

    public void delete(String ns, String k) {
        cache.put(ck(ns, k), DELETED);
        db.exec("DELETE FROM kv WHERE ns=? AND k=?", ns, k);
    }

    /** Keys starting with prefix, sorted. Reads from disk (committed data only). */
    public Map<String, String> list(String ns, String prefix, int limit) {
        Map<String, String> out = new LinkedHashMap<>();
        try {
            db.query("SELECT k, v FROM kv WHERE ns=? AND k>=? AND k<? ORDER BY k LIMIT ?", rs -> {
                while (rs.next()) out.put(rs.getString(1), rs.getString(2));
                return null;
            }, ns, prefix, prefix + "\uffff", Math.max(1, limit));
        } catch (SQLException ignored) {
            // empty result
        }
        return out;
    }

    // ---- typed helpers
    public long getLong(String ns, String k, long def) {
        String v = get(ns, k);
        if (v == null) return def;
        try {
            return Long.parseLong(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public void setLong(String ns, String k, long v) {
        set(ns, k, Long.toString(v));
    }

    public double getDouble(String ns, String k, double def) {
        String v = get(ns, k);
        if (v == null) return def;
        try {
            return Double.parseDouble(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public void setDouble(String ns, String k, double v) {
        set(ns, k, Double.toString(v));
    }

    public boolean getBoolean(String ns, String k, boolean def) {
        String v = get(ns, k);
        return v == null ? def : v.equals("true");
    }

    public void setBoolean(String ns, String k, boolean v) {
        set(ns, k, v ? "true" : "false");
    }
}
