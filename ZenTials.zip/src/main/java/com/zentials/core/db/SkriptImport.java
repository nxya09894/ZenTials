package com.zentials.core.db;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.HexFormat;
import java.util.function.LongConsumer;

/**
 * Streams a Skript variables.csv into the skript_vars table.
 * Nothing is thrown away: the raw type and hex value are kept, decoding happens when reading.
 * Memory use stays flat no matter how big the file is.
 */
public final class SkriptImport {
    private SkriptImport() {
    }

    public static void prepare(Database db) throws SQLException {
        db.execNow("CREATE TABLE IF NOT EXISTS skript_vars (name TEXT PRIMARY KEY, type TEXT NOT NULL, "
                + "value TEXT) WITHOUT ROWID");
    }

    /** Returns the number of variables imported. */
    public static long run(Database db, Path file, LongConsumer progress) throws IOException, SQLException {
        prepare(db);
        long count = 0;
        try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isBlank() || line.startsWith("#")) continue;
                String[] f = parse(line);
                if (f == null) continue;
                db.exec("INSERT OR REPLACE INTO skript_vars(name,type,value) VALUES(?,?,?)", f[0], f[1], f[2]);
                count++;
                if (count % 100_000 == 0 && progress != null) progress.accept(count);
            }
        }
        try {
            db.flush().get();
        } catch (Exception e) {
            throw new SQLException(e);
        }
        return count;
    }

    /** name, type, value  (name may be "quoted" with "" as an escaped quote). */
    static String[] parse(String line) {
        int i = 0;
        int n = line.length();
        String[] out = new String[3];
        for (int f = 0; f < 3; f++) {
            while (i < n && line.charAt(i) == ' ') i++;
            StringBuilder sb = new StringBuilder();
            if (i < n && line.charAt(i) == '"') {
                i++;
                while (i < n) {
                    char c = line.charAt(i++);
                    if (c == '"') {
                        if (i < n && line.charAt(i) == '"') {
                            sb.append('"');
                            i++;
                        } else {
                            break;
                        }
                    } else {
                        sb.append(c);
                    }
                }
                while (i < n && line.charAt(i) != ',') i++;
            } else if (f < 2) {
                while (i < n && line.charAt(i) != ',') sb.append(line.charAt(i++));
            } else {
                sb.append(line.substring(i));
                i = n;
            }
            out[f] = sb.toString().trim();
            if (i < n && line.charAt(i) == ',') i++;
        }
        return out[0].isEmpty() ? null : out;
    }

    /** Decodes known primitive types; returns null for anything else. */
    public static Object decode(String type, String hex) {
        try {
            byte[] b = HexFormat.of().parseHex(hex);
            ByteBuffer bb = ByteBuffer.wrap(b);
            return switch (type) {
                case "long" -> bb.getLong();
                case "integer" -> bb.getInt();
                case "double" -> bb.getDouble();
                case "float" -> bb.getFloat();
                case "boolean" -> b.length > 0 && b[0] != 0;
                case "string" -> new String(b, StandardCharsets.UTF_8);
                default -> null;
            };
        } catch (Exception e) {
            return null;
        }
    }

    /** "type: decoded" for a stored variable, or null if it does not exist. */
    public static String describe(Database db, String name) throws SQLException {
        return db.query("SELECT type, value FROM skript_vars WHERE name=?", rs -> {
            if (!rs.next()) return null;
            String type = rs.getString(1);
            String hex = rs.getString(2);
            Object v = decode(type, hex);
            return type + ": " + (v != null ? v : "(raw hex) " + hex);
        }, name);
    }
}
