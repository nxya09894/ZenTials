package com.zentials.core.db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

/**
 * SQLite (WAL) with one batching writer thread and a pool of read connections.
 * Writes are queued and committed in big transactions, reads never block the writer.
 * Data lives on disk, not in RAM, so size is limited by disk, not memory.
 */
public final class Database implements AutoCloseable {

    @FunctionalInterface
    public interface ResultHandler<T> {
        T handle(ResultSet rs) throws SQLException;
    }

    @FunctionalInterface
    public interface RowMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }

    /** One statement of an atomic group. */
    public record Stmt(String sql, Object... params) {
    }

    private record Op(String sql, Object[] params, CompletableFuture<Void> done, Op[] children) {
    }

    private static final Op STOP = new Op(null, null, null, null);

    private final Logger log;
    private final File file;
    private final String url;
    private final Connection writeConn;
    private final BlockingQueue<Op> queue = new LinkedBlockingQueue<>(200_000);
    private final BlockingQueue<Connection> readPool;
    private final List<Connection> allReads = new ArrayList<>();
    private final Thread writer;
    private final int batchSize;
    private volatile boolean closing;

    public final AtomicLong written = new AtomicLong();
    public final AtomicLong batches = new AtomicLong();

    public Database(File file, Logger log, int cacheMb, int mmapMb, int batchSize, int readers) throws SQLException {
        this.file = file;
        this.log = log;
        this.batchSize = Math.max(100, batchSize);
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite driver is not available on this server", e);
        }
        File dir = file.getParentFile();
        if (dir != null) dir.mkdirs();
        this.url = "jdbc:sqlite:" + file.getAbsolutePath();

        this.writeConn = open(cacheMb, mmapMb, false);
        this.writeConn.setAutoCommit(false);

        int n = Math.max(1, readers);
        this.readPool = new ArrayBlockingQueue<>(n);
        for (int i = 0; i < n; i++) {
            Connection c = open(cacheMb, mmapMb, true);
            allReads.add(c);
            readPool.add(c);
        }

        this.writer = new Thread(this::runWriter, "ZenTials-DB-Writer");
        this.writer.setDaemon(false);
        this.writer.start();
    }

    private Connection open(int cacheMb, int mmapMb, boolean readOnly) throws SQLException {
        Connection c = DriverManager.getConnection(url);
        try (Statement st = c.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
            st.execute("PRAGMA temp_store=MEMORY");
            st.execute("PRAGMA busy_timeout=10000");
            st.execute("PRAGMA cache_size=-" + (Math.max(8, cacheMb) * 1024));
            st.execute("PRAGMA mmap_size=" + (Math.max(0, mmapMb) * 1024L * 1024L));
            if (readOnly) st.execute("PRAGMA query_only=ON");
        }
        return c;
    }

    // ---------------------------------------------------------------- writing

    /** Queue a write. Returns a future that completes after the commit. */
    public CompletableFuture<Void> submit(String sql, Object... params) {
        if (closing) return CompletableFuture.failedFuture(new IllegalStateException("Database is closed"));
        Op op = new Op(sql, params == null ? new Object[0] : params, new CompletableFuture<>(), null);
        try {
            queue.put(op);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            op.done().completeExceptionally(e);
        }
        return op.done();
    }

    /** Queue several statements that are committed together or not at all (e.g. both sides of a payment). */
    public CompletableFuture<Void> submitGroup(Stmt... stmts) {
        if (closing) return CompletableFuture.failedFuture(new IllegalStateException("Database is closed"));
        Op[] kids = new Op[stmts.length];
        for (int i = 0; i < stmts.length; i++) {
            Object[] p = stmts[i].params() == null ? new Object[0] : stmts[i].params();
            kids[i] = new Op(stmts[i].sql(), p, null, null);
        }
        Op op = new Op(null, null, new CompletableFuture<>(), kids);
        try {
            queue.put(op);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            op.done().completeExceptionally(e);
        }
        return op.done();
    }

    /** Fire and forget write. */
    public void exec(String sql, Object... params) {
        submit(sql, params);
    }

    /** Write and wait until committed (use for schema/DDL, never on a hot path). */
    public void execNow(String sql, Object... params) throws SQLException {
        try {
            submit(sql, params).get(60, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            throw new SQLException(e.getCause());
        } catch (InterruptedException | TimeoutException e) {
            throw new SQLException(e);
        }
    }

    /** Completes when everything queued before this call is committed. */
    public CompletableFuture<Void> flush() {
        return submit("PRAGMA optimize");
    }

    private void runWriter() {
        List<Op> batch = new ArrayList<>(batchSize);
        boolean stop = false;
        while (!stop) {
            try {
                Op first = queue.take();
                batch.add(first);
                queue.drainTo(batch, batchSize - 1);
                stop = batch.remove(STOP);
                if (!batch.isEmpty()) flushBatch(batch);
                batch.clear();
            } catch (InterruptedException e) {
                break;
            }
        }
        List<Op> rest = new ArrayList<>();
        queue.drainTo(rest);
        rest.remove(STOP);
        if (!rest.isEmpty()) flushBatch(rest);
    }

    private void flushBatch(List<Op> ops) {
        List<Op> flat = new ArrayList<>(ops.size());
        for (Op op : ops) {
            if (op.children() != null) flat.addAll(Arrays.asList(op.children()));
            else flat.add(op);
        }
        try {
            PreparedStatement ps = null;
            String cur = null;
            try {
                for (Op op : flat) {
                    if (op.params().length == 0) {
                        if (ps != null) {
                            ps.executeBatch();
                            ps.close();
                            ps = null;
                            cur = null;
                        }
                        try (Statement st = writeConn.createStatement()) {
                            st.execute(op.sql());
                        }
                        continue;
                    }
                    if (!op.sql().equals(cur)) {
                        if (ps != null) {
                            ps.executeBatch();
                            ps.close();
                        }
                        ps = writeConn.prepareStatement(op.sql());
                        cur = op.sql();
                    }
                    bind(ps, op.params());
                    ps.addBatch();
                }
                if (ps != null) ps.executeBatch();
            } finally {
                if (ps != null) {
                    try {
                        ps.close();
                    } catch (SQLException ignored) {
                        // closing
                    }
                }
            }
            writeConn.commit();
            written.addAndGet(flat.size());
            batches.incrementAndGet();
            for (Op op : ops) {
                if (op.done() != null) op.done().complete(null);
            }
        } catch (SQLException e) {
            try {
                writeConn.rollback();
            } catch (SQLException ignored) {
                // nothing to roll back
            }
            log.severe("Database batch failed (" + e.getMessage() + "), retrying one by one.");
            for (Op op : ops) runSingle(op);
        }
    }

    private void execOne(Op op) throws SQLException {
        if (op.params().length == 0) {
            try (Statement st = writeConn.createStatement()) {
                st.execute(op.sql());
            }
        } else {
            try (PreparedStatement ps = writeConn.prepareStatement(op.sql())) {
                bind(ps, op.params());
                ps.executeUpdate();
            }
        }
    }

    private void runSingle(Op op) {
        try {
            if (op.children() != null) {
                for (Op k : op.children()) execOne(k);
            } else {
                execOne(op);
            }
            writeConn.commit();
            written.incrementAndGet();
            if (op.done() != null) op.done().complete(null);
        } catch (SQLException e) {
            try {
                writeConn.rollback();
            } catch (SQLException ignored) {
                // nothing to roll back
            }
            log.severe("Database op failed: " + e.getMessage() + " | " + (op.sql() == null ? "(group)" : op.sql()));
            if (op.done() != null) op.done().completeExceptionally(e);
        }
    }

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object o = params[i];
            if (o == null) ps.setNull(i + 1, Types.NULL);
            else ps.setObject(i + 1, o);
        }
    }

    // ---------------------------------------------------------------- reading

    /** Run a query on a read connection. Do not call from the main thread for big queries. */
    public <T> T query(String sql, ResultHandler<T> handler, Object... params) throws SQLException {
        Connection c;
        try {
            c = readPool.poll(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SQLException(e);
        }
        if (c == null) throw new SQLException("No read connection available");
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params == null ? new Object[0] : params);
            try (ResultSet rs = ps.executeQuery()) {
                return handler.handle(rs);
            }
        } finally {
            readPool.offer(c);
        }
    }

    public <T> List<T> list(String sql, RowMapper<T> mapper, Object... params) throws SQLException {
        return query(sql, rs -> {
            List<T> out = new ArrayList<>();
            while (rs.next()) out.add(mapper.map(rs));
            return out;
        }, params);
    }

    // ---------------------------------------------------------------- info / lifecycle

    public int queueSize() {
        return queue.size();
    }

    public long fileSize() {
        long size = file.length();
        File wal = new File(file.getPath() + "-wal");
        if (wal.exists()) size += wal.length();
        return size;
    }

    @Override
    public void close() {
        if (closing) return;
        closing = true;
        try {
            queue.put(STOP);
            writer.join(120_000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        try {
            writeConn.close();
        } catch (SQLException ignored) {
            // closing
        }
        for (Connection c : allReads) {
            try {
                c.close();
            } catch (SQLException ignored) {
                // closing
            }
        }
    }
}
