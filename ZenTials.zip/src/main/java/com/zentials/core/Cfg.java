package com.zentials.core;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class Cfg {
    private Cfg() {
    }

    /** Moves an old file or folder (plugins/ZenTials/<old>) to its new place if the new one does not exist yet. */
    public static void migrate(JavaPlugin p, String oldPath, String newPath) {
        File o = new File(p.getDataFolder(), oldPath);
        File n = new File(p.getDataFolder(), newPath);
        if (!o.exists() || n.exists()) return;
        File parent = n.getParentFile();
        if (parent != null) parent.mkdirs();
        if (o.renameTo(n)) p.getLogger().info("Moved " + oldPath + " -> " + newPath);
        else p.getLogger().warning("Could not move " + oldPath + " to " + newPath + " - move it yourself.");
    }

    /** Loads plugins/ZenTials/<path>, copying the default from the jar if missing. */
    public static YamlConfiguration yaml(JavaPlugin p, String path) {
        File f = new File(p.getDataFolder(), path);
        if (!f.exists()) p.saveResource(path, false);
        return YamlConfiguration.loadConfiguration(f);
    }

    /** Same as yaml(), but keys missing from the file fall back to the jar default (good for updates). */
    public static YamlConfiguration yamlWithDefaults(JavaPlugin p, String path) {
        YamlConfiguration y = yaml(p, path);
        InputStream in = p.getResource(path);
        if (in != null) {
            YamlConfiguration def = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            y.setDefaults(def);
            y.options().copyDefaults(true);
        }
        return y;
    }
}
