package com.zentials.teleport;

import com.zentials.core.DataFile;
import com.zentials.ZenTials;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Everything the teleport module saves, kept in memory and written to plugins/ZenTials/data/teleport.yml
 * (a moment after each change, and on shutdown). If plugins/ZenTials/data/teleport-import.yml exists it is
 * merged in at startup and renamed to teleport-import.yml.done.
 */
final class TeleportData {

    /** A saved position. The world is kept by name so it still works when the world loads later. */
    record Pos(String world, double x, double y, double z, float yaw, float pitch) {
        static Pos of(Location l) {
            return new Pos(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }

        /** null if the world is not loaded. */
        Location loc() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }

        String enc() {
            return world + ";" + String.format(Locale.US, "%.3f;%.3f;%.3f;%.1f;%.1f", x, y, z, yaw, pitch);
        }

        static Pos dec(String s) {
            if (s == null) return null;
            String[] p = s.split(";");
            if (p.length < 6) return null;
            try {
                return new Pos(p[0], Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                        Float.parseFloat(p[4]), Float.parseFloat(p[5]));
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }

    static final class Warp {
        final String id;
        String name;
        String owner;      // uuid text, or "server"
        String ownerName;
        Pos loc;
        String desc = "No description set.";
        String cat = "General";
        double price;
        boolean isPublic = true;
        String type = "player"; // player | server
        int visits;

        Warp(String id) {
            this.id = id;
        }
    }

    static final class Place {
        String name;
        Pos loc;
        double paid;
    }

    static final String[] CATS = {"General", "Farm", "Mob Farm", "Shop", "Build", "Resources", "PvP", "Event"};
    static final String[] SETTING_KEYS = {"warmup", "tp_cd", "req_expire", "tpa_cost", "rtp_cost", "rtp_radius", "rtp_cd",
            "warp_create_cost", "warp_max", "warp_visit_cap", "place_base", "place_inc"};

    private static final Map<String, Double> DEFAULTS = new LinkedHashMap<>();
    private static final Map<String, Double> MAXES = new LinkedHashMap<>();

    static {
        DEFAULTS.put("warmup", 3.0);
        DEFAULTS.put("tp_cd", 20.0);
        DEFAULTS.put("req_expire", 60.0);
        DEFAULTS.put("tpa_cost", 20.0);
        DEFAULTS.put("rtp_cost", 100.0);
        DEFAULTS.put("rtp_radius", 1000.0);
        DEFAULTS.put("rtp_cd", 300.0);
        DEFAULTS.put("warp_create_cost", 1500.0);
        DEFAULTS.put("warp_max", 3.0);
        DEFAULTS.put("warp_visit_cap", 100.0);
        DEFAULTS.put("place_base", 300.0);
        DEFAULTS.put("place_inc", 200.0);
        MAXES.put("warmup", 30.0);
        MAXES.put("tp_cd", 600.0);
        MAXES.put("req_expire", 300.0);
        MAXES.put("tpa_cost", 10000.0);
        MAXES.put("rtp_radius", 10000.0);
        MAXES.put("rtp_cd", 3600.0);
        MAXES.put("warp_max", 20.0);
        MAXES.put("warp_visit_cap", 100000.0);
    }

    private final ZenTials plugin;
    private final File file;
    private BukkitTask saveTask;

    final Map<String, Double> settings = new LinkedHashMap<>();
    final Map<String, Warp> warps = new LinkedHashMap<>();
    int nextWarp = 0;
    final Map<UUID, TreeMap<Integer, Place>> places = new java.util.concurrent.ConcurrentHashMap<>();
    final Map<UUID, Pos> deaths = new java.util.concurrent.ConcurrentHashMap<>();
    final Set<UUID> noReq = java.util.concurrent.ConcurrentHashMap.newKeySet();
    final Map<UUID, Map<UUID, String>> ignore = new java.util.concurrent.ConcurrentHashMap<>();
    Pos spawn;

    TeleportData(ZenTials plugin) {
        this.plugin = plugin;
        for (String old : new String[]{"teleport.yml", "modules/teleport/data.yml"}) com.zentials.core.Cfg.migrate(plugin, old, "data/teleport.yml");
        for (String old : new String[]{"teleport-import.yml", "modules/teleport/import.yml"}) com.zentials.core.Cfg.migrate(plugin, old, "data/teleport-import.yml");
        this.file = new File(plugin.getDataFolder(), "data/teleport.yml");
        this.file.getParentFile().mkdirs();
    }

    // ---------------------------------------------------------------- settings

    double cfg(String k) {
        Double v = settings.get(k);
        return v != null ? v : DEFAULTS.getOrDefault(k, 0.0);
    }

    static double cfgMax(String k) {
        return MAXES.getOrDefault(k, 1000000.0);
    }

    static String label(String k) {
        return switch (k) {
            case "warmup" -> "Teleport Warmup (seconds)";
            case "tp_cd" -> "Teleport Cooldown (seconds)";
            case "req_expire" -> "Request Expiry (seconds)";
            case "tpa_cost" -> "Player TP Cost";
            case "rtp_cost" -> "Random TP Cost";
            case "rtp_radius" -> "Random TP Radius";
            case "rtp_cd" -> "Random TP Cooldown (seconds)";
            case "warp_create_cost" -> "Warp Creation Cost";
            case "warp_max" -> "Max Warps Per Player";
            case "warp_visit_cap" -> "Max Visit Price Players Can Set";
            case "place_base" -> "Saved Place Base Cost";
            case "place_inc" -> "Saved Place Extra Cost Per Place";
            default -> k;
        };
    }

    // ---------------------------------------------------------------- load / save

    void load() {
        warps.clear();
        places.clear();
        deaths.clear();
        noReq.clear();
        ignore.clear();
        settings.clear();
        if (file.exists()) merge(YamlConfiguration.loadConfiguration(file));
        File imp = new File(plugin.getDataFolder(), "data/teleport-import.yml");
        if (imp.exists()) {
            merge(YamlConfiguration.loadConfiguration(imp));
            File done = new File(plugin.getDataFolder(), "data/teleport-import.yml.done");
            if (done.exists()) done.delete();
            if (imp.renameTo(done)) plugin.getLogger().info("Teleport: imported teleport-import.yml");
            markDirty();
        }
    }

    /** Reads the file format into memory (adds to / overwrites what is already loaded). */
    private void merge(YamlConfiguration y) {
        ConfigurationSection s = y.getConfigurationSection("settings");
        if (s != null) for (String k : s.getKeys(false)) settings.put(k, s.getDouble(k));
        if (y.contains("next-warp-id")) nextWarp = Math.max(nextWarp, y.getInt("next-warp-id"));
        ConfigurationSection w = y.getConfigurationSection("warps");
        if (w != null) {
            for (String id : w.getKeys(false)) {
                ConfigurationSection c = w.getConfigurationSection(id);
                if (c == null) continue;
                Warp x = new Warp(id);
                x.name = c.getString("name", "Warp " + id);
                x.owner = c.getString("owner", "server");
                x.ownerName = c.getString("owner_name", "Server");
                x.loc = Pos.dec(c.getString("loc"));
                x.desc = c.getString("desc", x.desc);
                x.cat = c.getString("cat", "General");
                x.price = c.getDouble("price", 0);
                x.isPublic = c.getBoolean("public", true);
                x.type = c.getString("type", "player");
                x.visits = c.getInt("visits", 0);
                if (x.loc != null) {
                    warps.put(id, x);
                    try {
                        nextWarp = Math.max(nextWarp, Integer.parseInt(id));
                    } catch (NumberFormatException ignored) {
                        // non numeric id
                    }
                }
            }
        }
        ConfigurationSection pl = y.getConfigurationSection("places");
        if (pl != null) {
            for (String u : pl.getKeys(false)) {
                UUID id = uuid(u);
                ConfigurationSection pc = pl.getConfigurationSection(u);
                if (id == null || pc == null) continue;
                TreeMap<Integer, Place> m = places.computeIfAbsent(id, k -> new TreeMap<>());
                for (String n : pc.getKeys(false)) {
                    ConfigurationSection c = pc.getConfigurationSection(n);
                    if (c == null) continue;
                    try {
                        Place p = new Place();
                        p.name = c.getString("name", "Place " + n);
                        p.loc = Pos.dec(c.getString("loc"));
                        p.paid = c.getDouble("paid", 0);
                        if (p.loc != null) m.put(Integer.parseInt(n), p);
                    } catch (NumberFormatException ignored) {
                        // bad slot number
                    }
                }
            }
        }
        ConfigurationSection d = y.getConfigurationSection("deaths");
        if (d != null) {
            for (String u : d.getKeys(false)) {
                UUID id = uuid(u);
                Pos p = Pos.dec(d.getString(u));
                if (id != null && p != null) deaths.put(id, p);
            }
        }
        for (String u : y.getStringList("no-requests")) {
            UUID id = uuid(u);
            if (id != null) noReq.add(id);
        }
        ConfigurationSection ig = y.getConfigurationSection("ignore");
        if (ig != null) {
            for (String u : ig.getKeys(false)) {
                UUID id = uuid(u);
                ConfigurationSection c = ig.getConfigurationSection(u);
                if (id == null || c == null) continue;
                Map<UUID, String> m = ignore.computeIfAbsent(id, k -> new LinkedHashMap<>());
                for (String t : c.getKeys(false)) {
                    UUID tid = uuid(t);
                    if (tid != null) m.put(tid, c.getString(t, "?"));
                }
            }
        }
        if (y.contains("spawn")) spawn = Pos.dec(y.getString("spawn"));
    }

    private static UUID uuid(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    void markDirty() {
        if (saveTask != null) return;
        saveTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            saveTask = null;
            saveNow();
        }, 40L);
    }

    void saveNow() {
        if (saveTask != null) {
            saveTask.cancel();
            saveTask = null;
        }
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Double> e : settings.entrySet()) y.set("settings." + e.getKey(), e.getValue());
        y.set("next-warp-id", nextWarp);
        for (Warp w : warps.values()) {
            String p = "warps." + w.id + ".";
            y.set(p + "name", w.name);
            y.set(p + "owner", w.owner);
            y.set(p + "owner_name", w.ownerName);
            y.set(p + "loc", w.loc.enc());
            y.set(p + "desc", w.desc);
            y.set(p + "cat", w.cat);
            y.set(p + "price", w.price);
            y.set(p + "public", w.isPublic);
            y.set(p + "type", w.type);
            y.set(p + "visits", w.visits);
        }
        for (Map.Entry<UUID, TreeMap<Integer, Place>> e : places.entrySet()) {
            for (Map.Entry<Integer, Place> pe : e.getValue().entrySet()) {
                String p = "places." + e.getKey() + "." + pe.getKey() + ".";
                y.set(p + "name", pe.getValue().name);
                y.set(p + "loc", pe.getValue().loc.enc());
                y.set(p + "paid", pe.getValue().paid);
            }
        }
        for (Map.Entry<UUID, Pos> e : deaths.entrySet()) y.set("deaths." + e.getKey(), e.getValue().enc());
        List<String> nr = new ArrayList<>();
        for (UUID u : new HashSet<>(noReq)) nr.add(u.toString());
        y.set("no-requests", nr);
        for (Map.Entry<UUID, Map<UUID, String>> e : ignore.entrySet()) {
            for (Map.Entry<UUID, String> t : e.getValue().entrySet()) {
                y.set("ignore." + e.getKey() + "." + t.getKey(), t.getValue());
            }
        }
        if (spawn != null) y.set("spawn", spawn.enc());
        DataFile.write(plugin, file, y);
    }

    // ---------------------------------------------------------------- helpers

    TreeMap<Integer, Place> placesOf(UUID u) {
        return places.computeIfAbsent(u, k -> new TreeMap<>());
    }

    int countOwned(UUID u) {
        int c = 0;
        String us = u.toString();
        for (Warp w : warps.values()) if (w.type.equals("player") && w.owner.equals(us)) c++;
        return c;
    }

    Warp newWarp(String owner, String ownerName, String name, Location l, String type) {
        nextWarp++;
        Warp w = new Warp(String.valueOf(nextWarp));
        w.name = name;
        w.owner = owner;
        w.ownerName = ownerName;
        w.loc = Pos.of(l);
        w.type = type;
        warps.put(w.id, w);
        markDirty();
        return w;
    }

    static String nextCat(String c) {
        for (int i = 0; i < CATS.length; i++) if (CATS[i].equals(c)) return CATS[(i + 1) % CATS.length];
        return CATS[0];
    }

    /** All -> General -> ... -> Event -> All */
    static String nextFilter(String c) {
        if (c == null || c.equals("All")) return CATS[0];
        if (c.equals(CATS[CATS.length - 1])) return "All";
        return nextCat(c);
    }
}
