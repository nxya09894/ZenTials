package com.zentials.security;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Bedrock (Geyser + Floodgate) detection without a compile-time dependency on Floodgate.
 * A player counts as Bedrock ONLY if Floodgate itself says so (its API cannot be faked by a Java client).
 * A name that merely starts with the Floodgate prefix proves nothing and is never trusted.
 */
final class Bedrock {
    private final Object api;
    private final Method isFloodgate;
    private final String prefix;

    private Bedrock(Object api, Method isFloodgate, String prefix) {
        this.api = api;
        this.isFloodgate = isFloodgate;
        this.prefix = prefix == null ? "" : prefix;
    }

    static Bedrock detect(String fallbackPrefix) {
        Plugin fg = Bukkit.getPluginManager().getPlugin("floodgate");
        if (fg == null || !fg.isEnabled()) return new Bedrock(null, null, fallbackPrefix);
        try {
            Class<?> cls = Class.forName("org.geysermc.floodgate.api.FloodgateApi", true, fg.getClass().getClassLoader());
            Object api = cls.getMethod("getInstance").invoke(null);
            Method is = cls.getMethod("isFloodgatePlayer", UUID.class);
            String prefix = fallbackPrefix;
            try {
                if (cls.getMethod("getPlayerPrefix").invoke(api) instanceof String s) prefix = s;
            } catch (ReflectiveOperationException ignored) {
                // keep the configured prefix
            }
            return new Bedrock(api, is, prefix);
        } catch (Throwable t) {
            return new Bedrock(null, null, fallbackPrefix);
        }
    }

    /** Floodgate is installed and readable. */
    boolean available() {
        return api != null;
    }

    String prefix() {
        return prefix;
    }

    boolean hasPrefix(String name) {
        return !prefix.isEmpty() && name.startsWith(prefix);
    }

    /** True only for players Floodgate has verified through Xbox Live. */
    boolean isBedrock(UUID id) {
        if (api == null) return false;
        try {
            return Boolean.TRUE.equals(isFloodgate.invoke(api, id));
        } catch (ReflectiveOperationException | RuntimeException e) {
            return false;
        }
    }
}
