package com.zentials.security;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/** Fired (main thread) when a player finishes the login step. Other plugins and .ryu scripts can listen to it. */
public final class PlayerAuthEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    /** How the player got in. */
    public enum Via {LOGIN, REGISTER, SESSION, BEDROCK, BYPASS, ADMIN}

    private final Player player;
    private final Via via;

    public PlayerAuthEvent(Player player, Via via) {
        this.player = player;
        this.via = via;
    }

    public Player getPlayer() {
        return player;
    }

    public Via getVia() {
        return via;
    }

    @NotNull
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
