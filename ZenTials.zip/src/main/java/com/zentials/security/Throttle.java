package com.zentials.security;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/** Small counters with a time window, plus timed locks. Used for per-IP failure counts, connection floods and lockouts. */
final class Throttle {
    private final Map<String, long[]> hits = new ConcurrentHashMap<>();   // key -> {windowStart, count}
    private final Map<String, Long> locks = new ConcurrentHashMap<>();    // key -> locked until (ms)

    /** Counts one event for key inside a window of windowMs and returns how many happened in the current window. */
    int hit(String key, long windowMs) {
        long now = System.currentTimeMillis();
        int[] out = new int[1];
        hits.compute(key, (k, cur) -> {
            if (cur == null || now - cur[0] >= windowMs) cur = new long[]{now, 0};
            cur[1]++;
            out[0] = (int) cur[1];
            return cur;
        });
        return out[0];
    }

    void reset(String key) {
        hits.remove(key);
    }

    void lock(String key, long ms) {
        locks.put(key, System.currentTimeMillis() + ms);
    }

    void unlock(String key) {
        locks.remove(key);
        hits.remove(key);
    }

    /** Milliseconds left on the lock, 0 if not locked. */
    long lockedFor(String key) {
        Long until = locks.get(key);
        if (until == null) return 0;
        long left = until - System.currentTimeMillis();
        if (left <= 0) {
            locks.remove(key, until);
            return 0;
        }
        return left;
    }

    int lockCount() {
        return locks.size();
    }

    void purge(long windowMs) {
        long now = System.currentTimeMillis();
        hits.values().removeIf(w -> now - w[0] >= windowMs);
        locks.values().removeIf(until -> until <= now);
    }
}
