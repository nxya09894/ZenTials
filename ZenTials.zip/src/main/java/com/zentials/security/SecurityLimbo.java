package com.zentials.security;

import com.zentials.core.DataFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The waiting room: players who are not logged in wait in an empty void world (one invisible floor block under them),
 * far away from the real world. After login/register they are teleported back to exactly where they were.
 * Where they were is saved in data/security-limbo.yml, so even a crash or a kick in the waiting room never loses it.
 */
final class SecurityLimbo {
    /** Nothing generated at all: pure void. */
    private static final class VoidGen extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 0.5, 100, 0.5);
        }
    }

    private final JavaPlugin plugin;
    private final File file;
    private final Map<String, String> origins = new ConcurrentHashMap<>();
    private volatile World world;
    private volatile double y = 100;

    SecurityLimbo(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data/security-limbo.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            String v = y.getString(k);
            if (v != null) origins.put(k, v);
        }
    }

    /** Creates / loads the void world. Returns false if that is not possible (then players just wait where they are). */
    boolean start(String worldName, int height) {
        try {
            y = Math.max(-50, Math.min(300, height));
            World w = Bukkit.getWorld(worldName);
            if (w == null) {
                WorldCreator wc = new WorldCreator(worldName);
                wc.generator(new VoidGen());
                wc.generateStructures(false);
                wc.environment(World.Environment.NORMAL);
                w = Bukkit.createWorld(wc);
            }
            if (w == null) return false;
            w.setSpawnLocation(0, (int) y, 0);
            w.setAutoSave(false);
            w.setDifficulty(org.bukkit.Difficulty.PEACEFUL);
            w.setSpawnFlags(false, false);
            w.setTime(18000);
            w.setStorm(false);
            try {
                w.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
                w.setGameRule(org.bukkit.GameRule.DO_WEATHER_CYCLE, false);
                w.setGameRule(org.bukkit.GameRule.DO_MOB_SPAWNING, false);
            } catch (Throwable ignored) {
                // game rule names differ between versions; the rest still works
            }
            // one invisible floor block, so nobody falls forever
            w.getChunkAt(0, 0).load(true);
            w.getBlockAt(0, (int) y - 1, 0).setType(Material.BARRIER, false);
            world = w;
            return true;
        } catch (Throwable t) {
            plugin.getLogger().warning("[Security] Could not create the waiting room world (" + t + "). Players wait where they join.");
            return false;
        }
    }

    World world() {
        return world;
    }

    private static String enc(Location l) {
        return l.getWorld().getName() + "|" + l.getX() + "|" + l.getY() + "|" + l.getZ() + "|" + l.getYaw() + "|" + l.getPitch();
    }

    private static Location dec(String s) {
        try {
            String[] t = s.split("\\|");
            World w = Bukkit.getWorld(t[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(t[1]), Double.parseDouble(t[2]), Double.parseDouble(t[3]),
                    Float.parseFloat(t[4]), Float.parseFloat(t[5]));
        } catch (Exception ex) {
            return null;
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, String> e : origins.entrySet()) y.set(e.getKey(), e.getValue());
        DataFile.writeText(plugin, file, y.saveToString());
    }

    /** Moves the player into the waiting room, remembering where they were. Main thread. */
    boolean send(Player p, String key) {
        World w = world;
        if (w == null) return false;
        Location here = p.getLocation();
        if (!here.getWorld().equals(w)) {            // already in the waiting room (left there last time): keep the older spot
            origins.put(key, enc(here));
            save();
        }
        p.teleportAsync(new Location(w, 0.5, y, 0.5, here.getYaw(), 0f));
        p.setFallDistance(0f);
        return true;
    }

    /** Takes the player back to where they were (or the main world spawn if that world is gone). Main thread. */
    void back(Player p, String key) {
        String saved = origins.remove(key);
        if (saved != null) save();
        World w = world;
        Location to = saved == null ? null : dec(saved);
        if (to == null && w != null && p.getWorld().equals(w)) {
            World main = Bukkit.getWorlds().get(0);
            to = main.getSpawnLocation();
        }
        if (to != null) {
            p.teleportAsync(to);
            p.setFallDistance(0f);
        }
    }

    /** Server stop / module off: nobody stays in the waiting room. */
    void shutdown(Iterable<Player> waiting, java.util.function.Function<Player, String> keyOf) {
        for (Player p : waiting) {
            String saved = origins.get(keyOf.apply(p));
            Location to = saved == null ? null : dec(saved);
            if (to != null && p.isOnline()) p.teleport(to);
        }
        // origins stay on disk for players who could not be moved
        save();
    }

    String keyOf(String name) {
        return name.toLowerCase(Locale.ROOT);
    }
}
