package com.zentials.security;

import com.zentials.ZenTials;
import com.zentials.security.SecurityStore.Account;
import com.zentials.core.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Level;

/**
 * Player commands: /login /register /changepassword /logout /unregister.
 * Admin command: /auth (register, unregister, changepassword, forcelogin, info, status, unlock, reload).
 */
final class SecurityCommands implements TabExecutor {
    private static final String TAG = "&8[&bSecurity&8]&7 ";
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.ROOT)
            .withZone(ZoneOffset.UTC);
    private static final List<String> SUBS = List.of("register", "unregister", "changepassword", "forcelogin",
            "info", "status", "unlock", "reload");
    private static final Set<String> NAME_SUBS = Set.of("register", "unregister", "changepassword", "forcelogin", "info");

    private final SecurityModule auth;
    private final ZenTials plugin;

    SecurityCommands(SecurityModule auth, ZenTials plugin) {
        this.auth = auth;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String name = c.getName().toLowerCase(Locale.ROOT);
        if (name.equals("security")) {
            admin(s, a);
            return true;
        }
        if (!(s instanceof Player p)) {
            Text.send(s, "&cOnly players can use this command.");
            return true;
        }
        switch (name) {
            case "login" -> {
                if (a.length != 1) p.sendMessage(auth.msg("usage-login"));
                else auth.doLogin(p, a[0]);
            }
            case "register" -> {
                if (a.length != 2) p.sendMessage(auth.msg("usage-register"));
                else auth.doRegister(p, a[0], a[1]);
            }
            case "changepassword" -> {
                if (a.length != 2) p.sendMessage(auth.msg("usage-changepassword"));
                else auth.doChangePassword(p, a[0], a[1]);
            }
            case "unregister" -> {
                if (a.length != 1) p.sendMessage(auth.msg("usage-unregister"));
                else auth.doUnregister(p, a[0]);
            }
            case "logout" -> auth.doLogout(p);
            default -> {
            }
        }
        return true;
    }

    // ---------------------------------------------------------------- /auth

    private void say(CommandSender to, String text) {
        Text.send(to, TAG + text);
    }

    /** Replies from any thread. */
    private void reply(CommandSender to, String text) {
        auth.sync(() -> say(to, text));
    }

    private void usage(CommandSender s) {
        say(s, "&f/auth register <name> <password> &8| &f/auth unregister <name> &8| &f/auth changepassword <name> <password>");
        say(s, "&f/auth forcelogin <name> &8| &f/auth info <name> &8| &f/auth status &8| &f/auth unlock <ip> &8| &f/auth reload");
    }

    private void admin(CommandSender s, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "register" -> adminRegister(s, a);
            case "unregister" -> adminUnregister(s, a);
            case "changepassword", "changepass" -> adminChangePassword(s, a);
            case "forcelogin" -> {
                if (a.length != 2) {
                    usage(s);
                    return;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) say(s, "&c" + a[1] + " is not online.");
                else if (auth.forceLogin(t)) say(s, "&a" + t.getName() + " is logged in now.");
                else say(s, "&e" + t.getName() + " is already logged in.");
            }
            case "info" -> adminInfo(s, a);
            case "status" -> adminStatus(s);
            case "unlock" -> {
                if (a.length != 2) {
                    usage(s);
                    return;
                }
                auth.unlockIp(a[1]);
                say(s, "&aCleared the wrong-password lock for &f" + a[1] + "&a.");
            }
            case "reload" -> {
                auth.reload();
                say(s, "&aSecurity settings reloaded. &7(pepper, thread count and the on/off switch need a restart)");
            }
            default -> usage(s);
        }
    }

    private void adminRegister(CommandSender s, String[] a) {
        if (a.length != 3) {
            usage(s);
            return;
        }
        final String name = a[1];
        final String pw = a[2];
        final String key = name.toLowerCase(Locale.ROOT);
        if (!auth.namePattern().matcher(name).matches() && !name.startsWith(auth.bedrockPrefix())) {
            say(s, "&cThat is not a valid player name.");
            return;
        }
        String bad = auth.policy().check(pw, name);
        if (bad != null) {
            say(s, "&cThat password is not allowed: &7" + bad + " &8(min " + auth.policy().min() + ", letters + digits)");
            return;
        }
        final PasswordHasher hs = auth.hasher();
        boolean queued = auth.runHash(() -> {
            try {
                if (auth.store().get(key) != null) {
                    reply(s, "&c" + name + " already has an account. Use /auth changepassword.");
                    return;
                }
                long now = System.currentTimeMillis();
                boolean ok = auth.store().create(new Account(name, hs.hash(pw), "admin", "", now, 0, 0, "java"));
                if (ok) auth.sync(() -> auth.accountCreatedFor(key));
                reply(s, ok ? "&aAccount created for &f" + name + "&a." : "&c" + name + " already has an account.");
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "[Security] /auth register failed", ex);
                reply(s, "&cFailed: " + ex.getMessage());
            }
        });
        if (!queued) say(s, "&cThe server is busy hashing passwords. Try again in a moment.");
    }

    private void adminChangePassword(CommandSender s, String[] a) {
        if (a.length != 3) {
            usage(s);
            return;
        }
        final String name = a[1];
        final String pw = a[2];
        final String key = name.toLowerCase(Locale.ROOT);
        String bad = auth.policy().check(pw, name);
        if (bad != null) {
            say(s, "&cThat password is not allowed: &7" + bad);
            return;
        }
        final PasswordHasher hs = auth.hasher();
        boolean queued = auth.runHash(() -> {
            try {
                if (auth.store().get(key) == null) {
                    reply(s, "&c" + name + " has no account.");
                    return;
                }
                auth.store().setHash(key, hs.hash(pw));
                auth.forgetSession(key);
                reply(s, "&aPassword of &f" + name + " &achanged.");
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "[Security] /auth changepassword failed", ex);
                reply(s, "&cFailed: " + ex.getMessage());
            }
        });
        if (!queued) say(s, "&cThe server is busy hashing passwords. Try again in a moment.");
    }

    private void adminUnregister(CommandSender s, String[] a) {
        if (a.length != 2) {
            usage(s);
            return;
        }
        final String key = a[1].toLowerCase(Locale.ROOT);
        auth.async(() -> {
            try {
                if (auth.store().get(key) == null) {
                    reply(s, "&c" + a[1] + " has no account.");
                    return;
                }
                auth.store().delete(key);
                auth.sync(() -> auth.accountDeletedFor(key));
                reply(s, "&aAccount of &f" + a[1] + " &adeleted.");
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "[Security] /auth unregister failed", ex);
                reply(s, "&cFailed: " + ex.getMessage());
            }
        });
    }

    private void adminInfo(CommandSender s, String[] a) {
        if (a.length != 2) {
            usage(s);
            return;
        }
        final String key = a[1].toLowerCase(Locale.ROOT);
        auth.async(() -> {
            try {
                Account acc = auth.store().get(key);
                if (acc == null) {
                    reply(s, "&c" + a[1] + " has no account.");
                    return;
                }
                auth.sync(() -> {
                    Player t = Bukkit.getPlayerExact(acc.name());
                    say(s, "&f" + acc.name() + " &8| &7" + acc.platform() + " &8| &7" + (t == null ? "offline"
                            : auth.isAuthenticated(t) ? "online, logged in" : "online, NOT logged in"));
                    say(s, "&7Registered: &f" + DATE.format(Instant.ofEpochMilli(acc.registered())) + " UTC &8(" + acc.regIp() + ")");
                    say(s, "&7Last login: &f" + (acc.lastLogin() == 0 ? "never" : DATE.format(Instant.ofEpochMilli(acc.lastLogin())) + " UTC")
                            + " &8(" + acc.lastIp() + ") &7Logins: &f" + acc.logins());
                });
            } catch (Exception ex) {
                reply(s, "&cFailed: " + ex.getMessage());
            }
        });
    }

    private void adminStatus(CommandSender s) {
        auth.async(() -> {
            long total = -1;
            try {
                total = auth.store().total();
            } catch (Exception ignored) {
                // shown as ?
            }
            final long t = total;
            auth.sync(() -> {
                say(s, "&7Accounts: &f" + (t < 0 ? "?" : String.valueOf(t)) + " &8| &7Waiting for login: &f" + auth.lockedCount()
                        + " &8| &7Sessions: &f" + auth.sessionCount() + " &8| &7Locked IPs: &f" + auth.ipLockCount());
                say(s, "&7Hash: &fPBKDF2-SHA512 x" + auth.hasher().iterations() + (auth.hasher().peppered() ? " + pepper" : "")
                        + " &8| &7Floodgate: &f" + (auth.floodgate() ? "found (prefix '" + auth.bedrockPrefix() + "')" : "not found"));
            });
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!c.getName().equalsIgnoreCase("security")) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : SUBS) if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
        } else if (a.length == 2 && NAME_SUBS.contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
