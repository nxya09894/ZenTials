package com.zentials.security;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Login / register window for Java clients OLDER than 1.21 (joining through ViaVersion/ViaBackwards). 1.21+ clients get
 * the popup (Dialog) window instead, so they never reach this class. Old clients get an anvil: type the password in the name box and click the
 * result item. Registering asks twice (password, then repeat). It uses only the normal Bukkit anvil, nothing else.
 */
final class SecurityAnvil implements Listener {
    private static final class St {
        InventoryView view;
        boolean register;
        boolean confirm;       // second step of registering
        String first;          // the password typed in the first step
        volatile String text = "";
    }

    private final SecurityModule a;
    private final JavaPlugin plugin;
    private final Map<UUID, St> open = new ConcurrentHashMap<>();
    private final Set<UUID> opening = ConcurrentHashMap.newKeySet();

    SecurityAnvil(SecurityModule a, JavaPlugin plugin) {
        this.a = a;
        this.plugin = plugin;
    }

    boolean isOpen(Player p) {
        return open.containsKey(p.getUniqueId());
    }

    /** The guard lets this player's own anvil open and be clicked. */
    boolean owns(UUID id) {
        return opening.contains(id) || open.containsKey(id);
    }

    private static String legacy(Component c) {
        return LegacyComponentSerializer.legacySection().serialize(c);
    }

    private ItemStack input(boolean register, boolean confirm) {
        ItemStack it = new ItemStack(Material.NAME_TAG);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text(" "));
        it.setItemMeta(m);
        return it;
    }

    private ItemStack result(String key) {
        ItemStack it = new ItemStack(Material.LIME_DYE);
        ItemMeta m = it.getItemMeta();
        m.displayName(a.plain(key));
        it.setItemMeta(m);
        return it;
    }

    private Component title(St s) {
        return a.plain(!s.register ? "anvil-title-login" : s.confirm ? "anvil-title-confirm" : "anvil-title-register");
    }

    /** Opens the window (or does nothing if it is already open). Main thread. */
    boolean show(Player p, boolean register) {
        if (open.containsKey(p.getUniqueId())) return true;
        opening.add(p.getUniqueId());
        try {
            InventoryView v = p.openAnvil(null, true);
            if (v == null) return false;
            St s = new St();
            s.view = v;
            s.register = register;
            open.put(p.getUniqueId(), s);
            v.setTitle(legacy(title(s)));
            v.getTopInventory().setItem(0, input(register, false));
            return true;
        } catch (Throwable t) {
            plugin.getLogger().warning("[Security] The anvil login window is not available (" + t + "). Using chat commands instead.");
            return false;
        } finally {
            opening.remove(p.getUniqueId());
        }
    }

    /** Shows a message in the window title and starts the typing over (after a mistake). */
    void notice(Player p, Component c) {
        if (!Bukkit.isPrimaryThread()) {
            Bukkit.getScheduler().runTask(plugin, () -> notice(p, c));
            return;
        }
        St s = open.get(p.getUniqueId());
        if (s == null) return;
        s.confirm = false;
        s.first = null;
        s.text = "";
        s.view.setTitle(legacy(c));
        s.view.getTopInventory().setItem(0, input(s.register, false));
    }

    /** Closes it for good (logged in, kicked). */
    void close(Player p) {
        St s = open.remove(p.getUniqueId());
        if (s == null) return;
        s.view.getTopInventory().clear();
        p.closeInventory();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepare(PrepareAnvilEvent e) {
        if (!(e.getView().getPlayer() instanceof Player p)) return;
        St s = open.get(p.getUniqueId());
        if (s == null) return;
        String t = e.getView() instanceof AnvilView av ? av.getRenameText() : null;
        s.text = t == null ? "" : t.trim();
        if (e.getView() instanceof AnvilView av) {
            try {
                av.setRepairCost(0);
            } catch (Throwable ignored) {
                // older API: the click is cancelled anyway
            }
        }
        e.setResult(s.text.isEmpty() ? null : result(s.register && !s.confirm ? "anvil-next" : "anvil-confirm"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        St s = open.get(p.getUniqueId());
        if (s == null) return;
        e.setCancelled(true);                      // nothing can be taken out or put in
        if (e.getRawSlot() != 2) return;           // only the result item does anything
        String pw = s.text;
        if (e.getView() instanceof AnvilView av && av.getRenameText() != null) pw = av.getRenameText().trim();
        if (pw.isEmpty()) return;
        if (!s.register) {
            a.doLogin(p, pw);
            return;
        }
        if (!s.confirm) {                          // step 1 of registering: now ask again
            s.first = pw;
            s.confirm = true;
            s.text = "";
            s.view.setTitle(legacy(title(s)));
            s.view.getTopInventory().setItem(0, input(true, true));
            return;
        }
        String first = s.first == null ? "" : s.first;
        s.confirm = false;
        s.first = null;
        s.text = "";
        a.doRegister(p, first, pw);
        St again = open.get(p.getUniqueId());
        if (again != null) {                       // still waiting (a mistake): back to step 1
            again.view.setTitle(legacy(title(again)));
            again.view.getTopInventory().setItem(0, input(true, false));
        }
    }

    /** Nothing can be dragged into the anvil (it would be deleted when the window closes). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(org.bukkit.event.inventory.InventoryDragEvent e) {
        if (open.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
    }

    /** The player pressed Esc: forget the window. It opens again with the next reminder, or with /login. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClose(InventoryCloseEvent e) {
        St s = open.get(e.getPlayer().getUniqueId());
        if (s == null || e.getInventory().getType() != org.bukkit.event.inventory.InventoryType.ANVIL) return;
        open.remove(e.getPlayer().getUniqueId());
        e.getInventory().clear();                  // the fake item must never reach the player's bag
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        St s = open.remove(e.getPlayer().getUniqueId());
        if (s != null) s.view.getTopInventory().clear();
    }
}
