package com.zentials.chat;

import com.zentials.core.DataFile;
import com.zentials.ZenTials;
import com.zentials.core.Papi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Chat format, join / quit messages with a first-join message and welcome lines, and a sidebar scoreboard.
 * Settings: modules/chat/config.yml (chat:, join:, scoreboard:). PlaceholderAPI placeholders work in all of them.
 * Note: if you also use TAB's scoreboard, leave scoreboard.enabled off here (two plugins would fight).
 */
public final class ChatModule implements ZModule, Listener, TabExecutor {
    private static final Pattern COLOR = Pattern.compile("(?i)&([0-9a-fk-orx]|#[0-9a-f]{6})");

    private final ZenTials plugin;

    private boolean chatOn;
    private String chatFormat;
    private boolean joinOn;
    private String joinMsg;
    private String quitMsg;
    private String firstJoinMsg;
    private List<String> welcome;
    private boolean sbOn;
    private String sbTitle;
    private List<String> sbLines;
    private int sbInterval;
    private boolean sbHideNumbers;

    private final Map<UUID, Set<UUID>> ignored = new ConcurrentHashMap<>();
    private final Set<UUID> msgOff = ConcurrentHashMap.newKeySet();
    private final Map<UUID, UUID> lastMsg = new ConcurrentHashMap<>();
    private File dataFile;

    private BukkitTask sbTask;
    private final Map<UUID, Scoreboard> boards = new ConcurrentHashMap<>();
    private final Set<UUID> sbOff = ConcurrentHashMap.newKeySet();

    public ChatModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "chat";
    }

    @Override
    public void enable() {
        readConfig();
        loadIgnores();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (String n : new String[]{"scoreboard", "msg", "reply", "msgtoggle", "ignore", "unignore", "broadcast", "clearchat"}) {
            if (n.equals("scoreboard") && plugin.aura() != null && plugin.aura().ownsScoreboard()) continue;
            PluginCommand c = plugin.getCommand(n);
            if (c != null) {
                c.setExecutor(this);
                c.setTabCompleter(this);
            }
        }
        startBoards();
    }

    @Override
    public void disable() {
        saveIgnores();
        stopBoards();
    }

    @Override
    public void reload() {
        stopBoards();
        readConfig();
        startBoards();
    }

    private void readConfig() {
        var c = plugin.moduleConfig("chat");
        chatOn = c.getBoolean("chat.enabled", true) && !(plugin.aura() != null && plugin.aura().ownsChat());
        chatFormat = c.getString("chat.format", "&7{displayname} &8» &f{message}");
        joinOn = c.getBoolean("join.enabled", true);
        joinMsg = c.getString("join.join-message", "&8[&a+&8] &7{player}");
        quitMsg = c.getString("join.quit-message", "&8[&c-&8] &7{player}");
        firstJoinMsg = c.getString("join.first-join-message", "&6Welcome &f{player} &6to the server for the first time!");
        welcome = c.getStringList("join.welcome-lines");
        sbOn = c.getBoolean("scoreboard.enabled", false) && !(plugin.aura() != null && plugin.aura().ownsScoreboard());
        sbTitle = c.getString("scoreboard.title", "&b&lHEAVEN SMP");
        sbLines = c.getStringList("scoreboard.lines");
        sbInterval = Math.max(5, c.getInt("scoreboard.update-ticks", 20));
        sbHideNumbers = c.getBoolean("scoreboard.hide-numbers", true);
    }

    // ---------------------------------------------------------------- chat

    private static String stripColors(String s) {
        return COLOR.matcher(s).replaceAll("");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID sender = p.getUniqueId();
        e.viewers().removeIf(v -> v instanceof Player vp && !vp.getUniqueId().equals(sender)
                && ignored.getOrDefault(vp.getUniqueId(), Set.of()).contains(sender));
        if (!chatOn) return;
        String plain = PlainTextComponentSerializer.plainText().serialize(e.message());
        if (!p.hasPermission("zentials.chat.color")) plain = stripColors(plain);
        final String body = plain;
        e.renderer((source, display, message, viewer) -> {
            String f = chatFormat.replace("{player}", source.getName())
                    .replace("{displayname}", PlainTextComponentSerializer.plainText().serialize(display));
            f = Papi.set(source, f);
            return Text.c(f.replace("{message}", body));
        });
    }

    // ---------------------------------------------------------------- join / quit

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (joinOn) {
            boolean first = !p.hasPlayedBefore();
            String m = first && !firstJoinMsg.isBlank() ? firstJoinMsg : joinMsg;
            e.joinMessage(m.isBlank() ? null : Text.c(Papi.set(p, m.replace("{player}", p.getName()))));
            for (String l : welcome) {
                p.sendMessage(Text.c(Papi.set(p, l.replace("{player}", p.getName()))));
            }
        }
        if (sbOn) Bukkit.getScheduler().runTaskLater(plugin, () -> update(p), 10L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (joinOn) {
            e.quitMessage(quitMsg.isBlank() ? null : Text.c(Papi.set(p, quitMsg.replace("{player}", p.getName()))));
        }
        boards.remove(p.getUniqueId());
    }

    // ---------------------------------------------------------------- scoreboard

    private void startBoards() {
        if (!sbOn) return;
        if (Bukkit.getPluginManager().isPluginEnabled("TAB")) {
            plugin.getLogger().warning("TAB is installed and the ZenTials scoreboard is on. If TAB also has its scoreboard on, turn one of them off.");
        }
        sbTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) update(p);
        }, 20L, sbInterval);
    }

    private void stopBoards() {
        if (sbTask != null) sbTask.cancel();
        sbTask = null;
        if (Bukkit.getScoreboardManager() != null) {
            for (UUID u : boards.keySet()) {
                Player p = Bukkit.getPlayer(u);
                if (p != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }
        boards.clear();
    }

    private String fill(Player p, String line) {
        String s = line.replace("{player}", p.getName())
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()));
        var eco = plugin.economyApi();
        if (eco != null) s = s.replace("{balance}", eco.format(eco.balance(p.getUniqueId())));
        return Papi.set(p, s);
    }

    private void update(Player p) {
        if (!sbOn || Bukkit.getScoreboardManager() == null) return;
        if (sbOff.contains(p.getUniqueId())) {
            if (boards.remove(p.getUniqueId()) != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            return;
        }
        Scoreboard sb = boards.get(p.getUniqueId());
        int n = Math.min(15, sbLines.size());
        if (sb == null) {
            sb = Bukkit.getScoreboardManager().getNewScoreboard();
            Objective o = sb.registerNewObjective("zen", "dummy", Text.c(sbTitle));
            o.setDisplaySlot(DisplaySlot.SIDEBAR);
            if (sbHideNumbers) o.numberFormat(NumberFormat.blank());
            for (int i = 0; i < 15; i++) {
                Team t = sb.registerNewTeam("l" + i);
                t.addEntry(entry(i));
            }
            boards.put(p.getUniqueId(), sb);
            p.setScoreboard(sb);
        }
        Objective o = sb.getObjective("zen");
        if (o == null) return;
        o.displayName(Text.c(fill(p, sbTitle)));
        for (int i = 0; i < 15; i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            if (i < n) {
                t.prefix(Text.c(fill(p, sbLines.get(i))));
                o.getScore(entry(i)).setScore(n - i);
            } else {
                sb.resetScores(entry(i));
            }
        }
    }

    /** Invisible unique scoreboard entry for line i. */
    private static String entry(int i) {
        return "§" + Integer.toHexString(i) + "§r";
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String cn = c.getName().toLowerCase(Locale.ROOT);
        if (!cn.equals("scoreboard")) return simple(s, cn, a);
        if (!(s instanceof Player p)) return true;
        if (!sbOn) {
            Text.send(s, "&8[&bZen&8]&7 The scoreboard is turned off on this server.");
            return true;
        }
        boolean off;
        if (a.length > 0 && a[0].equalsIgnoreCase("on")) off = false;
        else if (a.length > 0 && a[0].equalsIgnoreCase("off")) off = true;
        else off = !sbOff.contains(p.getUniqueId());
        if (off) sbOff.add(p.getUniqueId());
        else sbOff.remove(p.getUniqueId());
        update(p);
        Text.send(s, "&8[&bZen&8]&7 Scoreboard " + (off ? "&chidden" : "&ashown") + "&7.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        String cn0 = c.getName().toLowerCase(Locale.ROOT);
        if (!cn0.equals("scoreboard")) {
            List<String> r = new ArrayList<>();
            if (a.length == 1 && List.of("msg", "ignore", "unignore").contains(cn0)) {
                for (Player o : Bukkit.getOnlinePlayers()) if (o.getName().toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))) r.add(o.getName());
            }
            return r;
        }
        return a.length == 1 ? new ArrayList<>(List.of("on", "off")) : List.of();
    }

    // ---------------------------------------------------------------- simple chat commands

    private static final String T = "&8[&bChat&8]&7 ";

    private void loadIgnores() {
        for (String old : new String[]{"chat-data.yml", "data.yml", "modules/chat/data.yml"}) com.zentials.core.Cfg.migrate(plugin, old, "data/chat.yml");
        dataFile = new File(plugin.getDataFolder(), "data/chat.yml");
        dataFile.getParentFile().mkdirs();
        ignored.clear();
        msgOff.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        var sec = y.getConfigurationSection("ignore");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                try {
                    Set<UUID> set = ConcurrentHashMap.newKeySet();
                    for (String v : sec.getStringList(k)) set.add(UUID.fromString(v));
                    ignored.put(UUID.fromString(k), set);
                } catch (IllegalArgumentException ignoredEx) {
                    // skip bad entry
                }
            }
        }
        for (String v : y.getStringList("msg-off")) {
            try {
                msgOff.add(UUID.fromString(v));
            } catch (IllegalArgumentException ignoredEx) {
                // skip
            }
        }
    }

    private void saveIgnores() {
        if (dataFile == null) return;
        YamlConfiguration y = new YamlConfiguration();
        for (var en : ignored.entrySet()) {
            if (en.getValue().isEmpty()) continue;
            List<String> l = new ArrayList<>();
            for (UUID u : en.getValue()) l.add(u.toString());
            y.set("ignore." + en.getKey(), l);
        }
        List<String> off = new ArrayList<>();
        for (UUID u : msgOff) off.add(u.toString());
        y.set("msg-off", off);
        DataFile.write(plugin, dataFile, y);
    }

    private static Player find(String n) {
        for (Player q : Bukkit.getOnlinePlayers()) if (q.getName().equalsIgnoreCase(n)) return q;
        for (Player q : Bukkit.getOnlinePlayers()) if (q.getName().toLowerCase(Locale.ROOT).startsWith(n.toLowerCase(Locale.ROOT))) return q;
        return null;
    }

    private boolean simple(CommandSender s, String cn, String[] a) {
        switch (cn) {
            case "broadcast" -> {
                if (!s.hasPermission("zentials.chat.broadcast")) {
                    Text.send(s, T + "&cNo permission.");
                    return true;
                }
                if (a.length == 0) {
                    Text.send(s, T + "Usage: /broadcast <message>");
                    return true;
                }
                String m = plugin.moduleConfig("chat").getString("chat.broadcast-format", "&8[&c&lBROADCAST&8] &f{message}")
                        .replace("{message}", String.join(" ", a));
                Bukkit.broadcast(Text.c(m));
                return true;
            }
            case "clearchat" -> {
                if (!s.hasPermission("zentials.chat.clear")) {
                    Text.send(s, T + "&cNo permission.");
                    return true;
                }
                for (Player o : Bukkit.getOnlinePlayers()) {
                    if (o.hasPermission("zentials.chat.clear")) continue;
                    for (int i = 0; i < 100; i++) o.sendMessage(Component.empty());
                }
                Bukkit.broadcast(Text.c(T + "Chat was cleared by &f" + s.getName() + "&7."));
                return true;
            }
            default -> {
            }
        }
        if (!(s instanceof Player p)) {
            Text.send(s, T + "&cPlayers only.");
            return true;
        }
        UUID u = p.getUniqueId();
        switch (cn) {
            case "msg" -> {
                if (a.length < 2) {
                    Text.send(p, T + "Usage: /msg <player> <message>");
                    return true;
                }
                Player t = find(a[0]);
                if (t == null) {
                    Text.send(p, T + "&cThat player is not online.");
                    return true;
                }
                sendPm(p, t, String.join(" ", java.util.Arrays.copyOfRange(a, 1, a.length)));
            }
            case "reply" -> {
                UUID lu = lastMsg.get(u);
                Player t = lu == null ? null : Bukkit.getPlayer(lu);
                if (a.length < 1) {
                    Text.send(p, T + "Usage: /r <message>");
                    return true;
                }
                if (t == null) {
                    Text.send(p, T + "&cNobody to reply to.");
                    return true;
                }
                sendPm(p, t, String.join(" ", a));
            }
            case "msgtoggle" -> {
                if (msgOff.remove(u)) Text.send(p, T + "Private messages: &aON");
                else {
                    msgOff.add(u);
                    Text.send(p, T + "Private messages: &cOFF");
                }
                saveIgnores();
            }
            case "ignore" -> {
                if (a.length < 1) {
                    Set<UUID> set = ignored.getOrDefault(u, Set.of());
                    List<String> names = new ArrayList<>();
                    for (UUID x : set) names.add(String.valueOf(Bukkit.getOfflinePlayer(x).getName()));
                    Text.send(p, T + "Ignoring: &f" + (names.isEmpty() ? "nobody" : String.join(", ", names)) + " &7(use /ignore <player>)");
                    return true;
                }
                Player t = find(a[0]);
                if (t == null || t.getUniqueId().equals(u)) {
                    Text.send(p, T + "&cThat player is not online.");
                    return true;
                }
                ignored.computeIfAbsent(u, k -> ConcurrentHashMap.newKeySet()).add(t.getUniqueId());
                saveIgnores();
                Text.send(p, T + "Now ignoring &f" + t.getName() + "&7. Undo: /unignore " + t.getName());
            }
            case "unignore" -> {
                if (a.length < 1) {
                    Text.send(p, T + "Usage: /unignore <player>");
                    return true;
                }
                Set<UUID> set = ignored.get(u);
                boolean done = false;
                if (set != null) {
                    for (UUID x : new HashSet<>(set)) {
                        String nm = Bukkit.getOfflinePlayer(x).getName();
                        if (nm != null && nm.equalsIgnoreCase(a[0])) {
                            set.remove(x);
                            done = true;
                        }
                    }
                }
                saveIgnores();
                Text.send(p, T + (done ? "No longer ignoring &f" + a[0] + "&7." : "&cYou weren't ignoring that player."));
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private void sendPm(Player from, Player to, String text) {
        if (to.getUniqueId().equals(from.getUniqueId())) {
            Text.send(from, T + "&cYou can't message yourself.");
            return;
        }
        if (msgOff.contains(to.getUniqueId()) && !from.hasPermission("zentials.chat.bypass")) {
            Text.send(from, T + "&c" + to.getName() + " has private messages turned off.");
            return;
        }
        if (msgOff.contains(from.getUniqueId())) {
            Text.send(from, T + "&cYour private messages are off. Use /msgtoggle.");
            return;
        }
        String body = from.hasPermission("zentials.chat.color") ? text : stripColors(text);
        Text.send(from, "&8[&7You &8→ &f" + to.getName() + "&8] &7" + body);
        boolean blocked = ignored.getOrDefault(to.getUniqueId(), Set.of()).contains(from.getUniqueId());
        if (!blocked) {
            Text.send(to, "&8[&f" + from.getName() + " &8→ &7You&8] &7" + body);
            to.playSound(to.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.4f);
            lastMsg.put(to.getUniqueId(), from.getUniqueId());
        }
        lastMsg.put(from.getUniqueId(), to.getUniqueId());
    }
}
