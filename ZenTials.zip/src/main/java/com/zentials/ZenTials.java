package com.zentials;

import com.zentials.core.Tag;
import com.zentials.api.EconomyApi;
import com.zentials.core.Prompts;
import com.zentials.core.Sfx;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.db.Database;
import com.zentials.core.db.Kv;
import com.zentials.core.db.SkriptImport;
import com.zentials.core.gui.GuiListener;
import com.zentials.security.SecurityModule;
import com.zentials.chat.ChatModule;
import com.zentials.ranks.RankModule;
import com.zentials.economy.EconomyModule;
import com.zentials.holograms.HologramModule;
import com.zentials.npc.NpcModule;
import com.zentials.ryuu.RyuuModule;
import com.zentials.graves.GraveModule;
import com.zentials.aura.AuraModule;
import com.zentials.teleport.TeleportModule;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;

public final class ZenTials extends JavaPlugin implements TabExecutor {

    private static final String TAG = Tag.ZENTIALS;

    private final List<ZModule> modules = new ArrayList<>();
    private Sfx sfx;
    private Prompts prompts;
    private Database db;
    private Kv kv;
    private EconomyApi economyApi;
    private RyuuModule ryuu;
    private AuraModule aura;
    private GraveModule graves;
    private TeleportModule teleport;
    private SecurityModule auth;
    private RankModule ranks;

    /** The security (login) module, null if turned off. Use auth().isAuthenticated(player). */
    public SecurityModule auth() {
        return auth;
    }

    /** Same as auth(): the security module (null if turned off). */
    public SecurityModule security() {
        return auth;
    }

    /** The ranks (permissions) module, null if turned off. */
    public RankModule ranks() {
        return ranks;
    }

    /** The graves module (null if turned off). */
    public GraveModule graves() {
        return graves;
    }

    /** The teleport module (null if turned off). */
    public TeleportModule teleport() {
        return teleport;
    }

    /** Settings file of a built-in module: plugins/ZenTials/modules/<id>/config.yml (created from the jar if missing). */
    public org.bukkit.configuration.file.YamlConfiguration moduleConfig(String id) {
        return com.zentials.core.Cfg.yamlWithDefaults(this, "modules/" + id + "/config.yml");
    }

    /** The aura module (null if turned off). */
    public AuraModule aura() {
        return aura;
    }

    public Sfx sfx() {
        return sfx;
    }

    public Prompts prompts() {
        return prompts;
    }

    /** The economy API (null if the economy module is off). */
    public EconomyApi economyApi() {
        return economyApi;
    }

    public void setEconomyApi(EconomyApi api) {
        this.economyApi = api;
    }

    /** Shared database (null if it failed to start). */
    public Database db() {
        return db;
    }

    /** Shared key/value store, the replacement for Skript variables (null if the database is down). */
    public Kv kv() {
        return kv;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        sfx = new Sfx(this);
        sfx.load();
        prompts = new Prompts(this);
        getServer().getPluginManager().registerEvents(prompts, this);
        getServer().getPluginManager().registerEvents(new GuiListener(), this);

        openDatabase();
        prepareSecurityFiles();

        // config.yml from before 0.9.0 had teleport: false (the old default). Turn it on once.
        if (getConfig().getInt("config-version", 1) < 2) {
            getConfig().set("modules.teleport", true);
            getConfig().set("config-version", 2);
            saveConfig();
            getLogger().info("config.yml updated: modules.teleport is now ON (set it to false if you want it off).");
        }

        // Security (login) goes first so players are locked before any other module sees them. OFF unless switched on.
        if (getConfig().getBoolean("modules.security", false)) {
            auth = new SecurityModule(this);
            modules.add(auth);
        }

        // Ranks next: permissions must be in place before the other modules look at them.
        if (getConfig().getBoolean("modules.ranks", true)) {
            ranks = new RankModule(this);
            modules.add(ranks);
        }

        if (getConfig().getBoolean("modules.economy", true)) {
            modules.add(new EconomyModule(this));
        }

        if (getConfig().getBoolean("modules.npc", true)) {
            modules.add(new NpcModule(this));
        }
        if (getConfig().getBoolean("modules.holograms", true)) {
            modules.add(new HologramModule(this));
        }
        if (getConfig().getBoolean("modules.aura", true)) {
            aura = new AuraModule(this);   // before chat: chat checks what aura already handles
            modules.add(aura);
        }
        if (getConfig().getBoolean("modules.chat", true)) {
            modules.add(new ChatModule(this));
        }
        if (getConfig().getBoolean("modules.teleport", true)) {
            teleport = new TeleportModule(this);
            modules.add(teleport);
        }
        if (getConfig().getBoolean("modules.graves", true)) {
            graves = new GraveModule(this);
            modules.add(graves);
        }

        if (getConfig().getBoolean("modules.ryuudules", true)) {
            ryuu = new RyuuModule(this);
            modules.add(ryuu);
        }

        for (ZModule m : modules) {
            try {
                m.enable();
                getLogger().info("Module enabled: " + m.id());
            } catch (Exception ex) {
                getLogger().log(Level.SEVERE, "Module failed: " + m.id(), ex);
            }
        }

        PluginCommand cmd = getCommand("zentials");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("ZenTials v" + getPluginMeta().getVersion() + " by Jeremiah Alcantara (Niya) - " + modules.size() + " modules ready.");
    }

    /**
     * The login module used to be called "auth". Old config.yml files have "auth: true/false": rename that line to
     * "security" (same value) and move modules/auth/ to modules/security/ so nothing is lost. Then create the settings files.
     */
    private void prepareSecurityFiles() {
        try {
            File f = new File(getDataFolder(), "config.yml");
            if (!getConfig().contains("modules.security")) {
                String text = Files.readString(f.toPath());
                if (getConfig().contains("modules.auth")) {
                    text = text.replaceFirst("(?m)^([ \\t]+)auth:(?=[ \\t]*(true|false))", "$1security:");
                    getLogger().info("config.yml: 'modules.auth' is now called 'modules.security' (value kept).");
                } else {
                    String line = "  security: false    # login/register + safe waiting room for online-mode=false (cracked) servers, Java + Bedrock. OFF by default -> modules/security/";
                    text = text.replaceFirst("(?m)^modules:[ \\t]*\\r?\\n", "modules:\n" + java.util.regex.Matcher.quoteReplacement(line) + "\n");
                    getLogger().info("config.yml: added 'modules.security: false'. Set it to true to turn the login system on.");
                }
                Files.writeString(f.toPath(), text);
                reloadConfig();
            }
            File oldDir = new File(getDataFolder(), "modules/auth");
            File newDir = new File(getDataFolder(), "modules/security");
            if (oldDir.isDirectory() && !newDir.exists()) {
                if (oldDir.renameTo(newDir)) getLogger().info("Moved modules/auth/ to modules/security/.");
            }
            com.zentials.core.Cfg.yaml(this, "modules/security/config.yml");
            com.zentials.core.Cfg.yaml(this, "modules/security/messages.yml");
        } catch (Exception ex) {
            getLogger().log(Level.WARNING, "Could not prepare the Security files", ex);
        }
    }

    private void openDatabase() {
        try {
            File f = new File(getDataFolder(), "data/zentials.db");
            db = new Database(f, getLogger(),
                    getConfig().getInt("database.cache-mb", 64),
                    getConfig().getInt("database.mmap-mb", 512),
                    getConfig().getInt("database.batch-size", 2000),
                    getConfig().getInt("database.readers", 4));
            kv = new Kv(db, getConfig().getInt("database.kv-cache-entries", 100000));
            SkriptImport.prepare(db);
            getLogger().info("Database ready (SQLite, WAL mode): " + f.getName());
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Database failed to start. DB features are disabled.", ex);
            db = null;
            kv = null;
        }
    }

    @Override
    public void onDisable() {
        for (int i = modules.size() - 1; i >= 0; i--) {
            try {
                modules.get(i).disable();
            } catch (Exception ex) {
                getLogger().log(Level.SEVERE, "Module disable failed", ex);
            }
        }
        modules.clear();
        if (db != null) db.close();
        com.zentials.core.DataFile.shutdown();
    }

    // ---------------------------------------------------------------- /zentials

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (a.length > 1 && ryuu != null && !a[1].equalsIgnoreCase("all")) {
                    for (int i = 1; i < a.length; i++) Text.send(s, TAG + ryuu.reloadScript(a[i]));
                    return true;
                }
                reloadConfig();
                sfx.load();
                for (ZModule m : modules) {
                    try {
                        m.reload();
                    } catch (Exception ex) {
                        getLogger().log(Level.SEVERE, "Reload failed: " + m.id(), ex);
                    }
                }
                Text.send(s, TAG + "Reloaded.");
            }
            case "about", "info" -> {
                Text.send(s, "&8&m                                   ");
                Text.send(s, "&b&lZenTials &7v" + getPluginMeta().getVersion());
                Text.send(s, "&7Created by &fJeremiah Alcantara &8(&bNiya&8)");
                Text.send(s, "&7All-in-one core for SMP servers. All rights reserved.");
                Text.send(s, "&8&m                                   ");
            }
            case "db" -> dbCommand(s, a);
            case "import" -> importCommand(s, a);
            default -> {
                List<String> ids = new ArrayList<>();
                for (ZModule m : modules) ids.add(m.id());
                Text.send(s, TAG + "v" + getPluginMeta().getVersion() + " &8| &7Modules: &f" + ids
                        + " &8| &7DB: &f" + (db != null ? "online" : "offline"));
                Text.send(s, TAG + "&f/zt reload [script] &8| &f/zt about &8| &f/zt db &8| &f/zt import skript <file>");
            }
        }
        return true;
    }

    private static String mb(long bytes) {
        return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
    }

    private void dbCommand(CommandSender s, String[] a) {
        if (db == null) {
            Text.send(s, TAG + "&cDatabase is not running. Check the console.");
            return;
        }
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "status";
        switch (sub) {
            case "status" -> Text.send(s, TAG + "DB size: &f" + mb(db.fileSize()) + " &8| &7queued: &f" + db.queueSize()
                    + " &8| &7written: &f" + db.written.get() + " &8| &7batches: &f" + db.batches.get());
            case "get" -> {
                if (a.length < 4) {
                    Text.send(s, TAG + "&cUsage: /zentials db get <namespace> <key>");
                    return;
                }
                String v = kv.get(a[2], a[3]);
                Text.send(s, TAG + (v == null ? "&7(not set)" : "&f" + v));
            }
            case "list" -> {
                if (a.length < 3) {
                    Text.send(s, TAG + "&cUsage: /zentials db list <namespace> [prefix]");
                    return;
                }
                Map<String, String> m = kv.list(a[2], a.length > 3 ? a[3] : "", 20);
                if (m.isEmpty()) Text.send(s, TAG + "&7(nothing)");
                m.forEach((k, v) -> Text.send(s, "&8- &f" + k + " &8= &7" + v));
            }
            case "skript" -> {
                if (a.length < 3) {
                    Text.send(s, TAG + "&cUsage: /zentials db skript <variable name>");
                    return;
                }
                try {
                    String d = SkriptImport.describe(db, a[2]);
                    Text.send(s, TAG + (d == null ? "&7(not found)" : "&f" + d));
                } catch (Exception ex) {
                    Text.send(s, TAG + "&cQuery failed: " + ex.getMessage());
                }
            }
            default -> Text.send(s, TAG + "&cUsage: /zentials db status|get|list|skript");
        }
    }

    private void importCommand(CommandSender s, String[] a) {
        if (db == null) {
            Text.send(s, TAG + "&cDatabase is not running. Check the console.");
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("skript")) {
            Text.send(s, TAG + "&cUsage: /zentials import skript <file>  &7(file goes in plugins/ZenTials/import/)");
            return;
        }
        Path dir = new File(getDataFolder(), "import").toPath().toAbsolutePath().normalize();
        Path file = dir.resolve(a[2]).normalize();
        if (!file.startsWith(dir) || !Files.isRegularFile(file)) {
            Text.send(s, TAG + "&cFile not found in plugins/ZenTials/import/: &f" + a[2]);
            return;
        }
        Text.send(s, TAG + "Importing &f" + a[2] + "&7 in the background. Progress is in the console.");
        long start = System.currentTimeMillis();
        Bukkit.getAsyncScheduler().runNow(this, t -> {
            try {
                long n = SkriptImport.run(db, file,
                        done -> getLogger().info("Import: " + done + " variables so far..."));
                long sec = (System.currentTimeMillis() - start) / 1000;
                getLogger().info("Import finished: " + n + " variables in " + sec + "s.");
                Bukkit.getScheduler().runTask(this, () ->
                        Text.send(s, TAG + "&aImport finished: &f" + n + " &avariables in " + sec + "s."));
            } catch (Exception ex) {
                getLogger().log(Level.SEVERE, "Import failed", ex);
                Bukkit.getScheduler().runTask(this, () ->
                        Text.send(s, TAG + "&cImport failed: " + ex.getMessage()));
            }
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 1) return List.of("reload", "about", "db", "import");
        if (a.length >= 2 && a[0].equalsIgnoreCase("reload") && ryuu != null) {
            List<String> names = new ArrayList<>(ryuu.scriptNames());
            names.add("all");
            return names;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("db")) return List.of("status", "get", "list", "skript");
        if (a.length == 2 && a[0].equalsIgnoreCase("import")) return List.of("skript");
        return List.of();
    }
}
