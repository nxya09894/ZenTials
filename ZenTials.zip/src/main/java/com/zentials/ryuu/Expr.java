package com.zentials.ryuu;

@FunctionalInterface
interface Expr {
    Object eval(Ctx c);
}
