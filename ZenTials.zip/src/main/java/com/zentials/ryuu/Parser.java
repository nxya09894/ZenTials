package com.zentials.ryuu;

import com.zentials.core.Text;
import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns the text of a .ryu file into a Script. */
final class Parser {

    record Line(int no, int indent, String text, List<Line> kids) {
    }

    private interface LVal {
        Object get(Ctx c);

        void set(Ctx c, Object v);

        void del(Ctx c);
    }

    private static final Pattern LV = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)(?:\\[(.+)\\])?$");
    private static final Pattern IDENT = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");
    private static final Pattern OF_LV = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)\\s+of\\s+(.+)$");
    private static final Pattern META = Pattern.compile("^(permission message|permission-message|permission|aliases|alias|description|usage"
            + "|cooldown message|cooldown-message|cooldown|player-only|console-only|executable by)\\s*:\\s*(.*)$");
    private static final Set<String> BLOCK_WORDS = Set.of("if", "loop", "repeat", "while", "later", "open", "ask", "slot", "slots", "wait");
    private static final Set<String> OPTION_WORDS = Set.of("options", "settings", "config", "constants", "option");
    private static final String[] TOP_WORDS = {"options", "command", "on", "every", "function", "placeholder", "load", "unload"};

    private final Script script;

    Parser(String fileName) {
        this.script = new Script(fileName);
    }

    Script parse(String content) {
        if (content.startsWith("\uFEFF")) content = content.substring(1);
        for (Line l : tree(content)) top(l);
        return script;
    }

    // ---------------------------------------------------------------- text helpers

    private static RyuuException err(Line l, String msg) {
        return new RyuuException(l.no(), msg);
    }

    static List<Line> tree(String content) {
        List<Line> root = new ArrayList<>();
        Deque<Line> stack = new ArrayDeque<>();
        String[] raw = content.split("\r?\n", -1);
        for (int i = 0; i < raw.length; i++) {
            String s = stripComment(raw[i].replace("\t", "    "));
            if (s.isBlank()) continue;
            int indent = 0;
            while (indent < s.length() && s.charAt(indent) == ' ') indent++;
            Line l = new Line(i + 1, indent, s.trim(), new ArrayList<>());
            while (!stack.isEmpty() && stack.peek().indent() >= indent) stack.pop();
            if (stack.isEmpty()) root.add(l);
            else stack.peek().kids().add(l);
            stack.push(l);
        }
        return root;
    }

    static String stripComment(String s) {
        return Syntax.stripComment(s);
    }

    static String firstWord(String s) {
        return Syntax.firstWord(s);
    }

    /** Position of the word kw (surrounded by spaces) outside quotes and brackets, or -1. */
    static int findKw(String s, String kw, boolean last) {
        return Syntax.findKw(s, kw, last);
    }

    /** The line without its trailing colon. The colon may be left out when the block has lines under it. */
    private static String header(Line l) {
        String t = l.text();
        if (t.endsWith(":")) return t.substring(0, t.length() - 1).trim();
        if (!l.kids().isEmpty()) return t;
        throw err(l, "This line must end with ':'");
    }

    private static String colonRest(Line l, String rest) {
        if (rest.endsWith(":")) return rest.substring(0, rest.length() - 1).trim();
        if (!l.kids().isEmpty()) return rest;
        throw err(l, "This line must end with ':'");
    }

    private static String unquote(String s) {
        return Syntax.unquote(s);
    }

    private static long ticksOf(String unit, Line l) {
        long t = Syntax.unitTicks(unit);
        if (t < 0) throw err(l, "Unknown time unit '" + unit + "'. Use ticks, seconds, minutes, hours (or t, s, m, h)");
        return t;
    }

    private static Expr expr(String text, Line l) {
        if (text.isBlank()) throw err(l, "Something is missing here");
        return ExprParser.compile(text, l.no());
    }

    /** "a, b, c" written without brackets is a list. */
    private static Expr exprOrList(String text, Line l) {
        List<String> parts = Syntax.splitTop(text, ',');
        if (parts.size() < 2) return expr(text, l);
        List<Expr> items = new ArrayList<>();
        for (String p : parts) items.add(expr(p, l));
        return c -> {
            List<Object> out = new ArrayList<>(items.size());
            for (Expr e : items) out.add(e.eval(c));
            return out;
        };
    }

    // ---------------------------------------------------------------- top level

    /** First word of a block line, without a trailing colon: "options:" and "options" are the same block. */
    static String blockWord(String text) {
        return Syntax.blockWord(text);
    }

    private void top(Line l) {
        String w = blockWord(l.text()).toLowerCase(Locale.ROOT);
        switch (w) {
            case "options", "settings", "config", "constants", "option" -> options(l);
            case "command", "cmd" -> command(l);
            case "on" -> on(l);
            case "every" -> every(l);
            case "function", "fn", "def", "func", "define" -> function(l);
            case "placeholder" -> placeholder(l);
            case "load", "startup" -> script.onLoad.add(block(l.kids()));
            case "unload", "shutdown" -> script.onUnload.add(block(l.kids()));
            default -> {
                String near = Syntax.nearest(w, java.util.Arrays.asList(TOP_WORDS));
                throw err(l, "Unknown block '" + w + "'." + (near == null ? "" : " Did you mean '" + near + "'?")
                        + " A top-level line must start with: options, command, on, every, function, placeholder, load or unload"
                        + " (if this line belongs inside one of them, check its indentation)");
            }
        }
    }

    private void options(Line l) {
        String ot = l.text().endsWith(":") ? l.text().substring(0, l.text().length() - 1).trim() : l.text();
        if (!OPTION_WORDS.contains(ot.toLowerCase(Locale.ROOT))) throw err(l, "Write it like:  options:");
        Ctx c = new Ctx(script);
        for (Line k : l.kids()) {
            int i = k.text().indexOf(':');
            if (i <= 0) throw err(k, "Write it like:  name: value");
            String key = k.text().substring(0, i).trim();
            if (!IDENT.matcher(key).matches()) {
                throw err(k, "Option names can only use letters, numbers and _ (got '" + key + "')");
            }
            Expr e = exprOrList(k.text().substring(i + 1).trim(), k);
            try {
                script.opt.put(key, e.eval(c));
            } catch (RyuuException ex) {
                throw new RyuuException(k.no(), ex.getMessage());
            }
        }
    }

    private void command(Line l) {
        String h = header(l);
        List<String> parts = Syntax.splitWords(h);
        if (parts.size() < 2) {
            throw err(l, "Write it like:  command /name <required> [optional]:");
        }
        Script.CommandDef d = new Script.CommandDef();
        String nm = parts.get(1);
        d.name = (nm.startsWith("/") ? nm.substring(1) : nm).toLowerCase(Locale.ROOT);
        if (!d.name.matches("[a-z0-9_\\-]+")) throw err(l, "Bad command name '" + parts.get(1) + "'");
        d.line = l.no();
        d.stat = script.newStat("command /" + d.name + " (line " + l.no() + ")");
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (int i = 2; i < parts.size(); i++) {
            Syntax.Arg a = Syntax.parseArg(parts.get(i), i - 1);
            if (a == null) {
                throw err(l, "Bad argument '" + parts.get(i) + "'. Use <name>, [name], <name:type> or Skript style [<player>]");
            }
            String type = Syntax.canonType(a.type());
            if (type == null) {
                throw err(l, "Unknown argument type '" + a.type() + "'. Use text, word, number, int, player, offline player, world, boolean, "
                        + "or choices like [mode:on|off]");
            }
            if (!seen.add(a.name())) throw err(l, "The argument name '" + a.name() + "' is used twice");
            d.args.add(new Script.ArgSpec(a.name(), a.required(), type, a.rest()));
        }
        List<Line> code = new ArrayList<>();
        for (Line k : l.kids()) {
            Matcher m = META.matcher(k.text());
            if (m.matches()) meta(d, m.group(1), m.group(2).trim(), k);
            else if (k.text().equals("trigger:") || k.text().equals("trigger")) code.addAll(k.kids()); // Skript style: code under "trigger:"
            else code.add(k);
        }
        d.body = block(code);
        script.commands.add(d);
    }

    private static boolean yes(String v) {
        String s = unquote(v).toLowerCase(Locale.ROOT);
        return s.equals("true") || s.equals("yes") || s.equals("on");
    }

    private void meta(Script.CommandDef d, String key, String val, Line k) {
        switch (key) {
            case "permission" -> d.permission = unquote(val);
            case "description" -> d.description = unquote(val);
            case "usage" -> d.usage = unquote(val);
            case "player-only" -> d.playerOnly = yes(val);
            case "console-only" -> {
                // accepted: a console-only flag is not needed, scripts check sender themselves
            }
            case "executable by" -> d.playerOnly = val.toLowerCase(Locale.ROOT).startsWith("player");
            case "permission message", "permission-message" -> d.permMessage = unquote(val);
            case "cooldown message", "cooldown-message" -> d.cooldownMessage = unquote(val);
            case "cooldown" -> {
                String v = unquote(val);
                if (v.matches("\\d+")) {
                    d.cooldownSeconds = Integer.parseInt(v);
                } else {
                    Syntax.Dur dur = Syntax.duration(v);
                    if (dur == null || !dur.amount().matches("\\d+(\\.\\d+)?")) {
                        throw err(k, "cooldown must be a time like:  cooldown: 5 seconds   (or 30s, 2 minutes, 1 hour)");
                    }
                    d.cooldownSeconds = (int) Math.max(1, Math.ceil(Double.parseDouble(dur.amount()) * dur.ticks() / 20.0));
                }
            }
            default -> {
                for (String a : val.split(",")) {
                    String n = unquote(a.trim()).toLowerCase(Locale.ROOT);
                    if (!n.isEmpty()) d.aliases.add(n.startsWith("/") ? n.substring(1) : n);
                }
            }
        }
    }

    private void on(Line l) {
        String h = header(l);
        if (!blockWord(h).equalsIgnoreCase("on")) throw err(l, "Write it like:  on join:");
        String rawEv = h.substring(2).trim();
        if (rawEv.isEmpty()) throw err(l, "Write it like:  on join:");
        // on event org.bukkit.event.player.PlayerFishEvent:   (full class name, case matters)
        if (rawEv.toLowerCase(Locale.ROOT).startsWith("event ")) {
            String cls = rawEv.substring(6).trim();
            EventDefs.Def generic = EventDefs.resolve(cls);
            if (generic == null) throw err(l, "There is no event class '" + cls + "'");
            EventDefs.ALL.putIfAbsent(cls, generic);
            addEvent(l, cls, EventDefs.ALL.get(cls), null, null, block(l.kids()));
            return;
        }
        Syntax.EventHeader eh = Syntax.eventHeader(rawEv);
        if (eh.names().isEmpty()) throw err(l, "Write it like:  on join:");
        Stmt[] body = block(l.kids());
        for (String name : eh.names()) {
            Syntax.Canon cn = Syntax.canon(name);
            String ev = cn.event();
            if (ev.equals("load")) {
                script.onLoad.add(body);
                continue;
            }
            if (ev.equals("unload")) {
                script.onUnload.add(body);
                continue;
            }
            EventDefs.Def def = EventDefs.ALL.get(ev);
            if (def == null) {
                def = EventDefs.resolve(ev);
                if (def == null) {
                    List<String> known = new ArrayList<>(EventDefs.ALL.keySet());
                    for (String s : Syntax.eventNames()) known.add(s);
                    String near = Syntax.nearest(name, known);
                    throw err(l, "Unknown event '" + name + "'." + (near == null ? "" : " Did you mean '" + near + "'?")
                            + " Short names: load, unload, " + String.join(", ", EventDefs.ALL.keySet())
                            + ". Any Bukkit event also works by name, e.g.  on player fish:  or  on block form:");
                }
                EventDefs.ALL.put(ev, def);
            }
            List<String> values = eh.values().isEmpty() ? cn.values() : eh.values();
            addEvent(l, ev, def, eh, values, body);
        }
    }

    private void addEvent(Line l, String ev, EventDefs.Def def, Syntax.EventHeader eh, List<String> values, Stmt[] body) {
        Script.EventDef d = new Script.EventDef();
        d.event = ev;
        d.line = l.no();
        d.body = body;
        d.stat = script.newStat("on " + ev + " (line " + l.no() + ")");
        if (eh != null) {
            d.priority = eh.priority();
            d.ignoreCancelled = eh.ignoreCancelled();
        }
        if (values != null && !values.isEmpty()) {
            boolean containing = (eh != null && "containing".equals(eh.connector())) || (def.keys() == null && def.text() != null);
            if (containing) {
                if (def.text() == null) throw err(l, "'on " + ev + " containing ...' only works for chat and command events");
                d.containing = values.stream().map(v -> v.toLowerCase(Locale.ROOT)).toArray(String[]::new);
            } else {
                if (def.keys() == null) {
                    throw err(l, "The event '" + ev + "' has nothing to filter on. Use  if ...:  inside the block instead");
                }
                List<String> exact = new ArrayList<>();
                List<Pattern> globs = new ArrayList<>();
                for (String v : values) {
                    String n = EventDefs.norm(v);
                    if (n.contains("*")) globs.add(Pattern.compile(Pattern.quote(n).replace("*", "\\E.*\\Q")));
                    else exact.add(n);
                }
                d.exact = exact.toArray(new String[0]);
                d.globs = globs.toArray(new Pattern[0]);
            }
        }
        script.events.add(d);
    }

    private void every(Line l) {
        String rest = header(l).substring(5).trim();
        Syntax.Dur dur = Syntax.duration(rest);
        if (dur == null) throw err(l, "Write it like:  every 5 seconds:   (also: every second, every 2 minutes, every 30s, every 1 hour)");
        Script.TimerDef d = new Script.TimerDef();
        d.period = expr(dur.amount(), l);
        d.unitTicks = dur.ticks();
        d.line = l.no();
        d.stat = script.newStat("every " + rest + " (line " + l.no() + ")");
        d.body = block(l.kids());
        script.timers.add(d);
    }

    /**
     * placeholder name:  ->  %ryu_name% (and %ryu_name_anything%, the rest arrives as "params").
     * placeholder top cache 10 seconds global:  keeps the answer for 10 s for everybody (fast for scoreboards and tab).
     * placeholder rank cache 5 seconds:  keeps the answer for 5 s per player.
     */
    private void placeholder(Line l) {
        String h = header(l).substring("placeholder".length()).trim();
        String name = Parser.firstWord(h).toLowerCase(Locale.ROOT);
        String opts = h.substring(name.length()).trim();
        if (!name.matches("[a-z0-9_]+")) throw err(l, "Write it like:  placeholder profession:   or   placeholder top cache 10 seconds global:");
        if (script.placeholders.containsKey(name)) throw err(l, "Placeholder '" + name + "' is already defined in this file");
        Script.PlaceholderDef pd = new Script.PlaceholderDef();
        if (!opts.isEmpty()) {
            String o = opts;
            if (o.toLowerCase(Locale.ROOT).endsWith(" global")) {
                pd.global = true;
                o = o.substring(0, o.length() - 7).trim();
            } else if (o.toLowerCase(Locale.ROOT).endsWith(" per player")) {
                o = o.substring(0, o.length() - 11).trim();
            }
            if (o.toLowerCase(Locale.ROOT).startsWith("cache ")) o = o.substring(6).trim();
            Syntax.Dur dur = Syntax.duration(o);
            if (dur == null || !dur.amount().matches("\\d+(\\.\\d+)?")) {
                throw err(l, "Write it like:  placeholder " + name + " cache 10 seconds global:");
            }
            pd.cacheMs = (long) (Double.parseDouble(dur.amount()) * dur.ticks() * 50L);
        }
        pd.stat = script.newStat("placeholder %ryu_" + name + "% (line " + l.no() + ")");
        pd.body = block(l.kids());
        script.placeholders.put(name, pd);
    }

    private void function(Line l) {
        String h = header(l);
        Syntax.FuncHeader fh = Syntax.funcHeader(h);
        if (fh == null) throw err(l, "Write it like:  function name(a, b):   (defaults too:  function name(a, b = 5):)");
        Script.FuncDef f = new Script.FuncDef();
        f.name = fh.name();
        f.script = script;
        f.line = l.no();
        for (Syntax.Param p : fh.params()) {
            if (f.params.contains(p.name())) throw err(l, "Parameter '" + p.name() + "' is used twice");
            f.params.add(p.name());
            f.defaults.add(p.defaultText() == null ? null : expr(p.defaultText(), l));
        }
        if (script.functions.containsKey(f.name)) throw err(l, "Function '" + f.name + "' is already defined in this file");
        f.body = block(l.kids());
        script.functions.put(f.name, f);
    }

    // ---------------------------------------------------------------- blocks and statements

    private record Branch(Expr cond, Stmt[] body) {
    }

    private Line canonical(Line l) {
        String al = Syntax.aliasOf(l.text());
        if (al != null) {
            String w = Syntax.blockWord(l.text());
            l = new Line(l.no(), l.indent(), al + l.text().substring(w.length()), l.kids());
        }
        // one-line loops:  loop p in list: send "x"      repeat 3 times: stop      while x < 5: x++      later 1s: stop
        String w = Syntax.blockWord(l.text()).toLowerCase(Locale.ROOT);
        if (l.kids().isEmpty() && (w.equals("loop") || w.equals("repeat") || w.equals("while") || w.equals("later"))) {
            String rest = l.text().substring(w.length()).trim();
            String[] in = Syntax.inlineSplit(rest);
            if (in != null) {
                List<Line> kid = new ArrayList<>();
                kid.add(new Line(l.no(), l.indent() + 4, in[1], new ArrayList<>()));
                return new Line(l.no(), l.indent(), w + " " + in[0] + ":", kid);
            }
        }
        return l;
    }

    /** One line of code written after a colon ("if x: stop") as a block of its own. */
    private Stmt[] inlineBlock(Line l, String code) {
        if (!l.kids().isEmpty()) throw err(l, "Write the code either on the same line after ':' or indented below, not both");
        List<Line> one = new ArrayList<>();
        one.add(new Line(l.no(), l.indent() + 4, code, new ArrayList<>()));
        return block(one);
    }

    /** tail = what follows "if" / "else if" (condition, then ':' and maybe the code on the same line). */
    private Branch branch(Line l, String tail, boolean unless) {
        String[] in = Syntax.inlineSplit(tail);
        String condText;
        Stmt[] body;
        if (in != null) {
            condText = in[0];
            body = inlineBlock(l, in[1]);
        } else {
            condText = colonRest(l, tail);
            body = block(l.kids());
        }
        Expr cond = expr(condText, l);
        if (unless) {
            final Expr inner = cond;
            cond = c -> !Values.truthy(inner.eval(c));   // "unless x" = "if not x"
        }
        return new Branch(cond, body);
    }

    private Stmt[] block(List<Line> lines) {
        List<Stmt> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            Line l = canonical(lines.get(i));
            String w = firstWord(l.text()).toLowerCase(Locale.ROOT);
            if (w.equals("if") || w.equals("unless") || w.equals("if:")) {
                List<Expr> conds = new ArrayList<>();
                List<Stmt[]> bodies = new ArrayList<>();
                Stmt[] elseBody = null;
                Branch first = branch(l, l.text().substring(w.length()).trim(), w.equals("unless"));
                conds.add(first.cond());
                bodies.add(first.body());
                while (i + 1 < lines.size()) {
                    Line n = lines.get(i + 1);
                    Syntax.ElseInfo ei = Syntax.elseInfo(n.text());
                    if (ei == null) break;
                    i++;
                    if (ei.isIf()) {
                        Branch br = branch(n, ei.tail(), ei.unless());
                        conds.add(br.cond());
                        bodies.add(br.body());
                    } else {
                        String tail = ei.tail();
                        String code = tail.startsWith(":") ? tail.substring(1).trim() : "";
                        if (!code.isEmpty()) elseBody = inlineBlock(n, code);
                        else if (tail.startsWith(":") || !n.kids().isEmpty()) elseBody = block(n.kids());
                        else throw err(n, "This line must end with ':'");
                        break;
                    }
                }
                final Stmt[] eb = elseBody;
                final Expr[] ce = conds.toArray(new Expr[0]);
                final Stmt[][] be = bodies.toArray(new Stmt[0][]);
                Stmt ifs = c -> {
                    for (int k = 0; k < ce.length; k++) {
                        if (Values.truthy(ce[k].eval(c))) return Run.block(be[k], c);
                    }
                    return eb == null ? Run.NORMAL : Run.block(eb, c);
                };
                out.add(located(l.no(), ifs));
            } else if (Syntax.elseInfo(l.text()) != null) {
                throw err(l, "'else' needs an 'if' right above it");
            } else if (w.equals("wait") && l.kids().isEmpty()) {
                // Skript style:  wait 5 seconds  -> the rest of this block runs after the delay
                List<Line> rest = new ArrayList<>();
                for (int k = i + 1; k < lines.size(); k++) rest.add(lines.get(k));
                out.add(waitStmt(l, rest));
                break;
            } else {
                out.add(stmt(l));
            }
        }
        return out.toArray(new Stmt[0]);
    }

    private static Stmt located(int line, Stmt s) {
        return c -> {
            try {
                return s.run(c);
            } catch (RyuuException e) {
                if (e.line() > 0) throw e;
                throw new RyuuException(line, e.getMessage());
            } catch (RuntimeException e) {
                throw new RyuuException(line, e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        };
    }

    private static final String[] KEYWORDS = {"set", "add", "remove", "delete", "if", "unless", "else", "loop", "repeat", "while",
            "break", "continue", "stop", "cancel", "return", "send", "message", "broadcast", "console", "log", "later", "wait",
            "ask", "open", "slot", "slots", "fill", "uncancel", "pass"};

    /** Closest statement name for a typo (edit distance 2 or less), or null. */
    private static String nearest(String word) {
        return Syntax.nearest(word, java.util.Arrays.asList(KEYWORDS));
    }

    private Stmt stmt(Line l0) {
        // friendly spellings (x = 5, x++, teleport p to loc, give 5 DIAMOND to p ...) become the canonical statement
        String rewritten = Syntax.rewrite(l0.text());
        Line l = rewritten.equals(l0.text()) ? l0 : new Line(l0.no(), l0.indent(), rewritten, l0.kids());
        String t = l.text();
        String w = firstWord(t);
        String lw = w.toLowerCase(Locale.ROOT);
        String rest = t.substring(w.length()).trim();
        if (!l.kids().isEmpty() && !BLOCK_WORDS.contains(lw)) {
            throw err(l, "Lines indented under this line are not allowed here");
        }
        Stmt s;
        switch (lw) {
            case "set" -> s = set(l, rest);
            case "add" -> s = addRemove(l, rest, true);
            case "remove" -> s = addRemove(l, rest, false);
            case "delete" -> s = delete(l, rest);
            case "loop" -> s = loop(l, rest);
            case "repeat" -> s = repeat(l, rest);
            case "while" -> s = whileStmt(l, rest);
            case "break" -> s = c -> Run.BREAK;
            case "continue" -> s = c -> Run.CONTINUE;
            case "stop" -> s = c -> Run.STOP;
            case "cancel" -> s = c -> {
                c.cancel = true;
                return Run.NORMAL;
            };
            case "return" -> s = returnStmt(l, rest);
            case "send", "message" -> s = send(l, rest);
            case "broadcast" -> s = broadcast(l, rest);
            case "console" -> s = console(l, rest);
            case "log" -> s = log(l, rest);
            case "later" -> s = later(l, rest);
            case "open" -> s = openGui(l, rest);
            case "ask" -> s = ask(l, rest);
            case "slot", "slots" -> s = slot(l, rest);
            case "wait" -> s = later(l, rest);
            case "uncancel" -> s = c -> {
                c.uncancel = true;
                return Run.NORMAL;
            };
            case "pass" -> s = c -> Run.NORMAL;
            case "fill" -> s = fill(l, rest);
            default -> {
                if (t.indexOf('(') < 0 && t.indexOf('.') < 0 && t.indexOf('[') < 0 && IDENT.matcher(w).matches()) {
                    String near = nearest(lw);
                    throw err(l, "Unknown statement '" + w + "'" + (near == null ? "." : ". Did you mean '" + near + "'?")
                            + " Statements: set add remove delete if unless else loop repeat while break continue stop cancel return send broadcast console log later wait ask open slot fill"
                            + " (also: x = 5, x += 1, x++, let x = 5, for ... in ..., print, msg, teleport, give, kick, title, actionbar)");
                }
                Expr e = expr(t, l);
                s = c -> {
                    e.eval(c);
                    return Run.NORMAL;
                };
            }
        }
        return located(l.no(), s);
    }

    // ---------------------------------------------------------------- variables

    private static int matchOpen(String s) {
        int depth = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char ch = s.charAt(i);
            if (ch == ']') depth++;
            else if (ch == '[') {
                depth--;
                if (depth == 0) return i;
            }
        }
        return -1;
    }

    private static int lastTopDot(String s) {
        int depth = 0;
        boolean inQ = false;
        char q = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char ch = s.charAt(i);
            if (ch == ')' || ch == ']') depth++;
            else if (ch == '(' || ch == '[') depth--;
            else if (ch == '.' && depth == 0) return i;
        }
        return -1;
    }

    /** Sets index/key of a list or map (shared by name[idx] and expr[idx]). */
    @SuppressWarnings("unchecked")
    private static void putIndex(Object cont, Object key, Object v, String what) {
        if (cont instanceof List<?> list) {
            List<Object> lo = (List<Object>) list;
            int i = Values.intv(key);
            if (i == lo.size()) lo.add(v);
            else if (i >= 0 && i < lo.size()) lo.set(i, v);
            else throw new RyuuException(0, "List index " + i + " is out of range (size " + lo.size() + ")");
        } else if (cont instanceof Map<?, ?> map) {
            ((Map<String, Object>) map).put(Values.str(key), v);
        } else {
            throw new RyuuException(0, "'" + what + "' is not a list or map");
        }
    }

    /** a property of something: player.health, health of player, m.key, data.list[1] */
    private LVal propLval(Expr target, String prop) {
        final String setter = "set" + Character.toUpperCase(prop.charAt(0)) + prop.substring(1);
        return new LVal() {
            @Override
            public Object get(Ctx c) {
                return Access.get(target.eval(c), prop);
            }

            @Override
            @SuppressWarnings("unchecked")
            public void set(Ctx c, Object v) {
                Object t = target.eval(c);
                if (t instanceof Map<?, ?> m) ((Map<String, Object>) m).put(prop, v);
                else Access.call(t, setter.toLowerCase(Locale.ROOT), new ArrayList<>(java.util.Collections.singletonList(v)), c);
            }

            @Override
            public void del(Ctx c) {
                if (target.eval(c) instanceof Map<?, ?> m) m.remove(prop);
                else throw new RyuuException(0, "Can only delete a key of a map");
            }
        };
    }

    private LVal lval(String text, Line l) {
        String s = text.trim();
        Matcher m = LV.matcher(s);
        boolean simple = IDENT.matcher(s).matches();
        boolean indexed = !simple && m.matches() && m.group(2) != null && matchOpen(s) == m.group(1).length();
        if (simple || indexed) {
            String name = simple ? s : m.group(1);
            Expr idx = indexed ? expr(m.group(2), l) : null;
            if (idx == null) {
                return new LVal() {
                    @Override
                    public Object get(Ctx c) {
                        return c.vars.get(name);
                    }

                    @Override
                    public void set(Ctx c, Object v) {
                        c.vars.put(name, v);
                    }

                    @Override
                    public void del(Ctx c) {
                        c.vars.remove(name);
                    }
                };
            }
            return new LVal() {
                @Override
                public Object get(Ctx c) {
                    return Access.index(c.vars.get(name), idx.eval(c));
                }

                @Override
                public void set(Ctx c, Object v) {
                    Object cont = c.vars.get(name);
                    Object key = idx.eval(c);
                    if (cont == null) {
                        Map<String, Object> created = new java.util.LinkedHashMap<>();
                        created.put(Values.str(key), v);
                        c.vars.put(name, created);
                    } else {
                        putIndex(cont, key, v, name);
                    }
                }

                @Override
                @SuppressWarnings("unchecked")
                public void del(Ctx c) {
                    Object cont = c.vars.get(name);
                    Object key = idx.eval(c);
                    if (cont instanceof List<?> list) {
                        int i = Values.intv(key);
                        if (i >= 0 && i < list.size()) ((List<Object>) list).remove(i);
                    } else if (cont instanceof Map<?, ?> map) {
                        map.remove(Values.str(key));
                    }
                }
            };
        }
        // health of player
        Matcher of = OF_LV.matcher(s);
        if (of.matches()) return propLval(expr(of.group(2), l), of.group(1));
        // something[idx] on a longer expression: data.list[2]
        if (s.endsWith("]")) {
            int open = matchOpen(s);
            if (open > 0) {
                Expr base = expr(s.substring(0, open), l);
                Expr idx = expr(s.substring(open + 1, s.length() - 1), l);
                String label = s.substring(0, open);
                return new LVal() {
                    @Override
                    public Object get(Ctx c) {
                        return Access.index(base.eval(c), idx.eval(c));
                    }

                    @Override
                    public void set(Ctx c, Object v) {
                        putIndex(base.eval(c), idx.eval(c), v, label);
                    }

                    @Override
                    @SuppressWarnings("unchecked")
                    public void del(Ctx c) {
                        Object cont = base.eval(c);
                        Object key = idx.eval(c);
                        if (cont instanceof List<?> list) {
                            int i = Values.intv(key);
                            if (i >= 0 && i < list.size()) ((List<Object>) list).remove(i);
                        } else if (cont instanceof Map<?, ?> map) {
                            map.remove(Values.str(key));
                        }
                    }
                };
            }
        }
        int dot = lastTopDot(s);
        if (dot > 0 && dot < s.length() - 1 && IDENT.matcher(s.substring(dot + 1)).matches()) {
            return propLval(expr(s.substring(0, dot), l), s.substring(dot + 1));
        }
        throw err(l, "Cannot assign to '" + text + "'. Use a variable name, name[index], thing.property or  property of thing");
    }

    private Stmt set(Line l, String rest) {
        int k = findKw(rest, "to", false);
        if (k < 0) throw err(l, "Write it like:  set name to value     (or  name = value)");
        LVal lv = lval(rest.substring(0, k).trim(), l);
        Expr e = exprOrList(rest.substring(k + 2).trim(), l);
        return c -> {
            lv.set(c, e.eval(c));
            return Run.NORMAL;
        };
    }

    private Stmt addRemove(Line l, String rest, boolean add) {
        String kw = add ? "to" : "from";
        int k = findKw(rest, kw, true);
        if (k < 0) throw err(l, "Write it like:  " + (add ? "add 5 to name" : "remove 5 from name"));
        Expr e = expr(rest.substring(0, k).trim(), l);
        LVal lv = lval(rest.substring(k + kw.length()).trim(), l);
        return c -> {
            Object cur = lv.get(c);
            Object v = e.eval(c);
            lv.set(c, add ? Values.plus(cur, v) : Values.minus(cur, v));
            return Run.NORMAL;
        };
    }

    private Stmt delete(Line l, String rest) {
        LVal lv = lval(rest.trim(), l);
        return c -> {
            lv.del(c);
            return Run.NORMAL;
        };
    }

    // ---------------------------------------------------------------- control flow

    private static List<Object> items(Object o) {
        if (o == null) return List.of();
        if (o instanceof Map<?, ?> m) return new ArrayList<>(m.keySet());
        if (o instanceof Collection<?> col) return new ArrayList<>(col);
        if (o instanceof Number n) {
            List<Object> out = new ArrayList<>();
            int max = (int) n.doubleValue();
            for (int i = 1; i <= max; i++) out.add((double) i);
            return out;
        }
        throw new RyuuException(0, "Cannot loop over " + Values.typeName(o));
    }

    private Stmt loop(Line l, String rest) {
        String h = colonRest(l, rest);
        if (h.toLowerCase(Locale.ROOT).startsWith("each ")) h = h.substring(5).trim();
        if (h.endsWith(" times") || h.endsWith(" time")) return repeatBody(l, h);
        // loop i from 1 to 10 [step 2]:
        int kFrom = findKw(h, "from", false);
        if (kFrom > 0 && IDENT.matcher(h.substring(0, kFrom).trim()).matches()) {
            String varName = h.substring(0, kFrom).trim();
            String after = h.substring(kFrom + 4).trim();
            int kTo = findKw(after, "to", false);
            if (kTo < 0) throw err(l, "Write it like:  loop i from 1 to 10:");
            String toPart = after.substring(kTo + 2).trim();
            int kStep = findKw(toPart, "step", false);
            Expr from = expr(after.substring(0, kTo).trim(), l);
            Expr to = expr(kStep < 0 ? toPart : toPart.substring(0, kStep).trim(), l);
            Expr step = kStep < 0 ? null : expr(toPart.substring(kStep + 4).trim(), l);
            Stmt[] body = block(l.kids());
            return c -> {
                double a = Values.num(from.eval(c));
                double b = Values.num(to.eval(c));
                double st = step == null ? (a <= b ? 1 : -1) : Values.num(step.eval(c));
                if (st == 0) throw new RyuuException(0, "loop step cannot be 0");
                for (double v = a; st > 0 ? v <= b : v >= b; v += st) {
                    c.step();
                    c.vars.put(varName, v);
                    int r = Run.block(body, c);
                    if (r == Run.BREAK) break;
                    if (r == Run.CONTINUE) continue;
                    if (r != Run.NORMAL) return r;
                }
                return Run.NORMAL;
            };
        }
        // loop item in list:   (or just  loop list:  with the item called "value")
        int k = findKw(h, "in", false);
        String varName = "value";
        String srcText = h;
        if (k > 0 && IDENT.matcher(h.substring(0, k).trim()).matches()) {
            varName = h.substring(0, k).trim();
            srcText = h.substring(k + 2).trim();
        }
        final String vn = varName;
        Expr src = exprOrList(srcText, l);
        Stmt[] body = block(l.kids());
        return c -> {
            for (Object it : items(src.eval(c))) {
                c.step();
                c.vars.put(vn, it);
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt repeat(Line l, String rest) {
        return repeatBody(l, colonRest(l, rest));
    }

    /** repeat 5 times | repeat 5 | loop 5 times */
    private Stmt repeatBody(Line l, String h) {
        String cnt = h;
        if (h.endsWith(" times")) cnt = h.substring(0, h.length() - 6).trim();
        else if (h.endsWith(" time")) cnt = h.substring(0, h.length() - 5).trim();
        Expr n = expr(cnt, l);
        Stmt[] body = block(l.kids());
        return c -> {
            int count = Values.intv(n.eval(c));
            for (int i = 1; i <= count; i++) {
                c.step();
                c.vars.put("i", (double) i);
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt whileStmt(Line l, String rest) {
        Expr cond = expr(colonRest(l, rest), l);
        Stmt[] body = block(l.kids());
        return c -> {
            while (Values.truthy(cond.eval(c))) {
                c.step();
                int r = Run.block(body, c);
                if (r == Run.BREAK) break;
                if (r == Run.CONTINUE) continue;
                if (r != Run.NORMAL) return r;
            }
            return Run.NORMAL;
        };
    }

    private Stmt returnStmt(Line l, String rest) {
        if (rest.isEmpty()) {
            return c -> {
                c.ret = null;
                return Run.RETURN;
            };
        }
        Expr e = expr(rest, l);
        return c -> {
            c.ret = e.eval(c);
            return Run.RETURN;
        };
    }

    // ---------------------------------------------------------------- output

    private Stmt send(Line l, String rest) {
        int k = findKw(rest, "to", true);
        Expr msg = expr(k < 0 ? rest : rest.substring(0, k).trim(), l);
        Expr to = k < 0 ? null : expr(rest.substring(k + 2).trim(), l);
        return c -> {
            String m = Values.str(msg.eval(c));
            Values.deliver(to == null ? c.sender : to.eval(c), m);
            return Run.NORMAL;
        };
    }

    private Stmt broadcast(Line l, String rest) {
        Expr msg = expr(rest, l);
        return c -> {
            Bukkit.broadcast(Text.c(Values.str(msg.eval(c))));
            return Run.NORMAL;
        };
    }

    private Stmt console(Line l, String rest) {
        Expr cmd = expr(rest, l);
        return c -> {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Values.str(cmd.eval(c)));
            return Run.NORMAL;
        };
    }

    private Stmt log(Line l, String rest) {
        Expr msg = expr(rest, l);
        return c -> {
            RyuuModule.log(c.script.name, Values.str(msg.eval(c)));
            return Run.NORMAL;
        };
    }

    private Stmt waitStmt(Line l, List<Line> remaining) {
        String rest = l.text().substring(4).trim();
        Syntax.Dur dur = Syntax.duration(rest);
        if (dur == null) throw err(l, "Write it like:  wait 5 seconds     (also 5s, 2 minutes, 1 hour 30 minutes)");
        return delayed(l, dur, block(new ArrayList<>(remaining)));
    }

    private Stmt later(Line l, String rest) {
        String h = colonRest(l, rest);
        Syntax.Dur dur = Syntax.duration(h);
        if (dur == null) throw err(l, "Write it like:  later 5 seconds:     (also 5s, 2 minutes, 1 hour 30 minutes)");
        return delayed(l, dur, block(l.kids()));
    }

    private Stmt delayed(Line l, Syntax.Dur dur, Stmt[] body) {
        Expr n = expr(dur.amount(), l);
        long unit = dur.ticks();
        final int ln = l.no();
        return c -> {
            long ticks = Math.max(1, (long) (Values.num(n.eval(c)) * unit));
            Map<String, Object> snap = new HashMap<>(c.vars);
            Script sc = c.script;
            CommandSender snd = c.sender;
            Bukkit.getScheduler().runTaskLater(RyuuModule.plugin(), () -> {
                Ctx cc = new Ctx(sc, new HashMap<>(snap));
                cc.sender = snd;
                RyuuModule.safeRun(sc, ln, body, cc);
            }, ticks);
            return Run.NORMAL;
        };
    }

    // ---------------------------------------------------------------- GUI and chat input

    private Stmt openGui(Line l, String rest) {
        String lr = rest.toLowerCase(Locale.ROOT);
        String kind = null;
        for (String k : new String[]{"gui ", "menu ", "inventory ", "chest "}) if (lr.startsWith(k)) kind = k;
        if (kind == null) throw err(l, "Write it like:  open gui \"Title\" rows 3:");
        String h = colonRest(l, rest.substring(kind.length()).trim());
        Expr forE = null;
        int kf = findKw(h, "for", true);
        if (kf > 0) {
            forE = expr(h.substring(kf + 3).trim(), l);
            h = h.substring(0, kf).trim();
        }
        Expr title;
        Expr rows;
        int kr = findKw(h, "rows", false);
        int kz = findKw(h, "size", false);
        if (kr >= 0) {                          // "Title" rows 3
            title = expr(h.substring(0, kr).trim(), l);
            rows = expr(h.substring(kr + 4).trim(), l);
        } else if (h.endsWith(" rows") || h.endsWith(" row")) {   // "Title" 3 rows
            String body = h.substring(0, h.lastIndexOf(' ')).trim();
            int sp = body.lastIndexOf(' ');
            if (sp < 0) throw err(l, "Write it like:  open gui \"Title\" 3 rows:");
            title = expr(body.substring(0, sp).trim(), l);
            rows = expr(body.substring(sp + 1).trim(), l);
        } else if (kz >= 0) {                   // "Title" size 27
            title = expr(h.substring(0, kz).trim(), l);
            Expr size = expr(h.substring(kz + 4).trim(), l);
            rows = c -> Math.ceil(Values.num(size.eval(c)) / 9.0);
        } else {
            throw err(l, "Missing 'rows'. Example:  open gui \"Title\" rows 3:   (or  \"Title\" 3 rows  or  \"Title\" size 27)");
        }
        final Expr fForE = forE;
        Stmt[] body = block(l.kids());
        return c -> {
            Player p = fForE == null ? c.player() : Values.player(fForE.eval(c));
            if (p == null) throw new RyuuException(0, "open gui: there is no player to show it to");
            int r = Math.max(1, Math.min(6, Values.intv(rows.eval(c))));
            GuiBuild gb = new GuiBuild(new Gui(Text.c(Values.str(title.eval(c))), r), r);
            GuiBuild prev = c.gui;
            c.gui = gb;
            try {
                Run.block(body, c);
            } finally {
                c.gui = prev;
            }
            gb.finish();
            gb.gui.open(p);
            return Run.NORMAL;
        };
    }

    /**
     * slot 11 item EMERALD name "Buy" lore ["a"] glow:      also:  named / material / with / head
     * slots 0..8 item GRAY_STAINED_GLASS_PANE name " "       (a list or range of slots gets the same item)
     */
    private Stmt slot(Line l, String rest) {
        boolean hasBody = !l.kids().isEmpty();
        String h = rest.endsWith(":") ? rest.substring(0, rest.length() - 1).trim() : rest;
        boolean glow = false;
        if (h.endsWith(" glow")) {
            glow = true;
            h = h.substring(0, h.length() - 5).trim();
        }
        int[] iItem = Syntax.findAny(h, "item", "material", "with");
        int[] iHead = Syntax.findAny(h, "head");
        boolean head = iItem == null;
        int[] type = head ? iHead : iItem;
        if (type == null) throw err(l, "slot needs 'item' or 'head'. Example:  slot 10 item EMERALD name \"Hi\":");
        List<int[]> ks = new ArrayList<>();
        ks.add(new int[]{type[0], 0, type[1]});
        int[] iName = Syntax.findAny(h, "named", "name");
        int[] iLore = Syntax.findAny(h, "lore", "description");
        if (iName != null) ks.add(new int[]{iName[0], 1, iName[1]});
        if (iLore != null) ks.add(new int[]{iLore[0], 2, iLore[1]});
        ks.sort(Comparator.comparingInt(a -> a[0]));
        Expr slotE = expr(h.substring(0, ks.get(0)[0]).trim(), l);
        String[] seg = new String[3];
        for (int i = 0; i < ks.size(); i++) {
            int start = ks.get(i)[0];
            int end = i + 1 < ks.size() ? ks.get(i + 1)[0] : h.length();
            seg[ks.get(i)[1]] = h.substring(start + ks.get(i)[2], end).trim();
        }
        Expr itemE = expr(seg[0], l);
        Expr nameE = seg[1] == null ? null : expr(seg[1], l);
        Expr loreE = seg[2] == null ? null : expr(seg[2], l);
        Stmt[] click = hasBody ? block(l.kids()) : null;
        final boolean fHead = head;
        final boolean fGlow = glow;
        final int ln = l.no();
        return c -> {
            if (c.gui == null) throw new RyuuException(0, "'slot' can only be used inside 'open gui'");
            Object sv = slotE.eval(c);
            Object itemV = itemE.eval(c);
            String[] lore = new String[0];
            if (loreE != null) {
                Object lv = loreE.eval(c);
                if (lv instanceof List<?> ll) {
                    lore = new String[ll.size()];
                    for (int i = 0; i < ll.size(); i++) lore[i] = Values.str(ll.get(i));
                } else if (lv != null) {
                    lore = new String[]{Values.str(lv)};
                }
            }
            ItemStack it;
            if (fHead) {
                OfflinePlayer op = offline(itemV);
                String nm = nameE == null ? "&f" + Values.str(itemV) : Values.str(nameE.eval(c));
                it = op == null ? Items.of(Material.PLAYER_HEAD, nm, lore) : Items.head(op, nm, lore);
            } else {
                Material m = Material.matchMaterial(Values.str(itemV));
                if (m == null) throw new RyuuException(0, "Unknown material '" + Values.str(itemV) + "'");
                String nm = nameE == null ? "&f" + m.name() : Values.str(nameE.eval(c));
                it = Items.of(m, nm, lore);
            }
            if (fGlow) {
                ItemMeta im = it.getItemMeta();
                im.setEnchantmentGlintOverride(true);
                it.setItemMeta(im);
            }
            Map<String, Object> snap = click == null ? null : new HashMap<>(c.vars);
            Script sc = c.script;
            if (sv instanceof List<?> many) {
                for (Object one : many) putSlot(c, Values.intv(one), it.clone(), click, snap, sc, ln);
            } else {
                putSlot(c, Values.intv(sv), it, click, snap, sc, ln);
            }
            return Run.NORMAL;
        };
    }

    private static void putSlot(Ctx c, int slot, ItemStack it, Stmt[] click, Map<String, Object> snap, Script sc, int ln) {
        if (click == null) {
            c.gui.gui.set(slot, it);
            return;
        }
        c.gui.gui.set(slot, it, e -> {
            Player who = (Player) e.getWhoClicked();
            Ctx cc = new Ctx(sc, new HashMap<>(snap));
            cc.sender = who;
            cc.vars.put("player", who);
            cc.vars.put("click", e.getClick().name());
            cc.vars.put("slot", (double) slot);
            RyuuModule.safeRun(sc, ln, click, cc);
        });
    }

    private static OfflinePlayer offline(Object o) {
        if (o instanceof OfflinePlayer p) return p;
        if (o instanceof UUID u) return Bukkit.getOfflinePlayer(u);
        if (o instanceof String s) {
            try {
                return Bukkit.getOfflinePlayer(UUID.fromString(s));
            } catch (IllegalArgumentException e) {
                return Bukkit.getOfflinePlayerIfCached(s);
            }
        }
        return null;
    }

    private Stmt fill(Line l, String rest) {
        Expr e = expr(rest, l);
        return c -> {
            if (c.gui == null) throw new RyuuException(0, "'fill' can only be used inside 'open gui'");
            Material m = Material.matchMaterial(Values.str(e.eval(c)));
            if (m == null) throw new RyuuException(0, "Unknown material for fill");
            c.gui.fill = m;
            return Run.NORMAL;
        };
    }

    private Stmt ask(Line l, String rest) {
        String h = colonRest(l, rest);
        int ki = findKw(h, "into", true);
        if (ki < 0) throw err(l, "Write it like:  ask \"Type something\" into answer:");
        String varName = h.substring(ki + 4).trim();
        if (!IDENT.matcher(varName).matches()) throw err(l, "Bad variable name '" + varName + "'");
        String left = h.substring(0, ki).trim();
        int kf = findKw(left, "for", true);
        Expr prompt = expr(kf < 0 ? left : left.substring(0, kf).trim(), l);
        Expr forE = kf < 0 ? null : expr(left.substring(kf + 3).trim(), l);
        Stmt[] body = block(l.kids());
        final int ln = l.no();
        return c -> {
            Player p = forE == null ? c.player() : Values.player(forE.eval(c));
            if (p == null) throw new RyuuException(0, "ask: there is no player to ask");
            Values.deliver(p, Values.str(prompt.eval(c)));
            Map<String, Object> snap = new HashMap<>(c.vars);
            Script sc = c.script;
            java.util.function.Consumer<String> run = in -> {
                Ctx cc = new Ctx(sc, new HashMap<>(snap));
                cc.sender = p;
                cc.vars.put("player", p);
                cc.vars.put(varName, in);
                RyuuModule.safeRun(sc, ln, body, cc);
            };
            RyuuModule.plugin().prompts().ask(p, run, () -> run.accept("cancel"));
            return Run.NORMAL;
        };
    }
}
