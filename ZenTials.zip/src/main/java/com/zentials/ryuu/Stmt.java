package com.zentials.ryuu;

/** Returns one of the codes in Run: NORMAL, RETURN, STOP, BREAK, CONTINUE. */
@FunctionalInterface
interface Stmt {
    int run(Ctx c);
}
