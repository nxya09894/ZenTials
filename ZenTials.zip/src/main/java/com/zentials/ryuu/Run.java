package com.zentials.ryuu;

final class Run {
    static final int NORMAL = 0;
    static final int RETURN = 1;
    static final int STOP = 2;
    static final int BREAK = 3;
    static final int CONTINUE = 4;

    private Run() {
    }

    static int block(Stmt[] b, Ctx c) {
        for (Stmt s : b) {
            int r = s.run(c);
            if (r != NORMAL) return r;
        }
        return NORMAL;
    }
}
