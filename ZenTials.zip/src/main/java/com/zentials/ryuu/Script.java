package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.LongAdder;
import java.util.regex.Pattern;

/** One parsed .ryu file. */
final class Script {
    record ArgSpec(String name, boolean required, String type, boolean rest) {
    }

    /** How often and how long a handler ran (for /ryu profile). Counting costs two adds per run. */
    static final class Stat {
        final String label;
        final LongAdder runs = new LongAdder();
        final LongAdder nanos = new LongAdder();
        volatile long maxNanos;

        Stat(String label) {
            this.label = label;
        }

        void add(long dt) {
            runs.increment();
            nanos.add(dt);
            if (dt > maxNanos) maxNanos = dt;
        }

        void reset() {
            runs.reset();
            nanos.reset();
            maxNanos = 0;
        }
    }

    static final class CommandDef {
        String name;
        List<ArgSpec> args = new ArrayList<>();
        String permission;
        String permMessage;
        String description = "";
        String usage;
        boolean playerOnly;
        int cooldownSeconds;
        String cooldownMessage;
        List<String> aliases = new ArrayList<>();
        Stmt[] body = new Stmt[0];
        int line;
        Stat stat;
    }

    static final class EventDef {
        String event;
        Stmt[] body = new Stmt[0];
        int line;
        // filter: "on break of stone or dirt:"
        String[] exact;          // normalized names (null = no filter)
        Pattern[] globs = new Pattern[0];
        String[] containing;     // lower-case texts (on chat containing "x")
        String priority;         // lowest ... monitor, null = normal
        boolean ignoreCancelled;
        Stat stat;
        // circuit breaker: too many errors in a short time switches this handler off until the next reload
        volatile boolean tripped;
        int errors;
        long windowStart;
    }

    static final class TimerDef {
        Expr period;
        long unitTicks;
        Stmt[] body = new Stmt[0];
        int line;
        Stat stat;
    }

    static final class FuncDef {
        String name;
        List<String> params = new ArrayList<>();
        List<Expr> defaults = new ArrayList<>();   // same size as params, null = no default
        Stmt[] body = new Stmt[0];
        Script script;
        int line;
    }

    static final class PlaceholderDef {
        Stmt[] body = new Stmt[0];
        long cacheMs;       // 0 = no cache
        boolean global;     // cached once for everybody instead of per player
        Stat stat;
    }

    final String name;
    final String namespace;
    final Map<String, Object> opt = new LinkedHashMap<>();
    final List<CommandDef> commands = new ArrayList<>();
    final List<EventDef> events = new ArrayList<>();
    final List<TimerDef> timers = new ArrayList<>();
    final Map<String, FuncDef> functions = new LinkedHashMap<>();
    final Map<String, PlaceholderDef> placeholders = new LinkedHashMap<>();
    final List<Stmt[]> onLoad = new ArrayList<>();
    final List<Stmt[]> onUnload = new ArrayList<>();
    final List<Stat> stats = new ArrayList<>();
    final Stat misc;
    final Libs.DataLib data;

    Script(String name) {
        this.name = name;
        String base = name.endsWith(".ryu") ? name.substring(0, name.length() - 4) : name;
        this.namespace = "ryu:" + base.replace('\\', '/');
        this.data = new Libs.DataLib(namespace);
        this.misc = newStat("later / gui clicks / ask");
    }

    Stat newStat(String label) {
        Stat s = new Stat(label);
        stats.add(s);
        return s;
    }
}
