package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure text helpers for the parser (no Bukkit here, so they are cheap to test): comments, durations, event
 * headers, assignment shorthand, effect verbs, command arguments and function headers.
 * <p>
 * Idea: a scripter can write the same thing in several ways. Everything here turns the "friendly" spelling
 * into the one canonical spelling the Parser already understands, ONCE when the file is loaded.
 * Nothing in this class runs while the server is running scripts.
 */
final class Syntax {
    private Syntax() {
    }

    // ================================================================ scanning

    /** A ' that is part of isn't / doesn't / aren't ... and does NOT start a text. */
    static boolean contraction(String s, int i) {
        return s.charAt(i) == '\'' && i > 0 && Character.isLetter(s.charAt(i - 1)) && i + 1 < s.length()
                && Character.toLowerCase(s.charAt(i + 1)) == 't'
                && (i + 2 >= s.length() || !(Character.isLetterOrDigit(s.charAt(i + 2)) || s.charAt(i + 2) == '_'));
    }

    /** Does a text start at position i? */
    static boolean quoteAt(String s, int i) {
        char c = s.charAt(i);
        return c == '"' || (c == '\'' && !contraction(s, i));
    }

    /** Cuts a trailing comment: "# ..." or "// ..." (not inside quotes). */
    static String stripComment(String s) {
        boolean inQ = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
            } else if (quoteAt(s, i)) {
                inQ = true;
                q = c;
            } else if (c == '#') {
                return s.substring(0, i);
            } else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '/') {
                return s.substring(0, i);
            }
        }
        return s;
    }

    static String firstWord(String s) {
        int i = 0;
        while (i < s.length() && !Character.isWhitespace(s.charAt(i))) i++;
        return s.substring(0, i);
    }

    /** First word of a block line without trailing colon: letters, digits, _ and -. */
    static String blockWord(String text) {
        int i = 0;
        while (i < text.length() && (Character.isLetterOrDigit(text.charAt(i)) || text.charAt(i) == '_' || text.charAt(i) == '-')) i++;
        return text.substring(0, i);
    }

    /** Position of the word kw (surrounded by spaces) outside quotes and brackets, or -1. */
    static int findKw(String s, String kw, boolean last) {
        int found = -1;
        boolean inQ = false;
        char q = 0;
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(s, i)) {
                inQ = true;
                q = c;
            } else if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
            } else if (depth == 0 && c == ' ' && s.startsWith(kw, i + 1)) {
                int end = i + 1 + kw.length();
                if (end == s.length() || s.charAt(end) == ' ') {
                    found = i + 1;
                    if (!last) return found;
                }
            }
        }
        return found;
    }

    /** Earliest position (and keyword) of any of kws. Returns {position, keywordLength} or null. */
    static int[] findAny(String s, String... kws) {
        int best = -1;
        int len = 0;
        for (String k : kws) {
            int p = findKw(s, k, false);
            if (p >= 0 && (best < 0 || p < best)) {
                best = p;
                len = k.length();
            }
        }
        return best < 0 ? null : new int[]{best, len};
    }

    /** Splits at the separator when it is not inside quotes or brackets. Parts are trimmed. */
    static List<String> splitTop(String s, char sep) {
        List<String> out = new ArrayList<>();
        boolean inQ = false;
        char q = 0;
        int depth = 0;
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(s, i)) {
                inQ = true;
                q = c;
            } else if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
            } else if (depth == 0 && c == sep) {
                out.add(s.substring(start, i).trim());
                start = i + 1;
            }
        }
        out.add(s.substring(start).trim());
        return out;
    }

    /** Splits on spaces, but keeps [ ... ] and < ... > groups together (command arguments). */
    static List<String> splitWords(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '[' || c == '<') depth++;
            else if (c == ']' || c == '>') depth = Math.max(0, depth - 1);
            if (Character.isWhitespace(c) && depth == 0) {
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
            } else {
                cur.append(c);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    /**
     * "cond: statement" on ONE line (Skript style). Returns {cond, statement}, or null when the colon is
     * the last character (a normal block) or there is no colon. A "? :" in the condition is not mistaken
     * for the block colon.
     */
    static String[] inlineSplit(String s) {
        boolean inQ = false;
        char q = 0;
        int depth = 0;
        int pendingQ = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(s, i)) {
                inQ = true;
                q = c;
            } else if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
            } else if (depth == 0 && c == '?') {
                pendingQ++;
            } else if (depth == 0 && c == ':') {
                if (pendingQ > 0) {
                    pendingQ--;
                    continue;
                }
                String rest = s.substring(i + 1).trim();
                if (rest.isEmpty()) return null;
                return new String[]{s.substring(0, i).trim(), rest};
            }
        }
        return null;
    }

    static String unquote(String s) {
        s = s.trim();
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    // ================================================================ did-you-mean

    /** Closest word (edit distance 2 or less) or null. */
    static String nearest(String word, Iterable<String> words) {
        String best = null;
        int bd = 3;
        String w = word.toLowerCase(Locale.ROOT);
        for (String k : words) {
            int d = distance(w, k);
            if (d < bd) {
                bd = d;
                best = k;
            }
        }
        return best;
    }

    private static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            int[] cur = new int[b.length() + 1];
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            prev = cur;
        }
        return prev[b.length()];
    }

    // ================================================================ durations

    private static final Map<String, Long> UNITS = new HashMap<>();

    static {
        for (String u : new String[]{"t", "tick", "ticks"}) UNITS.put(u, 1L);
        for (String u : new String[]{"s", "sec", "secs", "second", "seconds"}) UNITS.put(u, 20L);
        for (String u : new String[]{"m", "min", "mins", "minute", "minutes"}) UNITS.put(u, 1200L);
        for (String u : new String[]{"h", "hr", "hrs", "hour", "hours"}) UNITS.put(u, 72000L);
        for (String u : new String[]{"d", "day", "days"}) UNITS.put(u, 1728000L);
    }

    /** Ticks in one unit (tick, 5s, minutes ...), or -1 when it is not a time unit. */
    static long unitTicks(String u) {
        Long v = UNITS.get(u.toLowerCase(Locale.ROOT));
        return v == null ? -1 : v;
    }

    /** amount = an expression (text), ticks = how many ticks one amount is worth. */
    record Dur(String amount, long ticks) {
    }

    private static final Pattern DUR_PAIR = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*([A-Za-z]+)");

    /**
     * Reads a time written many ways:  5 seconds | 5s | 1.5 minutes | 1 hour 30 minutes | 1h and 30m |
     * second | every-style "minute" | x * 2 seconds | {opt.delay} ticks.  Returns null when it is not a time.
     */
    static Dur duration(String raw) {
        String s = raw.trim();
        if (s.isEmpty()) return null;
        // pure literal, maybe several parts: "1 hour 30 minutes", "1h and 30m", "5s"
        String lit = s.replaceAll("(?i)\\s*(,|\\band\\b)\\s*", " ").trim();
        Matcher m = DUR_PAIR.matcher(lit);
        double total = 0;
        int pos = 0;
        boolean ok = true;
        boolean any = false;
        while (pos < lit.length()) {
            while (pos < lit.length() && lit.charAt(pos) == ' ') pos++;
            if (pos >= lit.length()) break;
            if (!m.find(pos) || m.start() != pos) {
                ok = false;
                break;
            }
            long u = unitTicks(m.group(2));
            if (u < 0) {
                ok = false;
                break;
            }
            total += Double.parseDouble(m.group(1)) * u;
            any = true;
            pos = m.end();
        }
        if (ok && any) return new Dur(Long.toString(Math.max(1, Math.round(total))), 1);
        // a bare unit: "second", "minute"
        long bare = unitTicks(s);
        if (bare >= 0 && s.length() > 1) return new Dur("1", bare);
        // expression + unit
        int sp = s.lastIndexOf(' ');
        if (sp > 0) {
            long u = unitTicks(s.substring(sp + 1).trim());
            if (u >= 0) return new Dur(s.substring(0, sp).trim(), u);
        }
        return null;
    }

    // ================================================================ events

    /** event = the canonical event name, values = implicit filter (right click -> RIGHT_CLICK). */
    record Canon(String event, List<String> values) {
    }

    private static final Map<String, Canon> EVENT_ALIASES = new HashMap<>();

    private static void ev(String target, String... names) {
        for (String n : names) EVENT_ALIASES.put(n, new Canon(target, List.of()));
    }

    private static void evf(String target, String filter, String... names) {
        for (String n : names) EVENT_ALIASES.put(n, new Canon(target, List.of(filter)));
    }

    static {
        ev("join", "player join", "join", "login", "player joined", "joined");
        ev("quit", "player quit", "player leave", "leave", "disconnect", "quit", "player left", "left");
        ev("respawn", "player respawn", "respawn");
        ev("break", "block break", "mine", "break", "player break", "break block");
        ev("place", "block place", "place", "player place", "place block");
        ev("death", "player death", "death", "die", "player die");
        ev("kill", "entity death", "kill", "mob death");
        ev("damage-entity", "damage of entity", "damage entity", "damage-entity", "entity damage by entity", "hit", "attack");
        ev("damage", "damage", "entity damage", "hurt", "player damage", "player hurt");
        ev("move", "player move", "move", "walk");
        ev("teleport", "player teleport", "teleport");
        ev("drop", "player drop", "item drop", "drop");
        ev("pickup", "item pickup", "player pickup", "pickup");
        ev("interact", "player interact", "interact", "click");
        evf("interact", "RIGHT_CLICK", "right click", "rightclick", "right-click");
        evf("interact", "LEFT_CLICK", "left click", "leftclick", "left-click");
        ev("interact-entity", "interact entity", "interact-entity", "entity interact", "player interact entity");
        ev("explode", "entity explode", "explode", "explosion");
        ev("block-explode", "block explode", "block-explode");
        ev("world-change", "world change", "world-change", "player world change", "changed world");
        ev("command", "player command", "command", "cmd");
        ev("close", "close", "inventory close", "close inventory", "gui close");
        ev("chat", "chat", "player chat", "async chat", "message");
        ev("spawn", "spawn", "mob spawn", "creature spawn", "entity spawn");
        ev("target", "target", "entity target");
        ev("bucket", "bucket", "bucket empty", "player bucket empty");
        // names that are plain Bukkit events written in friendly words
        ev("player toggle sneak", "sneak", "toggle sneak", "player sneak");
        ev("player toggle sprint", "sprint", "toggle sprint", "player sprint");
        ev("player toggle flight", "toggle flight", "flight toggle");
        ev("player fish", "fish", "fishing");
        ev("player item consume", "eat", "consume", "item consume", "drink");
        ev("player game mode change", "gamemode change", "game mode change");
        ev("food level change", "hunger", "food change", "food level change");
        ev("entity regain health", "heal", "regain health", "regenerate");
        ev("player swap hand items", "swap hands", "swap hand", "hand swap");
        ev("player bed enter", "bed enter", "sleep");
        ev("player bed leave", "bed leave", "wake");
        ev("player level change", "level change", "level up");
        ev("player portal", "portal");
        ev("player kick", "kick");
        ev("player edit book", "edit book");
        ev("player item held", "hotbar change", "item held", "switch item");
        ev("inventory click", "inventory click", "gui click");
        ev("inventory open", "inventory open", "open inventory");
        ev("craft item", "craft");
        ev("enchant item", "enchant");
        ev("projectile launch", "shoot", "projectile launch");
        ev("projectile hit", "projectile hit");
        ev("entity breed", "breed");
        ev("entity tame", "tame");
        ev("vehicle enter", "vehicle enter", "mount");
        ev("vehicle exit", "vehicle exit", "dismount");
        ev("weather change", "weather change", "weather");
        ev("block form", "block form");
        ev("block spread", "block spread");
        ev("leaves decay", "leaves decay");
        ev("block burn", "block burn");
        ev("block ignite", "block ignite", "ignite");
        // script lifecycle
        ev("load", "load", "start", "startup", "enable", "script load", "server load", "server start", "reload");
        ev("unload", "unload", "stop", "shutdown", "disable", "script unload", "server unload", "server stop");
    }

    static Canon canon(String name) {
        Canon c = EVENT_ALIASES.get(name);
        return c != null ? c : new Canon(name, List.of());
    }

    static Iterable<String> eventNames() {
        return EVENT_ALIASES.keySet();
    }

    /**
     * names = every event the block is for ("on break or place:"), connector/values = filter
     * ("on break of stone or dirt:", "on command \"spawn\":", "on chat containing \"hi\":").
     */
    record EventHeader(List<String> names, String connector, List<String> values, String priority, boolean ignoreCancelled) {
    }

    private static final Pattern PRIO = Pattern.compile("(?i)\\s+priority\\s+(lowest|low|normal|high|highest|monitor)\\b");
    private static final Pattern IGNC = Pattern.compile("(?i)\\s+(?:ignore cancelled|ignoring cancelled|not cancelled|ignorecancelled)\\b");
    private static final Pattern CONN = Pattern.compile("(?i)^(.*?)\\s+(of|with|containing|using)\\s+(.+)$");
    private static final Pattern SEP = Pattern.compile("(?i)\\s+or\\s+|\\s*,\\s*");

    static EventHeader eventHeader(String raw) {
        String s = raw.trim();
        String priority = null;
        boolean ign = false;
        Matcher m = PRIO.matcher(s);
        if (m.find()) {
            priority = m.group(1).toLowerCase(Locale.ROOT);
            s = (s.substring(0, m.start()) + s.substring(m.end())).trim();
        }
        m = IGNC.matcher(s);
        if (m.find()) {
            ign = true;
            s = (s.substring(0, m.start()) + s.substring(m.end())).trim();
        }
        s = s.replaceFirst("(?i)^(an?|the)\\s+", "");
        String conn = null;
        List<String> values = List.of();
        // on command "spawn":   (value written right after the event name)
        int q = firstQuote(s);
        Matcher cm = CONN.matcher(s);
        if (q > 0 && (!cm.matches() || cm.group(1).length() > q)) {
            conn = "of";
            values = splitValues(s.substring(q));
            s = s.substring(0, q).trim();
        } else if (cm.matches()) {
            conn = cm.group(2).toLowerCase(Locale.ROOT);
            s = cm.group(1).trim();
            values = splitValues(cm.group(3));
        }
        List<String> names = new ArrayList<>();
        for (String n : SEP.split(s)) {
            String t = n.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
            if (!t.isEmpty()) names.add(t);
        }
        return new EventHeader(names, conn, values, priority, ign);
    }

    private static int firstQuote(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quoteAt(s, i)) return i;
        }
        return -1;
    }

    private static List<String> splitValues(String s) {
        List<String> out = new ArrayList<>();
        // split on "or" / "," but not inside quotes
        StringBuilder cur = new StringBuilder();
        boolean inQ = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                cur.append(c);
                if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(s, i)) {
                inQ = true;
                q = c;
                cur.append(c);
            } else if (c == ',') {
                add(out, cur);
            } else if (c == ' ' && s.regionMatches(true, i, " or ", 0, 4)) {
                add(out, cur);
                i += 3;
            } else {
                cur.append(c);
            }
        }
        add(out, cur);
        return out;
    }

    private static void add(List<String> out, StringBuilder cur) {
        String v = unquote(cur.toString().trim());
        cur.setLength(0);
        if (!v.isEmpty()) out.add(v);
    }

    // ================================================================ statements

    /** Statement words people use for the same thing -> the one the Parser knows. */
    private static final Map<String, String> STMT_ALIAS = Map.ofEntries(
            Map.entry("msg", "send"), Map.entry("print", "log"), Map.entry("delay", "wait"), Map.entry("sleep", "wait"),
            Map.entry("after", "later"), Map.entry("foreach", "loop"), Map.entry("for", "loop"), Map.entry("each", "loop"),
            Map.entry("exit", "stop"), Map.entry("halt", "stop"), Map.entry("abort", "stop"),
            Map.entry("skip", "continue"), Map.entry("next", "continue"));

    /** The canonical first word for a line like "msg ..." (only when it is really a statement, not an assignment). */
    static String aliasOf(String text) {
        String w = blockWord(text);
        if (w.isEmpty()) return null;
        String canon = STMT_ALIAS.get(w.toLowerCase(Locale.ROOT));
        if (canon == null) return null;
        String rest = text.substring(w.length()).trim();
        if (rest.startsWith("=") || rest.startsWith("+=") || rest.startsWith("-=") || rest.startsWith("*=")
                || rest.startsWith("/=") || rest.startsWith(".") || rest.startsWith("(") || rest.startsWith("[")
                || rest.startsWith("++") || rest.startsWith("--") || rest.startsWith(":=")) {
            return null;
        }
        // "next:" "exit:" are fine as statements; "for"/"each" need something after them
        return canon;
    }

    record ElseInfo(boolean isIf, boolean unless, String tail) {
    }

    /** else / else if / elif / elseif / otherwise / otherwise if / else unless. null when the line is none of them. */
    static ElseInfo elseInfo(String t) {
        String w = blockWord(t).toLowerCase(Locale.ROOT);
        String rest = t.substring(blockWord(t).length()).trim();
        switch (w) {
            case "elif", "elseif" -> {
                return new ElseInfo(true, false, rest);
            }
            case "else", "otherwise" -> {
                String lr = rest.toLowerCase(Locale.ROOT);
                if (lr.startsWith("if ")) return new ElseInfo(true, false, rest.substring(3).trim());
                if (lr.startsWith("unless ")) return new ElseInfo(true, true, rest.substring(7).trim());
                if (rest.isEmpty() || rest.startsWith(":")) return new ElseInfo(false, false, rest);
                return null;
            }
            default -> {
                return null;
            }
        }
    }

    // ---- assignment shorthand

    private static final Pattern LV_SIMPLE =
            Pattern.compile("[A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*|\\[[^\\]]*\\])*");
    private static final Pattern LV_OF = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*\\s+of\\s+[A-Za-z_][A-Za-z0-9_.\\[\\]]*");
    private static final Pattern INC = Pattern.compile("^(.+?)\\s*(\\+\\+|--)$");
    private static final Pattern GIVE_N = Pattern.compile("^(\\d+)\\s+([A-Za-z_]+)\\s+to\\s+(.+)$");

    static boolean isLval(String s) {
        s = s.trim();
        return LV_SIMPLE.matcher(s).matches() || LV_OF.matcher(s).matches();
    }

    /** {start, length, op} of the first top-level assignment operator, or null. */
    private static Object[] findAssign(String t) {
        boolean inQ = false;
        char q = 0;
        int depth = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(t, i)) {
                inQ = true;
                q = c;
            } else if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
            } else if (depth == 0 && c == '=') {
                char next = i + 1 < t.length() ? t.charAt(i + 1) : 0;
                char prev = i > 0 ? t.charAt(i - 1) : 0;
                if (next == '=') {
                    i++;
                    continue;
                }
                if (prev == '!' || prev == '<' || prev == '>') continue;
                if (prev == '+' || prev == '-' || prev == '*' || prev == '/' || prev == '%' || prev == ':') {
                    return new Object[]{i - 1, 2, prev + "="};
                }
                return new Object[]{i, 1, "="};
            }
        }
        return null;
    }

    private static final java.util.Set<String> NO_ASSIGN = java.util.Set.of("if", "unless", "else", "elif", "elseif", "otherwise",
            "loop", "for", "each", "foreach", "repeat", "while", "later", "after", "wait", "ask", "open", "slot", "slots",
            "send", "message", "msg", "broadcast", "console", "log", "print", "return", "set", "add", "remove", "delete",
            "on", "every", "command", "function");

    /** x = 5, x += 1, x++, let x = 5 ...  ->  set / add / remove statements. null when it is not an assignment. */
    private static String rewriteAssign(String t) {
        Matcher inc = INC.matcher(t);
        if (inc.matches() && isLval(inc.group(1))) {
            return (inc.group(2).equals("++") ? "add 1 to " : "remove 1 from ") + inc.group(1).trim();
        }
        Object[] a = findAssign(t);
        if (a == null) return null;
        int start = (Integer) a[0];
        int len = (Integer) a[1];
        String op = (String) a[2];
        String lhs = t.substring(0, start).trim();
        String rhs = t.substring(start + len).trim();
        if (rhs.isEmpty() || !isLval(lhs)) return null;
        return switch (op) {
            case "=", ":=" -> "set " + lhs + " to " + rhs;
            case "+=" -> "add " + rhs + " to " + lhs;
            case "-=" -> "remove " + rhs + " from " + lhs;
            case "*=" -> "set " + lhs + " to " + lhs + " * (" + rhs + ")";
            case "/=" -> "set " + lhs + " to " + lhs + " / (" + rhs + ")";
            default -> "set " + lhs + " to " + lhs + " % (" + rhs + ")";
        };
    }

    private static String target(String s) {
        return s == null || s.isBlank() ? "player" : s.trim();
    }

    /**
     * Friendly statement spellings -> canonical ones. Returns the same text when nothing applies.
     * x = 5 | x += 1 | x++ | let x = 5 | increase x by 2 | teleport p to loc | give 5 DIAMOND to p | kick p because "x" ...
     */
    static String rewrite(String t) {
        String w = blockWord(t);
        String lw = w.toLowerCase(Locale.ROOT);
        String rest = t.substring(w.length()).trim();
        // assignment forms first (but never for real statement words)
        if (!NO_ASSIGN.contains(lw)) {
            String as = rewriteAssign(t);
            if (as != null) return as;
        } else if (lw.equals("set")) {
            if (findKw(rest, "to", false) < 0) {
                Object[] a = findAssign(rest);
                if (a != null && "=".equals(a[2])) {
                    String lhs = rest.substring(0, (Integer) a[0]).trim();
                    String rhs = rest.substring((Integer) a[0] + 1).trim();
                    if (isLval(lhs) && !rhs.isEmpty()) return "set " + lhs + " to " + rhs;
                }
            }
            return t;
        }
        switch (lw) {
            case "let", "var", "local" -> {
                int be = findKw(rest, "be", false);
                if (be > 0) return "set " + rest.substring(0, be).trim() + " to " + rest.substring(be + 2).trim();
                Object[] a = findAssign(rest);
                if (a != null && "=".equals(a[2])) {
                    return "set " + rest.substring(0, (Integer) a[0]).trim() + " to " + rest.substring((Integer) a[0] + 1).trim();
                }
                return t;
            }
            case "increase", "raise" -> {
                int by = findKw(rest, "by", true);
                if (by > 0) return "add " + rest.substring(by + 2).trim() + " to " + rest.substring(0, by).trim();
                return t;
            }
            case "decrease", "reduce", "lower" -> {
                int by = findKw(rest, "by", true);
                if (by > 0) return "remove " + rest.substring(by + 2).trim() + " from " + rest.substring(0, by).trim();
                return t;
            }
            case "subtract" -> {
                int fr = findKw(rest, "from", true);
                if (fr > 0) return "remove " + rest.substring(0, fr).trim() + " from " + rest.substring(fr + 4).trim();
                return t;
            }
            case "multiply" -> {
                int by = findKw(rest, "by", true);
                if (by > 0) {
                    String v = rest.substring(0, by).trim();
                    return "set " + v + " to " + v + " * (" + rest.substring(by + 2).trim() + ")";
                }
                return t;
            }
            case "divide" -> {
                int by = findKw(rest, "by", true);
                if (by > 0) {
                    String v = rest.substring(0, by).trim();
                    return "set " + v + " to " + v + " / (" + rest.substring(by + 2).trim() + ")";
                }
                return t;
            }
            case "clear", "reset" -> {
                return isLval(rest) ? "delete " + rest : t;
            }
            case "stop", "exit" -> {
                String lr = rest.toLowerCase(Locale.ROOT);
                if (lr.equals("loop") || lr.equals("the loop") || lr.equals("this loop")) return "break";
                return t;
            }
            case "cancel" -> {
                String lr = rest.toLowerCase(Locale.ROOT);
                return lr.isEmpty() || lr.equals("event") || lr.equals("the event") ? "cancel" : t;
            }
            case "uncancel" -> {
                return "uncancel";
            }
            case "teleport", "tp" -> {
                int to = findKw(rest, "to", true);
                if (to > 0) return target(rest.substring(0, to)) + ".teleport(" + rest.substring(to + 2).trim() + ")";
                return rest.isEmpty() ? t : "player.teleport(" + rest + ")";
            }
            case "give" -> {
                Matcher g = GIVE_N.matcher(rest);
                if (g.matches()) return g.group(3).trim() + ".give(\"" + g.group(2) + "\", " + g.group(1) + ")";
                int to = findKw(rest, "to", true);
                if (to > 0) return rest.substring(to + 2).trim() + ".give(" + rest.substring(0, to).trim() + ")";
                return rest.isEmpty() ? t : "player.give(" + rest + ")";
            }
            case "kick" -> {
                int[] k = findAny(rest, "because", "for", "with", "reason", "due");
                if (k != null) return target(rest.substring(0, k[0])) + ".kick(" + rest.substring(k[0] + k[1]).trim() + ")";
                return rest.isEmpty() ? "player.kick(\"\")" : rest + ".kick(\"\")";
            }
            case "heal" -> {
                return target(rest) + ".heal()";
            }
            case "feed" -> {
                return target(rest) + ".feed()";
            }
            case "title" -> {
                int to = findKw(rest, "to", true);
                String who = to > 0 ? rest.substring(to + 2).trim() : "player";
                String body = to > 0 ? rest.substring(0, to).trim() : rest;
                int[] sub = findAny(body, "subtitle", "sub");
                if (sub != null) return who + ".title(" + body.substring(0, sub[0]).trim() + ", " + body.substring(sub[0] + sub[1]).trim() + ")";
                return rest.isEmpty() ? t : who + ".title(" + body + ", \"\")";
            }
            case "actionbar" -> {
                int to = findKw(rest, "to", true);
                if (to > 0) return rest.substring(to + 2).trim() + ".actionbar(" + rest.substring(0, to).trim() + ")";
                return rest.isEmpty() ? t : "player.actionbar(" + rest + ")";
            }
            case "play", "sound", "sfx" -> {
                String r = rest;
                if (lw.equals("play")) {
                    if (!r.toLowerCase(Locale.ROOT).startsWith("sound ")) return t;
                    r = r.substring(6).trim();
                }
                int to = findKw(r, "to", true);
                String who = to > 0 ? r.substring(to + 2).trim() : "player";
                String snd = to > 0 ? r.substring(0, to).trim() : r;
                if (snd.isEmpty()) return t;
                boolean raw = snd.contains(".") || !(snd.startsWith("\"") || snd.startsWith("'"));
                return who + (raw ? ".sound(" : ".sfx(") + snd + ")";
            }
            case "close" -> {
                String lr = rest.toLowerCase(Locale.ROOT);
                if (lr.startsWith("inventory") || lr.startsWith("gui") || lr.startsWith("menu")) {
                    int of = findKw(rest, "of", false);
                    return (of > 0 ? rest.substring(of + 2).trim() : "player") + ".closeinv()";
                }
                return t;
            }
            case "execute", "run", "dispatch", "make" -> {
                String r = rest;
                String who = null;
                if (lw.equals("make")) {
                    int[] ex = findAny(r, "execute", "run");
                    if (ex == null) return t;
                    who = r.substring(0, ex[0]).trim();
                    r = r.substring(ex[0] + ex[1]).trim();
                }
                String lr = r.toLowerCase(Locale.ROOT);
                if (lr.startsWith("command ")) r = r.substring(8).trim();
                else if (lr.startsWith("cmd ")) r = r.substring(4).trim();
                else if (lw.equals("run") && who == null && !lr.startsWith("\"") && !lr.startsWith("'")) return t;
                int as = findKw(r, "as", true);
                if (as > 0) {
                    who = r.substring(as + 2).trim();
                    r = r.substring(0, as).trim();
                }
                if (r.isEmpty()) return t;
                return who == null ? "console " + r : who + ".command(" + r + ")";
            }
            default -> {
                return t;
            }
        }
    }

    // ================================================================ command arguments

    record Arg(String name, boolean required, String type, boolean rest) {
    }

    private static final Pattern ARG_PLAIN =
            Pattern.compile("^([<\\[])([A-Za-z_][A-Za-z0-9_]*)(?::([A-Za-z| _-]+))?(\\.\\.\\.)?([>\\]])$");
    private static final Pattern ARG_TYPED = Pattern.compile("^\\[<([A-Za-z _]+)>(\\.\\.\\.)?]$");

    /**
     * &lt;name&gt; [name] &lt;name:type&gt; [name:type] [name...] and Skript style [&lt;player&gt;] (named arg1, arg2 ...).
     * Returns null when the text is not an argument at all.
     */
    static Arg parseArg(String tok, int position) {
        Matcher t = ARG_TYPED.matcher(tok);
        if (t.matches()) return new Arg("arg" + position, false, t.group(1).trim().toLowerCase(Locale.ROOT), t.group(2) != null);
        Matcher m = ARG_PLAIN.matcher(tok);
        if (!m.matches()) return null;
        boolean req = m.group(1).equals("<");
        if (req != m.group(5).equals(">")) return null;
        String type = m.group(3) == null ? "text" : m.group(3).trim().toLowerCase(Locale.ROOT);
        return new Arg(m.group(2), req, type, m.group(4) != null);
    }

    /** Canonical argument type or null when unknown. Choices "a|b|c" are kept as they are. */
    static String canonType(String t) {
        String s = t.trim().toLowerCase(Locale.ROOT).replace(" ", "");
        if (s.contains("|")) return s;
        return switch (s) {
            case "text", "string", "str", "message", "reason" -> "text";
            case "word" -> "word";
            case "number", "decimal", "double", "float", "num" -> "number";
            case "int", "integer", "long", "whole" -> "int";
            case "player", "onlineplayer" -> "player";
            case "offlineplayer", "offline" -> "offline";
            case "world" -> "world";
            case "boolean", "bool" -> "boolean";
            default -> null;
        };
    }

    // ================================================================ function headers

    record Param(String name, String defaultText) {
    }

    record FuncHeader(String name, List<Param> params) {
    }

    private static final Pattern IDENT = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");

    /**
     * "function name(a, b = 5, c: text) :: number"  (fn / def / func / define also work). Types are for
     * readers only and are ignored. null when the text is not a function header.
     */
    static FuncHeader funcHeader(String h) {
        String w = blockWord(h);
        String rest = h.substring(w.length()).trim();
        int open = rest.indexOf('(');
        if (open <= 0) return null;
        String name = rest.substring(0, open).trim();
        if (!IDENT.matcher(name).matches()) return null;
        int depth = 0;
        int close = -1;
        boolean inQ = false;
        char q = 0;
        for (int i = open; i < rest.length(); i++) {
            char c = rest.charAt(i);
            if (inQ) {
                if (c == '\\') i++;
                else if (c == q) inQ = false;
                continue;
            }
            if (quoteAt(rest, i)) {
                inQ = true;
                q = c;
            } else if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth--;
                if (depth == 0) {
                    close = i;
                    break;
                }
            }
        }
        if (close < 0) return null;
        String tail = rest.substring(close + 1).trim();
        if (!(tail.isEmpty() || tail.startsWith("::") || tail.startsWith("->") || tail.toLowerCase(Locale.ROOT).startsWith("returns"))) {
            return null;
        }
        List<Param> ps = new ArrayList<>();
        String inner = rest.substring(open + 1, close).trim();
        if (!inner.isEmpty()) {
            for (String p : splitTop(inner, ',')) {
                String def = null;
                String decl = p;
                Object[] a = findAssign(p);
                if (a != null && "=".equals(a[2])) {
                    decl = p.substring(0, (Integer) a[0]).trim();
                    def = p.substring((Integer) a[0] + 1).trim();
                    if (def.isEmpty()) return null;
                }
                int colon = decl.indexOf(':');
                String pn = (colon > 0 ? decl.substring(0, colon) : decl).trim();
                if (!IDENT.matcher(pn).matches()) return null;
                ps.add(new Param(pn, def));
            }
        }
        return new FuncHeader(name, ps);
    }
}
