package com.zentials.ryuu;

import com.zentials.core.Text;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Reading properties (a.b), indexing (a[i]) and calling methods (a.b()) on script values. */
final class Access {
    private static final Object NOPE = new Object();

    private Access() {
    }

    // ---------------------------------------------------------------- properties

    static Object get(Object t, String n) {
        if (t == null) throw new RyuuException(0, "Cannot read '" + n + "' of nothing (it is empty)");
        if (t instanceof Map<?, ?> m) return m.get(n);
        Object v = NOPE;
        if (t instanceof Player p) v = playerProp(p, n);
        else if (t instanceof OfflinePlayer op) v = offlineProp(op, n);
        else if (t instanceof Location l) v = locProp(l, n);
        else if (t instanceof Block b) v = blockProp(b, n);
        else if (t instanceof World w) v = worldProp(w, n);
        else if (t instanceof ItemStack i) v = itemProp(i, n);
        else if (t instanceof Entity e) v = entityProp(e, n);
        else if (t instanceof List<?> l) v = listProp(l, n);
        else if (t instanceof String s) v = stringProp(s, n);
        if (v != NOPE) return v;
        return reflectGet(t, n);
    }

    private static Object worldProp(World w, String n) {
        return switch (n) {
            case "name" -> w.getName();
            case "uuid" -> w.getUID().toString();
            case "spawn" -> w.getSpawnLocation();
            default -> NOPE;
        };
    }

    static String itemName(ItemStack it) {
        if (it == null || !it.hasItemMeta() || !it.getItemMeta().hasDisplayName()) return "";
        return PlainTextComponentSerializer.plainText().serialize(it.getItemMeta().displayName());
    }

    private static Object bedOf(Player p) {
        for (String m : new String[]{"getRespawnLocation", "getBedSpawnLocation"}) {
            try {
                return p.getClass().getMethod(m).invoke(p);
            } catch (ReflectiveOperationException ignored) {
                // try the next name
            }
        }
        return null;
    }

    private static Object playerProp(Player p, String n) {
        return switch (n) {
            case "name" -> p.getName();
            case "uuid" -> p.getUniqueId().toString();
            case "world" -> p.getWorld().getName();
            case "x" -> p.getLocation().getX();
            case "y" -> p.getLocation().getY();
            case "z" -> p.getLocation().getZ();
            case "bx" -> (double) p.getLocation().getBlockX();
            case "by" -> (double) p.getLocation().getBlockY();
            case "bz" -> (double) p.getLocation().getBlockZ();
            case "loc", "location" -> p.getLocation();
            case "health" -> p.getHealth();
            case "food" -> (double) p.getFoodLevel();
            case "level" -> (double) p.getLevel();
            case "gamemode" -> p.getGameMode().name();
            case "op" -> p.isOp();
            case "online" -> p.isOnline();
            case "ping" -> (double) p.getPing();
            case "hand" -> p.getInventory().getItemInMainHand();
            case "handtype" -> p.getInventory().getItemInMainHand().getType().name();
            case "handamount" -> {
                ItemStack h = p.getInventory().getItemInMainHand();
                yield h.getType().isAir() ? 0.0 : (double) h.getAmount();
            }
            case "block" -> p.getLocation().getBlock();
            case "handname" -> itemName(p.getInventory().getItemInMainHand());
            case "maxhealth" -> {
                var at = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
                yield at == null ? 20.0 : at.getValue();
            }
            case "played" -> p.hasPlayedBefore();
            case "bed" -> bedOf(p);
            case "flying" -> p.getAllowFlight();
            case "ip" -> p.getAddress() == null ? "" : p.getAddress().getAddress().getHostAddress();
            case "invtitle" -> PlainTextComponentSerializer.plainText().serialize(p.getOpenInventory().title());
            case "playtime" -> playSeconds(p);
            default -> NOPE;
        };
    }

    /** Time played in seconds (the server statistic; the enum name changed between versions). */
    private static double playSeconds(Player p) {
        for (String name : new String[]{"PLAY_ONE_MINUTE", "TIME_PLAYED"}) {
            try {
                return p.getStatistic(org.bukkit.Statistic.valueOf(name)) / 20.0;
            } catch (IllegalArgumentException ignored) {
                // try the next name
            }
        }
        return 0;
    }

    private static Object offlineProp(OfflinePlayer p, String n) {
        return switch (n) {
            case "name" -> p.getName() == null ? p.getUniqueId().toString() : p.getName();
            case "uuid" -> p.getUniqueId().toString();
            case "online" -> p.isOnline();
            case "played" -> p.hasPlayedBefore();
            default -> NOPE;
        };
    }

    private static Object locProp(Location l, String n) {
        return switch (n) {
            case "x" -> l.getX();
            case "y" -> l.getY();
            case "z" -> l.getZ();
            case "bx" -> (double) l.getBlockX();
            case "by" -> (double) l.getBlockY();
            case "bz" -> (double) l.getBlockZ();
            case "yaw" -> (double) l.getYaw();
            case "pitch" -> (double) l.getPitch();
            case "world" -> l.getWorld() == null ? null : l.getWorld().getName();
            case "block" -> l.getBlock();
            default -> NOPE;
        };
    }

    private static Object blockProp(Block b, String n) {
        return switch (n) {
            case "type" -> b.getType().name();
            case "x" -> (double) b.getX();
            case "y" -> (double) b.getY();
            case "z" -> (double) b.getZ();
            case "world" -> b.getWorld().getName();
            case "loc", "location" -> b.getLocation();
            default -> NOPE;
        };
    }

    private static Object itemProp(ItemStack i, String n) {
        return switch (n) {
            case "type" -> i.getType().name();
            case "amount" -> (double) i.getAmount();
            case "name" -> itemName(i);
            default -> NOPE;
        };
    }

    private static Object entityProp(Entity e, String n) {
        return switch (n) {
            case "type" -> e.getType().name();
            case "name" -> e.getName();
            case "uuid" -> e.getUniqueId().toString();
            case "world" -> e.getWorld().getName();
            case "x" -> e.getLocation().getX();
            case "y" -> e.getLocation().getY();
            case "z" -> e.getLocation().getZ();
            case "loc", "location" -> e.getLocation();
            case "monster" -> e instanceof org.bukkit.entity.Monster;
            default -> NOPE;
        };
    }

    private static Object listProp(List<?> l, String n) {
        return switch (n) {
            case "size", "length" -> (double) l.size();
            case "first" -> l.isEmpty() ? null : l.get(0);
            case "last" -> l.isEmpty() ? null : l.get(l.size() - 1);
            case "empty" -> l.isEmpty();
            default -> NOPE;
        };
    }

    private static Object stringProp(String s, String n) {
        return switch (n) {
            case "length" -> (double) s.length();
            case "upper" -> s.toUpperCase(Locale.ROOT);
            case "lower" -> s.toLowerCase(Locale.ROOT);
            default -> NOPE;
        };
    }

    private static Object reflectGet(Object t, String n) {
        String cap = Character.toUpperCase(n.charAt(0)) + n.substring(1);
        for (String name : new String[]{"get" + cap, "is" + cap, "has" + cap, n}) {
            try {
                Method m = t.getClass().getMethod(name);
                if (m.getParameterCount() != 0) continue;
                return normalize(m.invoke(t));
            } catch (NoSuchMethodException ignored) {
                // try the next name
            } catch (ReflectiveOperationException e) {
                throw new RyuuException(0, "Cannot read '" + n + "': " + e.getMessage());
            }
        }
        throw new RyuuException(0, "Unknown property '" + n + "' on " + Values.typeName(t));
    }

    // ---------------------------------------------------------------- indexing

    @SuppressWarnings("unchecked")
    static Object index(Object t, Object i) {
        if (t == null) return null;
        if (t instanceof List<?> l) {
            int k = Values.intv(i);
            return k >= 0 && k < l.size() ? l.get(k) : null;
        }
        if (t instanceof Map<?, ?> m) return ((Map<Object, Object>) m).get(Values.str(i));
        if (t instanceof String s) {
            int k = Values.intv(i);
            return k >= 0 && k < s.length() ? String.valueOf(s.charAt(k)) : null;
        }
        throw new RyuuException(0, "Cannot use [ ] on " + Values.typeName(t));
    }

    // ---------------------------------------------------------------- methods

    static Object call(Object t, String name, List<Object> a, Ctx c) {
        if (t == null) throw new RyuuException(0, "Cannot call '" + name + "' on nothing (it is empty)");
        if (t instanceof Libs.Lib lib) return lib.call(name, a, c);
        String m = name.toLowerCase(Locale.ROOT);
        Object v = NOPE;
        if (t instanceof Player p) v = playerCall(p, m, a);
        if (v == NOPE && t instanceof CommandSender cs && (m.equals("send") || m.equals("message"))) {
            cs.sendMessage(Text.c(Values.str(arg(a, 0))));
            v = null;
        }
        if (v == NOPE && t instanceof World w && m.equals("highest")) {
            v = (double) w.getHighestBlockYAt(Values.intv(arg(a, 0)), Values.intv(arg(a, 1)));
        }
        if (v == NOPE && t instanceof Location l) v = locCall(l, m, a);
        if (v == NOPE && t instanceof List<?> l) v = listCall(l, m, a);
        if (v == NOPE && t instanceof String s) v = stringCall(s, m, a);
        if (v == NOPE && t instanceof Map<?, ?> mp) v = mapCall(mp, m, a);
        if (v == NOPE && t instanceof List<?> xl) {
            Object x = Extra.list(xl, m, a);
            if (x != Extra.NONE) v = x;
        }
        if (v == NOPE && t instanceof Map<?, ?> xm) {
            Object x = Extra.map(xm, m, a);
            if (x != Extra.NONE) v = x;
        }
        if (v == NOPE && t instanceof String xs) {
            // every text.* function also works as a method:  "hello".capitalize()
            List<Object> withSelf = new ArrayList<>();
            withSelf.add(xs);
            withSelf.addAll(a);
            Object x = Extra.text(m, withSelf);
            if (x != Extra.NONE) v = x;
        }
        if (v != NOPE) return v;
        return reflectCall(t, name, a);
    }

    private static Object arg(List<Object> a, int i) {
        return i < a.size() ? a.get(i) : null;
    }

    private static Object playerCall(Player p, String m, List<Object> a) {
        switch (m) {
            case "send", "message" -> {
                p.sendMessage(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "title" -> {
                p.showTitle(Title.title(Text.c(Values.str(arg(a, 0))), Text.c(Values.str(arg(a, 1)))));
                return null;
            }
            case "actionbar" -> {
                p.sendActionBar(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "teleport", "tp" -> {
                if (!(arg(a, 0) instanceof Location l)) throw new RyuuException(0, "teleport needs a location");
                p.teleport(l);
                return null;
            }
            case "has" -> {
                return p.hasPermission(Values.str(arg(a, 0)));
            }
            case "give" -> {
                if (arg(a, 0) instanceof ItemStack stack) {
                    var leftover = p.getInventory().addItem(stack.clone());
                    for (ItemStack rest : leftover.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
                    return null;
                }
                Material mat = Material.matchMaterial(Values.str(arg(a, 0)));
                if (mat == null) throw new RyuuException(0, "Unknown material '" + Values.str(arg(a, 0)) + "'");
                int amt = a.size() > 1 ? Values.intv(a.get(1)) : 1;
                var left = p.getInventory().addItem(new ItemStack(mat, Math.max(1, amt)));
                for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
                return null;
            }
            case "takehand" -> {
                ItemStack h = p.getInventory().getItemInMainHand();
                int n = Values.intv(arg(a, 0));
                if (h.getType().isAir()) return false;
                if (n >= h.getAmount()) p.getInventory().setItemInMainHand(null);
                else h.setAmount(h.getAmount() - n);
                return true;
            }
            case "sfx" -> {
                RyuuModule.plugin().sfx().play(p, Values.str(arg(a, 0)));
                return null;
            }
            case "sound" -> {
                float vol = a.size() > 1 ? (float) Values.num(a.get(1)) : 1f;
                float pitch = a.size() > 2 ? (float) Values.num(a.get(2)) : 1f;
                p.playSound(p.getLocation(), Values.str(arg(a, 0)), vol, pitch);
                return null;
            }
            case "heal" -> {
                var attr = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
                double max = attr == null ? 20.0 : attr.getValue();
                p.setHealth(a.isEmpty() ? max : Math.min(max, p.getHealth() + Values.num(a.get(0))));
                return null;
            }
            case "setfood" -> {
                p.setFoodLevel(Math.max(0, Math.min(20, Values.intv(arg(a, 0)))));
                return null;
            }
            case "particle" -> {
                Particle pt = Registry.PARTICLE_TYPE.get(NamespacedKey.minecraft(Values.str(arg(a, 0)).toLowerCase(Locale.ROOT)));
                if (pt == null) throw new RyuuException(0, "Unknown particle '" + Values.str(arg(a, 0)) + "'");
                p.spawnParticle(pt, Values.num(arg(a, 1)), Values.num(arg(a, 2)), Values.num(arg(a, 3)), 1, 0, 0, 0, 0);
                return null;
            }
            case "potion" -> {
                PotionEffectType pet = Registry.POTION_EFFECT_TYPE.get(NamespacedKey.minecraft(Values.str(arg(a, 0)).toLowerCase(Locale.ROOT)));
                if (pet == null) throw new RyuuException(0, "Unknown potion effect '" + Values.str(arg(a, 0)) + "'");
                // 4th argument true = quiet effect: no particles and no icon on the screen
                boolean quiet = a.size() > 3 && Values.truthy(a.get(3));
                p.addPotionEffect(quiet
                        ? new PotionEffect(pet, Values.intv(arg(a, 2)) * 20, Values.intv(arg(a, 1)), true, false, false)
                        : new PotionEffect(pet, Values.intv(arg(a, 2)) * 20, Values.intv(arg(a, 1))));
                return null;
            }
            case "removeitems" -> {
                String want = Values.str(arg(a, 0));
                ItemStack[] inv = p.getInventory().getContents();
                for (int i = 0; i < inv.length; i++) {
                    if (inv[i] != null && itemName(inv[i]).equals(want)) p.getInventory().setItem(i, null);
                }
                return null;
            }
            case "feed" -> {
                p.setFoodLevel(20);
                p.setSaturation(20f);
                return null;
            }
            case "fly" -> {
                // player.fly(true/false): allows flight (and stops it when turned off)
                boolean on = Values.truthy(arg(a, 0));
                p.setAllowFlight(on);
                if (!on) p.setFlying(false);
                return null;
            }
            case "hide" -> {
                // player.hide() hides from everyone, player.hide(viewer) hides from one player
                if (arg(a, 0) instanceof Player v) {
                    v.hidePlayer(RyuuModule.plugin(), p);
                } else {
                    for (Player o : org.bukkit.Bukkit.getOnlinePlayers()) if (o != p) o.hidePlayer(RyuuModule.plugin(), p);
                }
                return null;
            }
            case "reveal" -> {
                for (Player o : org.bukkit.Bukkit.getOnlinePlayers()) if (o != p) o.showPlayer(RyuuModule.plugin(), p);
                return null;
            }
            case "clearinv" -> {
                p.getInventory().clear();
                return null;
            }
            case "invsee" -> {
                if (!(arg(a, 0) instanceof Player t)) throw new RyuuException(0, "invsee needs an online player");
                p.openInventory(t.getInventory());
                return null;
            }
            case "count" -> {
                // player.count("DIAMOND") -> how many they carry
                return ExtraBukkit.count(p, arg(a, 0));
            }
            case "take" -> {
                // player.take("DIAMOND", 5) -> true when it was all there and got removed
                return ExtraBukkit.take(p, arg(a, 0), Values.intv(arg(a, 1)));
            }
            case "slot" -> {
                return ExtraBukkit.slot(p, Values.intv(arg(a, 0)));
            }
            case "setslot" -> {
                ExtraBukkit.setSlot(p, Values.intv(arg(a, 0)), arg(a, 1));
                return null;
            }
            case "hasitem" -> {
                // player.hasitem("Plain Item Name"): true if any item in the inventory has that display name
                String want = Values.str(arg(a, 0));
                for (ItemStack it : p.getInventory().getContents()) {
                    if (it != null && itemName(it).equals(want)) return true;
                }
                return false;
            }
            case "compass" -> {
                // player.compass(location): where the compass points
                if (arg(a, 0) instanceof Location cl) p.setCompassTarget(cl);
                return null;
            }
            case "cureeffects" -> {
                for (PotionEffect pe : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(pe.getType());
                return null;
            }
            case "kick" -> {
                p.kick(Text.c(Values.str(arg(a, 0))));
                return null;
            }
            case "command" -> {
                return p.performCommand(Values.str(arg(a, 0)));
            }
            case "gamemode" -> {
                try {
                    p.setGameMode(GameMode.valueOf(Values.str(arg(a, 0)).toUpperCase(Locale.ROOT)));
                } catch (IllegalArgumentException e) {
                    throw new RyuuException(0, "Unknown gamemode '" + Values.str(arg(a, 0)) + "'");
                }
                return null;
            }
            case "closeinv" -> {
                p.closeInventory();
                return null;
            }
            default -> {
                return NOPE;
            }
        }
    }

    private static Object locCall(Location l, String m, List<Object> a) {
        switch (m) {
            case "add" -> {
                return l.clone().add(Values.num(arg(a, 0)), Values.num(arg(a, 1)), Values.num(arg(a, 2)));
            }
            case "distance" -> {
                if (!(arg(a, 0) instanceof Location o)) throw new RyuuException(0, "distance needs a location");
                if (l.getWorld() == null || !l.getWorld().equals(o.getWorld())) return Double.MAX_VALUE;
                return l.distance(o);
            }
            case "block" -> {
                return l.getBlock();
            }
            case "entities" -> {
                if (l.getWorld() == null) return new ArrayList<Object>();
                double r = Values.num(arg(a, 0));
                return new ArrayList<Object>(l.getWorld().getNearbyEntities(l, r, r, r));
            }
            default -> {
                return NOPE;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Object listCall(List<?> l, String m, List<Object> a) {
        List<Object> list = (List<Object>) l;
        switch (m) {
            case "add" -> {
                list.add(arg(a, 0));
                return true;
            }
            case "remove" -> {
                for (int i = 0; i < list.size(); i++) {
                    if (Values.eq(list.get(i), arg(a, 0))) {
                        list.remove(i);
                        return true;
                    }
                }
                return false;
            }
            case "contains" -> {
                for (Object o : list) if (Values.eq(o, arg(a, 0))) return true;
                return false;
            }
            case "size" -> {
                return (double) list.size();
            }
            case "get" -> {
                return index(list, arg(a, 0));
            }
            case "join" -> {
                StringBuilder sb = new StringBuilder();
                String sep = a.isEmpty() ? ", " : Values.str(a.get(0));
                for (int i = 0; i < list.size(); i++) {
                    if (i > 0) sb.append(sep);
                    sb.append(Values.str(list.get(i)));
                }
                return sb.toString();
            }
            case "clear" -> {
                list.clear();
                return null;
            }
            case "indexof" -> {
                for (int i = 0; i < list.size(); i++) if (Values.eq(list.get(i), arg(a, 0))) return (double) i;
                return -1.0;
            }
            case "copy" -> {
                return new ArrayList<>(list);
            }
            case "isempty" -> {
                return list.isEmpty();
            }
            case "sort" -> {
                list.sort((x, y) -> Values.compare(x, y));
                return list;
            }
            case "reverse" -> {
                java.util.Collections.reverse(list);
                return list;
            }
            default -> {
                return NOPE;
            }
        }
    }

    private static Object stringCall(String s, String m, List<Object> a) {
        switch (m) {
            case "upper" -> {
                return s.toUpperCase(Locale.ROOT);
            }
            case "lower" -> {
                return s.toLowerCase(Locale.ROOT);
            }
            case "length" -> {
                return (double) s.length();
            }
            case "contains" -> {
                return s.contains(Values.str(arg(a, 0)));
            }
            case "startswith" -> {
                return s.startsWith(Values.str(arg(a, 0)));
            }
            case "endswith" -> {
                return s.endsWith(Values.str(arg(a, 0)));
            }
            case "replace" -> {
                return s.replace(Values.str(arg(a, 0)), Values.str(arg(a, 1)));
            }
            case "split" -> {
                List<Object> out = new ArrayList<>();
                for (String part : s.split(Pattern.quote(Values.str(arg(a, 0))))) out.add(part);
                return out;
            }
            case "trim" -> {
                return s.trim();
            }
            case "substring" -> {
                int from = Math.max(0, Math.min(s.length(), Values.intv(arg(a, 0))));
                int to = a.size() > 1 ? Math.max(from, Math.min(s.length(), Values.intv(a.get(1)))) : s.length();
                return s.substring(from, to);
            }
            case "isnumber" -> {
                try {
                    Double.parseDouble(s.trim());
                    return true;
                } catch (NumberFormatException e) {
                    return false;
                }
            }
            default -> {
                return NOPE;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Object mapCall(Map<?, ?> mp, String m, List<Object> a) {
        Map<Object, Object> map = (Map<Object, Object>) mp;
        switch (m) {
            case "get" -> {
                return map.get(Values.str(arg(a, 0)));
            }
            case "put", "set" -> {
                map.put(Values.str(arg(a, 0)), arg(a, 1));
                return null;
            }
            case "has" -> {
                return map.containsKey(Values.str(arg(a, 0)));
            }
            case "remove" -> {
                return map.remove(Values.str(arg(a, 0)));
            }
            case "keys" -> {
                return new ArrayList<>(map.keySet());
            }
            case "values" -> {
                return new ArrayList<>(map.values());
            }
            case "size" -> {
                return (double) map.size();
            }
            default -> {
                return NOPE;
            }
        }
    }

    // ---------------------------------------------------------------- reflection fallback

    private static Object reflectCall(Object t, String name, List<Object> args) {
        for (Method m : t.getClass().getMethods()) {
            if (!m.getName().equalsIgnoreCase(name) || m.getParameterCount() != args.size()) continue;
            Object[] conv = coerce(m.getParameterTypes(), args);
            if (conv == null) continue;
            try {
                try {
                    m.setAccessible(true);
                } catch (RuntimeException ignored) {
                    // not needed for public API methods
                }
                return normalize(m.invoke(t, conv));
            } catch (InvocationTargetException e) {
                Throwable cause = e.getCause() == null ? e : e.getCause();
                throw new RyuuException(0, name + "() failed: " + cause);
            } catch (IllegalAccessException e) {
                throw new RyuuException(0, name + "() is not accessible");
            }
        }
        throw new RyuuException(0, "Unknown method '" + name + "' with " + args.size()
                + " argument(s) on " + Values.typeName(t));
    }

    private static Object[] coerce(Class<?>[] types, List<Object> args) {
        Object[] out = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            Class<?> ty = types[i];
            Object a = args.get(i);
            if (a == null) {
                if (ty.isPrimitive()) return null;
                out[i] = null;
            } else if (ty == int.class || ty == Integer.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.intValue();
            } else if (ty == long.class || ty == Long.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.longValue();
            } else if (ty == double.class || ty == Double.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.doubleValue();
            } else if (ty == float.class || ty == Float.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.floatValue();
            } else if (ty == boolean.class || ty == Boolean.class) {
                if (!(a instanceof Boolean b)) return null;
                out[i] = b;
            } else if (ty == String.class) {
                out[i] = Values.str(a);
            } else if (ty == Material.class && a instanceof String s) {
                Material mat = Material.matchMaterial(s);
                if (mat == null) return null;
                out[i] = mat;
            } else if (ty == org.bukkit.plugin.Plugin.class) {
                out[i] = RyuuModule.plugin();
            } else if (ty == short.class || ty == Short.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.shortValue();
            } else if (ty == byte.class || ty == Byte.class) {
                if (!(a instanceof Number n)) return null;
                out[i] = n.byteValue();
            } else if (ty.isInstance(a)) {
                out[i] = a;
            } else if (ty.isEnum() && a instanceof String es) {
                Object ev = enumConst(ty, es);
                if (ev == null) return null;
                out[i] = ev;
            } else if (ty == net.kyori.adventure.text.Component.class && a instanceof String cs) {
                out[i] = Text.c(cs);
            } else if (ty == java.util.UUID.class && a instanceof String us) {
                try {
                    out[i] = java.util.UUID.fromString(us);
                } catch (IllegalArgumentException ex) {
                    return null;
                }
            } else if (ty == NamespacedKey.class && a instanceof String ks) {
                NamespacedKey nk = ks.contains(":") ? NamespacedKey.fromString(ks) : NamespacedKey.minecraft(ks);
                if (nk == null) return null;
                out[i] = nk;
            } else if (ty == World.class && a instanceof String ws) {
                World w = org.bukkit.Bukkit.getWorld(ws);
                if (w == null) return null;
                out[i] = w;
            } else if (ty == Player.class) {
                Player pl = Values.player(a);
                if (pl == null) return null;
                out[i] = pl;
            } else if (ty == OfflinePlayer.class) {
                Player pl = Values.player(a);
                if (pl == null) return null;
                out[i] = pl;
            } else if (ty == ItemStack.class && a instanceof String is) {
                Material im = Material.matchMaterial(is);
                if (im == null) return null;
                out[i] = new ItemStack(im);
            } else {
                return null;
            }
        }
        return out;
    }

    private static Object enumConst(Class<?> ty, String s) {
        String want = s.trim().toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        for (Object c : ty.getEnumConstants()) {
            if (((Enum<?>) c).name().equals(want)) return c;
        }
        return null;
    }

    /** Reads a property if it exists, otherwise null (used for event properties like block, cause, message). */
    static Object softGet(Object t, String n) {
        if (t == null || n.isEmpty()) return null;
        try {
            return reflectGet(t, n);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static Object normalize(Object r) {
        if (r instanceof Number n && !(r instanceof Double)) return n.doubleValue();
        if (r instanceof Enum<?> e) return e.name();
        if (r instanceof net.kyori.adventure.text.Component c) return PlainTextComponentSerializer.plainText().serialize(c);
        return r;
    }
}
