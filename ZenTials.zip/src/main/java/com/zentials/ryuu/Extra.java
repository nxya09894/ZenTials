package com.zentials.ryuu;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;

/**
 * Extra built-in functions for Ryuudules that need no Bukkit classes:
 * text / math / list / map helpers, json, file, http and cooldowns.
 * (The Bukkit-touching extras live in ExtraBukkit.)
 */
final class Extra {
    /** Returned when a name is not one of ours, so the caller can carry on. */
    static final Object NONE = new Object();

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final Map<String, Long> COOLDOWNS = new ConcurrentHashMap<>();
    private static final java.util.Random RNG = new java.util.Random();

    private Extra() {
    }

    private static Object arg(List<Object> a, int i) {
        return i < a.size() ? a.get(i) : null;
    }

    // ------------------------------------------------------------------ text.*

    static Object text(String fn, List<Object> a) {
        String s = Values.str(arg(a, 0));
        switch (fn) {
            case "startswith" -> {
                return s.startsWith(Values.str(arg(a, 1)));
            }
            case "endswith" -> {
                return s.endsWith(Values.str(arg(a, 1)));
            }
            case "capitalize" -> {
                return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase(Locale.ROOT);
            }
            case "title" -> {
                StringBuilder sb = new StringBuilder();
                boolean up = true;
                for (char ch : s.toCharArray()) {
                    sb.append(up ? Character.toUpperCase(ch) : Character.toLowerCase(ch));
                    up = ch == ' ' || ch == '_' || ch == '-';
                }
                return sb.toString();
            }
            case "padleft", "padright" -> {
                int n = Values.intv(arg(a, 1));
                String pad = a.size() > 2 ? Values.str(a.get(2)) : " ";
                if (pad.isEmpty()) pad = " ";
                StringBuilder sb = new StringBuilder(s);
                while (sb.length() < n) {
                    if (fn.equals("padleft")) sb.insert(0, pad.charAt(0));
                    else sb.append(pad.charAt(0));
                }
                return sb.toString();
            }
            case "number" -> {
                // text.number(1234567.891, "#,##0.00")  ->  1,234,567.89
                String pattern = a.size() > 1 ? Values.str(a.get(1)) : "#,##0.##";
                try {
                    return new DecimalFormat(pattern, DecimalFormatSymbols.getInstance(Locale.US))
                            .format(Values.num(arg(a, 0)));
                } catch (IllegalArgumentException e) {
                    throw new RyuuException(0, "Bad number pattern '" + pattern + "'");
                }
            }
            case "matches" -> {
                return regex(Values.str(arg(a, 1))).matcher(s).find();
            }
            case "regexreplace" -> {
                return regex(Values.str(arg(a, 1))).matcher(s).replaceAll(Values.str(arg(a, 2)));
            }
            case "count" -> {
                String sub = Values.str(arg(a, 1));
                if (sub.isEmpty()) return 0.0;
                int n = 0;
                int i = 0;
                while ((i = s.indexOf(sub, i)) >= 0) {
                    n++;
                    i += sub.length();
                }
                return (double) n;
            }
            case "reverse" -> {
                return new StringBuilder(s).reverse().toString();
            }
            case "indexof" -> {
                return (double) s.indexOf(Values.str(arg(a, 1)));
            }
            default -> {
                return NONE;
            }
        }
    }

    private static Pattern regex(String re) {
        try {
            return Pattern.compile(re);
        } catch (PatternSyntaxException e) {
            throw new RyuuException(0, "Bad pattern '" + re + "'");
        }
    }

    // ------------------------------------------------------------------ math.*

    static Object math(String fn, List<Object> a) {
        double x = Values.num(arg(a, 0));
        switch (fn) {
            case "mod" -> {
                double y = Values.num(arg(a, 1));
                return y == 0 ? 0.0 : x - y * Math.floor(x / y);
            }
            case "sign" -> {
                return Math.signum(x);
            }
            case "ln" -> {
                return Math.log(x);
            }
            case "log10" -> {
                return Math.log10(x);
            }
            case "exp" -> {
                return Math.exp(x);
            }
            case "sin" -> {
                return Math.sin(x);
            }
            case "cos" -> {
                return Math.cos(x);
            }
            case "lerp" -> {
                // math.lerp(from, to, t)
                double to = Values.num(arg(a, 1));
                return x + (to - x) * Values.num(arg(a, 2));
            }
            case "randint" -> {
                // inclusive: math.randint(1, 6)
                int lo = (int) Math.min(x, Values.num(arg(a, 1)));
                int hi = (int) Math.max(x, Values.num(arg(a, 1)));
                return (double) (lo + RNG.nextInt(hi - lo + 1));
            }
            case "chance" -> {
                // math.chance(25)  ->  true 25% of the time
                return RNG.nextDouble() * 100.0 < x;
            }
            default -> {
                return NONE;
            }
        }
    }

    // ------------------------------------------------------------------ list / map methods

    @SuppressWarnings("unchecked")
    static Object list(List<?> src, String m, List<Object> a) {
        List<Object> l = (List<Object>) src;
        switch (m) {
            case "sort" -> {
                List<Object> out = new ArrayList<>(l);
                out.sort(Values::compare);
                return out;
            }
            case "rsort" -> {
                List<Object> out = new ArrayList<>(l);
                out.sort((x, y) -> Values.compare(y, x));
                return out;
            }
            case "sortby", "rsortby" -> {
                // list of maps:  rows.sortby("score")
                String key = Values.str(arg(a, 0));
                List<Object> out = new ArrayList<>(l);
                Comparator<Object> cmp = (x, y) -> Values.compare(field(x, key), field(y, key));
                out.sort(m.equals("sortby") ? cmp : cmp.reversed());
                return out;
            }
            case "reverse" -> {
                List<Object> out = new ArrayList<>(l);
                Collections.reverse(out);
                return out;
            }
            case "shuffle" -> {
                List<Object> out = new ArrayList<>(l);
                Collections.shuffle(out, RNG);
                return out;
            }
            case "choice" -> {
                return l.isEmpty() ? null : l.get(RNG.nextInt(l.size()));
            }
            case "sum" -> {
                double t = 0;
                for (Object o : l) t += Values.num(o);
                return t;
            }
            case "max", "min" -> {
                Object best = null;
                for (Object o : l) {
                    if (best == null) best = o;
                    else if (m.equals("max") ? Values.compare(o, best) > 0 : Values.compare(o, best) < 0) best = o;
                }
                return best;
            }
            case "unique" -> {
                List<Object> out = new ArrayList<>();
                for (Object o : l) if (!out.contains(o)) out.add(o);
                return out;
            }
            case "slice" -> {
                // slice(from) or slice(from, to)   (to is not included)
                int from = Math.max(0, Values.intv(arg(a, 0)));
                int to = a.size() > 1 ? Math.min(l.size(), Values.intv(a.get(1))) : l.size();
                return from >= to ? new ArrayList<>() : new ArrayList<>(l.subList(from, to));
            }
            case "take" -> {
                int n = Math.max(0, Math.min(l.size(), Values.intv(arg(a, 0))));
                return new ArrayList<>(l.subList(0, n));
            }
            case "first" -> {
                return l.isEmpty() ? null : l.get(0);
            }
            case "last" -> {
                return l.isEmpty() ? null : l.get(l.size() - 1);
            }
            case "copy" -> {
                return new ArrayList<>(l);
            }
            case "indexof" -> {
                return (double) l.indexOf(arg(a, 0));
            }
            case "count" -> {
                int n = 0;
                for (Object o : l) if (Values.eq(o, arg(a, 0))) n++;
                return (double) n;
            }
            default -> {
                return NONE;
            }
        }
    }

    private static Object field(Object row, String key) {
        return row instanceof Map<?, ?> mm ? mm.get(key) : null;
    }

    @SuppressWarnings("unchecked")
    static Object map(Map<?, ?> src, String m, List<Object> a) {
        Map<Object, Object> mp = (Map<Object, Object>) src;
        switch (m) {
            case "values" -> {
                return new ArrayList<>(mp.values());
            }
            case "copy" -> {
                return new LinkedHashMap<>(mp);
            }
            case "merge" -> {
                // returns a NEW map with the entries of both
                Map<Object, Object> out = new LinkedHashMap<>(mp);
                if (arg(a, 0) instanceof Map<?, ?> other) out.putAll(other);
                return out;
            }
            case "get" -> {
                Object v = mp.get(Values.str(arg(a, 0)));
                return v == null ? arg(a, 1) : v;
            }
            default -> {
                return NONE;
            }
        }
    }

    // ------------------------------------------------------------------ cd.*  (cooldowns)

    /** The key for a cooldown: a player (by uuid) or any text, plus the cooldown name. */
    private static String cdKey(Object who, Object name) {
        Object id = who;
        if (who instanceof org.bukkit.OfflinePlayer op) id = op.getUniqueId();
        return Values.str(id) + ":" + Values.str(name);
    }

    static Object cd(String fn, List<Object> a) {
        switch (fn) {
            case "use" -> {
                // cd.use(player, "name", seconds): 0 and the cooldown starts, or the seconds still left
                String k = cdKey(arg(a, 0), arg(a, 1));
                long now = System.currentTimeMillis();
                Long until = COOLDOWNS.get(k);
                if (until != null && until > now) return Math.ceil((until - now) / 1000.0);
                COOLDOWNS.put(k, now + (long) (Values.num(arg(a, 2)) * 1000));
                return 0.0;
            }
            case "left" -> {
                Long until = COOLDOWNS.get(cdKey(arg(a, 0), arg(a, 1)));
                long now = System.currentTimeMillis();
                return until == null || until <= now ? 0.0 : Math.ceil((until - now) / 1000.0);
            }
            case "reset" -> {
                COOLDOWNS.remove(cdKey(arg(a, 0), arg(a, 1)));
                return null;
            }
            default -> throw new RyuuException(0, "Unknown function cd." + fn + "()");
        }
    }

    // ------------------------------------------------------------------ json.*

    static Object json(String fn, List<Object> a) {
        switch (fn) {
            case "parse" -> {
                try {
                    return new Json(Values.str(arg(a, 0))).parse();
                } catch (RuntimeException e) {
                    return null;
                }
            }
            case "dump" -> {
                StringBuilder sb = new StringBuilder();
                Json.write(arg(a, 0), sb, false, 0);
                return sb.toString();
            }
            case "pretty" -> {
                StringBuilder sb = new StringBuilder();
                Json.write(arg(a, 0), sb, true, 0);
                return sb.toString();
            }
            default -> throw new RyuuException(0, "Unknown function json." + fn + "()");
        }
    }

    /** A small JSON reader/writer (maps, lists, text, numbers, true/false/null). */
    private static final class Json {
        private final String s;
        private int i;

        Json(String s) {
            this.s = s;
        }

        Object parse() {
            Object v = value();
            ws();
            if (i != s.length()) throw new IllegalStateException("trailing text");
            return v;
        }

        private void ws() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }

        private Object value() {
            ws();
            if (i >= s.length()) throw new IllegalStateException("end");
            char c = s.charAt(i);
            if (c == '{') {
                i++;
                Map<String, Object> m = new LinkedHashMap<>();
                ws();
                if (s.charAt(i) == '}') {
                    i++;
                    return m;
                }
                while (true) {
                    ws();
                    String k = string();
                    ws();
                    expect(':');
                    m.put(k, value());
                    ws();
                    if (s.charAt(i) == ',') {
                        i++;
                        continue;
                    }
                    expect('}');
                    return m;
                }
            }
            if (c == '[') {
                i++;
                List<Object> l = new ArrayList<>();
                ws();
                if (s.charAt(i) == ']') {
                    i++;
                    return l;
                }
                while (true) {
                    l.add(value());
                    ws();
                    if (s.charAt(i) == ',') {
                        i++;
                        continue;
                    }
                    expect(']');
                    return l;
                }
            }
            if (c == '"') return string();
            if (s.startsWith("true", i)) {
                i += 4;
                return true;
            }
            if (s.startsWith("false", i)) {
                i += 5;
                return false;
            }
            if (s.startsWith("null", i)) {
                i += 4;
                return null;
            }
            int st = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw new IllegalStateException("unexpected " + c);
            return Double.parseDouble(s.substring(st, i));
        }

        private void expect(char c) {
            if (i >= s.length() || s.charAt(i) != c) throw new IllegalStateException("expected " + c);
            i++;
        }

        private String string() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return sb.toString();
                if (c == '\\') {
                    char n = s.charAt(i++);
                    switch (n) {
                        case 'n' -> sb.append('\n');
                        case 't' -> sb.append('\t');
                        case 'r' -> sb.append('\r');
                        case 'b' -> sb.append('\b');
                        case 'f' -> sb.append('\f');
                        case 'u' -> {
                            sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                        }
                        default -> sb.append(n);
                    }
                } else {
                    sb.append(c);
                }
            }
            throw new IllegalStateException("unterminated text");
        }

        static void write(Object v, StringBuilder sb, boolean pretty, int depth) {
            if (v == null) {
                sb.append("null");
            } else if (v instanceof Boolean || v instanceof String) {
                if (v instanceof String str) quote(str, sb);
                else sb.append(v);
            } else if (v instanceof Number n) {
                double d = n.doubleValue();
                if (d == Math.rint(d) && Math.abs(d) < 1e15) sb.append((long) d);
                else sb.append(d);
            } else if (v instanceof Map<?, ?> m) {
                if (m.isEmpty()) {
                    sb.append("{}");
                    return;
                }
                sb.append('{');
                boolean first = true;
                for (Map.Entry<?, ?> e : m.entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    nl(sb, pretty, depth + 1);
                    quote(Values.str(e.getKey()), sb);
                    sb.append(pretty ? ": " : ":");
                    write(e.getValue(), sb, pretty, depth + 1);
                }
                nl(sb, pretty, depth);
                sb.append('}');
            } else if (v instanceof List<?> l) {
                if (l.isEmpty()) {
                    sb.append("[]");
                    return;
                }
                sb.append('[');
                boolean first = true;
                for (Object o : l) {
                    if (!first) sb.append(',');
                    first = false;
                    nl(sb, pretty, depth + 1);
                    write(o, sb, pretty, depth + 1);
                }
                nl(sb, pretty, depth);
                sb.append(']');
            } else {
                quote(Values.str(v), sb);
            }
        }

        private static void nl(StringBuilder sb, boolean pretty, int depth) {
            if (!pretty) return;
            sb.append('\n');
            for (int k = 0; k < depth; k++) sb.append("  ");
        }

        private static void quote(String str, StringBuilder sb) {
            sb.append('"');
            for (char c : str.toCharArray()) {
                switch (c) {
                    case '"' -> sb.append("\\\"");
                    case '\\' -> sb.append("\\\\");
                    case '\n' -> sb.append("\\n");
                    case '\r' -> sb.append("\\r");
                    case '\t' -> sb.append("\\t");
                    default -> {
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                    }
                }
            }
            sb.append('"');
        }
    }

    // ------------------------------------------------------------------ file.*  (plugins/ZenTials/files/)

    private static Path fileRoot() {
        return RyuuModule.plugin().getDataFolder().toPath().resolve("files");
    }

    private static Path safe(String name) {
        if (name.isEmpty() || name.contains("..") || name.startsWith("/") || name.startsWith("\\")
                || !name.matches("[A-Za-z0-9_.\\-/]+")) {
            throw new RyuuException(0, "file: use a simple name like 'notes.txt' or 'logs/today.txt'");
        }
        return fileRoot().resolve(name);
    }

    static Object file(String fn, List<Object> a) {
        try {
            switch (fn) {
                case "read" -> {
                    Path p = safe(Values.str(arg(a, 0)));
                    return Files.isRegularFile(p) ? Files.readString(p, StandardCharsets.UTF_8) : null;
                }
                case "lines" -> {
                    Path p = safe(Values.str(arg(a, 0)));
                    return Files.isRegularFile(p) ? new ArrayList<Object>(Files.readAllLines(p, StandardCharsets.UTF_8))
                            : new ArrayList<Object>();
                }
                case "write", "append" -> {
                    Path p = safe(Values.str(arg(a, 0)));
                    Files.createDirectories(p.getParent());
                    String body = Values.str(arg(a, 1));
                    if (fn.equals("append")) {
                        Files.writeString(p, body + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                                StandardOpenOption.APPEND);
                    } else {
                        Files.writeString(p, body, StandardCharsets.UTF_8);
                    }
                    return true;
                }
                case "exists" -> {
                    return Files.exists(safe(Values.str(arg(a, 0))));
                }
                case "delete" -> {
                    return Files.deleteIfExists(safe(Values.str(arg(a, 0))));
                }
                case "list" -> {
                    List<Object> out = new ArrayList<>();
                    Path root = fileRoot();
                    if (!Files.isDirectory(root)) return out;
                    try (Stream<Path> w = Files.walk(root)) {
                        for (Path p : w.filter(Files::isRegularFile).sorted().toList()) {
                            out.add(root.relativize(p).toString().replace('\\', '/'));
                        }
                    }
                    return out;
                }
                default -> throw new RyuuException(0, "Unknown function file." + fn + "()");
            }
        } catch (IOException e) {
            throw new RyuuException(0, "file." + fn + "() failed: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ http.*  (never blocks the server)

    /**
     * http.get(url, "myFunction")           -> myFunction(status, body) runs on the main thread
     * http.post(url, body, "myFunction")    -> same, sends the body as JSON (or plain text)
     * The function name is optional (fire and forget, e.g. for Discord webhooks).
     */
    static Object http(String fn, List<Object> a) {
        String url = Values.str(arg(a, 0));
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            throw new RyuuException(0, "http: the url must start with http:// or https://");
        }
        HttpRequest.Builder rb;
        String callback;
        try {
            rb = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10));
        } catch (IllegalArgumentException e) {
            throw new RyuuException(0, "http: bad url");
        }
        switch (fn) {
            case "get" -> {
                callback = a.size() > 1 ? Values.str(a.get(1)) : "";
                rb.GET();
            }
            case "post" -> {
                String body = Values.str(arg(a, 1));
                callback = a.size() > 2 ? Values.str(a.get(2)) : "";
                String type = body.trim().startsWith("{") || body.trim().startsWith("[")
                        ? "application/json" : "text/plain; charset=utf-8";
                rb.header("Content-Type", type).POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));
            }
            default -> throw new RyuuException(0, "Unknown function http." + fn + "()");
        }
        final String cb = callback;
        HTTP.sendAsync(rb.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).whenComplete((res, err) -> {
            if (cb.isEmpty()) return;
            double status = err == null ? res.statusCode() : 0;
            String body = err == null ? res.body() : String.valueOf(err.getMessage());
            RyuuModule.runLater(() -> {
                Script.FuncDef f = RyuuModule.function(cb);
                if (f != null) Libs.invoke(f, new ArrayList<>(List.of(status, body)), new Ctx(f.script));
            });
        });
        return true;
    }

    // ------------------------------------------------------------------ global helpers

    /** call("functionName", args...) and exists("functionName"): run a script function by name. */
    static Object global(String name, List<Object> a, Ctx c) {
        switch (name) {
            case "call" -> {
                Script.FuncDef f = RyuuModule.function(Values.str(arg(a, 0)));
                if (f == null) throw new RyuuException(0, "call(): no function named '" + Values.str(arg(a, 0)) + "'");
                return Libs.invoke(f, new ArrayList<>(a.subList(1, a.size())), c);
            }
            case "exists" -> {
                return RyuuModule.function(Values.str(arg(a, 0))) != null;
            }
            default -> {
                return NONE;
            }
        }
    }
}
