package com.zentials.ryuu;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** The Bukkit-touching extras: world and entity helpers, boss bars, item options, inventory counting. */
final class ExtraBukkit {
    private static final Map<String, BossBar> BARS = new ConcurrentHashMap<>();

    private ExtraBukkit() {
    }

    private static Object arg(List<Object> a, int i) {
        return i < a.size() ? a.get(i) : null;
    }

    private static Location loc(Object o, String fn) {
        if (o instanceof Location l && l.getWorld() != null) return l;
        throw new RyuuException(0, "server." + fn + "() needs a location (use loc(\"world\", x, y, z))");
    }

    private static Material mat(Object o) {
        Material m = Material.matchMaterial(Values.str(o));
        if (m == null) throw new RyuuException(0, "Unknown material '" + Values.str(o) + "'");
        return m;
    }

    // ------------------------------------------------------------------ server.* extras

    static Object server(String fn, List<Object> a) {
        switch (fn) {
            case "setblock" -> {
                loc(arg(a, 0), fn).getBlock().setType(mat(arg(a, 1)));
                return true;
            }
            case "blockat" -> {
                return loc(arg(a, 0), fn).getBlock();
            }
            case "spawn" -> {
                // server.spawn("ZOMBIE", loc) -> the entity
                EntityType et;
                try {
                    et = EntityType.valueOf(Values.str(arg(a, 0)).toUpperCase(Locale.ROOT).replace(' ', '_'));
                } catch (IllegalArgumentException e) {
                    throw new RyuuException(0, "Unknown entity type '" + Values.str(arg(a, 0)) + "'");
                }
                Location l = loc(arg(a, 1), fn);
                Entity en = l.getWorld().spawnEntity(l, et);
                return en;
            }
            case "strike" -> {
                Location l = loc(arg(a, 0), fn);
                l.getWorld().strikeLightning(l);
                return true;
            }
            case "explode" -> {
                // server.explode(loc, power, breakBlocks)  (breakBlocks defaults to false)
                Location l = loc(arg(a, 0), fn);
                float power = (float) Values.num(arg(a, 1));
                boolean breaks = a.size() > 2 && Values.truthy(a.get(2));
                l.getWorld().createExplosion(l, power, false, breaks);
                return true;
            }
            case "drop" -> {
                Location l = loc(arg(a, 0), fn);
                Object it = arg(a, 1);
                ItemStack st = it instanceof ItemStack is ? is : new ItemStack(mat(it));
                return l.getWorld().dropItemNaturally(l, st);
            }
            case "players" -> {
                // server.players("world") -> online players in that world
                List<Object> out = new ArrayList<>();
                World w = Bukkit.getWorld(Values.str(arg(a, 0)));
                if (w != null) out.addAll(w.getPlayers());
                return out;
            }
            case "worlds" -> {
                List<Object> out = new ArrayList<>();
                for (World w : Bukkit.getWorlds()) out.add(w.getName());
                return out;
            }
            case "tps" -> {
                double[] t = Bukkit.getTPS();
                return Math.min(20.0, Math.round(t[0] * 100.0) / 100.0);
            }
            case "plugin" -> {
                // server.plugin("LuckPerms") -> true when installed and enabled
                return Bukkit.getPluginManager().isPluginEnabled(Values.str(arg(a, 0)));
            }
            case "motd" -> {
                return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                        .serialize(Bukkit.motd());
            }
            default -> {
                return Extra.NONE;
            }
        }
    }

    // ------------------------------------------------------------------ item options

    private static Enchantment enchant(String name) {
        String key = name.toLowerCase(Locale.ROOT).replace(' ', '_');
        NamespacedKey nk = key.contains(":") ? NamespacedKey.fromString(key) : NamespacedKey.minecraft(key);
        return nk == null ? null : Registry.ENCHANTMENT.get(nk);
    }

    /**
     * item("DIAMOND_SWORD", "&bName", lore, map("enchants", map("sharpness", 5), "glow", true, ...))
     * keys: amount, enchants, glow, unbreakable, hide, model, damage, head
     */
    static ItemStack decorate(ItemStack it, Map<?, ?> o) {
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            if (o.get("enchants") instanceof Map<?, ?> em) {
                for (Map.Entry<?, ?> e : em.entrySet()) {
                    Enchantment en = enchant(Values.str(e.getKey()));
                    if (en != null) meta.addEnchant(en, Math.max(1, Values.intv(e.getValue())), true);
                }
            }
            if (Values.truthy(o.get("glow"))) meta.setEnchantmentGlintOverride(true);
            if (Values.truthy(o.get("unbreakable"))) meta.setUnbreakable(true);
            if (Values.truthy(o.get("hide"))) meta.addItemFlags(ItemFlag.values());
            if (o.get("model") != null) meta.setCustomModelData(Values.intv(o.get("model")));
            if (o.get("damage") != null && meta instanceof Damageable d) d.setDamage(Values.intv(o.get("damage")));
            if (o.get("head") != null && meta instanceof SkullMeta sm) {
                String who = Values.str(o.get("head"));
                OfflinePlayer op = null;
                try {
                    op = Bukkit.getOfflinePlayer(UUID.fromString(who));
                } catch (IllegalArgumentException notUuid) {
                    op = Bukkit.getOfflinePlayerIfCached(who);
                }
                if (op != null) sm.setOwningPlayer(op);
            }
            it.setItemMeta(meta);
        }
        if (o.get("amount") != null) it.setAmount(Math.max(1, Math.min(99, Values.intv(o.get("amount")))));
        return it;
    }

    // ------------------------------------------------------------------ player inventory

    /** How many of this material the player carries (storage and hotbar). */
    static double count(Player p, Object material) {
        Material m = mat(material);
        PlayerInventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv.getItem(i);
            if (st != null && st.getType() == m) n += st.getAmount();
        }
        return n;
    }

    /** Removes up to n of the material; false (and nothing removed) if the player has less than n. */
    static boolean take(Player p, Object material, int n) {
        if (count(p, material) < n) return false;
        Material m = mat(material);
        PlayerInventory inv = p.getInventory();
        int left = n;
        for (int i = 0; i < 36 && left > 0; i++) {
            ItemStack st = inv.getItem(i);
            if (st == null || st.getType() != m) continue;
            int take = Math.min(left, st.getAmount());
            left -= take;
            if (take >= st.getAmount()) {
                inv.setItem(i, null);
            } else {
                st.setAmount(st.getAmount() - take);
                inv.setItem(i, st);
            }
        }
        return true;
    }

    static Object slot(Player p, int i) {
        return i < 0 || i >= 36 ? null : p.getInventory().getItem(i);
    }

    static void setSlot(Player p, int i, Object item) {
        if (i < 0 || i >= 36) throw new RyuuException(0, "setslot: slot must be 0 to 35");
        ItemStack st = null;
        if (item instanceof ItemStack is) st = is;
        else if (item != null) st = new ItemStack(mat(item));
        p.getInventory().setItem(i, st);
    }

    // ------------------------------------------------------------------ bossbar.*

    private static String barKey(Object p, Object id) {
        return (p instanceof Player pl ? pl.getUniqueId().toString() : Values.str(p)) + ":" + Values.str(id);
    }

    private static <E extends Enum<E>> E enumOf(Class<E> cls, Object name, E fallback) {
        if (name == null) return fallback;
        try {
            return Enum.valueOf(cls, Values.str(name).toUpperCase(Locale.ROOT).replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    /**
     * bossbar.show(p, "id", "title", 0.5, "RED", "NOTCHED_10")   progress is 0 to 1
     * bossbar.update(p, "id", "title", 0.8)     bossbar.hide(p, "id")     bossbar.clear(p)
     */
    static Object bossbar(String fn, List<Object> a) {
        if (!(arg(a, 0) instanceof Player p)) throw new RyuuException(0, "bossbar." + fn + "() needs an online player");
        switch (fn) {
            case "show", "update" -> {
                String key = barKey(p, arg(a, 1));
                float progress = (float) Math.max(0, Math.min(1, Values.num(arg(a, 3))));
                net.kyori.adventure.text.Component title = com.zentials.core.Text.c(Values.str(arg(a, 2)));
                BossBar bar = BARS.get(key);
                if (bar == null) {
                    bar = BossBar.bossBar(title, progress, enumOf(BossBar.Color.class, arg(a, 4), BossBar.Color.WHITE),
                            enumOf(BossBar.Overlay.class, arg(a, 5), BossBar.Overlay.PROGRESS));
                    BARS.put(key, bar);
                    p.showBossBar(bar);
                } else {
                    bar.name(title);
                    bar.progress(progress);
                    if (arg(a, 4) != null) bar.color(enumOf(BossBar.Color.class, arg(a, 4), BossBar.Color.WHITE));
                    p.showBossBar(bar);
                }
                return true;
            }
            case "hide" -> {
                BossBar bar = BARS.remove(barKey(p, arg(a, 1)));
                if (bar != null) p.hideBossBar(bar);
                return true;
            }
            case "clear" -> {
                String prefix = p.getUniqueId() + ":";
                for (String k : new ArrayList<>(BARS.keySet())) {
                    if (k.startsWith(prefix)) {
                        BossBar bar = BARS.remove(k);
                        if (bar != null) p.hideBossBar(bar);
                    }
                }
                return true;
            }
            default -> throw new RyuuException(0, "Unknown function bossbar." + fn + "()");
        }
    }

    /** Hides every boss bar a script made (used when scripts are reloaded). */
    static void clearBars() {
        for (Map.Entry<String, BossBar> e : new ArrayList<>(BARS.entrySet())) {
            String uid = e.getKey().substring(0, e.getKey().indexOf(':'));
            try {
                Player p = Bukkit.getPlayer(UUID.fromString(uid));
                if (p != null) p.hideBossBar(e.getValue());
            } catch (IllegalArgumentException ignored) {
                // not a player key
            }
        }
        BARS.clear();
    }
}
