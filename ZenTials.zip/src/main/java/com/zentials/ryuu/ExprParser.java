package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Compiles an expression into an Expr (a tree of small lambdas).
 * <p>
 * Most things can be written more than one way, so scripters from other languages feel at home:
 * <pre>
 *   a == b   a = b   a is b   a equals b   a is equal to b            (equal)
 *   a != b   a <> b  a is not b   a isn't b                           (not equal)
 *   a and b  a && b      a or b  a || b      not a   !a
 *   a > b    a is greater than b   a is more than b   a is above b   a is over b
 *   a >= b   a is at least b       a is greater than or equal to b
 *   x is between 1 and 5     x in list   x not in list   x is in list
 *   text contains "a"   text does not contain "a"   text starts with "a"   text ends with "a"   text matches "re"
 *   x is set   x is not set   x is empty   x is a number   x is a text   player is online   player has permission "a.b"
 *   a + b   a plus b   a - b   a minus b   a * b   a times b   a / b   a divided by b   a % b   a mod b
 *   "a" & b   (join as text)      1..10  (a list of numbers)     5k = 5000   2.5m = 2500000   1_000
 *   cond ? a : b      a if cond else b
 *   "Hi %player.name%"   "Hi {player.name}"   "Hi {_name}"   "{@option}"
 *   name of player   size of list   first of list   item 2 of list (1-based)   random element of list   all players
 *   [1, 2, 3]   {"key": 1, other: 2}     yes/no/on/off  nothing/none/null
 * </pre>
 */
final class ExprParser {
    private static final Set<String> RESERVED = Set.of("true", "false", "null", "none", "nothing", "yes", "no", "on", "off",
            "and", "or", "not", "in", "is", "isnt", "if", "else", "of", "contains", "contain", "between", "has", "mod", "plus",
            "minus", "times", "divided", "multiplied", "starts", "ends", "matches", "does", "doesnt", "exists", "equals", "equal");

    /** "player is online": words that mean "ask the object for this true/false property". */
    private static final Set<String> FLAGS = Set.of("online", "op", "flying", "sneaking", "sprinting", "dead", "valid",
            "blocking", "gliding", "swimming", "burning", "invisible", "sleeping", "glowing", "silent", "banned", "whitelisted");

    private final List<Lexer.Tok> t;
    private final int line;
    private int p;

    private ExprParser(String src, int line) {
        this.t = Lexer.lex(src, line);
        this.line = line;
    }

    static Expr compile(String src, int line) {
        ExprParser ep = new ExprParser(src, line);
        Expr e = ep.ternary();
        if (ep.peek().t() != Lexer.T.EOF) {
            throw new RyuuException(line, "Unexpected '" + ep.peek().s() + "' in: " + src.trim());
        }
        return e;
    }

    // ---------------------------------------------------------------- token helpers

    private Lexer.Tok peek() {
        return t.get(p);
    }

    private Lexer.Tok peek(int ahead) {
        return t.get(Math.min(p + ahead, t.size() - 1));
    }

    private Lexer.Tok next() {
        return t.get(p++);
    }

    private boolean isOp(String s) {
        Lexer.Tok k = peek();
        return k.t() == Lexer.T.OP && k.s().equals(s);
    }

    private boolean isId(String s) {
        Lexer.Tok k = peek();
        return k.t() == Lexer.T.ID && k.s().equals(s);
    }

    private boolean isIdAt(int ahead, String s) {
        Lexer.Tok k = peek(ahead);
        return k.t() == Lexer.T.ID && k.s().equals(s);
    }

    private void expectOp(String s) {
        if (!isOp(s)) throw new RyuuException(line, "Expected '" + s + "' but found '" + peek().s() + "'");
        p++;
    }

    private void expectId(String s) {
        if (!isId(s)) throw new RyuuException(line, "Expected '" + s + "' but found '" + peek().s() + "'");
        p++;
    }

    // ---------------------------------------------------------------- grammar

    /** a if cond else b   |   cond ? a : b */
    private Expr ternary() {
        Expr e = or();
        if (isId("if")) {
            p++;
            Expr cond = or();
            if (!isId("else")) throw new RyuuException(line, "Write it like:  value if condition else other");
            p++;
            Expr other = ternary();
            Expr then = e;
            return c -> Values.truthy(cond.eval(c)) ? then.eval(c) : other.eval(c);
        }
        if (isOp("?")) {
            p++;
            Expr a = ternary();
            expectOp(":");
            Expr b = ternary();
            Expr cond = e;
            return c -> Values.truthy(cond.eval(c)) ? a.eval(c) : b.eval(c);
        }
        return e;
    }

    private Expr or() {
        Expr l = and();
        while (isId("or") || isOp("||")) {
            p++;
            Expr a = l;
            Expr b = and();
            l = c -> Values.truthy(a.eval(c)) || Values.truthy(b.eval(c));
        }
        return l;
    }

    private Expr and() {
        Expr l = not();
        while (isId("and") || isOp("&&")) {
            p++;
            Expr a = l;
            Expr b = not();
            l = c -> Values.truthy(a.eval(c)) && Values.truthy(b.eval(c));
        }
        return l;
    }

    private Expr not() {
        if (isId("not") || isOp("!")) {
            p++;
            Expr e = not();
            return c -> !Values.truthy(e.eval(c));
        }
        return cmp();
    }

    private static Expr negate(Expr e) {
        return c -> !Values.truthy(e.eval(c));
    }

    private static Expr eq(Expr a, Expr b) {
        return c -> Values.eq(a.eval(c), b.eval(c));
    }

    private Expr cmp() {
        Expr l = range();
        while (true) {
            Lexer.Tok k = peek();
            if (k.t() == Lexer.T.OP && (k.s().equals("==") || k.s().equals("=") || k.s().equals("!=") || k.s().equals("<")
                    || k.s().equals("<=") || k.s().equals(">") || k.s().equals(">="))) {
                p++;
                String op = k.s();
                Expr a = l;
                Expr b = range();
                l = switch (op) {
                    case "==", "=" -> c -> Values.eq(a.eval(c), b.eval(c));
                    case "!=" -> c -> !Values.eq(a.eval(c), b.eval(c));
                    case "<" -> c -> Values.compare(a.eval(c), b.eval(c)) < 0;
                    case "<=" -> c -> Values.compare(a.eval(c), b.eval(c)) <= 0;
                    case ">" -> c -> Values.compare(a.eval(c), b.eval(c)) > 0;
                    default -> c -> Values.compare(a.eval(c), b.eval(c)) >= 0;
                };
            } else if (k.t() == Lexer.T.ID) {
                Expr r = wordOp(l);
                if (r == null) return l;
                l = r;
            } else {
                return l;
            }
        }
    }

    /** The operators written as words. Returns null (and consumes nothing) when the next word is not one. */
    private Expr wordOp(Expr l) {
        int save = p;
        String w = peek().s();
        switch (w) {
            case "in" -> {
                p++;
                Expr b = range();
                return c -> contains(b.eval(c), l.eval(c));
            }
            case "is", "isnt" -> {
                p++;
                boolean neg = w.equals("isnt");
                if (!neg && isId("not")) {
                    p++;
                    neg = true;
                }
                Expr e = isTail(l);
                if (e == null) {
                    p = save;
                    return null;
                }
                return neg ? negate(e) : e;
            }
            case "equals" -> {
                p++;
                return eq(l, range());
            }
            case "equal" -> {
                if (!isIdAt(1, "to")) return null;
                p += 2;
                return eq(l, range());
            }
            case "contains", "contain" -> {
                p++;
                Expr b = range();
                return c -> contains(l.eval(c), b.eval(c));
            }
            case "does", "doesnt" -> {
                p++;
                boolean neg = true;
                if (w.equals("does")) {
                    if (isId("not")) p++;
                    else neg = false;
                }
                Expr e = verb(l);
                if (e == null) {
                    p = save;
                    return null;
                }
                return neg ? negate(e) : e;
            }
            case "starts", "ends", "matches", "exists" -> {
                Expr e = verb(l);
                if (e == null) {
                    p = save;
                    return null;
                }
                return e;
            }
            case "has" -> {
                if (!isIdAt(1, "permission") && !isIdAt(1, "perm")) return null;
                p += 2;
                Expr b = range();
                return c -> Values.hasPerm(l.eval(c), b.eval(c));
            }
            case "between" -> {
                p++;
                return betweenTail(l);
            }
            case "not" -> {
                if (!isIdAt(1, "in")) return null;
                p += 2;
                Expr b = range();
                return c -> !contains(b.eval(c), l.eval(c));
            }
            default -> {
                return null;
            }
        }
    }

    /** After "does not": contain(s) | start(s) with | end(s) with | exist(s) | match(es) | equal */
    private Expr verb(Expr l) {
        String v = peek().s();
        switch (v) {
            case "contain", "contains" -> {
                p++;
                Expr b = range();
                return c -> contains(l.eval(c), b.eval(c));
            }
            case "start", "starts" -> {
                p++;
                expectId("with");
                Expr b = range();
                return c -> Ops.startsWith(l.eval(c), b.eval(c));
            }
            case "end", "ends" -> {
                p++;
                expectId("with");
                Expr b = range();
                return c -> Ops.endsWith(l.eval(c), b.eval(c));
            }
            case "match", "matches" -> {
                p++;
                Expr b = range();
                return c -> Ops.matches(l.eval(c), b.eval(c));
            }
            case "exist", "exists" -> {
                p++;
                return c -> l.eval(c) != null;
            }
            case "equal" -> {
                p++;
                if (isId("to")) p++;
                return eq(l, range());
            }
            default -> {
                return null;
            }
        }
    }

    private Expr betweenTail(Expr l) {
        Expr lo = add();
        expectId("and");
        Expr hi = add();
        return c -> Ops.between(l.eval(c), lo.eval(c), hi.eval(c));
    }

    private Expr compareTail(Expr l, int mode) {
        // mode: 0 >, 1 >=, 2 <, 3 <=
        if (isId("or") && isIdAt(1, "equal")) {
            p += 2;
            if (isId("to")) p++;
            mode = mode == 0 ? 1 : 3;
        }
        Expr b = range();
        final int m = mode;
        return switch (m) {
            case 0 -> c -> Values.compare(l.eval(c), b.eval(c)) > 0;
            case 1 -> c -> Values.compare(l.eval(c), b.eval(c)) >= 0;
            case 2 -> c -> Values.compare(l.eval(c), b.eval(c)) < 0;
            default -> c -> Values.compare(l.eval(c), b.eval(c)) <= 0;
        };
    }

    /** What follows "is" / "is not". null when it does not look like anything we know. */
    private Expr isTail(Expr l) {
        Lexer.Tok k = peek();
        if (k.t() == Lexer.T.ID) {
            switch (k.s()) {
                case "set" -> {
                    p++;
                    return c -> l.eval(c) != null;
                }
                case "empty" -> {
                    p++;
                    return c -> Ops.isEmpty(l.eval(c));
                }
                case "a", "an" -> {
                    if (peek(1).t() == Lexer.T.ID && Ops.knownType(peek(1).s())) {
                        String type = peek(1).s();
                        p += 2;
                        return c -> Ops.isType(l.eval(c), type);
                    }
                }
                case "between" -> {
                    p++;
                    return betweenTail(l);
                }
                case "in" -> {
                    p++;
                    Expr b = range();
                    return c -> contains(b.eval(c), l.eval(c));
                }
                case "greater", "more", "bigger", "higher" -> {
                    if (!isIdAt(1, "than")) return null;
                    p += 2;
                    return compareTail(l, 0);
                }
                case "less", "smaller", "lower", "fewer" -> {
                    if (!isIdAt(1, "than")) return null;
                    p += 2;
                    return compareTail(l, 2);
                }
                case "above", "over" -> {
                    p++;
                    return compareTail(l, 0);
                }
                case "below", "under" -> {
                    p++;
                    return compareTail(l, 2);
                }
                case "at" -> {
                    if (isIdAt(1, "least")) {
                        p += 2;
                        return compareTail(l, 1);
                    }
                    if (isIdAt(1, "most")) {
                        p += 2;
                        return compareTail(l, 3);
                    }
                    return null;
                }
                case "equal" -> {
                    p++;
                    if (isId("to")) p++;
                    return eq(l, range());
                }
                default -> {
                    if (FLAGS.contains(k.s()) && !(peek(1).t() == Lexer.T.OP && peek(1).s().equals("("))) {
                        String flag = k.s();
                        p++;
                        return c -> Values.truthy(Access.get(l.eval(c), flag));
                    }
                }
            }
        }
        // "a is b" = equality
        if (k.t() == Lexer.T.EOF) return null;
        return eq(l, range());
    }

    private static boolean contains(Object haystack, Object needle) {
        if (haystack instanceof List<?> list) {
            for (Object o : list) if (Values.eq(o, needle)) return true;
            return false;
        }
        if (haystack instanceof Map<?, ?> m) return m.containsKey(Values.str(needle));
        if (haystack instanceof String s) return s.contains(Values.str(needle));
        return false;
    }

    /** 1..10 */
    private Expr range() {
        Expr a = add();
        if (isOp("..")) {
            p++;
            Expr b = add();
            return c -> Ops.range(a.eval(c), b.eval(c));
        }
        return a;
    }

    private Expr add() {
        Expr l = mul();
        while (true) {
            Expr a = l;
            if (isOp("+")) {
                p++;
                Expr b = mul();
                l = c -> Values.add(a.eval(c), b.eval(c));
            } else if (isOp("-") || isId("minus")) {
                p++;
                Expr b = mul();
                l = c -> Values.num(a.eval(c)) - Values.num(b.eval(c));
            } else if (isId("plus")) {
                p++;
                Expr b = mul();
                l = c -> Values.add(a.eval(c), b.eval(c));
            } else if (isOp("&")) {
                p++;
                Expr b = mul();
                l = c -> Ops.join(a.eval(c), b.eval(c));
            } else {
                return l;
            }
        }
    }

    private Expr mul() {
        Expr l = unary();
        while (true) {
            Expr a = l;
            if (isOp("*") || isId("times")) {
                p++;
                Expr b = unary();
                l = c -> Values.num(a.eval(c)) * Values.num(b.eval(c));
            } else if (isId("multiplied") && isIdAt(1, "by")) {
                p += 2;
                Expr b = unary();
                l = c -> Values.num(a.eval(c)) * Values.num(b.eval(c));
            } else if (isOp("/") || (isId("divided") && isIdAt(1, "by"))) {
                p += isOp("/") ? 1 : 2;
                Expr b = unary();
                l = c -> {
                    double d = Values.num(b.eval(c));
                    if (d == 0) throw new RyuuException(0, "Division by zero");
                    return Values.num(a.eval(c)) / d;
                };
            } else if (isOp("%") || isId("mod")) {
                p++;
                Expr b = unary();
                l = c -> {
                    double d = Values.num(b.eval(c));
                    if (d == 0) throw new RyuuException(0, "Division by zero");
                    return Values.num(a.eval(c)) % d;
                };
            } else {
                return l;
            }
        }
    }

    private Expr unary() {
        if (isOp("-")) {
            p++;
            Expr e = unary();
            return c -> -Values.num(e.eval(c));
        }
        return postfix();
    }

    private List<Expr> args() {
        expectOp("(");
        List<Expr> out = new ArrayList<>();
        if (isOp(")")) {
            p++;
            return out;
        }
        while (true) {
            out.add(ternary());
            if (isOp(",")) {
                p++;
                continue;
            }
            expectOp(")");
            return out;
        }
    }

    private static List<Object> evalAll(List<Expr> args, Ctx c) {
        List<Object> out = new ArrayList<>(args.size());
        for (Expr a : args) out.add(a.eval(c));
        return out;
    }

    private Expr postfix() {
        Expr e = primary();
        while (true) {
            if (isOp(".")) {
                p++;
                Lexer.Tok name = next();
                if (name.t() != Lexer.T.ID) throw new RyuuException(line, "Expected a name after '.'");
                String n = name.s();
                Expr target = e;
                if (isOp("(")) {
                    List<Expr> a = args();
                    String ln = n.toLowerCase(Locale.ROOT);   // lower-cased once here, not on every call
                    e = c -> Access.call(target.eval(c), ln, evalAll(a, c), c);
                } else {
                    e = c -> Access.get(target.eval(c), n);
                }
            } else if (isOp("[")) {
                p++;
                Expr idx = ternary();
                expectOp("]");
                Expr target = e;
                e = c -> Access.index(target.eval(c), idx.eval(c));
            } else {
                return e;
            }
        }
    }

    private Expr primary() {
        Lexer.Tok k = next();
        switch (k.t()) {
            case NUM -> {
                Double d = k.n();
                return c -> d;
            }
            case STR -> {
                return text(k.s());
            }
            case ID -> {
                return idPrimary(k.s());
            }
            case OP -> {
                if (k.s().equals("(")) {
                    Expr e = ternary();
                    expectOp(")");
                    return e;
                }
                if (k.s().equals("[")) {
                    List<Expr> items = new ArrayList<>();
                    if (isOp("]")) {
                        p++;
                    } else {
                        while (true) {
                            items.add(ternary());
                            if (isOp(",")) {
                                p++;
                                if (isOp("]")) {   // trailing comma
                                    p++;
                                    break;
                                }
                                continue;
                            }
                            expectOp("]");
                            break;
                        }
                    }
                    return c -> evalAll(items, c);
                }
                if (k.s().equals("{")) return mapLiteral();
                throw new RyuuException(line, "Unexpected '" + k.s() + "'");
            }
            default -> throw new RyuuException(line, "Unexpected end of expression");
        }
    }

    /** {"a": 1, b: 2}  (a bare word before the colon is the key as text) */
    private Expr mapLiteral() {
        List<Expr> keys = new ArrayList<>();
        List<Expr> vals = new ArrayList<>();
        if (isOp("}")) {
            p++;
        } else {
            while (true) {
                Expr key;
                if (peek().t() == Lexer.T.ID && peek(1).t() == Lexer.T.OP && peek(1).s().equals(":")) {
                    String kn = next().s();
                    key = c -> kn;
                } else if (peek().t() == Lexer.T.NUM && peek(1).t() == Lexer.T.OP && peek(1).s().equals(":")) {
                    String kn = next().s();
                    key = c -> kn;
                } else {
                    key = ternary();
                }
                expectOp(":");
                keys.add(key);
                vals.add(ternary());
                if (isOp(",")) {
                    p++;
                    if (isOp("}")) {
                        p++;
                        break;
                    }
                    continue;
                }
                expectOp("}");
                break;
            }
        }
        return c -> {
            Map<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i < keys.size(); i++) m.put(Values.str(keys.get(i).eval(c)), vals.get(i).eval(c));
            return m;
        };
    }

    private Expr idPrimary(String n) {
        switch (n) {
            case "true", "yes", "on" -> {
                return c -> Boolean.TRUE;
            }
            case "false", "no", "off" -> {
                return c -> Boolean.FALSE;
            }
            case "null", "none", "nothing" -> {
                return c -> null;
            }
            default -> {
            }
        }
        // all players / online players / every player
        if ((n.equals("all") || n.equals("online") || n.equals("every")) && (isId("players") || isId("player"))) {
            p++;
            return c -> Libs.SERVER.call("online", List.of(), c);
        }
        if (n.equals("random") && !isOp("(")) {
            if (isId("player")) {
                p++;
                return c -> Ops.randomOf(Libs.SERVER.call("online", List.of(), c));
            }
            boolean named = false;
            if (isId("element") || isId("item") || isId("entry")) {
                p++;
                named = true;
            }
            if (isId("of") || isId("from") || isId("in")) {
                p++;
                Expr target = postfix();
                return c -> Ops.randomOf(target.eval(c));
            }
            if (named) throw new RyuuException(line, "Write it like:  random element of list");
        }
        // item 2 of list   (1-based, like Skript)
        if ((n.equals("item") || n.equals("element") || n.equals("entry")) && peek().t() == Lexer.T.NUM) {
            double idx = next().n();
            if (!isId("of")) throw new RyuuException(line, "Write it like:  item 2 of list");
            p++;
            Expr target = postfix();
            return c -> Ops.nth(target.eval(c), idx);
        }
        if (isOp("(")) {
            List<Expr> a = args();
            return c -> Libs.callGlobal(n, evalAll(a, c), c);
        }
        // name of player, size of list, first of list
        if (isId("of") && !RESERVED.contains(n)) {
            p++;
            Expr target = postfix();
            return c -> Ops.ofProp(target.eval(c), n);
        }
        return c -> c.get(n);
    }

    // ---------------------------------------------------------------- text with {expressions} and %expressions%

    private Expr tryCompile(String inner) {
        try {
            return compile(inner, line);
        } catch (RyuuException e) {
            return null;
        }
    }

    private static boolean plainWord(String s) {
        if (s.isEmpty() || !(Character.isLetter(s.charAt(0)) || s.charAt(0) == '_')) return false;
        for (int i = 1; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (!(Character.isLetterOrDigit(ch) || ch == '_')) return false;
        }
        return true;
    }

    private Expr text(String raw) {
        List<Object> parts = new ArrayList<>();
        StringBuilder lit = new StringBuilder();
        int i = 0;
        while (i < raw.length()) {
            char ch = raw.charAt(i);
            if (ch == '\\' && i + 1 < raw.length()) {
                char d = raw.charAt(i + 1);
                switch (d) {
                    case 'n' -> lit.append('\n');
                    case 't' -> lit.append('\t');
                    default -> lit.append(d);
                }
                i += 2;
                continue;
            }
            if (ch == '{') {
                int depth = 1;
                int j = i + 1;
                while (j < raw.length() && depth > 0) {
                    char d = raw.charAt(j);
                    if (d == '\\') {
                        j += 2;
                        continue;
                    }
                    if (d == '{') depth++;
                    else if (d == '}') depth--;
                    j++;
                }
                if (depth != 0) throw new RyuuException(line, "Missing } in text: " + raw);
                String inner = raw.substring(i + 1, j - 1);
                if (lit.length() > 0) {
                    parts.add(lit.toString());
                    lit.setLength(0);
                }
                // Skript style option:  {@prefix}  works the same as  {opt.prefix}
                String ie = inner.trim();
                if (ie.startsWith("@") && ie.length() > 1) ie = "opt." + ie.substring(1).trim();
                parts.add(compile(ie, line));
                i = j;
                continue;
            }
            if (ch == '%') {
                // "Hello %player.name%": Skript style. Falls back to plain text when it is not an expression,
                // and a plain %word% whose variable is not set stays as it is (PlaceholderAPI placeholders).
                int j = raw.indexOf('%', i + 1);
                if (j > i + 1) {
                    String inner = raw.substring(i + 1, j);
                    if (inner.equals(inner.trim()) && inner.length() <= 80 && inner.indexOf('{') < 0
                            && (Character.isLetter(inner.charAt(0)) || inner.charAt(0) == '_')) {
                        Expr e = tryCompile(inner);
                        if (e != null) {
                            if (lit.length() > 0) {
                                parts.add(lit.toString());
                                lit.setLength(0);
                            }
                            if (plainWord(inner)) {
                                String keep = "%" + inner + "%";
                                parts.add((Expr) c -> {
                                    Object v = e.eval(c);
                                    return v == null ? keep : v;
                                });
                            } else {
                                parts.add(e);
                            }
                            i = j + 1;
                            continue;
                        }
                    }
                }
            }
            lit.append(ch);
            i++;
        }
        if (lit.length() > 0) parts.add(lit.toString());
        if (parts.isEmpty()) return c -> "";
        if (parts.size() == 1 && parts.get(0) instanceof String s) return c -> s;
        final Object[] arr = parts.toArray();
        return c -> {
            StringBuilder sb = new StringBuilder(32);
            for (Object o : arr) {
                if (o instanceof String s) sb.append(s);
                else sb.append(Values.str(((Expr) o).eval(c)));
            }
            return sb.toString();
        };
    }
}
