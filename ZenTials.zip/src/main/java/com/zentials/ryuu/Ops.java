package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Small value helpers used by the word operators of the expression parser (is, contains, between, of ...). */
final class Ops {
    private static final int MAX_RANGE = 100_000;
    private static final Map<String, Pattern> REGEX = new ConcurrentHashMap<>();

    private Ops() {
    }

    static boolean isEmpty(Object o) {
        if (o == null) return true;
        if (o instanceof String s) return s.isEmpty();
        if (o instanceof Collection<?> c) return c.isEmpty();
        if (o instanceof Map<?, ?> m) return m.isEmpty();
        return false;
    }

    /** Type words allowed after "is a". */
    static boolean knownType(String t) {
        return switch (t) {
            case "number", "num", "integer", "int", "text", "string", "list", "map", "boolean", "bool", "player", "world",
                 "item", "entity", "location", "block" -> true;
            default -> false;
        };
    }

    static boolean isType(Object o, String kind) {
        switch (kind) {
            case "number", "num" -> {
                if (o instanceof Number) return true;
                if (o instanceof String s) {
                    try {
                        Double.parseDouble(s.trim());
                        return true;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                }
                return false;
            }
            case "integer", "int" -> {
                if (o instanceof Number n) return n.doubleValue() == Math.rint(n.doubleValue());
                if (o instanceof String s) {
                    try {
                        Long.parseLong(s.trim());
                        return true;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                }
                return false;
            }
            case "text", "string" -> {
                return o instanceof String;
            }
            case "list" -> {
                return o instanceof List;
            }
            case "map" -> {
                return o instanceof Map;
            }
            case "boolean", "bool" -> {
                return o instanceof Boolean;
            }
            default -> {
                return Values.isKind(o, kind);
            }
        }
    }

    static boolean startsWith(Object a, Object b) {
        return Values.str(a).startsWith(Values.str(b));
    }

    static boolean endsWith(Object a, Object b) {
        return Values.str(a).endsWith(Values.str(b));
    }

    static boolean matches(Object a, Object regex) {
        String rx = Values.str(regex);
        Pattern p = REGEX.get(rx);
        if (p == null) {
            try {
                p = Pattern.compile(rx);
            } catch (PatternSyntaxException e) {
                throw new RyuuException(0, "Bad pattern '" + rx + "': " + e.getDescription());
            }
            if (REGEX.size() > 500) REGEX.clear();
            REGEX.put(rx, p);
        }
        return p.matcher(Values.str(a)).matches();
    }

    static boolean between(Object v, Object lo, Object hi) {
        double x = Values.num(v);
        double a = Values.num(lo);
        double b = Values.num(hi);
        return x >= Math.min(a, b) && x <= Math.max(a, b);
    }

    /** a & b : always joins as text. */
    static String join(Object a, Object b) {
        return Values.str(a) + Values.str(b);
    }

    static Object randomOf(Object o) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (o instanceof List<?> l) return l.isEmpty() ? null : l.get(r.nextInt(l.size()));
        if (o instanceof Collection<?> c) {
            if (c.isEmpty()) return null;
            int k = r.nextInt(c.size());
            for (Object x : c) if (k-- == 0) return x;
            return null;
        }
        if (o instanceof Map<?, ?> m) return randomOf(new ArrayList<>(m.keySet()));
        if (o instanceof Number n) return (double) (1 + r.nextInt(Math.max(1, (int) n.doubleValue())));
        return null;
    }

    /** "size of list", "name of player", "uppercase of text": properties written the English way. */
    static Object ofProp(Object target, String prop) {
        switch (prop.toLowerCase(Locale.ROOT)) {
            case "size", "amount", "number", "count", "length" -> {
                if (target == null) return 0.0;
                if (target instanceof Collection<?> c) return (double) c.size();
                if (target instanceof Map<?, ?> m) return (double) m.size();
                if (target instanceof String s) return (double) s.length();
            }
            case "uppercase" -> {
                if (target instanceof String s) return s.toUpperCase(Locale.ROOT);
            }
            case "lowercase" -> {
                if (target instanceof String s) return s.toLowerCase(Locale.ROOT);
            }
            default -> {
            }
        }
        return Access.get(target, prop);
    }

    /** 1-based "item 3 of list" (Skript style). */
    static Object nth(Object target, Object n) {
        return Access.index(target, Values.num(n) - 1);
    }

    /** 1..10 and 10..1 as a list of numbers (at most 100000 of them). */
    static List<Object> range(Object a, Object b) {
        long from = (long) Math.floor(Values.num(a));
        long to = (long) Math.floor(Values.num(b));
        long count = Math.abs(to - from) + 1;
        if (count > MAX_RANGE) throw new RyuuException(0, "A range can have at most " + MAX_RANGE + " numbers (got " + count + ")");
        List<Object> out = new ArrayList<>((int) count);
        if (from <= to) for (long i = from; i <= to; i++) out.add((double) i);
        else for (long i = from; i >= to; i--) out.add((double) i);
        return out;
    }
}
