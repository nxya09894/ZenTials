package com.zentials.ryuu;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/** Script event names and the variables each one gives to the script. */
final class EventDefs {
    /**
     * keys = values an "on break of stone:" filter is compared with (null = this event has no filter),
     * text = the text "on chat containing ..." looks in, gate = cheap yes/no check before any script work.
     */
    record Def(Class<? extends Event> cls, Function<Event, Map<String, Object>> vars,
               Function<Event, String[]> keys, Function<Event, String> text, java.util.function.Predicate<Event> gate) {
        Def(Class<? extends Event> cls, Function<Event, Map<String, Object>> vars) {
            this(cls, vars, null, null, null);
        }
    }

    /** Filter values and keys are compared in one spelling: upper case, no leading /, spaces and - become _. */
    static String norm(String s) {
        String t = s.trim();
        if (t.startsWith("/")) t = t.substring(1);
        return t.toUpperCase(java.util.Locale.ROOT).replace(' ', '_').replace('-', '_');
    }

    /** Does this event pass the "of ..." / "containing ..." filter of the handler? */
    static boolean matches(Script.EventDef d, Def def, Event e) {
        if (d.containing != null) {
            String t = def.text().apply(e);
            if (t == null) return false;
            String lt = t.toLowerCase(java.util.Locale.ROOT);
            for (String v : d.containing) if (lt.contains(v)) return true;
            return false;
        }
        String[] ks = def.keys().apply(e);
        for (String k : ks) {
            if (k == null) continue;
            String nk = norm(k);
            for (String v : d.exact) if (nk.equals(v)) return true;
            for (java.util.regex.Pattern g : d.globs) if (g.matcher(nk).matches()) return true;
        }
        return false;
    }

    private static String typeOf(Object o) {
        return o instanceof Entity en ? en.getType().name() : null;
    }

    private static void filter(String name, Function<Event, String[]> keys, Function<Event, String> text,
                               java.util.function.Predicate<Event> gate) {
        Def d = ALL.get(name);
        ALL.put(name, new Def(d.cls(), d.vars(), keys, text, gate));
    }

    static final Map<String, Def> ALL = new LinkedHashMap<>();

    private EventDefs() {
    }

    private static final String[] PACKAGES = {
            "org.bukkit.event.player", "org.bukkit.event.entity", "org.bukkit.event.block",
            "org.bukkit.event.inventory", "org.bukkit.event.world", "org.bukkit.event.server",
            "org.bukkit.event.vehicle", "org.bukkit.event.weather", "org.bukkit.event.hanging",
            "org.bukkit.event.enchantment", "io.papermc.paper.event.player", "io.papermc.paper.event.entity",
            "io.papermc.paper.event.block", "io.papermc.paper.event.world", "com.destroystokyo.paper.event.player",
            "com.destroystokyo.paper.event.entity", "com.destroystokyo.paper.event.block",
            "com.destroystokyo.paper.event.server"};

    private static Class<?> load(String fqcn) {
        try {
            return Class.forName(fqcn);
        } catch (ClassNotFoundException | LinkageError e) {
            return null;
        }
    }

    /**
     * Finds ANY Bukkit/Paper event from the words in "on player fish:" (-> PlayerFishEvent) or from a full
     * class name ("on event org.bukkit.event.player.PlayerFishEvent:"). Returns null when there is no such event.
     * Inside the script the event's properties are plain names (block, cause, message ...), plus "event".
     */
    static Def resolve(String raw) {
        String n = raw.trim();
        if (n.toLowerCase(java.util.Locale.ROOT).startsWith("event ")) n = n.substring(6).trim();
        Class<?> found = null;
        if (n.contains(".")) {
            found = load(n);
        } else {
            StringBuilder camel = new StringBuilder();
            for (String w : n.split("[ _\\-]+")) {
                if (w.isEmpty()) continue;
                camel.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
            }
            String base = camel.toString();
            if (!base.endsWith("Event")) base = base + "Event";
            for (String pkg : PACKAGES) {
                found = load(pkg + "." + base);
                if (found != null) break;
            }
        }
        if (found == null || !Event.class.isAssignableFrom(found)) return null;
        Class<? extends Event> cls = found.asSubclass(Event.class);
        return new Def(cls, EventDefs::genericVars);
    }

    /** Variables every generic event gets: "player" when the event is about one. */
    private static Map<String, Object> genericVars(Event e) {
        Map<String, Object> out = new LinkedHashMap<>();
        Object pl = Access.softGet(e, "player");
        if (!(pl instanceof Player)) pl = Access.softGet(e, "whoClicked");
        if (!(pl instanceof Player)) pl = Access.softGet(e, "entity");
        if (pl instanceof Player) out.put("player", pl);
        return out;
    }

    private static Map<String, Object> m(Object... kv) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) out.put((String) kv[i], kv[i + 1]);
        return out;
    }

    private static void put(String name, Class<? extends Event> cls, Function<Event, Map<String, Object>> f) {
        ALL.put(name, new Def(cls, f));
    }

    static {
        put("join", PlayerJoinEvent.class, e -> m("player", ((PlayerJoinEvent) e).getPlayer()));
        put("quit", PlayerQuitEvent.class, e -> m("player", ((PlayerQuitEvent) e).getPlayer()));
        put("respawn", PlayerRespawnEvent.class, e -> {
            PlayerRespawnEvent x = (PlayerRespawnEvent) e;
            return m("player", x.getPlayer(), "respawnloc", x.getRespawnLocation());
        });
        put("break", BlockBreakEvent.class, e -> {
            BlockBreakEvent x = (BlockBreakEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlock());
        });
        put("place", BlockPlaceEvent.class, e -> {
            BlockPlaceEvent x = (BlockPlaceEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlockPlaced());
        });
        put("interact", PlayerInteractEvent.class, e -> {
            PlayerInteractEvent x = (PlayerInteractEvent) e;
            return m("player", x.getPlayer(), "block", x.getClickedBlock(), "action", x.getAction().name(),
                    "item", x.getItem() == null ? null : x.getItem().getType().name(),
                    "itemname", Access.itemName(x.getItem()),
                    "hand", x.getHand() == null ? null : x.getHand().name());
        });
        put("interact-entity", PlayerInteractEntityEvent.class, e -> {
            PlayerInteractEntityEvent x = (PlayerInteractEntityEvent) e;
            return m("player", x.getPlayer(), "entity", x.getRightClicked());
        });
        put("death", PlayerDeathEvent.class, e -> {
            PlayerDeathEvent x = (PlayerDeathEvent) e;
            return m("player", x.getEntity(), "killer", x.getEntity().getKiller());
        });
        put("kill", EntityDeathEvent.class, e -> {
            EntityDeathEvent x = (EntityDeathEvent) e;
            return m("entity", x.getEntity(), "killer", x.getEntity().getKiller());
        });
        put("move", PlayerMoveEvent.class, e -> {
            PlayerMoveEvent x = (PlayerMoveEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom(), "to", x.getTo());
        });
        put("teleport", PlayerTeleportEvent.class, e -> {
            PlayerTeleportEvent x = (PlayerTeleportEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom(), "to", x.getTo());
        });
        put("damage", EntityDamageEvent.class, e -> {
            EntityDamageEvent x = (EntityDamageEvent) e;
            Entity en = x.getEntity();
            return m("entity", en, "player", en instanceof Player ? en : null, "damage", x.getDamage(),
                    "cause", x.getCause().name());
        });
        put("damage-entity", EntityDamageByEntityEvent.class, e -> {
            EntityDamageByEntityEvent x = (EntityDamageByEntityEvent) e;
            Entity d = x.getDamager();
            Entity v = x.getEntity();
            Object pl = d instanceof Player ? d : (v instanceof Player ? v : null);
            Object attacker = d;
            if (d instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Entity shooter) attacker = shooter;
            return m("damager", d, "attacker", attacker, "victim", v, "player", pl, "damage", x.getDamage(),
                    "cause", x.getCause().name());
        });
        put("command", PlayerCommandPreprocessEvent.class, e -> {
            PlayerCommandPreprocessEvent x = (PlayerCommandPreprocessEvent) e;
            String msg = x.getMessage();
            return m("player", x.getPlayer(), "message", msg, "command", msg.startsWith("/") ? msg.substring(1) : msg);
        });
        put("explode", EntityExplodeEvent.class, e -> {
            EntityExplodeEvent x = (EntityExplodeEvent) e;
            return m("entity", x.getEntity(), "blocks", new ArrayList<Object>(x.blockList()), "loc", x.getLocation());
        });
        put("block-explode", BlockExplodeEvent.class, e -> {
            BlockExplodeEvent x = (BlockExplodeEvent) e;
            List<Object> blocks = new ArrayList<>(x.blockList());
            return m("block", x.getBlock(), "blocks", blocks);
        });
        put("drop", PlayerDropItemEvent.class, e -> {
            PlayerDropItemEvent x = (PlayerDropItemEvent) e;
            return m("player", x.getPlayer(), "item", x.getItemDrop().getItemStack().getType().name(),
                    "itemname", Access.itemName(x.getItemDrop().getItemStack()));
        });
        put("pickup", EntityPickupItemEvent.class, e -> {
            EntityPickupItemEvent x = (EntityPickupItemEvent) e;
            Entity en = x.getEntity();
            return m("entity", en, "player", en instanceof Player ? en : null,
                    "item", x.getItem().getItemStack().getType().name());
        });
        put("bucket", PlayerBucketEmptyEvent.class, e -> {
            PlayerBucketEmptyEvent x = (PlayerBucketEmptyEvent) e;
            return m("player", x.getPlayer(), "block", x.getBlock());
        });
        put("spawn", CreatureSpawnEvent.class, e -> {
            CreatureSpawnEvent x = (CreatureSpawnEvent) e;
            return m("entity", x.getEntity(), "loc", x.getLocation(), "reason", x.getSpawnReason().name());
        });
        put("target", EntityTargetLivingEntityEvent.class, e -> {
            EntityTargetLivingEntityEvent x = (EntityTargetLivingEntityEvent) e;
            return m("entity", x.getEntity(), "target", x.getTarget(), "player",
                    x.getTarget() instanceof Player ? x.getTarget() : null);
        });
        // chat runs OFF the main thread: keep "on chat:" scripts to quick checks (mem.*, cancel)
        put("chat", io.papermc.paper.event.player.AsyncChatEvent.class, e -> {
            io.papermc.paper.event.player.AsyncChatEvent x = (io.papermc.paper.event.player.AsyncChatEvent) e;
            return m("player", x.getPlayer(), "message",
                    net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(x.message()));
        });
        put("close", InventoryCloseEvent.class, e -> {
            InventoryCloseEvent x = (InventoryCloseEvent) e;
            return m("player", x.getPlayer() instanceof Player pl ? pl : null, "title",
                    net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(x.getView().title()));
        });
        put("world-change", PlayerChangedWorldEvent.class, e -> {
            PlayerChangedWorldEvent x = (PlayerChangedWorldEvent) e;
            return m("player", x.getPlayer(), "from", x.getFrom().getName());
        });

        // ---- filters ("on break of stone:", "on command \"spawn\":") and the cheap gate for move
        filter("break", e -> new String[]{((BlockBreakEvent) e).getBlock().getType().name()}, null, null);
        filter("place", e -> new String[]{((BlockPlaceEvent) e).getBlockPlaced().getType().name()}, null, null);
        filter("bucket", e -> new String[]{((PlayerBucketEmptyEvent) e).getBlock().getType().name()}, null, null);
        filter("interact", e -> {
            PlayerInteractEvent x = (PlayerInteractEvent) e;
            String action = x.getAction().name();
            String simple = action.startsWith("RIGHT") ? "RIGHT_CLICK" : action.startsWith("LEFT") ? "LEFT_CLICK" : action;
            return new String[]{x.getItem() == null ? null : x.getItem().getType().name(),
                    x.getClickedBlock() == null ? null : x.getClickedBlock().getType().name(), action, simple};
        }, null, null);
        filter("drop", e -> new String[]{((PlayerDropItemEvent) e).getItemDrop().getItemStack().getType().name()}, null, null);
        filter("pickup", e -> new String[]{((EntityPickupItemEvent) e).getItem().getItemStack().getType().name()}, null, null);
        filter("damage", e -> {
            EntityDamageEvent x = (EntityDamageEvent) e;
            return new String[]{x.getCause().name(), x.getEntity().getType().name()};
        }, null, null);
        filter("damage-entity", e -> {
            EntityDamageByEntityEvent x = (EntityDamageByEntityEvent) e;
            return new String[]{x.getCause().name(), typeOf(x.getDamager()), typeOf(x.getEntity())};
        }, null, null);
        filter("kill", e -> new String[]{typeOf(((EntityDeathEvent) e).getEntity())}, null, null);
        filter("spawn", e -> {
            CreatureSpawnEvent x = (CreatureSpawnEvent) e;
            return new String[]{x.getEntity().getType().name(), x.getSpawnReason().name()};
        }, null, null);
        filter("target", e -> {
            EntityTargetLivingEntityEvent x = (EntityTargetLivingEntityEvent) e;
            return new String[]{typeOf(x.getEntity()), typeOf(x.getTarget())};
        }, null, null);
        filter("world-change", e -> {
            PlayerChangedWorldEvent x = (PlayerChangedWorldEvent) e;
            return new String[]{x.getPlayer().getWorld().getName(), x.getFrom().getName()};
        }, null, null);
        filter("command", e -> {
            String msg = ((PlayerCommandPreprocessEvent) e).getMessage();
            if (msg.startsWith("/")) msg = msg.substring(1);
            int sp = msg.indexOf(' ');
            return new String[]{sp < 0 ? msg : msg.substring(0, sp)};
        }, e -> ((PlayerCommandPreprocessEvent) e).getMessage(), null);
        filter("chat", null, e -> net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(((io.papermc.paper.event.player.AsyncChatEvent) e).message()), null);
        // "on move" fires for every head turn of every player; by default it runs only when the player changes block
        filter("move", null, null, e -> {
            PlayerMoveEvent x = (PlayerMoveEvent) e;
            org.bukkit.Location f = x.getFrom();
            org.bukkit.Location t = x.getTo();
            return t != null && (f.getBlockX() != t.getBlockX() || f.getBlockY() != t.getBlockY()
                    || f.getBlockZ() != t.getBlockZ() || f.getWorld() != t.getWorld());
        });
    }
}
