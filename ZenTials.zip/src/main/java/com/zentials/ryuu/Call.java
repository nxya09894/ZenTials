package com.zentials.ryuu;

import java.util.List;

/** Calling a script function (kept apart from Libs so it has no Bukkit dependency). */
final class Call {
    private Call() {
    }

    static Object invoke(Script.FuncDef f, List<Object> args, Ctx caller) {
        if (caller.depth >= Ctx.MAX_DEPTH) {
            throw new RyuuException(0, "Too many nested calls in function '" + f.name + "'");
        }
        Ctx c = new Ctx(f.script);
        c.depth = caller.depth + 1;
        c.sender = caller.sender;
        c.gui = caller.gui;
        c.deadline = caller.deadline;   // a function shares the time budget of whoever called it
        Object pl = caller.vars.get("player");
        if (pl != null) c.vars.put("player", pl);
        for (int i = 0; i < f.params.size(); i++) {
            Object v;
            if (i < args.size()) v = args.get(i);
            else if (f.defaults.get(i) != null) v = f.defaults.get(i).eval(c);   // function greet(name, hi = "Hello")
            else v = null;
            c.vars.put(f.params.get(i), v);
        }
        Run.block(f.body, c);
        if (c.cancel) caller.cancel = true;
        if (c.uncancel) caller.uncancel = true;
        return c.ret;
    }
}
