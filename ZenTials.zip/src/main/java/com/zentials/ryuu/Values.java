package com.zentials.ryuu;

import com.zentials.core.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Type conversion and operators for script values. Numbers are always Double. */
final class Values {
    private Values() {
    }

    static boolean truthy(Object o) {
        if (o == null) return false;
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.doubleValue() != 0;
        if (o instanceof String s) return !s.isEmpty();
        if (o instanceof Collection<?> c) return !c.isEmpty();
        return true;
    }

    static double num(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) {
            try {
                return Double.parseDouble(s.trim());
            } catch (NumberFormatException e) {
                throw new RyuuException(0, "Expected a number but got '" + s + "'");
            }
        }
        if (o instanceof Boolean b) return b ? 1 : 0;
        throw new RyuuException(0, "Expected a number but got " + (o == null ? "nothing" : typeName(o)));
    }

    static int intv(Object o) {
        return (int) num(o);
    }

    static String typeName(Object o) {
        if (o == null) return "nothing";
        if (o instanceof Number) return "number";
        if (o instanceof String) return "text";
        if (o instanceof Boolean) return "boolean";
        if (o instanceof List) return "list";
        if (o instanceof Map) return "map";
        return o.getClass().getSimpleName();
    }

    static String str(Object o) {
        if (o == null) return "";
        if (o instanceof String s) return s;
        if (o instanceof Number n) {
            double d = n.doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
            return BigDecimal.valueOf(d).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        }
        if (o instanceof Boolean b) return b ? "true" : "false";
        if (o instanceof OfflinePlayer p) return p.getName() == null ? p.getUniqueId().toString() : p.getName();
        if (o instanceof World w) return w.getName();
        if (o instanceof Location l) {
            return (l.getWorld() == null ? "?" : l.getWorld().getName()) + ","
                    + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ();
        }
        if (o instanceof Block b) return b.getType().name() + "@" + b.getX() + "," + b.getY() + "," + b.getZ();
        if (o instanceof ItemStack i) return i.getType().name();
        if (o instanceof Entity e) return e.getType().name();
        if (o instanceof Enum<?> e) return e.name();
        if (o instanceof Component c) return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                .plainText().serialize(c);
        if (o instanceof List<?> l) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(str(l.get(i)));
            }
            return sb.append(']').toString();
        }
        return String.valueOf(o);
    }

    static boolean eq(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a instanceof Number x && b instanceof Number y) return Math.abs(x.doubleValue() - y.doubleValue()) < 1e-9;
        if (Objects.equals(a, b)) return true;
        boolean aSimple = a instanceof String || a instanceof Enum || a instanceof Number || a instanceof Boolean;
        boolean bSimple = b instanceof String || b instanceof Enum || b instanceof Number || b instanceof Boolean;
        if (aSimple && bSimple) return str(a).equals(str(b));
        return false;
    }

    static int compare(Object a, Object b) {
        if (a instanceof String x && b instanceof String y) return x.compareTo(y);
        return Double.compare(num(a), num(b));
    }

    static Object add(Object a, Object b) {
        if (a instanceof String || b instanceof String) return str(a) + str(b);
        if (a instanceof List<?> la) {
            List<Object> out = new ArrayList<>(la);
            if (b instanceof List<?> lb) out.addAll(lb);
            else out.add(b);
            return out;
        }
        return num(a) + num(b);
    }

    /** add X to target: lists get the item, text gets appended, numbers are added. */
    @SuppressWarnings("unchecked")
    static Object plus(Object cur, Object v) {
        if (cur instanceof List<?> l) {
            ((List<Object>) l).add(v);
            return l;
        }
        if (cur instanceof String s) return s + str(v);
        return (cur == null ? 0 : num(cur)) + num(v);
    }

    /** remove X from target: lists lose the item, maps lose the key, numbers are subtracted. */
    @SuppressWarnings("unchecked")
    static Object minus(Object cur, Object v) {
        if (cur instanceof List<?> l) {
            List<Object> list = (List<Object>) l;
            for (int i = 0; i < list.size(); i++) {
                if (eq(list.get(i), v)) {
                    list.remove(i);
                    break;
                }
            }
            return list;
        }
        if (cur instanceof Map<?, ?> m) {
            ((Map<Object, Object>) m).remove(str(v));
            return m;
        }
        return (cur == null ? 0 : num(cur)) - num(v);
    }

    // ---------------------------------------------------------------- players

    static Player player(Object o) {
        if (o instanceof Player p) return p;
        if (o instanceof UUID u) return Bukkit.getPlayer(u);
        if (o instanceof String s) {
            Player p = Bukkit.getPlayerExact(s);
            if (p != null) return p;
            try {
                return Bukkit.getPlayer(UUID.fromString(s));
            } catch (IllegalArgumentException e) {
                return null;
            }
        }
        return null;
    }

    /** Player / OfflinePlayer / UUID / name -> UUID. */
    static UUID uuid(Object o) {
        if (o instanceof OfflinePlayer p) return p.getUniqueId();
        if (o instanceof Entity e) return e.getUniqueId();
        if (o instanceof UUID u) return u;
        if (o instanceof String s) {
            try {
                return UUID.fromString(s);
            } catch (IllegalArgumentException ignored) {
                // not a uuid, treat as a name
            }
            Player p = Bukkit.getPlayerExact(s);
            if (p != null) return p.getUniqueId();
            UUID fromEco = RyuuModule.uuidOfName(s);
            if (fromEco != null) return fromEco;
            OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(s);
            if (off != null) return off.getUniqueId();
        }
        throw new RyuuException(0, "Unknown player '" + str(o) + "'");
    }

    // ---------------------------------------------------------------- messages

    static void deliver(Object target, String msg) {
        if (target == null) {
            Bukkit.getConsoleSender().sendMessage(Text.c(msg));
        } else if (target instanceof CommandSender cs) {
            cs.sendMessage(Text.c(msg));
        } else if (target instanceof Collection<?> col) {
            for (Object o : col) deliver(o, msg);
        } else if (target instanceof UUID u) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(Text.c(msg));
        } else if (target instanceof String s) {
            Player p = player(s);
            if (p != null) p.sendMessage(Text.c(msg));
        }
    }
}
