package com.zentials.ryuu;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

/** Everything one run of a script needs: variables, who ran it, the GUI being built, ... */
final class Ctx {
    static final int MAX_STEPS = 2_000_000;
    static final int MAX_DEPTH = 100;

    final Script script;
    final Map<String, Object> vars;
    CommandSender sender;
    Object ret;
    boolean cancel;
    GuiBuild gui;
    int depth;
    private int steps;

    Ctx(Script script) {
        this(script, new HashMap<>());
    }

    Ctx(Script script, Map<String, Object> vars) {
        this.script = script;
        this.vars = vars;
    }

    Object get(String name) {
        Object v = vars.get(name);
        if (v != null || vars.containsKey(name)) return v;
        Object g = Libs.global(name, script);
        if (g != null) return g;
        if (isConstant(name)) return name;
        // inside an event, any property of the event works as a plain name: block, cause, message, damage ...
        Object ev = vars.get("event");
        return ev == null ? null : Access.softGet(ev, name);
    }

    /** DIAMOND_ORE, STONE, LEFT_CLICK_BLOCK ... a bare ALL_CAPS word is just its own name as text. */
    private static boolean isConstant(String n) {
        if (n.length() < 2 || !Character.isUpperCase(n.charAt(0))) return false;
        for (int i = 0; i < n.length(); i++) {
            char ch = n.charAt(i);
            if (!(Character.isUpperCase(ch) || Character.isDigit(ch) || ch == '_')) return false;
        }
        return true;
    }

    void step() {
        if (++steps > MAX_STEPS) {
            throw new RyuuException(0, "Script ran for too long (possible infinite loop)");
        }
    }

    /** The player this run is about: the "player" variable, or the sender if it is a player. */
    Player player() {
        Object p = vars.get("player");
        if (p instanceof Player pl) return pl;
        return sender instanceof Player sp ? sp : null;
    }
}
