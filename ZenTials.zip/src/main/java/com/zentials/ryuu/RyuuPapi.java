package com.zentials.ryuu;

import com.zentials.ZenTials;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/** %ryu_name% placeholders for "placeholder name:" blocks in .ryu scripts. */
final class RyuuPapi extends PlaceholderExpansion {
    private final ZenTials plugin;

    RyuuPapi(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "ryu";
    }

    @Override
    public @NotNull String getAuthor() {
        return "ZenTials";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        return RyuuModule.placeholder(player, params);
    }
}
