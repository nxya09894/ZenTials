package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Splits one expression into tokens. */
final class Lexer {
    enum T { NUM, STR, ID, OP, EOF }

    record Tok(T t, String s, double n) {
    }

    private Lexer() {
    }

    /** isn't / doesn't / aren't / hasn't  ->  isnt / doesnt / arent / hasnt (so the ' does not start a text). */
    private static String contraction(String id, String src, int end) {
        if (end + 1 < src.length() && src.charAt(end) == '\'' && Character.toLowerCase(src.charAt(end + 1)) == 't'
                && (end + 2 >= src.length() || !(Character.isLetterOrDigit(src.charAt(end + 2)) || src.charAt(end + 2) == '_'))) {
            switch (id.toLowerCase(Locale.ROOT)) {
                case "isn", "doesn", "aren", "hasn", "haven", "don" -> {
                    return id.toLowerCase(Locale.ROOT) + "t";
                }
                default -> {
                    return null;
                }
            }
        }
        return null;
    }

    static List<Tok> lex(String src, int line) {
        List<Tok> out = new ArrayList<>();
        int i = 0;
        int n = src.length();
        while (i < n) {
            char c = src.charAt(i);
            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }
            if (Character.isDigit(c)) {
                int j = i;
                StringBuilder num = new StringBuilder();
                while (j < n && (Character.isDigit(src.charAt(j)) || (src.charAt(j) == '_' && j + 1 < n && Character.isDigit(src.charAt(j + 1)) && j > i))) {
                    if (src.charAt(j) != '_') num.append(src.charAt(j));
                    j++;
                }
                if (j + 1 < n && src.charAt(j) == '.' && Character.isDigit(src.charAt(j + 1))) {
                    num.append('.');
                    j++;
                    while (j < n && Character.isDigit(src.charAt(j))) num.append(src.charAt(j++));
                }
                double v = Double.parseDouble(num.toString());
                // 5k = 5 thousand, 2.5m = 2.5 million, 1b = 1 billion (only when glued to the number)
                if (j < n && "kKmMbB".indexOf(src.charAt(j)) >= 0
                        && (j + 1 >= n || !(Character.isLetterOrDigit(src.charAt(j + 1)) || src.charAt(j + 1) == '_'))) {
                    char s = Character.toLowerCase(src.charAt(j));
                    v *= s == 'k' ? 1_000d : s == 'm' ? 1_000_000d : 1_000_000_000d;
                    j++;
                }
                out.add(new Tok(T.NUM, num.toString(), v));
                i = j;
                continue;
            }
            if (Character.isLetter(c) || c == '_') {
                int j = i;
                while (j < n && (Character.isLetterOrDigit(src.charAt(j)) || src.charAt(j) == '_')) j++;
                String id = src.substring(i, j);
                String contracted = contraction(id, src, j);
                if (contracted != null) {
                    out.add(new Tok(T.ID, contracted, 0));
                    i = j + 2;
                    continue;
                }
                out.add(new Tok(T.ID, id, 0));
                i = j;
                continue;
            }
            if (c == '"' || c == '\'') {
                StringBuilder sb = new StringBuilder();
                int j = i + 1;
                while (j < n) {
                    char d = src.charAt(j);
                    if (d == '\\' && j + 1 < n) {
                        sb.append(d).append(src.charAt(j + 1));
                        j += 2;
                        continue;
                    }
                    if (d == c) break;
                    sb.append(d);
                    j++;
                }
                if (j >= n) throw new RyuuException(line, "Text is missing its closing quote");
                out.add(new Tok(T.STR, sb.toString(), 0));
                i = j + 1;
                continue;
            }
            if (i + 1 < n) {
                String two = src.substring(i, i + 2);
                switch (two) {
                    case "==", "!=", "<=", ">=", "&&", "||", ".." -> {
                        out.add(new Tok(T.OP, two, 0));
                        i += 2;
                        continue;
                    }
                    case "<>" -> {
                        out.add(new Tok(T.OP, "!=", 0));
                        i += 2;
                        continue;
                    }
                    default -> {
                    }
                }
            }
            if ("+-*/%<>()[],.=!?:{}&".indexOf(c) >= 0) {
                out.add(new Tok(T.OP, String.valueOf(c), 0));
                i++;
                continue;
            }
            throw new RyuuException(line, "Unexpected character '" + c + "'");
        }
        out.add(new Tok(T.EOF, "", 0));
        return out;
    }
}
