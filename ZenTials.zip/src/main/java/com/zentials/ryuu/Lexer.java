package com.zentials.ryuu;

import java.util.ArrayList;
import java.util.List;

/** Splits one expression into tokens. */
final class Lexer {
    enum T { NUM, STR, ID, OP, EOF }

    record Tok(T t, String s, double n) {
    }

    private Lexer() {
    }

    static List<Tok> lex(String src, int line) {
        List<Tok> out = new ArrayList<>();
        int i = 0;
        int n = src.length();
        while (i < n) {
            char c = src.charAt(i);
            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }
            if (Character.isDigit(c)) {
                int j = i;
                while (j < n && Character.isDigit(src.charAt(j))) j++;
                if (j + 1 < n && src.charAt(j) == '.' && Character.isDigit(src.charAt(j + 1))) {
                    j++;
                    while (j < n && Character.isDigit(src.charAt(j))) j++;
                }
                String num = src.substring(i, j);
                out.add(new Tok(T.NUM, num, Double.parseDouble(num)));
                i = j;
                continue;
            }
            if (Character.isLetter(c) || c == '_') {
                int j = i;
                while (j < n && (Character.isLetterOrDigit(src.charAt(j)) || src.charAt(j) == '_')) j++;
                out.add(new Tok(T.ID, src.substring(i, j), 0));
                i = j;
                continue;
            }
            if (c == '"' || c == '\'') {
                StringBuilder sb = new StringBuilder();
                int j = i + 1;
                while (j < n) {
                    char d = src.charAt(j);
                    if (d == '\\' && j + 1 < n) {
                        sb.append(d).append(src.charAt(j + 1));
                        j += 2;
                        continue;
                    }
                    if (d == c) break;
                    sb.append(d);
                    j++;
                }
                if (j >= n) throw new RyuuException(line, "Text is missing its closing quote");
                out.add(new Tok(T.STR, sb.toString(), 0));
                i = j + 1;
                continue;
            }
            if (i + 1 < n) {
                String two = src.substring(i, i + 2);
                if (two.equals("==") || two.equals("!=") || two.equals("<=") || two.equals(">=")) {
                    out.add(new Tok(T.OP, two, 0));
                    i += 2;
                    continue;
                }
            }
            if ("+-*/%<>()[],.".indexOf(c) >= 0) {
                out.add(new Tok(T.OP, String.valueOf(c), 0));
                i++;
                continue;
            }
            throw new RyuuException(line, "Unexpected character '" + c + "'");
        }
        out.add(new Tok(T.EOF, "", 0));
        return out;
    }
}
