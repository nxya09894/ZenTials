package com.zentials.ryuu;

import com.zentials.core.gui.Gui;
import com.zentials.core.gui.Items;
import org.bukkit.Material;

/** A chest GUI being built by an "open gui" block. */
final class GuiBuild {
    final Gui gui;
    final int rows;
    Material fill;

    GuiBuild(Gui gui, int rows) {
        this.gui = gui;
        this.rows = rows;
    }

    void finish() {
        if (fill == null) return;
        for (int i = 0; i < rows * 9; i++) {
            if (gui.getInventory().getItem(i) == null) gui.set(i, Items.of(fill, " "));
        }
    }
}
