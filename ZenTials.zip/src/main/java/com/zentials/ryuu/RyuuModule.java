package com.zentials.ryuu;

import com.zentials.ZenTials;
import com.zentials.api.EconomyApi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Ryuudules: the ZenTials scripting system. Loads every .ryu file under plugins/ZenTials/ryuudules/
 * (except the examples folder) and turns it into commands, event handlers, timers and functions.
 */
public final class RyuuModule implements ZModule, CommandExecutor, TabCompleter {

    private static RyuuModule inst;
    private static final Map<String, Script.FuncDef> FUNCS = new ConcurrentHashMap<>();

    private static final List<String> RESOURCES = List.of("README.md");
    private static final List<String> OLD_EXAMPLES = List.of("hello.ryu", "economy-shop.ryu", "gui-menu.ryu", "shared-data.ryu");

    private static final class Active {
        Script script;
        Listener listener = new Listener() {
        };
        final List<RyuuCommand> cmds = new ArrayList<>();
        final List<BukkitTask> tasks = new ArrayList<>();
    }

    private final ZenTials plugin;
    private File root;
    private final Map<String, Active> active = new LinkedHashMap<>();
    private final List<String> errors = new ArrayList<>();
    private final Map<String, Long> lastReport = new HashMap<>();

    public RyuuModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "ryuudules";
    }

    // ---------------------------------------------------------------- static helpers for the interpreter

    static ZenTials plugin() {
        return inst.plugin;
    }

    static Kv kv() {
        Kv kv = inst.plugin.kv();
        if (kv == null) throw new RyuuException(0, "The ZenTials database is not running");
        return kv;
    }

    static EconomyApi economy() {
        EconomyApi api = inst.plugin.economyApi();
        if (api == null) throw new RyuuException(0, "The economy module is not enabled");
        return api;
    }

    static UUID uuidOfName(String name) {
        EconomyApi api = inst == null ? null : inst.plugin.economyApi();
        return api == null ? null : api.uuidOf(name);
    }

    static Script.FuncDef function(String name) {
        return FUNCS.get(name);
    }

    /** Runs something on the main thread (used when an async result comes back). */
    static void runLater(Runnable r) {
        if (inst != null) Bukkit.getScheduler().runTask(inst.plugin, r);
    }

    private record PH(Script script, Stmt[] body) {
    }

    private static final Map<String, PH> PLACEHOLDERS = new ConcurrentHashMap<>();

    /** Value of %ryu_params% from a "placeholder name:" block, or null when no block matches. */
    public static String placeholder(org.bukkit.OfflinePlayer p, String params) {
        if (inst == null) return null;
        String k = params.toLowerCase(Locale.ROOT);
        PH best = null;
        String bestName = null;
        for (Map.Entry<String, PH> e : PLACEHOLDERS.entrySet()) {
            String n = e.getKey();
            if ((k.equals(n) || k.startsWith(n + "_")) && (bestName == null || n.length() > bestName.length())) {
                best = e.getValue();
                bestName = n;
            }
        }
        if (best == null) return null;
        Ctx c = new Ctx(best.script());
        Player online = p == null ? null : p.getPlayer();
        if (online != null) {
            c.vars.put("player", online);
            c.sender = online;
        }
        c.vars.put("offline", p);
        c.vars.put("params", k.length() > bestName.length() ? k.substring(bestName.length() + 1) : "");
        try {
            Run.block(best.body(), c);
        } catch (RuntimeException e) {
            return "";
        }
        return c.ret == null ? "" : Values.str(c.ret);
    }

    static void log(String script, String msg) {
        inst.plugin.getLogger().info("[" + script + "] " + msg);
    }

    /** Runs a block, and reports (instead of throwing) any script error. */
    static void safeRun(Script s, int line, Stmt[] body, Ctx c) {
        try {
            Run.block(body, c);
        } catch (RyuuException e) {
            inst.report(s, e.line() > 0 ? e.line() : line, e.getMessage(), c.sender);
        } catch (Throwable t) {
            inst.report(s, line, t.toString(), c.sender);
        }
    }

    private void report(Script s, int line, String msg, CommandSender who) {
        String key = s.name + ":" + line + ":" + msg;
        long now = System.currentTimeMillis();
        Long last = lastReport.get(key);
        if (last == null || now - last > 5000) {
            lastReport.put(key, now);
            if (lastReport.size() > 500) lastReport.clear();
            plugin.getLogger().warning("[Ryuudules] " + s.name + ":" + line + "  " + msg);
        }
        if (who instanceof Player p) {
            if (p.hasPermission("zentials.admin")) Text.send(p, "&c[Ryuudules] " + s.name + ":" + line + "  " + msg);
            else Text.send(p, "&cSomething went wrong. Please tell an admin.");
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void enable() {
        inst = this;
        root = new File(plugin.getDataFolder(), "ryuudules");
        root.mkdirs();
        removeOldExamples();
        for (String r : RESOURCES) {
            try {
                plugin.saveResource("ryuudules/" + r, true);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Missing bundled file: ryuudules/" + r);
            }
        }
        PluginCommand cmd = plugin.getCommand("ryu");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        loadAll();
        syncCommands();
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new RyuuPapi(plugin).register();
            } catch (Throwable t) {
                plugin.getLogger().warning("Ryuudules: could not hook PlaceholderAPI: " + t);
            }
        }
        startWatcher();
    }

    /** Deletes the example scripts older versions copied into the folder (only those exact files). */
    private void removeOldExamples() {
        File dir = new File(root, "examples");
        if (!dir.isDirectory()) return;
        for (String n : OLD_EXAMPLES) {
            File f = new File(dir, n);
            if (f.isFile() && !f.delete()) plugin.getLogger().warning("Ryuudules: could not delete old example " + n);
        }
        String[] left = dir.list();
        if (left != null && left.length == 0) dir.delete();
    }

    @Override
    public void disable() {
        if (watcher != null) watcher.cancel();
        unloadAll();
    }

    // ---------------------------------------------------------------- auto reload (edit a .ryu file, it reloads)

    private BukkitTask watcher;
    private final Map<String, Long> stamps = new HashMap<>();
    private final Map<String, Long> pending = new HashMap<>();

    private Map<String, Long> scanStamps() {
        Map<String, Long> now = new HashMap<>();
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (r.startsWith("examples/")) continue;
                now.put(r, Files.getLastModifiedTime(p).toMillis());
            }
        } catch (IOException ignored) {
            // try again on the next check
        }
        return now;
    }

    private void startWatcher() {
        stamps.clear();
        stamps.putAll(scanStamps());
        watcher = Bukkit.getScheduler().runTaskTimer(plugin, this::checkFiles, 60L, 40L);
    }

    private void tellStaff(String msg) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isOp() || p.hasPermission("zentials.admin") || p.hasPermission("core.admin")) Text.send(p, "&8[&dRyuudules&8] " + msg);
        }
    }

    /** Reloads a script ~2 seconds after its file was saved (waits until the file stops changing). */
    private void checkFiles() {
        if (!plugin.getConfig().getBoolean("ryuudules.auto-reload", true)) return;
        Map<String, Long> now = scanStamps();
        List<String> todo = new ArrayList<>();
        for (Map.Entry<String, Long> e : now.entrySet()) {
            Long known = stamps.get(e.getKey());
            if (e.getValue().equals(known)) {
                pending.remove(e.getKey());
            } else if (e.getValue().equals(pending.get(e.getKey()))) {
                pending.remove(e.getKey());
                stamps.put(e.getKey(), e.getValue());
                todo.add(e.getKey());
            } else {
                pending.put(e.getKey(), e.getValue());
            }
        }
        for (String gone : new ArrayList<>(stamps.keySet())) {
            if (!now.containsKey(gone)) {
                stamps.remove(gone);
                todo.add(gone);
            }
        }
        for (String r : todo) tellStaff(reloadScript(r));
    }

    @Override
    public void reload() {
        unloadAll();
        loadAll();
        syncCommands();
    }

    private void addError(String msg) {
        errors.add(msg);
        plugin.getLogger().warning("[Ryuudules] " + msg);
    }

    private void loadAll() {
        errors.clear();
        List<Script> parsed = new ArrayList<>();
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            List<Path> files = w.filter(p -> p.toString().endsWith(".ryu"))
                    .filter(p -> !rootPath.relativize(p).startsWith("examples"))
                    .sorted().toList();
            for (Path f : files) {
                String rel = rootPath.relativize(f).toString().replace('\\', '/');
                try {
                    parsed.add(new Parser(rel).parse(Files.readString(f, StandardCharsets.UTF_8)));
                } catch (RyuuException e) {
                    addError(rel + ":" + e.line() + "  " + e.getMessage());
                } catch (IOException | RuntimeException e) {
                    addError(rel + "  " + e);
                }
            }
        } catch (IOException e) {
            addError("Cannot read the ryuudules folder: " + e.getMessage());
        }
        for (Script s : parsed) {
            for (Script.FuncDef f : s.functions.values()) {
                if (FUNCS.putIfAbsent(f.name, f) != null) {
                    addError(s.name + ":" + f.line + "  function '" + f.name
                            + "' already exists in another file (this one is only used inside its own file)");
                }
            }
        }
        int cmds = 0;
        int evs = 0;
        int tms = 0;
        for (Script s : parsed) {
            try {
                activate(s);
                cmds += s.commands.size();
                evs += s.events.size();
                tms += s.timers.size();
            } catch (RuntimeException e) {
                addError(s.name + "  failed to start: " + e);
            }
        }
        plugin.getLogger().info("Ryuudules: " + parsed.size() + " script(s) loaded - " + cmds + " command(s), "
                + evs + " event handler(s), " + tms + " timer(s)" + (errors.isEmpty() ? "" : ", " + errors.size()
                + " ERROR(S) (see /ryu errors)"));
    }

    private void activate(Script s) {
        Active a = new Active();
        a.script = s;
        active.put(s.name, a);

        for (Map.Entry<String, Stmt[]> ph : s.placeholders.entrySet()) {
            PLACEHOLDERS.put(ph.getKey(), new PH(s, ph.getValue()));
        }

        for (Script.EventDef d : s.events) {
            EventDefs.Def def = EventDefs.ALL.get(d.event);
            Bukkit.getPluginManager().registerEvent(def.cls(), a.listener, EventPriority.NORMAL, (l, e) -> {
                if (def.cls().isInstance(e)) runEvent(s, d, def, e);
            }, plugin, false);
        }

        CommandMap cm = Bukkit.getCommandMap();
        for (Script.CommandDef d : s.commands) {
            RyuuCommand cmd = new RyuuCommand(s, d);
            cm.register("ryu", cmd);
            a.cmds.add(cmd);
        }

        for (Script.TimerDef d : s.timers) {
            double n = Values.num(d.period.eval(new Ctx(s)));
            long period = Math.max(1, (long) (n * d.unitTicks));
            a.tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> safeRun(s, d.line, d.body, new Ctx(s)),
                    period, period));
        }

        for (Stmt[] body : s.onLoad) safeRun(s, 0, body, new Ctx(s));
    }

    private void runEvent(Script s, Script.EventDef d, EventDefs.Def def, Event e) {
        Ctx c = new Ctx(s);
        c.vars.putAll(def.vars().apply(e));
        c.vars.put("event", e);
        if (c.vars.get("player") instanceof Player p) c.sender = p;
        safeRun(s, d.line, d.body, c);
        if (c.cancel && e instanceof Cancellable ce) ce.setCancelled(true);
        if (c.vars.get("blocks") instanceof List<?> keep) {
            if (e instanceof org.bukkit.event.entity.EntityExplodeEvent ex) ex.blockList().retainAll(keep);
            else if (e instanceof org.bukkit.event.block.BlockExplodeEvent bx) bx.blockList().retainAll(keep);
        }
    }

    private void teardown(Active a) {
        CommandMap cm = Bukkit.getCommandMap();
        for (Stmt[] body : a.script.onUnload) safeRun(a.script, 0, body, new Ctx(a.script));
        HandlerList.unregisterAll(a.listener);
        for (BukkitTask t : a.tasks) t.cancel();
        for (RyuuCommand cmd : a.cmds) {
            cm.getKnownCommands().values().removeIf(v -> v == cmd);
            cmd.unregister(cm);
        }
        FUNCS.values().removeIf(f -> f.script == a.script);
        PLACEHOLDERS.values().removeIf(ph -> ph.script() == a.script);
    }

    private void unloadAll() {
        for (Active a : new ArrayList<>(active.values())) teardown(a);
        active.clear();
        FUNCS.clear();
        PLACEHOLDERS.clear();
        ExtraBukkit.clearBars();
        Libs.clearMem();
    }

    private static String stripExt(String n) {
        return n.endsWith(".ryu") ? n.substring(0, n.length() - 4) : n;
    }

    /** Names (without .ryu) of every script file on disk, for tab completion. */
    public List<String> scriptNames() {
        List<String> out = new ArrayList<>();
        if (root == null) return out;
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).sorted().toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (!r.startsWith("examples/")) out.add(stripExt(r));
            }
        } catch (IOException ignored) {
            // empty list
        }
        return out;
    }

    /**
     * Reloads ONE script file (new, edited or deleted) without touching the others.
     * Returns a colored message for the person who ran the command.
     */
    public String reloadScript(String name) {
        String want = stripExt(name.toLowerCase(Locale.ROOT).replace('\\', '/'));
        Path rootPath = root.toPath();
        Path found = null;
        String rel = null;
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).sorted().toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (r.startsWith("examples/")) continue;
                String noExt = stripExt(r).toLowerCase(Locale.ROOT);
                String fileOnly = noExt.contains("/") ? noExt.substring(noExt.lastIndexOf('/') + 1) : noExt;
                if (noExt.equals(want) || fileOnly.equals(want)) {
                    found = p;
                    rel = r;
                    break;
                }
            }
        } catch (IOException e) {
            return "&cCannot read the ryuudules folder: " + e.getMessage();
        }

        if (found == null) {
            for (Active a : new ArrayList<>(active.values())) {
                String n = stripExt(a.script.name).toLowerCase(Locale.ROOT);
                String fileOnly = n.contains("/") ? n.substring(n.lastIndexOf('/') + 1) : n;
                if (n.equals(want) || fileOnly.equals(want)) {
                    teardown(a);
                    active.remove(a.script.name);
                    syncCommands();
                    return "&eUnloaded &f" + a.script.name + "&e (the file is gone).";
                }
            }
            return "&cNo script named '" + name + "' in the ryuudules folder.";
        }

        final String relName = rel;
        Script parsed;
        try {
            parsed = new Parser(relName).parse(Files.readString(found, StandardCharsets.UTF_8));
        } catch (RyuuException e) {
            errors.removeIf(x -> x.startsWith(relName + ":") || x.startsWith(relName + " "));
            addError(relName + ":" + e.line() + "  " + e.getMessage());
            return "&c" + relName + ":" + e.line() + "  " + e.getMessage() + " &7(the old version keeps running)";
        } catch (IOException | RuntimeException e) {
            return "&c" + relName + "  " + e;
        }

        Active old = active.get(relName);
        if (old != null) {
            teardown(old);
            active.remove(relName);
        }
        errors.removeIf(x -> x.startsWith(relName + ":") || x.startsWith(relName + " "));
        for (Script.FuncDef f : parsed.functions.values()) {
            if (FUNCS.putIfAbsent(f.name, f) != null) {
                addError(relName + ":" + f.line + "  function '" + f.name + "' already exists in another file");
            }
        }
        try {
            activate(parsed);
        } catch (RuntimeException e) {
            addError(relName + "  failed to start: " + e);
            return "&c" + relName + " failed to start: " + e.getMessage();
        }
        syncCommands();
        return "&aReloaded &f" + relName + "&a: " + parsed.commands.size() + " command(s), "
                + parsed.events.size() + " event(s), " + parsed.timers.size() + " timer(s), "
                + parsed.functions.size() + " function(s)";
    }

    private void syncCommands() {
        try {
            Bukkit.getServer().getClass().getMethod("syncCommands").invoke(Bukkit.getServer());
        } catch (Exception ignored) {
            // older servers: players just need to rejoin for tab-completion
        }
    }

    // ---------------------------------------------------------------- /ryu

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (a.length > 1 && !a[1].equalsIgnoreCase("all")) {
                    for (int i = 1; i < a.length; i++) Text.send(s, "&8[&bRyuudules&8]&7 " + reloadScript(a[i]));
                    return true;
                }
                reload();
                Text.send(s, "&8[&bRyuudules&8]&7 Reloaded. Scripts: &f" + active.size()
                        + (errors.isEmpty() ? "" : " &8| &c" + errors.size() + " error(s) &7- /ryu errors"));
            }
            case "list" -> {
                if (active.isEmpty()) Text.send(s, "&8[&bRyuudules&8]&7 No scripts loaded. Put .ryu files in plugins/ZenTials/ryuudules/");
                for (Active x : active.values()) {
                    Script sc = x.script;
                    Text.send(s, "&8- &f" + sc.name + " &8| &7" + sc.commands.size() + " cmd, " + sc.events.size()
                            + " event, " + sc.timers.size() + " timer, " + sc.functions.size() + " function");
                }
            }
            case "errors" -> {
                if (errors.isEmpty()) Text.send(s, "&8[&bRyuudules&8]&a No errors.");
                for (String e : errors) Text.send(s, "&c" + e);
            }
            default -> Text.send(s, "&8[&bRyuudules&8]&7 &f/ryu reload &8| &f/ryu list &8| &f/ryu errors");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 1) return List.of("reload", "list", "errors");
        if (a.length >= 2 && a[0].equalsIgnoreCase("reload")) return scriptNames();
        return List.of();
    }
}
