package com.zentials.ryuu;

import com.zentials.core.Tag;
import com.zentials.ZenTials;
import com.zentials.api.EconomyApi;
import com.zentials.core.Text;
import com.zentials.core.ZModule;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Ryuudules: the ZenTials scripting system. Loads every .ryu file under plugins/ZenTials/ryuudules/
 * (except the examples folder) and turns it into commands, event handlers, timers and functions.
 */
public final class RyuuModule implements ZModule, CommandExecutor, TabCompleter {

    private static RyuuModule inst;
    private static final Map<String, Script.FuncDef> FUNCS = new ConcurrentHashMap<>();

    private static final List<String> RESOURCES = List.of("README.md");
    private static final List<String> OLD_EXAMPLES = List.of("hello.ryu", "economy-shop.ryu", "gui-menu.ryu", "shared-data.ryu");

    private static final class Active {
        Script script;
        Listener listener = new Listener() {
        };
        final List<RyuuCommand> cmds = new ArrayList<>();
        final List<BukkitTask> tasks = new ArrayList<>();
    }

    private final ZenTials plugin;
    private File root;
    private final Map<String, Active> active = new LinkedHashMap<>();
    private final List<String> errors = new ArrayList<>();
    private final Map<String, Long> lastReport = new HashMap<>();

    public RyuuModule(ZenTials plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "ryuudules";
    }

    // ---------------------------------------------------------------- static helpers for the interpreter

    static ZenTials plugin() {
        return inst.plugin;
    }

    static Kv kv() {
        Kv kv = inst.plugin.kv();
        if (kv == null) throw new RyuuException(0, "The ZenTials database is not running");
        return kv;
    }

    static EconomyApi economy() {
        EconomyApi api = inst.plugin.economyApi();
        if (api == null) throw new RyuuException(0, "The economy module is not enabled");
        return api;
    }

    static UUID uuidOfName(String name) {
        EconomyApi api = inst == null ? null : inst.plugin.economyApi();
        return api == null ? null : api.uuidOf(name);
    }

    static Script.FuncDef function(String name) {
        return FUNCS.get(name);
    }

    /** Runs something on the main thread (used when an async result comes back). */
    static void runLater(Runnable r) {
        if (inst != null) Bukkit.getScheduler().runTask(inst.plugin, r);
    }

    private record PH(Script script, Script.PlaceholderDef def) {
    }

    private record Cached(String value, long expires) {
    }

    private static final Map<String, PH> PLACEHOLDERS = new ConcurrentHashMap<>();
    private static final Map<String, Cached> PH_CACHE = new ConcurrentHashMap<>();

    /** Settings from config.yml (ryuudules.*), read once per reload. */
    static volatile boolean moveBlockOnly = true;
    private static volatile long slowNanos = 20_000_000L;

    /**
     * Value of %ryu_params% from a "placeholder name:" block, or null when no block matches.
     * The block is found by cutting the name at underscores from the right (longest match first), so this stays
     * fast when scoreboards and tab lists ask for it thousands of times per second.
     */
    public static String placeholder(org.bukkit.OfflinePlayer p, String params) {
        if (inst == null) return null;
        String k = params.toLowerCase(Locale.ROOT);
        PH best = PLACEHOLDERS.get(k);
        String bestName = best == null ? null : k;
        if (best == null) {
            for (int i = k.lastIndexOf('_'); i > 0 && best == null; i = k.lastIndexOf('_', i - 1)) {
                best = PLACEHOLDERS.get(k.substring(0, i));
                if (best != null) bestName = k.substring(0, i);
            }
        }
        if (best == null) return null;
        Script.PlaceholderDef pd = best.def();
        String ckey = null;
        long now = 0;
        if (pd.cacheMs > 0) {
            now = System.currentTimeMillis();
            ckey = (pd.global || p == null ? "-" : p.getUniqueId().toString()) + "|" + k;
            Cached hit = PH_CACHE.get(ckey);
            if (hit != null && hit.expires() > now) return hit.value();
        }
        Ctx c = new Ctx(best.script());
        Player online = p == null ? null : p.getPlayer();
        if (online != null && !pd.global) {
            c.vars.put("player", online);
            c.sender = online;
        }
        c.vars.put("offline", pd.global ? null : p);
        c.vars.put("params", k.length() > bestName.length() ? k.substring(bestName.length() + 1) : "");
        long t0 = System.nanoTime();
        String result;
        try {
            Run.block(pd.body, c);
            result = c.ret == null ? "" : Values.str(c.ret);
        } catch (RuntimeException e) {
            result = "";
        }
        pd.stat.add(System.nanoTime() - t0);
        if (ckey != null) {
            if (PH_CACHE.size() > 20000) PH_CACHE.clear();
            PH_CACHE.put(ckey, new Cached(result, now + pd.cacheMs));
        }
        return result;
    }

    static void log(String script, String msg) {
        inst.plugin.getLogger().info("[" + script + "] " + msg);
    }

    /** Runs a block, and reports (instead of throwing) any script error. Returns false when it failed. */
    static boolean safeRun(Script s, int line, Stmt[] body, Ctx c) {
        return safeRun(s, line, body, c, s.misc);
    }

    static boolean safeRun(Script s, int line, Stmt[] body, Ctx c, Script.Stat stat) {
        long t0 = System.nanoTime();
        boolean ok = true;
        try {
            Run.block(body, c);
        } catch (RyuuException e) {
            ok = false;
            inst.report(s, e.line() > 0 ? e.line() : line, e.getMessage(), c.sender);
        } catch (Throwable t) {
            ok = false;
            inst.report(s, line, t.toString(), c.sender);
        }
        long dt = System.nanoTime() - t0;
        stat.add(dt);
        if (slowNanos > 0 && dt > slowNanos) inst.slow(s, stat, dt);
        return ok;
    }

    private void slow(Script s, Script.Stat stat, long dt) {
        String key = "slow:" + s.name + ":" + stat.label;
        long now = System.currentTimeMillis();
        Long last = lastReport.get(key);
        if (last == null || now - last > 30000) {
            lastReport.put(key, now);
            plugin.getLogger().warning("[Ryuudules] slow: " + s.name + " " + stat.label + " took " + (dt / 1_000_000L)
                    + " ms (see /ryu profile)");
        }
    }

    private void loadSettings() {
        moveBlockOnly = plugin.getConfig().getBoolean("ryuudules.move-block-only", true);
        Ctx.limitNanos = Math.max(0L, plugin.getConfig().getLong("ryuudules.max-run-ms", 200L)) * 1_000_000L;
        slowNanos = Math.max(0L, plugin.getConfig().getLong("ryuudules.slow-warn-ms", 20L)) * 1_000_000L;
    }

    private void report(Script s, int line, String msg, CommandSender who) {
        String key = s.name + ":" + line + ":" + msg;
        long now = System.currentTimeMillis();
        Long last = lastReport.get(key);
        if (last == null || now - last > 5000) {
            lastReport.put(key, now);
            if (lastReport.size() > 500) lastReport.clear();
            plugin.getLogger().warning("[Ryuudules] " + s.name + ":" + line + "  " + msg);
        }
        if (who instanceof Player p) {
            if (p.hasPermission("zentials.admin")) Text.send(p, Tag.RYUUDULES + "&c" + s.name + ":" + line + "  " + msg);
            else Text.send(p, "&cSomething went wrong. Please tell an admin.");
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void enable() {
        inst = this;
        loadSettings();
        root = new File(plugin.getDataFolder(), "ryuudules");
        root.mkdirs();
        removeOldExamples();
        for (String r : RESOURCES) {
            try {
                plugin.saveResource("ryuudules/" + r, true);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Missing bundled file: ryuudules/" + r);
            }
        }
        PluginCommand cmd = plugin.getCommand("ryu");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        loadAll();
        syncCommands();
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new RyuuPapi(plugin).register();
            } catch (Throwable t) {
                plugin.getLogger().warning("Ryuudules: could not hook PlaceholderAPI: " + t);
            }
        }
        startWatcher();
    }

    /** Deletes the example scripts older versions copied into the folder (only those exact files). */
    private void removeOldExamples() {
        File dir = new File(root, "examples");
        if (!dir.isDirectory()) return;
        for (String n : OLD_EXAMPLES) {
            File f = new File(dir, n);
            if (f.isFile() && !f.delete()) plugin.getLogger().warning("Ryuudules: could not delete old example " + n);
        }
        String[] left = dir.list();
        if (left != null && left.length == 0) dir.delete();
    }

    @Override
    public void disable() {
        if (watcher != null) watcher.cancel();
        unloadAll();
    }

    // ---------------------------------------------------------------- auto reload (edit a .ryu file, it reloads)

    private BukkitTask watcher;
    private final Map<String, Long> stamps = new HashMap<>();
    private final Map<String, Long> pending = new HashMap<>();

    private Map<String, Long> scanStamps() {
        Map<String, Long> now = new HashMap<>();
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (r.startsWith("examples/")) continue;
                now.put(r, Files.getLastModifiedTime(p).toMillis());
            }
        } catch (IOException ignored) {
            // try again on the next check
        }
        return now;
    }

    private void startWatcher() {
        stamps.clear();
        stamps.putAll(scanStamps());
        // the folder scan runs off the main thread; only the reload itself happens on it
        watcher = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::checkFiles, 60L, 40L);
    }

    private void tellStaff(String msg) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isOp() || p.hasPermission("zentials.admin") || p.hasPermission("core.admin")) Text.send(p, Tag.RYUUDULES + msg);
        }
    }

    /** Reloads a script ~2 seconds after its file was saved (waits until the file stops changing). Runs async. */
    private void checkFiles() {
        if (!plugin.getConfig().getBoolean("ryuudules.auto-reload", true)) return;
        Map<String, Long> now = scanStamps();
        List<String> todo = new ArrayList<>();
        for (Map.Entry<String, Long> e : now.entrySet()) {
            Long known = stamps.get(e.getKey());
            if (e.getValue().equals(known)) {
                pending.remove(e.getKey());
            } else if (e.getValue().equals(pending.get(e.getKey()))) {
                pending.remove(e.getKey());
                stamps.put(e.getKey(), e.getValue());
                todo.add(e.getKey());
            } else {
                pending.put(e.getKey(), e.getValue());
            }
        }
        for (String gone : new ArrayList<>(stamps.keySet())) {
            if (!now.containsKey(gone)) {
                stamps.remove(gone);
                todo.add(gone);
            }
        }
        if (todo.isEmpty()) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (String r : todo) tellStaff(reloadScript(r));
        });
    }

    @Override
    public void reload() {
        loadSettings();
        unloadAll();
        loadAll();
        syncCommands();
    }

    private void addError(String msg) {
        errors.add(msg);
        plugin.getLogger().warning("[Ryuudules] " + msg);
    }

    private void loadAll() {
        errors.clear();
        List<Script> parsed = new ArrayList<>();
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            List<Path> files = w.filter(p -> p.toString().endsWith(".ryu"))
                    .filter(p -> !rootPath.relativize(p).startsWith("examples"))
                    .sorted().toList();
            for (Path f : files) {
                String rel = rootPath.relativize(f).toString().replace('\\', '/');
                try {
                    parsed.add(new Parser(rel).parse(Files.readString(f, StandardCharsets.UTF_8)));
                } catch (RyuuException e) {
                    addError(rel + ":" + e.line() + "  " + e.getMessage());
                } catch (IOException | RuntimeException e) {
                    addError(rel + "  " + e);
                }
            }
        } catch (IOException e) {
            addError("Cannot read the ryuudules folder: " + e.getMessage());
        }
        for (Script s : parsed) {
            for (Script.FuncDef f : s.functions.values()) {
                if (FUNCS.putIfAbsent(f.name, f) != null) {
                    addError(s.name + ":" + f.line + "  function '" + f.name
                            + "' already exists in another file (this one is only used inside its own file)");
                }
            }
        }
        int cmds = 0;
        int evs = 0;
        int tms = 0;
        for (Script s : parsed) {
            try {
                activate(s);
                cmds += s.commands.size();
                evs += s.events.size();
                tms += s.timers.size();
            } catch (RuntimeException e) {
                addError(s.name + "  failed to start: " + e);
            }
        }
        plugin.getLogger().info("Ryuudules: " + parsed.size() + " script(s) loaded - " + cmds + " command(s), "
                + evs + " event handler(s), " + tms + " timer(s)" + (errors.isEmpty() ? "" : ", " + errors.size()
                + " ERROR(S) (see /ryu errors)"));
    }

    private void activate(Script s) {
        Active a = new Active();
        a.script = s;
        active.put(s.name, a);

        for (Map.Entry<String, Script.PlaceholderDef> ph : s.placeholders.entrySet()) {
            PLACEHOLDERS.put(ph.getKey(), new PH(s, ph.getValue()));
        }

        for (Script.EventDef d : s.events) {
            EventDefs.Def def = EventDefs.ALL.get(d.event);
            EventPriority prio = EventPriority.NORMAL;
            if (d.priority != null) prio = EventPriority.valueOf(d.priority.toUpperCase(Locale.ROOT));
            Bukkit.getPluginManager().registerEvent(def.cls(), a.listener, prio, (l, e) -> {
                if (def.cls().isInstance(e)) runEvent(s, d, def, e);
            }, plugin, d.ignoreCancelled);
        }

        CommandMap cm = Bukkit.getCommandMap();
        for (Script.CommandDef d : s.commands) {
            RyuuCommand cmd = new RyuuCommand(s, d);
            cm.register("ryu", cmd);
            a.cmds.add(cmd);
        }

        for (Script.TimerDef d : s.timers) {
            double n = Values.num(d.period.eval(new Ctx(s)));
            long period = Math.max(1, (long) (n * d.unitTicks));
            a.tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, () -> safeRun(s, d.line, d.body, new Ctx(s), d.stat),
                    period, period));
        }

        for (Stmt[] body : s.onLoad) safeRun(s, 0, body, new Ctx(s));
    }

    private void runEvent(Script s, Script.EventDef d, EventDefs.Def def, Event e) {
        if (d.tripped) return;
        // cheap checks first: nothing is allocated for events the script does not care about
        if (moveBlockOnly && def.gate() != null && !def.gate().test(e)) return;
        if ((d.exact != null || d.containing != null) && !EventDefs.matches(d, def, e)) return;
        Map<String, Object> vars = def.vars().apply(e);   // a fresh map: the script owns it
        vars.put("event", e);
        Ctx c = new Ctx(s, vars);
        if (vars.get("player") instanceof Player p) c.sender = p;
        boolean ok = safeRun(s, d.line, d.body, c, d.stat);
        if (!ok) breaker(s, d);
        if (c.uncancel && e instanceof Cancellable ce) ce.setCancelled(false);
        else if (c.cancel && e instanceof Cancellable ce) ce.setCancelled(true);
        if (vars.get("blocks") instanceof List<?> keep) {
            if (e instanceof org.bukkit.event.entity.EntityExplodeEvent ex) ex.blockList().retainAll(keep);
            else if (e instanceof org.bukkit.event.block.BlockExplodeEvent bx) bx.blockList().retainAll(keep);
        }
    }

    /** 100 errors within 10 seconds: switch this handler off (until the next reload) instead of flooding the console. */
    private void breaker(Script s, Script.EventDef d) {
        long now = System.currentTimeMillis();
        if (now - d.windowStart > 10_000L) {
            d.windowStart = now;
            d.errors = 1;
            return;
        }
        if (++d.errors >= 100 && !d.tripped) {
            d.tripped = true;
            plugin.getLogger().severe("[Ryuudules] " + s.name + ":" + d.line + " 'on " + d.event
                    + "' failed 100 times in 10 seconds and was switched off. Fix it and /zt reload " + s.name);
            tellStaff("&c" + s.name + ":" + d.line + " 'on " + d.event + "' was switched off after too many errors. See /ryu errors");
        }
    }

    private void teardown(Active a) {
        CommandMap cm = Bukkit.getCommandMap();
        for (Stmt[] body : a.script.onUnload) safeRun(a.script, 0, body, new Ctx(a.script));
        HandlerList.unregisterAll(a.listener);
        for (BukkitTask t : a.tasks) t.cancel();
        for (RyuuCommand cmd : a.cmds) {
            cm.getKnownCommands().values().removeIf(v -> v == cmd);
            cmd.unregister(cm);
        }
        FUNCS.values().removeIf(f -> f.script == a.script);
        PLACEHOLDERS.values().removeIf(ph -> ph.script() == a.script);
        PH_CACHE.clear();
    }

    private void unloadAll() {
        for (Active a : new ArrayList<>(active.values())) teardown(a);
        active.clear();
        FUNCS.clear();
        PLACEHOLDERS.clear();
        PH_CACHE.clear();
        ExtraBukkit.clearBars();
        Libs.clearMem();
    }

    private static String stripExt(String n) {
        return n.endsWith(".ryu") ? n.substring(0, n.length() - 4) : n;
    }

    /** Names (without .ryu) of every script file on disk, for tab completion. */
    public List<String> scriptNames() {
        List<String> out = new ArrayList<>();
        if (root == null) return out;
        Path rootPath = root.toPath();
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).sorted().toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (!r.startsWith("examples/")) out.add(stripExt(r));
            }
        } catch (IOException ignored) {
            // empty list
        }
        return out;
    }

    /**
     * Reloads ONE script file (new, edited or deleted) without touching the others.
     * Returns a colored message for the person who ran the command.
     */
    public String reloadScript(String name) {
        String want = stripExt(name.toLowerCase(Locale.ROOT).replace('\\', '/'));
        Path rootPath = root.toPath();
        Path found = null;
        String rel = null;
        try (Stream<Path> w = Files.walk(rootPath)) {
            for (Path p : w.filter(x -> x.toString().endsWith(".ryu")).sorted().toList()) {
                String r = rootPath.relativize(p).toString().replace('\\', '/');
                if (r.startsWith("examples/")) continue;
                String noExt = stripExt(r).toLowerCase(Locale.ROOT);
                String fileOnly = noExt.contains("/") ? noExt.substring(noExt.lastIndexOf('/') + 1) : noExt;
                if (noExt.equals(want) || fileOnly.equals(want)) {
                    found = p;
                    rel = r;
                    break;
                }
            }
        } catch (IOException e) {
            return "&cCannot read the ryuudules folder: " + e.getMessage();
        }

        if (found == null) {
            for (Active a : new ArrayList<>(active.values())) {
                String n = stripExt(a.script.name).toLowerCase(Locale.ROOT);
                String fileOnly = n.contains("/") ? n.substring(n.lastIndexOf('/') + 1) : n;
                if (n.equals(want) || fileOnly.equals(want)) {
                    teardown(a);
                    active.remove(a.script.name);
                    syncCommands();
                    return "&eUnloaded &f" + a.script.name + "&e (the file is gone).";
                }
            }
            return "&cNo script named '" + name + "' in the ryuudules folder.";
        }

        final String relName = rel;
        Script parsed;
        try {
            parsed = new Parser(relName).parse(Files.readString(found, StandardCharsets.UTF_8));
        } catch (RyuuException e) {
            errors.removeIf(x -> x.startsWith(relName + ":") || x.startsWith(relName + " "));
            addError(relName + ":" + e.line() + "  " + e.getMessage());
            return "&c" + relName + ":" + e.line() + "  " + e.getMessage() + " &7(the old version keeps running)";
        } catch (IOException | RuntimeException e) {
            return "&c" + relName + "  " + e;
        }

        Active old = active.get(relName);
        if (old != null) {
            teardown(old);
            active.remove(relName);
        }
        errors.removeIf(x -> x.startsWith(relName + ":") || x.startsWith(relName + " "));
        for (Script.FuncDef f : parsed.functions.values()) {
            if (FUNCS.putIfAbsent(f.name, f) != null) {
                addError(relName + ":" + f.line + "  function '" + f.name + "' already exists in another file");
            }
        }
        try {
            activate(parsed);
        } catch (RuntimeException e) {
            addError(relName + "  failed to start: " + e);
            return "&c" + relName + " failed to start: " + e.getMessage();
        }
        syncCommands();
        return "&aReloaded &f" + relName + "&a: " + parsed.commands.size() + " command(s), "
                + parsed.events.size() + " event(s), " + parsed.timers.size() + " timer(s), "
                + parsed.functions.size() + " function(s)";
    }

    private void syncCommands() {
        try {
            Bukkit.getServer().getClass().getMethod("syncCommands").invoke(Bukkit.getServer());
        } catch (Exception ignored) {
            // older servers: players just need to rejoin for tab-completion
        }
    }

    // ---------------------------------------------------------------- /ryu

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (a.length > 1 && !a[1].equalsIgnoreCase("all")) {
                    for (int i = 1; i < a.length; i++) Text.send(s, Tag.RYUUDULES + reloadScript(a[i]));
                    return true;
                }
                reload();
                Text.send(s, Tag.RYUUDULES + "Reloaded. Scripts: &f" + active.size()
                        + (errors.isEmpty() ? "" : " &8| &c" + errors.size() + " error(s) &7- /ryu errors"));
            }
            case "list" -> {
                if (active.isEmpty()) Text.send(s, Tag.RYUUDULES + "No scripts loaded. Put .ryu files in plugins/ZenTials/ryuudules/");
                for (Active x : active.values()) {
                    Script sc = x.script;
                    Text.send(s, "&8- &f" + sc.name + " &8| &7" + sc.commands.size() + " cmd, " + sc.events.size()
                            + " event, " + sc.timers.size() + " timer, " + sc.functions.size() + " function");
                }
            }
            case "errors" -> {
                if (errors.isEmpty()) Text.send(s, Tag.RYUUDULES + "&aNo errors.");
                for (String e : errors) Text.send(s, "&c" + e);
            }
            case "profile" -> {
                if (a.length > 1 && a[1].equalsIgnoreCase("reset")) {
                    for (Active x : active.values()) for (Script.Stat st : x.script.stats) st.reset();
                    Text.send(s, Tag.RYUUDULES + "&aProfile reset.");
                    return true;
                }
                record Row(String script, Script.Stat st) {
                }
                List<Row> rows = new ArrayList<>();
                for (Active x : active.values()) for (Script.Stat st : x.script.stats) if (st.runs.sum() > 0) rows.add(new Row(x.script.name, st));
                rows.sort((p, q) -> Long.compare(q.st().nanos.sum(), p.st().nanos.sum()));
                if (rows.isEmpty()) Text.send(s, Tag.RYUUDULES + "&7Nothing has run yet.");
                else Text.send(s, Tag.RYUUDULES + "&fSlowest scripts &8(total ms | runs | avg ms | worst ms)");
                for (int i = 0; i < Math.min(12, rows.size()); i++) {
                    Row r = rows.get(i);
                    long runs = r.st().runs.sum();
                    double total = r.st().nanos.sum() / 1e6;
                    Text.send(s, String.format(Locale.ROOT, "&8%d. &f%s &7%s &8| &e%.1f &8| &7%d &8| &7%.3f &8| &c%.2f",
                            i + 1, r.script(), r.st().label, total, runs, total / runs, r.st().maxNanos / 1e6));
                }
            }
            default -> Text.send(s, Tag.RYUUDULES + "&f/ryu reload &8| &f/ryu list &8| &f/ryu errors &8| &f/ryu profile [reset]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 1) return List.of("reload", "list", "errors", "profile");
        if (a.length == 2 && a[0].equalsIgnoreCase("profile")) return List.of("reset");
        if (a.length >= 2 && a[0].equalsIgnoreCase("reload")) return scriptNames();
        return List.of();
    }
}
