package com.zentials.ryuu;

/** A script error. line is 1-based, 0 when unknown yet. */
public final class RyuuException extends RuntimeException {
    private final int line;

    public RyuuException(int line, String message) {
        super(message);
        this.line = line;
    }

    public int line() {
        return line;
    }
}
