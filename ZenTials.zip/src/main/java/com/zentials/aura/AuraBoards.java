package com.zentials.aura;

import com.zentials.ZenTials;
import com.zentials.core.Text;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * One private Scoreboard per viewer. It carries: the sidebar, the name tags of everybody (teams), the
 * number below names and the number in the tab list (ping). Everything is only re-sent when the text changed.
 */
final class AuraBoards {
    private static final int MAX_LINES = 15;

    private static final class TeamRef {
        String name;
        String prefix = "";
        String suffix = "";
        String color = "";
    }

    private static final class Board {
        Scoreboard sb;
        Objective side;
        Objective below;
        Objective ping;
        String boardId = "";
        String title = "";
        final String[] lines = new String[MAX_LINES];
        int used;
        int lastN;
        final Map<UUID, TeamRef> teams = new HashMap<>();
        final Map<UUID, Integer> belowScore = new HashMap<>();
        final Map<UUID, Integer> pingScore = new HashMap<>();
    }

    /** Same for every viewer, computed once per target per update. */
    private record Tag(String team, String prefix, String suffix, String color) {
    }

    private final ZenTials plugin;
    private final AuraConfig cfg;
    private final AuraText text;
    private final Map<UUID, Board> boards = new ConcurrentHashMap<>();

    AuraBoards(ZenTials plugin, AuraConfig cfg, AuraText text) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.text = text;
    }

    private static String entry(int i) {
        return "§" + Integer.toHexString(i) + "§r";
    }

    private Board ensure(Player p) {
        Board b = boards.get(p.getUniqueId());
        if (b != null) return b;
        b = new Board();
        b.sb = Bukkit.getScoreboardManager().getNewScoreboard();
        boards.put(p.getUniqueId(), b);
        p.setScoreboard(b.sb);
        return b;
    }

    void release(Player p) {
        Board b = boards.remove(p.getUniqueId());
        if (b == null) return;
        if (p.isOnline() && p.getScoreboard() == b.sb) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    void releaseAll() {
        for (Player p : Bukkit.getOnlinePlayers()) release(p);
        boards.clear();
    }

    void forget(UUID u) {
        boards.remove(u);
        for (Board b : boards.values()) {
            TeamRef t = b.teams.remove(u);
            if (t != null) {
                Team tm = b.sb.getTeam(t.name);
                if (tm != null) tm.unregister();
            }
            b.belowScore.remove(u);
            b.pingScore.remove(u);
        }
    }

    // ---------------------------------------------------------------- sidebar

    void updateSidebar(Player p, long now) {
        Board b = ensure(p);
        AuraConfig.BoardDef def = cfg.sbOff.contains(p.getUniqueId()) ? null : cfg.boardFor(p);
        if (def == null) {
            if (b.side != null) {
                b.side.unregister();
                b.side = null;
                b.boardId = "";
                b.used = 0;
                for (int i = 0; i < MAX_LINES; i++) b.lines[i] = null;
            }
            return;
        }
        if (b.side == null || !b.boardId.equals(def.id)) {
            if (b.side != null) b.side.unregister();
            for (int i = 0; i < MAX_LINES; i++) {
                Team t = b.sb.getTeam("zt_l" + i);
                if (t != null) t.unregister();
                b.sb.resetScores(entry(i));
                b.lines[i] = null;
            }
            b.title = "";
            b.used = 0;
            b.side = b.sb.registerNewObjective("zt_side", "dummy", Component.empty());
            b.side.setDisplaySlot(DisplaySlot.SIDEBAR);
            if (cfg.boardsYml.getBoolean("hide-numbers", true)) b.side.numberFormat(NumberFormat.blank());
            b.boardId = def.id;
        }
        String title = text.render(p, def.title, now);
        if (!title.equals(b.title)) {
            b.title = title;
            b.side.displayName(Text.c(title));
        }
        int n = Math.min(MAX_LINES, def.lines.size());
        for (int i = 0; i < n; i++) {
            String line = text.render(p, def.lines.get(i), now);
            if (line.isEmpty()) line = "&r";
            Team t = b.sb.getTeam("zt_l" + i);
            if (t == null) {
                t = b.sb.registerNewTeam("zt_l" + i);
                t.addEntry(entry(i));
            }
            if (!line.equals(b.lines[i])) {
                b.lines[i] = line;
                t.prefix(Text.c(line));
            }
            if (i >= b.used || n != b.lastN) b.side.getScore(entry(i)).setScore(n - i);
        }
        for (int i = n; i < b.used; i++) {
            b.sb.resetScores(entry(i));
            b.lines[i] = null;
        }
        b.used = n;
        b.lastN = n;
    }

    // ---------------------------------------------------------------- name tags, below-name, ping

    private static NamedTextColor named(String code) {
        if (code == null || code.length() < 2) return null;
        return switch (Character.toLowerCase(code.charAt(1))) {
            case '0' -> NamedTextColor.BLACK;
            case '1' -> NamedTextColor.DARK_BLUE;
            case '2' -> NamedTextColor.DARK_GREEN;
            case '3' -> NamedTextColor.DARK_AQUA;
            case '4' -> NamedTextColor.DARK_RED;
            case '5' -> NamedTextColor.DARK_PURPLE;
            case '6' -> NamedTextColor.GOLD;
            case '7' -> NamedTextColor.GRAY;
            case '8' -> NamedTextColor.DARK_GRAY;
            case '9' -> NamedTextColor.BLUE;
            case 'a' -> NamedTextColor.GREEN;
            case 'b' -> NamedTextColor.AQUA;
            case 'c' -> NamedTextColor.RED;
            case 'd' -> NamedTextColor.LIGHT_PURPLE;
            case 'e' -> NamedTextColor.YELLOW;
            case 'f' -> NamedTextColor.WHITE;
            default -> null;
        };
    }

    /**
     * Refreshes the name tags (and below-name / ping numbers) on every viewer board.
     *
     * @param eligible players that are shown (not in a disabled world)
     */
    void updateTags(Set<Player> eligible, long now, boolean tags, boolean belowOn, boolean pingOn) {
        Map<UUID, Tag> info = new HashMap<>();
        Map<UUID, Integer> below = new HashMap<>();
        Map<UUID, Integer> ping = new HashMap<>();
        String belowValue = cfg.main.getString("nametag.below-name.value", "{health}");
        for (Player t : eligible) {
            if (tags) {
                AuraConfig.Group g = cfg.groupOf(t);
                String sort = String.format("%03d", Math.max(0, Math.min(999, 999 - g.weight)));
                String team = sort + t.getUniqueId().toString().replace("-", "").substring(0, 12);
                info.put(t.getUniqueId(), new Tag(team, text.render(t, g.tagPrefix, now), text.render(t, g.tagSuffix, now), g.tagColor));
            }
            if (belowOn) below.put(t.getUniqueId(), parseInt(text.plain(t, belowValue, now)));
            if (pingOn) ping.put(t.getUniqueId(), t.getPing());
        }
        boolean hideNames = cfg.main.getBoolean("nametag.hide-nametags", false);
        boolean collide = cfg.main.getBoolean("nametag.collision", true);
        String belowText = cfg.main.getString("nametag.below-name.text", "");

        for (Player v : eligible) {
            Board b = ensure(v);
            if (tags) {
                Iterator<Map.Entry<UUID, TeamRef>> it = b.teams.entrySet().iterator();
                while (it.hasNext()) {
                    var en = it.next();
                    Tag tag = info.get(en.getKey());
                    if (tag == null || !tag.team().equals(en.getValue().name)) {
                        Team old = b.sb.getTeam(en.getValue().name);
                        if (old != null) old.unregister();
                        it.remove();
                    }
                }
                for (Player t : eligible) {
                    Tag tag = info.get(t.getUniqueId());
                    TeamRef ref = b.teams.get(t.getUniqueId());
                    Team team;
                    if (ref == null) {
                        ref = new TeamRef();
                        ref.name = tag.team();
                        team = b.sb.getTeam(ref.name);
                        if (team == null) team = b.sb.registerNewTeam(ref.name);
                        team.addEntry(t.getName());
                        team.setOption(Team.Option.COLLISION_RULE, collide ? Team.OptionStatus.ALWAYS : Team.OptionStatus.NEVER);
                        team.setOption(Team.Option.NAME_TAG_VISIBILITY, hideNames ? Team.OptionStatus.NEVER : Team.OptionStatus.ALWAYS);
                        b.teams.put(t.getUniqueId(), ref);
                        ref.prefix = null;
                        ref.suffix = null;
                        ref.color = null;
                    } else {
                        team = b.sb.getTeam(ref.name);
                        if (team == null) {
                            b.teams.remove(t.getUniqueId());
                            continue;
                        }
                    }
                    if (!tag.prefix().equals(ref.prefix)) {
                        ref.prefix = tag.prefix();
                        team.prefix(Text.c(tag.prefix()));
                    }
                    if (!tag.suffix().equals(ref.suffix)) {
                        ref.suffix = tag.suffix();
                        team.suffix(Text.c(tag.suffix()));
                    }
                    if (!tag.color().equals(ref.color)) {
                        ref.color = tag.color();
                        NamedTextColor c = named(tag.color());
                        if (c != null) team.color(c);
                    }
                }
            }
            if (belowOn) {
                if (b.below == null) {
                    b.below = b.sb.registerNewObjective("zt_below", "dummy", Text.c(belowText));
                    b.below.setDisplaySlot(DisplaySlot.BELOW_NAME);
                    b.belowScore.clear();
                }
                for (var en : below.entrySet()) {
                    Player t = Bukkit.getPlayer(en.getKey());
                    if (t == null) continue;
                    if (!en.getValue().equals(b.belowScore.get(en.getKey()))) {
                        b.belowScore.put(en.getKey(), en.getValue());
                        b.below.getScore(t.getName()).setScore(en.getValue());
                    }
                }
            } else if (b.below != null) {
                b.below.unregister();
                b.below = null;
            }
            if (pingOn) {
                if (b.ping == null) {
                    b.ping = b.sb.registerNewObjective("zt_ping", "dummy", Component.text("ping"));
                    b.ping.setDisplaySlot(DisplaySlot.PLAYER_LIST);
                    b.pingScore.clear();
                }
                for (var en : ping.entrySet()) {
                    Player t = Bukkit.getPlayer(en.getKey());
                    if (t == null) continue;
                    if (!en.getValue().equals(b.pingScore.get(en.getKey()))) {
                        b.pingScore.put(en.getKey(), en.getValue());
                        b.ping.getScore(t.getName()).setScore(en.getValue());
                    }
                }
            } else if (b.ping != null) {
                b.ping.unregister();
                b.ping = null;
            }
        }
        // drop boards of players that are no longer eligible
        Set<UUID> keep = new HashSet<>();
        for (Player p : eligible) keep.add(p.getUniqueId());
        for (UUID u : new HashSet<>(boards.keySet())) {
            if (!keep.contains(u)) {
                Player p = Bukkit.getPlayer(u);
                if (p != null) release(p);
                else boards.remove(u);
            }
        }
    }

    private static int parseInt(String s) {
        try {
            return (int) Double.parseDouble(s.replaceAll("[^0-9.\\-]", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
