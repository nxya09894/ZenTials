package com.zentials.aura;

import com.zentials.ZenTials;
import com.zentials.core.Papi;
import com.zentials.core.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Text engine of the aura module: {placeholders}, %anim:name% animations, PlaceholderAPI and the
 * per-tick colour effects <rainbow>, <gradient>, <pulse>, <blink>. Output is a legacy "&" string
 * (hex as &#rrggbb) that Text.c() turns into a Component.
 */
final class AuraText {
    private static final Pattern EFFECT = Pattern.compile("<(rainbow|gradient|pulse|blink)(?::([^>]*))?>(.*?)</\\1>", Pattern.DOTALL);
    private static final Pattern ANIM = Pattern.compile("%anim:([A-Za-z0-9_\\-]+)%");
    private static final Pattern HOLDER = Pattern.compile("\\{([a-z_]+)}");
    private static final Pattern NUM = Pattern.compile("[0-9]+(\\.[0-9]+)?");

    private static final Map<String, Integer> NAMED = new HashMap<>();

    static {
        String[][] n = {{"black", "000000"}, {"dark_blue", "0000aa"}, {"dark_green", "00aa00"}, {"dark_aqua", "00aaaa"},
                {"dark_red", "aa0000"}, {"dark_purple", "aa00aa"}, {"gold", "ffaa00"}, {"gray", "aaaaaa"},
                {"dark_gray", "555555"}, {"blue", "5555ff"}, {"green", "55ff55"}, {"aqua", "55ffff"},
                {"red", "ff5555"}, {"light_purple", "ff55ff"}, {"yellow", "ffff55"}, {"white", "ffffff"},
                {"pink", "ff55ff"}, {"orange", "ffaa00"}, {"purple", "aa00aa"}};
        for (String[] a : n) NAMED.put(a[0], Integer.parseInt(a[1], 16));
    }

    private interface Anim {
        String frame(long tick);
    }

    private final ZenTials plugin;
    private final AuraConfig cfg;
    private final Map<String, Anim> anims = new HashMap<>();
    private ZoneId zone = ZoneId.systemDefault();

    AuraText(ZenTials plugin, AuraConfig cfg) {
        this.plugin = plugin;
        this.cfg = cfg;
    }

    void reload() {
        anims.clear();
        String tz = cfg.main.getString("timezone", "");
        try {
            zone = tz == null || tz.isBlank() ? ZoneId.systemDefault() : ZoneId.of(tz);
        } catch (Exception e) {
            zone = ZoneId.systemDefault();
        }
        ConfigurationSection s = cfg.animations.getConfigurationSection("animations");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection a = s.getConfigurationSection(id);
            if (a == null) continue;
            int interval = Math.max(1, a.getInt("interval", 5));
            String type = a.getString("type", "frames").toLowerCase(Locale.ROOT);
            switch (type) {
                case "scroll" -> {
                    String text = a.getString("text", "");
                    int width = Math.max(3, a.getInt("width", 16));
                    String color = a.getString("color", "");
                    String loop = text + "   ";
                    String twice = loop + loop;
                    anims.put(id.toLowerCase(Locale.ROOT), t -> {
                        int i = (int) ((t / interval) % loop.length());
                        return color + twice.substring(i, Math.min(twice.length(), i + width));
                    });
                }
                case "typewriter" -> {
                    String text = a.getString("text", "");
                    int hold = Math.max(1, a.getInt("hold", 30));
                    String color = a.getString("color", "");
                    int cycle = text.length() + hold + 1;
                    anims.put(id.toLowerCase(Locale.ROOT), t -> {
                        int i = (int) ((t / interval) % cycle);
                        return color + text.substring(0, Math.min(i, text.length()));
                    });
                }
                default -> {
                    List<String> frames = a.getStringList("frames");
                    if (frames.isEmpty()) continue;
                    anims.put(id.toLowerCase(Locale.ROOT), t -> frames.get((int) ((t / interval) % frames.size())));
                }
            }
        }
    }

    Set<String> animNames() {
        return anims.keySet();
    }

    // ---------------------------------------------------------------- main entry points

    /** Full pipeline: animations, {placeholders}, PlaceholderAPI, colour effects. */
    String render(Player p, String s, long tick) {
        return render(p, s, tick, Set.of());
    }

    String render(Player p, String s, long tick, Set<String> keep) {
        if (s == null || s.isEmpty()) return "";
        s = expandAnims(s, tick);
        s = holders(p, s, keep, 0);
        if (p != null) s = Papi.set(p, s);
        return effects(s, tick);
    }

    Component comp(Player p, String s, long tick) {
        return Text.c(render(p, s, tick));
    }

    String plain(Player p, String s, long tick) {
        return PlainTextComponentSerializer.plainText().serialize(comp(p, s, tick));
    }

    private String expandAnims(String s, long tick) {
        if (s.indexOf("%anim:") < 0) return s;
        for (int pass = 0; pass < 2; pass++) {
            Matcher m = ANIM.matcher(s);
            StringBuilder sb = new StringBuilder();
            boolean any = false;
            while (m.find()) {
                Anim a = anims.get(m.group(1).toLowerCase(Locale.ROOT));
                m.appendReplacement(sb, Matcher.quoteReplacement(a == null ? "" : a.frame(tick)));
                any = true;
            }
            m.appendTail(sb);
            s = sb.toString();
            if (!any || s.indexOf("%anim:") < 0) break;
        }
        return s;
    }

    // ---------------------------------------------------------------- {placeholders}

    private String holders(Player p, String s, Set<String> keep, int depth) {
        if (s.indexOf('{') < 0) return s;
        Matcher m = HOLDER.matcher(s);
        StringBuilder sb = new StringBuilder();
        boolean any = false;
        while (m.find()) {
            String k = m.group(1);
            String v = keep.contains(k) ? null : value(p, k);
            if (v == null) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group()));
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(v));
                any = true;
            }
        }
        m.appendTail(sb);
        String out = sb.toString();
        return any && depth < 2 ? holders(p, out, keep, depth + 1) : out;
    }

    String value(Player p, String k) {
        switch (k) {
            case "online":
                return String.valueOf(Bukkit.getOnlinePlayers().size());
            case "max":
                return String.valueOf(Bukkit.getMaxPlayers());
            case "tps": {
                double t = Math.min(20.0, Bukkit.getTPS()[0]);
                return String.format(Locale.US, "%.1f", t);
            }
            case "tpscolor": {
                double t = Bukkit.getTPS()[0];
                return t >= 18 ? "&a" : t >= 15 ? "&e" : "&c";
            }
            case "time":
                return ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern(cfg.main.getString("time-format", "HH:mm")));
            case "date":
                return ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern(cfg.main.getString("date-format", "MMM d, yyyy")));
            default:
                break;
        }
        if (p == null) return null;
        AuraConfig.Group g = cfg.groupOf(p);
        switch (k) {
            case "player":
            case "name":
                return p.getName();
            case "displayname":
                return PlainTextComponentSerializer.plainText().serialize(p.displayName());
            case "world":
                return p.getWorld().getName();
            case "ping":
                return String.valueOf(p.getPing());
            case "pingcolor": {
                int ping = p.getPing();
                return ping < 80 ? "&a" : ping < 160 ? "&e" : "&c";
            }
            case "health":
                return String.valueOf((int) Math.ceil(p.getHealth()));
            case "maxhealth":
                return String.valueOf((int) Math.ceil(p.getMaxHealth()));
            case "food":
                return String.valueOf(p.getFoodLevel());
            case "level":
                return String.valueOf(p.getLevel());
            case "x":
                return String.valueOf(p.getLocation().getBlockX());
            case "y":
                return String.valueOf(p.getLocation().getBlockY());
            case "z":
                return String.valueOf(p.getLocation().getBlockZ());
            case "gamemode":
                return p.getGameMode().name().toLowerCase(Locale.ROOT);
            case "kills":
                return String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS));
            case "deaths":
                return String.valueOf(p.getStatistic(Statistic.DEATHS));
            case "mobkills":
                return String.valueOf(p.getStatistic(Statistic.MOB_KILLS));
            case "playtime":
                return String.valueOf(p.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20 / 3600);
            case "balance":
                return plugin.economyApi() == null ? "0" : plugin.economyApi().format(plugin.economyApi().balance(p.getUniqueId()));
            case "balance_short":
                return plugin.economyApi() == null ? "0" : plugin.economyApi().formatShort(plugin.economyApi().balance(p.getUniqueId()));
            case "group":
                return g.id;
            case "prefix":
                return g.chatPrefix;
            case "suffix":
                return g.chatSuffix;
            case "tabprefix":
                return g.tabPrefix;
            case "tabsuffix":
                return g.tabSuffix;
            case "tagprefix":
                return g.tagPrefix;
            case "tagsuffix":
                return g.tagSuffix;
            case "tag": {
                String t = cfg.tagDisplay(p.getUniqueId());
                return t.isEmpty() ? "" : t + " ";
            }
            default:
                return null;
        }
    }

    // ---------------------------------------------------------------- colour effects

    String effects(String s, long tick) {
        if (s.indexOf('<') < 0) return s;
        for (int pass = 0; pass < 3; pass++) {
            Matcher m = EFFECT.matcher(s);
            if (!m.find()) break;
            m.reset();
            StringBuilder sb = new StringBuilder();
            while (m.find()) {
                String r;
                try {
                    r = apply(m.group(1), m.group(2) == null ? new String[0] : m.group(2).split(":"), m.group(3), tick);
                } catch (RuntimeException e) {
                    r = m.group(3);
                }
                m.appendReplacement(sb, Matcher.quoteReplacement(r));
            }
            m.appendTail(sb);
            s = sb.toString();
        }
        return s;
    }

    private static String apply(String kind, String[] a, String content, long tick) {
        switch (kind) {
            case "rainbow": {
                double speed = a.length > 0 ? Double.parseDouble(a[0]) : 3;
                double sat = a.length > 1 ? Double.parseDouble(a[1]) : 1.0;
                double off = tick * speed * 0.004;
                return paint(content, (i, n) -> hsv((i * 0.06 + off) % 1.0, sat, 1.0));
            }
            case "gradient": {
                List<Integer> cols = new ArrayList<>();
                double speed = 0;
                for (String x : a) {
                    Integer c = color(x);
                    if (c != null) cols.add(c);
                    else if (NUM.matcher(x).matches()) speed = Double.parseDouble(x);
                }
                if (cols.size() < 2) return content;
                final boolean moving = speed > 0;
                if (moving) cols.add(cols.get(0)); // closed loop so it wraps smoothly
                final double off = tick * speed * 0.004;
                final List<Integer> pal = cols;
                return paint(content, (i, n) -> {
                    double t = n <= 1 ? 0 : (double) i / (n - 1);
                    if (moving) t = (t + off) % 1.0;
                    double pos = t * (pal.size() - 1);
                    int lo = Math.min((int) pos, pal.size() - 2);
                    return lerp(pal.get(lo), pal.get(lo + 1), pos - lo);
                });
            }
            case "pulse": {
                Integer c1 = color(a.length > 0 ? a[0] : "#ffffff");
                Integer c2 = color(a.length > 1 ? a[1] : "#888888");
                double speed = a.length > 2 ? Double.parseDouble(a[2]) : 3;
                if (c1 == null || c2 == null) return content;
                double f = (Math.sin(tick * speed * 0.05) + 1) / 2;
                int c = lerp(c1, c2, f);
                return paint(content, (i, n) -> c);
            }
            case "blink": {
                Integer c1 = color(a.length > 0 ? a[0] : "#ffffff");
                Integer c2 = color(a.length > 1 ? a[1] : "#555555");
                int period = a.length > 2 ? Math.max(1, Integer.parseInt(a[2])) : 10;
                if (c1 == null || c2 == null) return content;
                int c = (tick / period) % 2 == 0 ? c1 : c2;
                return paint(content, (i, n) -> c);
            }
            default:
                return content;
        }
    }

    private interface ColorAt {
        int at(int index, int count);
    }

    /** Colours every visible character. Inner colour codes are dropped, format codes (&l &o ...) are kept. */
    private static String paint(String content, ColorAt f) {
        StringBuilder fmt = new StringBuilder();
        List<String> chars = new ArrayList<>();
        List<String> fmts = new ArrayList<>();
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '&' && i + 1 < content.length()) {
                char n = Character.toLowerCase(content.charAt(i + 1));
                if (n == '#' && content.length() >= i + 8 && isHex(content.substring(i + 2, i + 8))) {
                    i += 7;
                    continue;
                }
                if ("0123456789abcdef".indexOf(n) >= 0) {
                    fmt.setLength(0);
                    i++;
                    continue;
                }
                if (n == 'r') {
                    fmt.setLength(0);
                    i++;
                    continue;
                }
                if ("lmnok".indexOf(n) >= 0) {
                    fmt.append('&').append(n);
                    i++;
                    continue;
                }
            }
            chars.add(String.valueOf(c));
            fmts.add(fmt.toString());
        }
        int visible = 0;
        for (String ch : chars) if (!ch.isBlank()) visible++;
        StringBuilder out = new StringBuilder();
        int idx = 0;
        for (int i = 0; i < chars.size(); i++) {
            String ch = chars.get(i);
            if (ch.isBlank()) {
                out.append(ch);
                continue;
            }
            out.append(hex(f.at(idx++, visible))).append(fmts.get(i)).append(ch);
        }
        return out.toString();
    }

    private static boolean isHex(String s) {
        if (s.length() != 6) return false;
        for (char c : s.toCharArray()) if (Character.digit(c, 16) < 0) return false;
        return true;
    }

    static String hex(int rgb) {
        return String.format("&#%06x", rgb & 0xFFFFFF);
    }

    static Integer color(String s) {
        if (s == null) return null;
        s = s.trim().toLowerCase(Locale.ROOT);
        if (s.startsWith("#") && isHex(s.substring(1))) return Integer.parseInt(s.substring(1), 16);
        return NAMED.get(s);
    }

    private static int lerp(int a, int b, double t) {
        int r = (int) Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static int hsv(double h, double s, double v) {
        double hh = h * 6;
        int i = (int) Math.floor(hh);
        double f = hh - i;
        double p = v * (1 - s);
        double q = v * (1 - s * f);
        double t = v * (1 - s * (1 - f));
        double r;
        double g;
        double b;
        switch (i % 6) {
            case 0 -> {
                r = v;
                g = t;
                b = p;
            }
            case 1 -> {
                r = q;
                g = v;
                b = p;
            }
            case 2 -> {
                r = p;
                g = v;
                b = t;
            }
            case 3 -> {
                r = p;
                g = q;
                b = v;
            }
            case 4 -> {
                r = t;
                g = p;
                b = v;
            }
            default -> {
                r = v;
                g = p;
                b = q;
            }
        }
        return ((int) Math.round(r * 255) << 16) | ((int) Math.round(g * 255) << 8) | (int) Math.round(b * 255);
    }

    // ---------------------------------------------------------------- legacy code helpers

    /** The colour/format codes that are still active at the end of a legacy string. */
    static String carry(String s) {
        String color = "";
        StringBuilder fmt = new StringBuilder();
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) != '&') continue;
            char n = Character.toLowerCase(s.charAt(i + 1));
            if (n == '#' && s.length() >= i + 8 && isHex(s.substring(i + 2, i + 8))) {
                color = s.substring(i, i + 8);
                fmt.setLength(0);
                i += 7;
            } else if ("0123456789abcdef".indexOf(n) >= 0) {
                color = "&" + n;
                fmt.setLength(0);
                i++;
            } else if (n == 'r') {
                color = "";
                fmt.setLength(0);
                i++;
            } else if ("lmnok".indexOf(n) >= 0) {
                fmt.append('&').append(n);
                i++;
            }
        }
        return color + fmt;
    }

    static String stripColors(String s) {
        return s.replaceAll("(?i)&([0-9a-fk-orx]|#[0-9a-f]{6})", "");
    }

    static String stripEffects(String s) {
        return s.replaceAll("(?s)</?(rainbow|gradient|pulse|blink)[^>]*>", "");
    }
}
