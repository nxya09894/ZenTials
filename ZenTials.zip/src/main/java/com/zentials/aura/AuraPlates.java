package com.zentials.aura;

import com.zentials.core.BedrockCheck;
import com.zentials.core.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Multi-line name plate above each player (a text display riding the player).
 * The owner does not see their own; Bedrock viewers see it too unless nametag.bedrock is "vanilla".
 */
final class AuraPlates {
    private static final class Plate {
        TextDisplay d;
        String last = "";
        final Set<UUID> hidden = new HashSet<>();
    }

    private final JavaPlugin plugin;
    private final AuraText text;
    private final Map<UUID, Plate> plates = new HashMap<>();

    AuraPlates(JavaPlugin plugin, AuraText text) {
        this.plugin = plugin;
        this.text = text;
    }

    void update(Set<Player> eligible, List<String> lines, double extra, boolean hideFromBedrock, long now) {
        for (Iterator<Map.Entry<UUID, Plate>> it = plates.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            Player o = plugin.getServer().getPlayer(en.getKey());
            if (o == null || !o.isOnline() || !eligible.contains(o)) {
                kill(en.getValue());
                it.remove();
            }
        }
        List<Player> bedrock = new ArrayList<>();
        for (Player v : plugin.getServer().getOnlinePlayers()) if (hideFromBedrock && BedrockCheck.is(v.getUniqueId())) bedrock.add(v);

        for (Player p : eligible) {
            Plate pl = plates.get(p.getUniqueId());
            if (pl == null || !pl.d.isValid() || !p.getPassengers().contains(pl.d)) {
                if (pl != null) kill(pl);
                pl = create(p, lines.size(), extra);
                if (pl == null) {
                    plates.remove(p.getUniqueId());
                    continue;
                }
                plates.put(p.getUniqueId(), pl);
            }
            String s = hidden(p) ? "" : render(p, lines, now);
            if (!s.equals(pl.last)) {
                pl.last = s;
                pl.d.text(s.isEmpty() ? Component.empty() : Text.c(s));
            }
            if (pl.hidden.add(p.getUniqueId())) p.hideEntity(plugin, pl.d);
            for (Player b : bedrock) if (pl.hidden.add(b.getUniqueId())) b.hideEntity(plugin, pl.d);
        }
    }

    private static boolean hidden(Player p) {
        return p.isInvisible() || p.isDead() || p.getGameMode() == GameMode.SPECTATOR;
    }

    private String render(Player p, List<String> lines, long now) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) b.append('\n');
            b.append(text.render(p, lines.get(i), now));
        }
        return b.toString();
    }

    private Plate create(Player p, int lineCount, double extra) {
        try {
            Plate pl = new Plate();
            float up = (float) (0.3 + 0.115 * lineCount + extra);
            pl.d = p.getWorld().spawn(p.getLocation(), TextDisplay.class, d -> {
                d.setPersistent(false);
                d.setBillboard(Display.Billboard.CENTER);
                d.setAlignment(TextDisplay.TextAlignment.CENTER);
                d.setDefaultBackground(false);
                d.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
                d.setShadowed(true);
                d.setLineWidth(1000);
                d.setViewRange(0.7f);
                d.setTransformation(new Transformation(new Vector3f(0f, up, 0f), new AxisAngle4f(), new Vector3f(1f, 1f, 1f), new AxisAngle4f()));
                d.addScoreboardTag("zt_plate");
            });
            if (!p.addPassenger(pl.d)) {
                pl.d.remove();
                return null;
            }
            return pl;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void kill(Plate pl) {
        if (pl != null && pl.d != null) pl.d.remove();
    }

    void remove(UUID id) {
        kill(plates.remove(id));
    }

    void removeAll() {
        for (Plate pl : plates.values()) kill(pl);
        plates.clear();
    }
}
