package com.zentials.ranks;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** A rank. Higher weight wins when a player has several. Other threads (PlaceholderAPI, chat) only read the volatile fields. */
final class Group extends Holder {
    final String name;
    volatile int weight;
    volatile String display = "";
    volatile String prefix = "";
    volatile String suffix = "";
    /** Rank color like &#7A1224 or &c. Read with %zrank_color%; the scoreboard {rank} uses it. */
    volatile String color = "";
    /** A sub-rank is only a bundle of permissions: never the main rank, no prefix/color, not on tracks. */
    volatile boolean sub;
    /** Your own settings for this rank (max-homes, backpack-rows, ...). Read with %zrank_meta_<key>% or RankModule.meta(). */
    final Map<String, String> meta = new ConcurrentHashMap<>();
    /** Console commands run when a player gets / loses this rank. */
    volatile List<String> onAdd = List.of();
    volatile List<String> onRemove = List.of();

    Group(String name) {
        this.name = name;
    }

    @Override
    String label() {
        return "group " + name;
    }

    /** The name to show: display if set, else the id with a capital letter. */
    String shown() {
        String d = display;
        if (d != null && !d.isBlank()) return d;
        return name.isEmpty() ? name : name.substring(0, 1).toUpperCase(Locale.ROOT) + name.substring(1);
    }
}
