package com.zentials.ranks;

import com.zentials.core.Tag;
import com.zentials.core.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/** /rank ... (aliases /zr, /ranks). Works from the console too. */
final class RankCommands implements TabExecutor {
    static final String ADMIN = "zentials.ranks.admin";
    private static final String P = Tag.RANKS;
    private static final Pattern NODE = Pattern.compile("[a-z0-9_.:*/-]+");
    private static final Pattern COLOR_ONLY = Pattern.compile("(?:&[0-9a-fk-orA-FK-OR]|&#[0-9a-fA-F]{6})*");
    private static final List<String> SUBS = List.of("help", "info", "reload", "list", "order", "create", "delete", "rename",
            "priority", "prefix", "suffix", "display", "addperm", "denyperm", "delperm", "inherit", "uninherit", "meta",
            "onadd", "onremove", "members", "give", "take", "set", "add", "remove", "promote", "demote", "check",
            "group", "user", "track", "creategroup", "deletegroup", "sub", "color");
    private static final List<String> GROUP_ACTS = List.of("info", "permission", "parent", "priority", "setprefix",
            "setsuffix", "setdisplay", "setcolor", "meta", "onadd", "onremove", "rename", "clone", "listmembers", "clear");
    private static final List<String> USER_ACTS = List.of("info", "permission", "parent", "promote", "demote", "clear");
    private static final List<String> TRACK_ACTS = List.of("list", "create", "delete", "info", "append", "insert", "remove");

    private final RankModule m;

    RankCommands(RankModule m) {
        this.m = m;
    }

    /** A mistake by the person typing: shown in red, nothing is changed. */
    private static final class Bad extends RuntimeException {
        private static final long serialVersionUID = 1L;

        Bad(String message) {
            super(message, null, false, false);
        }
    }

    private record Target(UUID id, String name) {
    }

    // ================================================================ entry

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof ConsoleCommandSender) && !s.hasPermission(ADMIN)) {
            say(s, "&cYou don't have permission to use this.");
            return true;
        }
        try {
            run(s, a);
        } catch (Bad e) {
            say(s, "&c" + e.getMessage());
        }
        return true;
    }

    private void run(CommandSender s, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "help", "?" -> help(s);
            case "info" -> info(s);
            case "reload" -> {
                m.reload();
                say(s, "&aReloaded. &7Groups: &f" + m.groups.size() + " &7Players with own data: &f" + m.users.size());
            }
            case "list", "groups" -> listGroups(s);
            case "create", "new", "creategroup", "cg" -> createGroup(s, a);
            case "delete", "deletegroup", "dg" -> deleteGroup(s, a);
            case "order" -> listGroups(s);
            case "rename" -> via(s, a, "rename");
            case "priority", "prio" -> via(s, a, "priority");
            case "color", "colour" -> via(s, a, "setcolor");
            case "sub", "subrank", "sr" -> sub(s, a);
            case "prefix" -> via(s, a, "setprefix");
            case "suffix" -> via(s, a, "setsuffix");
            case "display" -> via(s, a, "setdisplay");
            case "members" -> via(s, a, "listmembers");
            case "meta", "onadd", "onremove" -> via(s, a, sub);
            case "addperm" -> via(s, a, "permission", "set");
            case "delperm" -> via(s, a, "permission", "unset");
            case "inherit" -> via(s, a, "parent", "add");
            case "uninherit" -> via(s, a, "parent", "remove");
            case "denyperm" -> {
                String g = arg(a, 1, "/rank denyperm <group> <node> [duration]");
                String node = arg(a, 2, "/rank denyperm <group> <node> [duration]");
                List<String> l = new ArrayList<>(List.of("group", g, "permission", "set", node, "false"));
                for (int i = 3; i < a.length; i++) l.add(a[i]);
                group(s, l.toArray(new String[0]));
            }
            case "group", "g" -> group(s, a);
            case "user", "u" -> user(s, a);
            case "track", "tracks", "t" -> track(s, a);
            case "set" -> {
                Target t = target(arg(a, 1, "/rank set <player> <group>"));
                Group g = needGroup(arg(a, 2, "/rank set <player> <group>"));
                if (g.sub) throw new Bad(g.name + " is a sub-rank. Use /rank give " + t.name() + " " + g.name);
                m.setGroup(m.userFor(t.id(), t.name()), g);
                audit(s, "set " + t.name() + " to " + g.name);
                say(s, "&f" + t.name() + " &7is now in &f" + g.shown() + "&7 only.");
            }
            case "add", "give" -> {
                Target t = target(arg(a, 1, "/rank add <player> <group> [duration]"));
                Group g = needGroup(arg(a, 2, "/rank add <player> <group> [duration]"));
                if (g.name.equals(m.defaultGroup)) throw new Bad("Everybody is already in " + g.name + ".");
                long exp = durationArg(a, 3);
                m.addGroup(m.userFor(t.id(), t.name()), g, exp);
                audit(s, "added " + t.name() + " to " + g.name);
                say(s, "&f" + t.name() + " &7is now also in &f" + g.shown() + (exp > 0 ? " &7for &f" + Dur.format(exp - System.currentTimeMillis()) : "") + "&7.");
            }
            case "remove", "take" -> {
                Target t = target(arg(a, 1, "/rank remove <player> <group>"));
                String g = arg(a, 2, "/rank remove <player> <group>").toLowerCase(Locale.ROOT);
                if (!m.removeGroup(m.userFor(t.id(), t.name()), g)) throw new Bad(t.name() + " is not directly in " + g + ".");
                audit(s, "removed " + t.name() + " from " + g);
                say(s, "&f" + t.name() + " &7was removed from &f" + g + "&7.");
            }
            case "promote" -> ladder(s, target(arg(a, 1, "/rank promote <player> [track]")), a.length > 2 ? a[2] : null, true);
            case "demote" -> ladder(s, target(arg(a, 1, "/rank demote <player> [track]")), a.length > 2 ? a[2] : null, false);
            case "check" -> {
                Target t = target(arg(a, 1, "/rank check <player> <permission>"));
                checkNode(s, m.userFor(t.id(), t.name()), arg(a, 2, "/rank check <player> <permission>"));
            }
            default -> {
                say(s, "&cUnknown command.");
                help(s);
            }
        }
    }

    // ================================================================ general

    private void help(CommandSender s) {
        plain(s, "&8&m                                        ");
        plain(s, "&b&lRanks &7(ZenRanks) &8- &7easy commands (console or in game)");
        plain(s, "&e Ranks");
        plain(s, " &b/rank create <name> [priority] [display name] &8- &7new rank");
        plain(s, " &b/rank delete <name> &8| &b/rank rename <old> <new> &8| &b/rank list");
        plain(s, " &b/rank priority <rank> <number|top|bottom|above <rank>|below <rank>>");
        plain(s, " &b/rank prefix|suffix|display <rank> <text|clear>");
        plain(s, " &b/rank addperm <rank> <node> [true|false] [time] &8| &b/rank denyperm <rank> <node> &8| &b/rank delperm <rank> <node>");
        plain(s, " &b/rank inherit <rank> <parent> &8| &b/rank uninherit <rank> <parent>");
        plain(s, " &b/rank meta <rank> set <key> <value> | unset <key> | list");
        plain(s, " &b/rank onadd|onremove <rank> <console command> | list | clear");
        plain(s, " &b/rank members <rank> &8| &b/rank group <rank> info");
        plain(s, " &b/rank color <rank> <&#RRGGBB|&c|clear>");
        plain(s, "&e Sub-ranks &7(permission packs: make once, give to anyone)");
        plain(s, " &b/rank sub create <name> [display] &8| &b/rank sub list &8| &b/rank sub info <name> &8| &b/rank sub delete <name>");
        plain(s, " &b/rank sub addperm <sub> <node> &8| &b/rank sub delperm <sub> <node> &8| &b/rank sub members <sub>");
        plain(s, " &b/rank give <player> <sub> [time] &8| &b/rank take <player> <sub> &8| &b/rank inherit <rank> <sub>");
        plain(s, "&e Players");
        plain(s, " &b/rank set <player> <rank> &8| &b/rank give <player> <rank> [time] &8| &b/rank take <player> <rank>");
        plain(s, " &b/rank promote|demote <player> [track] &8| &b/rank check <player> <permission>");
        plain(s, " &b/rank user <player> info | clear | permission ... | parent ...");
        plain(s, "&e Other");
        plain(s, " &b/rank track list|create|delete|info|append|insert|remove");
        plain(s, " &b/rank group <rank> permission set|unset|list|check ...  &8(the long form of everything above)");
        plain(s, " &b/rank info &8| &b/rank reload");
        plain(s, "&7Time: &f30m 12h 7d 2w 1mo 1d12h &8| &7Everyone is in &f" + m.defaultGroup + " &7automatically.");
        plain(s, "&8&m                                        ");
    }

    /** /rank <cmd> <group> [rest...]  runs  /rank group <group> <action> [fixed...] [rest...]. */
    private void via(CommandSender s, String[] a, String action, String... fixed) {
        String g = arg(a, 1, "/rank " + a[0] + " <rank> ...");
        List<String> l = new ArrayList<>(List.of("group", g, action));
        l.addAll(List.of(fixed));
        for (int i = 2; i < a.length; i++) l.add(a[i]);
        group(s, l.toArray(new String[0]));
    }

    /** "owner(100) > admin(90) > ... > members(0)", and a warning when two ranks share a priority. */
    private String orderLine() {
        List<String> parts = new ArrayList<>();
        List<String> ties = new ArrayList<>();
        Group prev = null;
        for (Group g : m.sortedGroups().values()) {
            if (g.sub) continue;
            parts.add("&f" + g.name + "&8(" + g.weight + ")");
            if (prev != null && prev.weight == g.weight) ties.add(prev.name + "=" + g.name);
            prev = g;
        }
        return String.join(" &8> ", parts) + (ties.isEmpty() ? "" : " &e(same priority: " + String.join(", ", ties) + ")");
    }

    private void info(CommandSender s) {
        say(s, "&fGroups: &b" + m.groups.size() + " &8| &fPlayers with own data: &b" + m.users.size()
                + " &8| &fTracks: &b" + m.tracks.size());
        say(s, "&fDefault group: &b" + m.defaultGroup + " &8| &fDefault track: &b" + m.defaultTrack);
        if (Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) {
            say(s, "&eLuckPerms is installed too. Use only one permission plugin.");
        }
    }

    private void listGroups(CommandSender s) {
        say(s, "&fRanks &8(most important first)&f:");
        for (Group g : m.sortedGroups().values()) {
            if (g.sub) continue;
            long members = m.users.values().stream().filter(u -> u.get(Node.GROUP + g.name) != null).count();
            plain(s, " &8- &b" + g.name + " &8(" + (g.color.isEmpty() ? "&7" : g.color) + g.shown() + "&8) &7priority &f" + g.weight
                    + (g.name.equals(m.defaultGroup) ? " &8[default, everyone]" : " &8[" + members + " players]")
                    + (g.prefix.isEmpty() ? "" : " &7prefix: " + g.prefix + "Name"));
        }
        listSubs(s);
    }

    private void listSubs(CommandSender s) {
        boolean any = false;
        for (Group g : m.sortedGroups().values()) {
            if (!g.sub) continue;
            if (!any) say(s, "&fSub-ranks &8(permission packs)&f:");
            any = true;
            long members = m.users.values().stream().filter(u -> u.get(Node.GROUP + g.name) != null).count();
            long perms = g.nodes.values().stream().filter(n -> !n.isGroup()).count();
            plain(s, " &8- &d" + g.name + " &8(&7" + g.shown() + "&8) &7" + perms + " permissions &8[" + members + " players]");
        }
        if (!any) say(s, "&7No sub-ranks yet. Make one: &f/rank sub create <name>");
    }

    /** /rank sub create|list|info|... : sub-ranks are permission packs. Everything else is the normal rank command. */
    private void sub(CommandSender s, String[] a) {
        String act = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "list";
        switch (act) {
            case "list" -> listSubs(s);
            case "create", "new" -> {
                String name = arg(a, 2, "/rank sub create <name> [display name]").toLowerCase(Locale.ROOT);
                if (!RankModule.NAME.matcher(name).matches()) throw new Bad("Names use a-z, 0-9, _ and - (up to 32 characters).");
                if (m.groups.containsKey(name)) throw new Bad("A rank or sub-rank named " + name + " already exists.");
                Group g = m.createGroup(name, 0, true);
                if (a.length > 3) {
                    g.display = String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length)).toUpperCase(Locale.ROOT);
                    m.changed(g);
                }
                audit(s, "created sub-rank " + name);
                say(s, "&aCreated sub-rank &d" + name + "&a. Next:");
                plain(s, " &b/rank sub addperm " + name + " <permission> &7- put permissions in it");
                plain(s, " &b/rank give <player> " + name + " [time] &7- give it to a player");
                plain(s, " &b/rank inherit <rank> " + name + " &7- or give it to a whole rank");
            }
            case "info" -> groupInfo(s, needSub(arg(a, 2, "/rank sub info <name>")));
            case "delete", "remove" -> {
                Group g = needSub(arg(a, 2, "/rank sub delete <name>"));
                m.deleteGroup(g);
                audit(s, "deleted sub-rank " + g.name);
                say(s, "&aDeleted sub-rank &f" + g.name + "&7 (removed from players and ranks too).");
            }
            case "addperm", "denyperm", "delperm", "members", "meta", "onadd", "onremove", "rename", "display" -> {
                needSub(arg(a, 2, "/rank sub " + act + " <sub> ..."));
                String[] b = new String[a.length - 1];
                System.arraycopy(a, 1, b, 0, b.length);
                run(s, b);
            }
            default -> throw new Bad("Usage: /rank sub <create|list|info|delete|addperm|delperm|denyperm|members|rename> ...");
        }
    }

    private Group needSub(String name) {
        Group g = needGroup(name);
        if (!g.sub) throw new Bad(g.name + " is a normal rank, not a sub-rank.");
        return g;
    }

    private void createGroup(CommandSender s, String[] a) {
        String name = arg(a, 1, "/rank create <name> [priority] [display name]").toLowerCase(Locale.ROOT);
        if (!RankModule.NAME.matcher(name).matches()) throw new Bad("Rank names use a-z, 0-9, _ and - (up to 32 characters).");
        if (m.groups.containsKey(name)) throw new Bad("A rank named " + name + " already exists.");
        Group def = m.groups.get(m.defaultGroup);
        int priority = (def == null ? 0 : def.weight) + 10; // just above the default rank unless you say otherwise
        if (a.length > 2) priority = intArg(a[2]);
        Group g = m.createGroup(name, priority);
        if (a.length > 3) {
            g.display = String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length)).toUpperCase(Locale.ROOT);
            m.changed(g);
        }
        audit(s, "created rank " + name);
        say(s, "&aCreated rank &f" + name + " &7(priority " + priority + "). Order: " + orderLine());
        say(s, "&7Next: &f/rank addperm " + name + " <permission> &8| &f/rank prefix " + name + " &6[Tag]");
    }

    private void deleteGroup(CommandSender s, String[] a) {
        Group g = needGroup(arg(a, 1, "/rank deletegroup <name>"));
        if (g.name.equals(m.defaultGroup)) throw new Bad("The default group cannot be deleted.");
        m.deleteGroup(g);
        audit(s, "deleted group " + g.name);
        say(s, "&aDeleted rank &f" + g.name + "&7 (removed from players, other ranks and tracks too).");
    }

    // ================================================================ /rank group

    private void group(CommandSender s, String[] a) {
        Group g = needGroup(arg(a, 1, "/rank group <group> <action>"));
        String act = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : "info";
        switch (act) {
            case "info" -> groupInfo(s, g);
            case "permission", "perm", "permissions" -> permission(s, g, a, 3);
            case "parent", "parents", "inherit" -> parent(s, g, a, 3);
            case "priority", "setpriority", "setweight", "weight" -> {
                if (a.length <= 3) {
                    say(s, "Priority of &f" + g.name + "&7: &b" + g.weight + " &8| &7" + orderLine());
                    return;
                }
                String v = a[3].toLowerCase(Locale.ROOT);
                switch (v) {
                    case "top", "bottom" -> m.movePriority(g, v, null);
                    case "above", "below" -> {
                        Group ref = needGroup(arg(a, 4, "/rank priority " + g.name + " " + v + " <rank>"));
                        if (ref == g) throw new Bad("Pick a different rank.");
                        m.movePriority(g, v, ref);
                    }
                    default -> {
                        g.weight = intArg(v);
                        m.changed(g);
                    }
                }
                audit(s, g.name + " priority " + g.weight);
                say(s, "Priority of &f" + g.name + " &7is now &b" + g.weight + "&7. " + orderLine());
            }
            case "meta" -> {
                String ma = arg(a, 3, "/rank meta " + g.name + " <set|unset|list> ...").toLowerCase(Locale.ROOT);
                switch (ma) {
                    case "list" -> {
                        if (g.meta.isEmpty()) say(s, "&f" + g.name + " &7has no meta settings. Add one: &f/rank meta " + g.name + " set <key> <value>");
                        else for (Map.Entry<String, String> e : new java.util.TreeMap<>(g.meta).entrySet()) plain(s, " &8- &b" + e.getKey() + "&7 = &f" + e.getValue());
                    }
                    case "set" -> {
                        String key = metaKey(arg(a, 4, "/rank meta " + g.name + " set <key> <value>"));
                        g.meta.put(key, join(a, 5));
                        m.changed(g);
                        audit(s, g.name + " meta " + key);
                        say(s, "&f" + g.name + " &7meta &b" + key + " &7= &f" + g.meta.get(key) + " &8(read it with %zrank_meta_" + key + "%)");
                    }
                    case "unset", "remove" -> {
                        String key = metaKey(arg(a, 4, "/rank meta " + g.name + " unset <key>"));
                        if (g.meta.remove(key) == null) throw new Bad(g.name + " has no meta " + key + ".");
                        m.changed(g);
                        say(s, "Removed meta &b" + key + " &7from &f" + g.name + "&7.");
                    }
                    default -> throw new Bad("Usage: /rank meta " + g.name + " <set|unset|list> ...");
                }
            }
            case "onadd", "onremove" -> {
                boolean add = act.equals("onadd");
                String what = arg(a, 3, "/rank " + act + " " + g.name + " <console command | list | clear>");
                List<String> cur = new ArrayList<>(add ? g.onAdd : g.onRemove);
                if (what.equalsIgnoreCase("list")) {
                    say(s, "Commands run when a player " + (add ? "gets" : "loses") + " &f" + g.name + "&7:");
                    for (String c : cur) plain(s, " &8- &f" + c);
                    if (cur.isEmpty()) plain(s, " &8none");
                    return;
                }
                if (what.equalsIgnoreCase("clear")) {
                    cur.clear();
                } else {
                    String cmd = join(a, 3).trim();
                    cur.add(cmd.startsWith("/") ? cmd.substring(1) : cmd);
                }
                List<String> fin = List.copyOf(cur);
                if (add) g.onAdd = fin;
                else g.onRemove = fin;
                m.saveGroups();
                audit(s, g.name + " " + act + " changed");
                say(s, "&f" + g.name + " &7now runs &f" + fin.size() + " &7console command(s) when a player " + (add ? "gets" : "loses") + " it. &8({player} {uuid} {group} work)");
            }
            case "rename" -> {
                String nn = arg(a, 3, "/rank rename " + g.name + " <new name>").toLowerCase(Locale.ROOT);
                if (g.name.equals(m.defaultGroup)) throw new Bad("The default rank is named in config.yml (default-group). Change it there, then /rank reload.");
                if (!RankModule.NAME.matcher(nn).matches()) throw new Bad("Rank names use a-z, 0-9, _ and -.");
                if (m.groups.containsKey(nn)) throw new Bad("A rank named " + nn + " already exists.");
                m.renameGroup(g, nn);
                audit(s, "renamed " + g.name + " to " + nn);
                say(s, "&aRenamed &f" + g.name + " &ato &f" + nn + "&a (players, parents and tracks updated).");
            }
            case "setprefix" -> {
                g.prefix = decorate(join(a, 3), false);
                m.changed(g);
                say(s, "Prefix of &f" + g.name + "&7: " + (g.prefix.isEmpty() ? "&8(none)" : g.prefix + "Name"));
            }
            case "setsuffix" -> {
                g.suffix = decorate(join(a, 3), true);
                m.changed(g);
                say(s, "Suffix of &f" + g.name + "&7: " + (g.suffix.isEmpty() ? "&8(none)" : "Name" + g.suffix));
            }
            case "setcolor", "color" -> {
                if (g.sub) throw new Bad("Sub-ranks have no color.");
                String t = join(a, 3).trim();
                if (t.equalsIgnoreCase("clear") || t.equalsIgnoreCase("none")) t = "";
                else {
                    if (t.matches("[0-9a-fA-F]{6}")) t = "&#" + t;
                    else if (t.matches("#[0-9a-fA-F]{6}")) t = "&" + t;
                    if (t.isEmpty() || !COLOR_ONLY.matcher(t).matches()) throw new Bad("Use a color like &#7A1224 or &c, or 'clear'.");
                }
                g.color = t;
                m.changed(g);
                say(s, "Color of &f" + g.name + "&7: " + (t.isEmpty() ? "&8(none)" : t + g.shown()));
            }
            case "setdisplay", "setdisplayname" -> {
                String t = join(a, 3);
                g.display = t.equalsIgnoreCase("clear") || t.equalsIgnoreCase("none") ? "" : t.toUpperCase(Locale.ROOT);
                m.changed(g);
                say(s, "Display name of &f" + g.name + "&7: &f" + g.shown());
            }
            case "clone" -> {
                String name = arg(a, 3, "/rank group " + g.name + " clone <new name>").toLowerCase(Locale.ROOT);
                if (!RankModule.NAME.matcher(name).matches()) throw new Bad("Group names use a-z, 0-9, _ and -.");
                if (m.groups.containsKey(name)) throw new Bad("A group named " + name + " already exists.");
                Group c = m.createGroup(name, g.weight, g.sub);
                c.color = g.color;
                c.display = g.display;
                c.prefix = g.prefix;
                c.suffix = g.suffix;
                c.nodes.putAll(g.nodes);
                m.changed(c);
                audit(s, "cloned " + g.name + " to " + name);
                say(s, "&aCloned &f" + g.name + " &ainto &f" + name + "&a.");
            }
            case "listmembers", "members" -> {
                if (g.name.equals(m.defaultGroup)) {
                    say(s, "Everybody is in &f" + g.name + " &7by default.");
                    return;
                }
                List<String> names = new ArrayList<>();
                long now = System.currentTimeMillis();
                for (User u : m.users.values()) {
                    Node n = u.get(Node.GROUP + g.name);
                    if (n != null && n.value() && !n.expired(now)) names.add(u.name);
                }
                Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
                say(s, "Members of &f" + g.name + " &8(" + names.size() + ")&7: &f" + (names.isEmpty() ? "-" : String.join("&7, &f", names)));
            }
            case "clear" -> {
                g.nodes.clear();
                m.changed(g);
                audit(s, "cleared " + g.name);
                say(s, "Removed every permission and parent from &f" + g.name + "&7.");
            }
            default -> throw new Bad("Usage: /rank group " + g.name + " <" + String.join("|", GROUP_ACTS) + ">");
        }
    }

    private void groupInfo(CommandSender s, Group g) {
        long now = System.currentTimeMillis();
        if (g.sub) {
            say(s, "&fSub-rank &d" + g.name + " &8(&7" + g.shown() + "&8) &7- a permission pack");
            List<String> users = new ArrayList<>();
            for (Group o : m.groups.values()) if (!o.sub && o.get(Node.GROUP + g.name) != null) users.add(o.name);
            plain(s, " &7Included in ranks: " + (users.isEmpty() ? "&8none" : "&f" + String.join("&7, &f", users)));
        } else {
            say(s, "&fRank &b" + g.name + " &8(&7" + g.shown() + "&8) &7priority &f" + g.weight
                    + (g.name.equals(m.defaultGroup) ? " &8[default]" : ""));
            plain(s, " &7Color: " + (g.color.isEmpty() ? "&8(none)" : g.color + g.shown()) + " &8| &7Prefix: "
                    + (g.prefix.isEmpty() ? "&8(none)" : g.prefix + "Name") + " &8| &7Suffix: "
                    + (g.suffix.isEmpty() ? "&8(none)" : "Name" + g.suffix));
        }
        List<String> parents = new ArrayList<>();
        for (Node n : g.parentNodes(now)) parents.add(nodeText(n, now, true));
        plain(s, " &7Parents: " + (parents.isEmpty() ? "&8none" : String.join("&7, ", parents)));
        if (!g.meta.isEmpty()) {
            List<String> kv = new ArrayList<>();
            for (Map.Entry<String, String> e : new java.util.TreeMap<>(g.meta).entrySet()) kv.add("&b" + e.getKey() + "&7=&f" + e.getValue());
            plain(s, " &7Meta: " + String.join("&7, ", kv));
        }
        if (!g.onAdd.isEmpty() || !g.onRemove.isEmpty()) {
            plain(s, " &7Console commands: &f" + g.onAdd.size() + " &7on add, &f" + g.onRemove.size() + " &7on remove");
        }
        listPermissions(s, g, now);
    }

    // ================================================================ /rank user

    private void user(CommandSender s, String[] a) {
        Target t = target(arg(a, 1, "/rank user <player> <action>"));
        User u = m.userFor(t.id(), t.name());
        String act = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : "info";
        switch (act) {
            case "info" -> userInfo(s, t, u);
            case "permission", "perm", "permissions" -> permission(s, u, a, 3);
            case "parent", "parents", "group", "groups" -> parent(s, u, a, 3);
            case "promote" -> ladder(s, t, a.length > 3 ? a[3] : null, true);
            case "demote" -> ladder(s, t, a.length > 3 ? a[3] : null, false);
            case "clear" -> {
                m.clearGroups(u);
                u.nodes.clear();
                m.changed(u);
                audit(s, "cleared " + t.name());
                say(s, "&f" + t.name() + " &7was reset: back to only &f" + m.defaultGroup + "&7 with no own permissions.");
            }
            default -> throw new Bad("Usage: /rank user " + t.name() + " <" + String.join("|", USER_ACTS) + ">");
        }
    }

    private void userInfo(CommandSender s, Target t, User u) {
        long now = System.currentTimeMillis();
        String primary = m.computePrimary(u.nodes.isEmpty() ? null : u);
        Group pg = m.groupById(primary);
        say(s, "&f" + t.name() + " &8(" + t.id() + ")" + (Bukkit.getPlayer(t.id()) != null ? " &aonline" : " &8offline"));
        plain(s, " &7Main group: &b" + (pg == null ? primary : pg.shown()));
        List<String> gs = new ArrayList<>();
        gs.add("&f" + m.defaultGroup + " &8(default)");
        for (Node n : u.parentNodes(now)) gs.add(nodeText(n, now, true));
        plain(s, " &7Groups: " + String.join("&7, ", gs));
        plain(s, " &7Own permissions: &f" + u.nodes.values().stream().filter(n -> !n.isGroup()).count()
                + " &8| &7All permissions they get: &f" + m.effective(u).size());
        listPermissions(s, u, now);
    }

    // ================================================================ permission / parent (groups and players)

    private void permission(CommandSender s, Holder h, String[] a, int i) {
        String act = arg(a, i, "permission <set|unset|list|check> ...").toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        switch (act) {
            case "set" -> {
                String node = nodeArg(arg(a, i + 1, "permission set <node> [true|false] [duration]"));
                boolean val = true;
                long exp = 0;
                for (int k = i + 2; k < a.length; k++) {
                    if (a[k].equalsIgnoreCase("true") || a[k].equalsIgnoreCase("false")) val = Boolean.parseBoolean(a[k]);
                    else exp = durationArg(a, k);
                }
                h.set(node, val, exp);
                commit(h);
                audit(s, node + "=" + val + " for " + h.label());
                say(s, "Set &f" + node + " &7to " + (val ? "&atrue" : "&cfalse") + " &7for &f" + h.label()
                        + (exp > 0 ? " &7for &f" + Dur.format(exp - now) : "") + "&7.");
            }
            case "unset", "remove" -> {
                String node = nodeArg(arg(a, i + 1, "permission unset <node>"));
                if (!h.unset(node)) throw new Bad(h.label() + " does not have " + node + " set directly.");
                commit(h);
                audit(s, "unset " + node + " for " + h.label());
                say(s, "Removed &f" + node + " &7from &f" + h.label() + "&7.");
            }
            case "list" -> listPermissions(s, h, now);
            case "check" -> checkNode(s, h, arg(a, i + 1, "permission check <node>"));
            default -> throw new Bad("Usage: permission <set|unset|list|check> ...");
        }
    }

    private void parent(CommandSender s, Holder h, String[] a, int i) {
        String act = arg(a, i, "parent <add|remove|set|clear|list> ...").toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        boolean isGroup = h instanceof Group;
        switch (act) {
            case "list" -> {
                List<String> parents = new ArrayList<>();
                for (Node n : h.parentNodes(now)) parents.add(nodeText(n, now, true));
                say(s, "&f" + h.label() + " &7inherits: " + (parents.isEmpty() ? "&8nothing" : String.join("&7, ", parents)));
            }
            case "add" -> {
                Group g = needGroup(arg(a, i + 1, "parent add <group> [duration]"));
                long exp = durationArg(a, i + 2);
                if (isGroup) {
                    Group hg = (Group) h;
                    if (m.wouldLoop(hg, g)) throw new Bad("That would make a loop (" + g.name + " already inherits " + hg.name + ").");
                    hg.set(Node.GROUP + g.name, true, exp);
                    m.changed(hg);
                } else {
                    if (g.name.equals(m.defaultGroup)) throw new Bad("Everybody is already in " + g.name + ".");
                    m.addGroup((User) h, g, exp);
                }
                audit(s, h.label() + " + parent " + g.name);
                say(s, "&f" + h.label() + " &7now inherits &f" + g.shown() + (exp > 0 ? " &7for &f" + Dur.format(exp - now) : "") + "&7.");
            }
            case "remove" -> {
                String gn = arg(a, i + 1, "parent remove <group>").toLowerCase(Locale.ROOT);
                boolean ok;
                if (isGroup) {
                    ok = h.unset(Node.GROUP + gn);
                    if (ok) m.changed((Group) h);
                } else {
                    ok = m.removeGroup((User) h, gn);
                }
                if (!ok) throw new Bad(h.label() + " does not directly inherit " + gn + ".");
                audit(s, h.label() + " - parent " + gn);
                say(s, "&f" + h.label() + " &7no longer inherits &f" + gn + "&7.");
            }
            case "set" -> {
                Group g = needGroup(arg(a, i + 1, "parent set <group>"));
                if (isGroup) {
                    Group hg = (Group) h;
                    if (m.wouldLoop(hg, g)) throw new Bad("That would make a loop (" + g.name + " already inherits " + hg.name + ").");
                    for (Node n : new ArrayList<>(hg.nodes.values())) if (n.isGroup()) hg.unset(n.key());
                    hg.set(Node.GROUP + g.name, true, 0);
                    m.changed(hg);
                } else {
                    m.setGroup((User) h, g);
                }
                audit(s, h.label() + " parent set " + g.name);
                say(s, "&f" + h.label() + " &7now inherits only &f" + g.shown() + "&7.");
            }
            case "clear" -> {
                if (isGroup) {
                    for (Node n : new ArrayList<>(h.nodes.values())) if (n.isGroup()) h.unset(n.key());
                    m.changed((Group) h);
                } else {
                    m.clearGroups((User) h);
                }
                audit(s, h.label() + " parents cleared");
                say(s, "&f" + h.label() + " &7has no parents now.");
            }
            default -> throw new Bad("Usage: parent <add|remove|set|clear|list> ...");
        }
    }

    private void checkNode(CommandSender s, Holder h, String raw) {
        String node = raw.toLowerCase(Locale.ROOT);
        Boolean v = m.effective(h).get(node);
        Node own = h.get(node);
        say(s, "&f" + node + " &7for &f" + h.label() + "&7: " + (v == null ? "&8not set" : v ? "&atrue" : "&cfalse")
                + (own != null ? " &8(set directly)" : v != null ? " &8(inherited or wildcard)" : ""));
    }

    private void listPermissions(CommandSender s, Holder h, long now) {
        List<String> out = new ArrayList<>();
        for (Node n : h.active(now)) if (!n.isGroup()) out.add(nodeText(n, now, false));
        if (out.isEmpty()) {
            plain(s, " &7Permissions: &8none set directly");
            return;
        }
        int max = 40;
        plain(s, " &7Permissions &8(" + out.size() + ")&7: " + String.join("&7, ", out.subList(0, Math.min(max, out.size())))
                + (out.size() > max ? " &8... +" + (out.size() - max) + " more" : ""));
    }

    private static String nodeText(Node n, long now, boolean group) {
        String name = group ? n.groupName() : n.key();
        return (n.value() ? "&a" : "&c") + name + (n.expiry() > 0 ? " &8(" + Dur.format(n.expiry() - now) + " left)" : "");
    }

    private void commit(Holder h) {
        if (h instanceof Group g) m.changed(g);
        else m.changed((User) h);
    }

    // ================================================================ promote / demote / tracks

    private void ladder(CommandSender s, Target t, String trackName, boolean up) {
        String tn = (trackName == null ? m.defaultTrack : trackName).toLowerCase(Locale.ROOT);
        List<String> tr = m.tracks.get(tn);
        if (tr == null || tr.isEmpty()) {
            throw new Bad("Unknown or empty track '" + tn + "'. Tracks: " + (m.tracks.isEmpty() ? "none" : String.join(", ", m.tracks.keySet())));
        }
        User u = m.userFor(t.id(), t.name());
        long now = System.currentTimeMillis();
        int idx = -1;
        for (int i = 0; i < tr.size(); i++) {
            Node n = u.get(Node.GROUP + tr.get(i));
            if (n != null && n.value() && !n.expired(now)) idx = i;
        }
        if (idx < 0 && tr.get(0).equals(m.defaultGroup)) idx = 0;
        int to = up ? idx + 1 : idx - 1;
        if (to >= tr.size()) throw new Bad(t.name() + " is already at the top of track " + tn + ".");
        if (to < 0) throw new Bad(t.name() + " is already at the bottom of track " + tn + ".");
        String from = idx >= 0 ? tr.get(idx) : null;
        Group dest = needGroup(tr.get(to));
        if (from != null && !from.equals(m.defaultGroup)) m.removeGroup(u, from);
        if (!dest.name.equals(m.defaultGroup)) m.addGroup(u, dest, 0);
        audit(s, (up ? "promoted " : "demoted ") + t.name() + " to " + dest.name);
        say(s, "&f" + t.name() + " &7was " + (up ? "promoted" : "demoted") + ": &e" + (from == null ? "-" : from) + " &8-> &a" + dest.name + " &8(track " + tn + ")");
    }

    private void track(CommandSender s, String[] a) {
        String act = arg(a, 1, "/rank track <" + String.join("|", TRACK_ACTS) + ">").toLowerCase(Locale.ROOT);
        if (act.equals("list")) {
            if (m.tracks.isEmpty()) {
                say(s, "No tracks yet. Create one: &f/rank track create <name>");
                return;
            }
            for (Map.Entry<String, List<String>> e : new java.util.TreeMap<>(m.tracks).entrySet()) {
                plain(s, " &8- &b" + e.getKey() + (e.getKey().equals(m.defaultTrack) ? " &8(default)" : "") + "&7: &f" + String.join(" &8-> &f", e.getValue()));
            }
            return;
        }
        String name = arg(a, 2, "/rank track " + act + " <track> ...").toLowerCase(Locale.ROOT);
        if (act.equals("create")) {
            if (!RankModule.NAME.matcher(name).matches()) throw new Bad("Track names use a-z, 0-9, _ and -.");
            if (m.tracks.containsKey(name)) throw new Bad("Track " + name + " already exists.");
            m.tracks.put(name, new ArrayList<>());
            m.saveGroups();
            say(s, "&aCreated track &f" + name + "&a. Add groups: &f/rank track append " + name + " <group>");
            return;
        }
        List<String> cur = m.tracks.get(name);
        if (cur == null) throw new Bad("Unknown track '" + name + "'.");
        List<String> list = new ArrayList<>(cur);
        switch (act) {
            case "info" -> say(s, "Track &b" + name + "&7: &f" + (list.isEmpty() ? "(empty)" : String.join(" &8-> &f", list)));
            case "delete" -> {
                m.tracks.remove(name);
                m.saveGroups();
                say(s, "Deleted track &f" + name + "&7.");
            }
            case "append" -> {
                Group g = needGroup(arg(a, 3, "/rank track append <track> <group>"));
                if (g.sub) throw new Bad("Sub-ranks cannot be on a track.");
                if (list.contains(g.name)) throw new Bad(g.name + " is already on this track.");
                list.add(g.name);
                m.tracks.put(name, list);
                m.saveGroups();
                say(s, "Track &b" + name + "&7: &f" + String.join(" &8-> &f", list));
            }
            case "insert" -> {
                Group g = needGroup(arg(a, 3, "/rank track insert <track> <group> <position>"));
                int pos = intArg(arg(a, 4, "/rank track insert <track> <group> <position>"));
                if (g.sub) throw new Bad("Sub-ranks cannot be on a track.");
                if (list.contains(g.name)) throw new Bad(g.name + " is already on this track.");
                list.add(Math.max(0, Math.min(list.size(), pos - 1)), g.name);
                m.tracks.put(name, list);
                m.saveGroups();
                say(s, "Track &b" + name + "&7: &f" + String.join(" &8-> &f", list));
            }
            case "remove" -> {
                String g = arg(a, 3, "/rank track remove <track> <group>").toLowerCase(Locale.ROOT);
                if (!list.remove(g)) throw new Bad(g + " is not on this track.");
                m.tracks.put(name, list);
                m.saveGroups();
                say(s, "Track &b" + name + "&7: &f" + (list.isEmpty() ? "(empty)" : String.join(" &8-> &f", list)));
            }
            default -> throw new Bad("Usage: /rank track <" + String.join("|", TRACK_ACTS) + ">");
        }
    }

    // ================================================================ helpers

    private void say(CommandSender s, String text) {
        Text.send(s, P + text);
    }

    private void plain(CommandSender s, String text) {
        Text.send(s, text);
    }

    private void audit(CommandSender s, String what) {
        if (!(s instanceof ConsoleCommandSender) && m.logChanges()) m.plugin.getLogger().info("[Ranks] " + s.getName() + ": " + what);
    }

    private static String arg(String[] a, int i, String usage) {
        if (i >= a.length) throw new Bad("Usage: " + (usage.startsWith("/") ? usage : "/rank ... " + usage));
        return a[i];
    }

    private static String join(String[] a, int from) {
        if (from >= a.length) throw new Bad("Type the text after the command (or 'clear' to remove it).");
        return String.join(" ", java.util.Arrays.copyOfRange(a, from, a.length));
    }

    private static int intArg(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            throw new Bad("Not a number: " + s);
        }
    }

    /** 0 when there is no duration argument, else the time (ms) when it ends. */
    private static long durationArg(String[] a, int i) {
        if (i >= a.length) return 0;
        long d = Dur.parse(a[i]);
        if (d < 0) throw new Bad("Not a duration: " + a[i] + " (try 30m, 12h, 7d, 2w)");
        return System.currentTimeMillis() + d;
    }

    private static String metaKey(String raw) {
        String k = raw.toLowerCase(Locale.ROOT).trim();
        if (!RankModule.NAME.matcher(k).matches()) throw new Bad("Meta keys use a-z, 0-9, _ and - (example: max-homes).");
        return k;
    }

    private static String nodeArg(String raw) {
        String n = raw.toLowerCase(Locale.ROOT).trim();
        if (n.startsWith("-")) throw new Bad("To deny a permission use: permission set <node> false");
        if (n.startsWith(Node.GROUP)) throw new Bad("Groups are not permissions. Use the 'parent' command.");
        if (!NODE.matcher(n).matches()) throw new Bad("Invalid permission: " + raw);
        return n;
    }

    /** Prefix needs a space before the name, suffix a space after the name, unless it is only color codes. */
    private static String decorate(String text, boolean suffix) {
        if (text.equalsIgnoreCase("clear") || text.equalsIgnoreCase("none")) return "";
        if (COLOR_ONLY.matcher(text).matches()) return text;
        if (suffix) return text.startsWith(" ") ? text : " " + text;
        return text.endsWith(" ") ? text : text + " ";
    }

    private Group needGroup(String name) {
        Group g = m.groups.get(name.toLowerCase(Locale.ROOT));
        if (g == null) throw new Bad("Unknown group '" + name + "'. Groups: " + String.join(", ", m.sortedGroups().keySet()));
        return g;
    }

    private Target target(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return new Target(online.getUniqueId(), online.getName());
        OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(name);
        if (off != null) return new Target(off.getUniqueId(), off.getName() == null ? name : off.getName());
        for (User u : m.users.values()) if (u.name.equalsIgnoreCase(name)) return new Target(u.id, u.name);
        try {
            UUID id = UUID.fromString(name);
            OfflinePlayer o = Bukkit.getOfflinePlayer(id);
            return new Target(id, o.getName() == null ? name : o.getName());
        } catch (IllegalArgumentException ignored) {
            throw new Bad("Unknown player '" + name + "'. They must have joined once (or use their UUID).");
        }
    }

    // ================================================================ tab complete

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof ConsoleCommandSender) && !s.hasPermission(ADMIN)) return List.of();
        int n = a.length;
        String cur = a[n - 1].toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if (n == 1) {
            out.addAll(SUBS);
        } else {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "group", "g" -> {
                    if (n == 2) out.addAll(m.groups.keySet());
                    else if (n == 3) out.addAll(GROUP_ACTS);
                    else if (List.of("priority", "meta", "onadd", "onremove").contains(a[2].toLowerCase(Locale.ROOT))) {
                        String[] b = new String[n - 1];
                        b[0] = a[2].toLowerCase(Locale.ROOT);
                        b[1] = a[1];
                        System.arraycopy(a, 3, b, 2, n - 3);
                        groupFirstTab(b, n - 1, out);
                    } else holderTab(a, n, out);
                }
                case "user", "u" -> {
                    if (n == 2) out.addAll(players());
                    else if (n == 3) out.addAll(USER_ACTS);
                    else if (a[2].equalsIgnoreCase("promote") || a[2].equalsIgnoreCase("demote")) {
                        if (n == 4) out.addAll(m.tracks.keySet());
                    } else holderTab(a, n, out);
                }
                case "sub", "subrank", "sr" -> {
                    if (n == 2) out.addAll(List.of("create", "list", "info", "delete", "addperm", "delperm", "denyperm", "members", "rename"));
                    else if (n == 3 && !a[1].equalsIgnoreCase("create") && !a[1].equalsIgnoreCase("list")) {
                        for (Group g : m.groups.values()) if (g.sub) out.add(g.name);
                    } else if (n >= 4) {
                        String[] b = new String[n - 1];
                        System.arraycopy(a, 1, b, 0, n - 1);
                        groupFirstTab(b, n - 1, out);
                    }
                }
                case "color", "colour" -> {
                    if (n == 2) { for (Group g : m.groups.values()) if (!g.sub) out.add(g.name); }
                    else if (n == 3) out.addAll(List.of("clear", "&#"));
                }
                case "deletegroup", "dg" -> {
                    if (n == 2) out.addAll(m.groups.keySet());
                }
                case "set", "add", "remove", "give", "take" -> {
                    if (n == 2) out.addAll(players());
                    else if (n == 3) out.addAll(m.groups.keySet());
                }
                case "delete", "rename", "members", "prefix", "suffix", "display", "onadd", "onremove", "meta", "priority", "prio",
                        "addperm", "delperm", "denyperm", "inherit", "uninherit" -> groupFirstTab(a, n, out);
                case "promote", "demote" -> {
                    if (n == 2) out.addAll(players());
                    else if (n == 3) out.addAll(m.tracks.keySet());
                }
                case "check" -> {
                    if (n == 2) out.addAll(players());
                    else if (n == 3) out.addAll(m.permissionNames());
                }
                case "track", "tracks", "t" -> {
                    if (n == 2) out.addAll(TRACK_ACTS);
                    else if (n == 3 && !a[1].equalsIgnoreCase("list") && !a[1].equalsIgnoreCase("create")) out.addAll(m.tracks.keySet());
                    else if (n == 4 && List.of("append", "insert", "remove").contains(a[1].toLowerCase(Locale.ROOT))) out.addAll(m.groups.keySet());
                }
                default -> {
                }
            }
        }
        List<String> res = new ArrayList<>();
        for (String o : out) {
            if (o.toLowerCase(Locale.ROOT).startsWith(cur)) {
                res.add(o);
                if (res.size() >= 60) break;
            }
        }
        return res;
    }

    /** For the short commands: a[0]=command, a[1]=rank, a[2...] the rest. */
    private void groupFirstTab(String[] a, int n, List<String> out) {
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (n == 2) {
            out.addAll(m.groups.keySet());
            return;
        }
        switch (sub) {
            case "priority", "prio" -> {
                if (n == 3) out.addAll(List.of("top", "bottom", "above", "below"));
                else if (n == 4 && (a[2].equalsIgnoreCase("above") || a[2].equalsIgnoreCase("below"))) out.addAll(m.groups.keySet());
            }
            case "addperm", "delperm", "denyperm" -> {
                if (n == 3) out.addAll(m.permissionNames());
                else if (n == 4 && sub.equals("addperm")) out.addAll(List.of("true", "false"));
            }
            case "inherit", "uninherit" -> {
                if (n == 3) out.addAll(m.groups.keySet());
            }
            case "meta" -> {
                if (n == 3) out.addAll(List.of("set", "unset", "list"));
                else if (n == 4 && !a[2].equalsIgnoreCase("list")) {
                    Group g = m.groupById(a[1]);
                    if (g != null) out.addAll(g.meta.keySet());
                }
            }
            case "onadd", "onremove" -> {
                if (n == 3) out.addAll(List.of("list", "clear"));
            }
            default -> {
            }
        }
    }

    /** a[0]=group|user, a[1]=name, a[2]=permission|parent, a[3...] the rest. */
    private void holderTab(String[] a, int n, List<String> out) {
        String act = a[2].toLowerCase(Locale.ROOT);
        if (act.startsWith("perm")) {
            if (n == 4) out.addAll(List.of("set", "unset", "list", "check"));
            else if (n == 5 && !a[3].equalsIgnoreCase("list")) out.addAll(m.permissionNames());
            else if (n == 6 && a[3].equalsIgnoreCase("set")) out.addAll(List.of("true", "false"));
        } else if (act.startsWith("parent") || act.equals("group") || act.equals("groups") || act.equals("inherit")) {
            if (n == 4) out.addAll(List.of("add", "remove", "set", "clear", "list"));
            else if (n == 5 && !a[3].equalsIgnoreCase("clear") && !a[3].equalsIgnoreCase("list")) out.addAll(m.groups.keySet());
        }
    }

    private static List<String> players() {
        List<String> l = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) l.add(p.getName());
        return l;
    }
}
