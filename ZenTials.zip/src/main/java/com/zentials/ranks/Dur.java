package com.zentials.ranks;

import java.util.Locale;

/** Durations like 30m, 12h, 7d, 2w, 1mo, 1d12h. */
final class Dur {
    private Dur() {
    }

    /** Milliseconds, or -1 if the text is not a valid duration. */
    static long parse(String text) {
        String s = text.toLowerCase(Locale.ROOT).trim();
        long total = 0;
        int i = 0;
        boolean any = false;
        while (i < s.length()) {
            int st = i;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            if (st == i || i - st > 9) return -1;
            long n = Long.parseLong(s.substring(st, i));
            int us = i;
            while (i < s.length() && Character.isLetter(s.charAt(i))) i++;
            long mul = switch (s.substring(us, i)) {
                case "s", "sec" -> 1000L;
                case "m", "min" -> 60_000L;
                case "h", "hr" -> 3_600_000L;
                case "d" -> 86_400_000L;
                case "w" -> 604_800_000L;
                case "mo" -> 2_592_000_000L;
                case "y" -> 31_536_000_000L;
                default -> -1L;
            };
            if (mul < 0) return -1;
            total += n * mul;
            any = true;
        }
        return any && total > 0 ? total : -1;
    }

    /** "2d 3h 4m" style text for a time span. */
    static String format(long ms) {
        long s = Math.max(0, ms) / 1000;
        if (s < 60) return s + "s";
        long d = s / 86400;
        long h = (s % 86400) / 3600;
        long m = (s % 3600) / 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0 && d == 0) sb.append(m).append("m ");
        return sb.toString().trim();
    }
}
