package com.zentials.ranks;

import com.zentials.ZenTials;
import com.zentials.core.Cfg;
import com.zentials.core.DataFile;
import com.zentials.core.ZModule;
import com.zentials.core.db.Kv;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Ranks (ZenRanks): groups, permissions, parents, tracks and timed ranks, like LuckPerms but built into ZenTials.
 *
 *  - Everybody is in the default group ("members" unless you change it) without being stored anywhere.
 *  - A player's own data (extra permissions, extra groups) is saved in the ZenTials database.
 *  - Groups and tracks live in plugins/ZenTials/modules/ranks/groups.yml (edit it, then /rank reload; commands edit it too).
 *  - Permissions are given to the player with a normal Bukkit permission attachment, wildcards (* and a.b.*) included.
 *
 * Settings: modules/ranks/config.yml. Commands: /rank help.
 */
public final class RankModule implements ZModule, Listener {
    static final String NS = "ranks.user";
    static final Pattern NAME = Pattern.compile("[a-z0-9_-]{1,32}");

    final ZenTials plugin;
    final Map<String, Group> groups = new ConcurrentHashMap<>();
    final Map<String, List<String>> tracks = new ConcurrentHashMap<>();
    final Map<UUID, User> users = new ConcurrentHashMap<>();
    private final Map<UUID, String> primary = new ConcurrentHashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final File groupsFile;
    private YamlConfiguration cfg;
    private BukkitTask expiryTask;
    private Field attachmentPerms;
    private List<String> permNames;

    volatile String defaultGroup = "members";
    volatile String defaultTrack = "main";
    private volatile boolean applyPermissions = true;

    public RankModule(ZenTials plugin) {
        this.plugin = plugin;
        this.groupsFile = new File(plugin.getDataFolder(), "modules/ranks/groups.yml");
    }

    @Override
    public String id() {
        return "ranks";
    }

    // ================================================================ life cycle

    @Override
    public void enable() {
        if (plugin.kv() == null) throw new IllegalStateException("the database is offline, Ranks cannot save player data");
        try {
            attachmentPerms = PermissionAttachment.class.getDeclaredField("permissions");
            attachmentPerms.setAccessible(true);
        } catch (Throwable t) {
            attachmentPerms = null; // slower, but works: one setPermission call per node
        }
        readAll();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        PluginCommand c = plugin.getCommand("rank");
        if (c != null) {
            RankCommands rc = new RankCommands(this);
            c.setExecutor(rc);
            c.setTabCompleter(rc);
        }
        expiryTask = Bukkit.getScheduler().runTaskTimer(plugin, this::expiryTick, 200L, 200L);
        recalcAll(true);
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                RankPapi.register(this);
            } catch (Throwable t) {
                plugin.getLogger().warning("[Ranks] PlaceholderAPI hook failed: " + t.getMessage());
            }
        }
        if (Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) {
            plugin.getLogger().warning("[Ranks] LuckPerms is installed too. Two permission plugins fight each other: "
                    + "use only one of them (set modules.ranks: false to keep LuckPerms).");
        }
    }

    @Override
    public void disable() {
        if (expiryTask != null) expiryTask.cancel();
        expiryTask = null;
        try {
            RankPapi.unhook();
        } catch (Throwable ignored) {
            // PlaceholderAPI was not there
        }
        for (Player p : Bukkit.getOnlinePlayers()) detach(p);
        attachments.clear();
        primary.clear();
    }

    @Override
    public void reload() {
        readAll();
        recalcAll(true);
    }

    private void readAll() {
        cfg = Cfg.yamlWithDefaults(plugin, "modules/ranks/config.yml");
        defaultGroup = cfg.getString("default-group", "members").toLowerCase(Locale.ROOT).trim();
        if (!NAME.matcher(defaultGroup).matches()) defaultGroup = "members";
        defaultTrack = cfg.getString("default-track", "main").toLowerCase(Locale.ROOT).trim();
        applyPermissions = cfg.getBoolean("apply-permissions", true);
        loadGroups();
        loadUsers();
    }

    // ================================================================ storage

    private void loadGroups() {
        YamlConfiguration y = Cfg.yaml(plugin, "modules/ranks/groups.yml");
        groups.clear();
        tracks.clear();
        ConfigurationSection gs = y.getConfigurationSection("groups");
        if (gs != null) {
            for (String key : gs.getKeys(false)) {
                String name = key.toLowerCase(Locale.ROOT);
                ConfigurationSection c = gs.getConfigurationSection(key);
                if (c == null || !NAME.matcher(name).matches()) continue;
                Group g = new Group(name);
                g.weight = c.contains("priority") ? c.getInt("priority", 0) : c.getInt("weight", 0);
                g.display = c.getString("display", "").toUpperCase(Locale.ROOT);
                g.prefix = c.getString("prefix", "");
                g.suffix = c.getString("suffix", "");
                g.color = c.getString("color", "");
                g.sub = "sub".equalsIgnoreCase(c.getString("type", "rank"));
                for (String e : c.getStringList("parents")) g.parseEntry(e, true);
                for (String e : c.getStringList("permissions")) g.parseEntry(e, false);
                ConfigurationSection ms = c.getConfigurationSection("meta");
                if (ms != null) {
                    for (String mk : ms.getKeys(false)) {
                        String metaKey = mk.toLowerCase(Locale.ROOT);
                        String val = ms.getString(mk);
                        if (NAME.matcher(metaKey).matches() && val != null) g.meta.put(metaKey, val);
                    }
                }
                g.onAdd = cleanCommands(c.getStringList("on-add"));
                g.onRemove = cleanCommands(c.getStringList("on-remove"));
                groups.put(name, g);
            }
        }
        ConfigurationSection ts = y.getConfigurationSection("tracks");
        if (ts != null) {
            for (String key : ts.getKeys(false)) {
                List<String> list = new ArrayList<>();
                for (String s : ts.getStringList(key)) list.add(s.toLowerCase(Locale.ROOT).trim());
                tracks.put(key.toLowerCase(Locale.ROOT), list);
            }
        }
        if (!groups.containsKey(defaultGroup)) {
            Group d = new Group(defaultGroup);
            d.display = "MEMBERS";
            d.prefix = "&7";
            groups.put(defaultGroup, d);
            saveGroups();
        }
    }

    void saveGroups() {
        DataFile.writeText(plugin, groupsFile, renderGroups());
    }

    private static List<String> cleanCommands(List<String> in) {
        List<String> out = new ArrayList<>();
        for (String c : in) {
            String l = c == null ? "" : c.trim();
            if (l.startsWith("/")) l = l.substring(1);
            if (!l.isEmpty()) out.add(l);
        }
        return List.copyOf(out);
    }

    private static String q(String text) {
        String t = text == null ? "" : text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
        return "\"" + t + "\"";
    }

    private static void list(StringBuilder b, String key, List<String> items) {
        if (items.isEmpty()) {
            b.append("    ").append(key).append(": []\n");
            return;
        }
        b.append("    ").append(key).append(":\n");
        for (String i : items) b.append("      - ").append(q(i)).append('\n');
    }

    /** groups.yml as text: always the same readable layout, with the explanation on top. */
    String renderGroups() {
        StringBuilder b = new StringBuilder(GROUPS_HEADER);
        b.append("groups:\n");
        for (Group g : sortedGroups().values()) {
            b.append('\n');
            b.append("  ").append(g.name).append(":\n");
            b.append("    type: ").append(g.sub ? "sub" : "rank").append('\n');
            b.append("    priority: ").append(g.weight).append('\n');
            b.append("    display: ").append(q(g.display)).append('\n');
            if (!g.sub) {
                b.append("    color: ").append(q(g.color)).append('\n');
                b.append("    prefix: ").append(q(g.prefix)).append('\n');
                b.append("    suffix: ").append(q(g.suffix)).append('\n');
            }
            List<String> parents = new ArrayList<>();
            List<String> perms = new ArrayList<>();
            for (Node n : g.nodes.values()) (n.isGroup() ? parents : perms).add(n.write(true));
            list(b, "parents", parents);
            list(b, "permissions", perms);
            if (g.meta.isEmpty()) {
                b.append("    meta: {}\n");
            } else {
                b.append("    meta:\n");
                for (Map.Entry<String, String> e : new TreeMap<>(g.meta).entrySet()) {
                    b.append("      ").append(e.getKey()).append(": ").append(q(e.getValue())).append('\n');
                }
            }
            list(b, "on-add", g.onAdd);
            list(b, "on-remove", g.onRemove);
        }
        b.append("\n# ladders for /rank promote and demote, lowest first\n");
        b.append("tracks:\n");
        if (tracks.isEmpty()) b.append("  {}\n");
        for (Map.Entry<String, List<String>> t : new TreeMap<>(tracks).entrySet()) {
            b.append("  ").append(t.getKey()).append(": [").append(String.join(", ", t.getValue())).append("]\n");
        }
        b.append(GROUPS_TEMPLATE);
        return b.toString();
    }

    static final String GROUPS_HEADER = """
            # Edit by hand then /rank reload, or use /rank commands (they rewrite this file).
            # priority    higher = more important; decides main rank and permission conflicts
            # type        rank | sub (sub = permission pack: never the main rank, no prefix, not on tracks)
            # display     name on scoreboard and %zrank_name% (always CAPITALS)
            # color       &#RRGGBB or &c
            # prefix      before the name in chat/tab
            # suffix      after the name
            # parents     ranks (or subs) this one inherits
            # permissions "node" allow, "-node" deny, wildcards "*" and "a.b.*"; specific beats wildcard
            # meta        own settings, read with %zrank_meta_<key>%
            # on-add      console commands when gained. {player} {uuid} {group}
            # on-remove   console commands when lost

            """;

    static final String GROUPS_TEMPLATE = """

            # rank template (remove the #, rename, /rank reload)
            #  myrank:
            #    type: rank
            #    priority: 60
            #    display: "MYRANK"
            #    color: "&#FFAA00"
            #    prefix: "&#FFAA00[MYRANK] &#FFAA00"
            #    suffix: ""
            #    parents: [members]
            #    permissions: ["essentials.fly", "-essentials.ban"]
            #    meta: {max-homes: "5"}
            #    on-add: ["broadcast {player} is now MYRANK"]
            #    on-remove: []
            # sub-rank template
            #  my-pack:
            #    type: sub
            #    display: "MY PACK"
            #    parents: []
            #    permissions: ["zentials.homes.unlimited"]
            #    meta: {}
            #    on-add: []
            #    on-remove: []
            """;

    private void loadUsers() {
        users.clear();
        Kv kv = plugin.kv();
        for (Map.Entry<String, String> e : kv.list(NS, "", 1_000_000).entrySet()) {
            try {
                User u = User.parse(UUID.fromString(e.getKey()), e.getValue());
                if (!u.nodes.isEmpty()) users.put(u.id, u);
            } catch (IllegalArgumentException ignored) {
                // not a player row
            }
        }
    }

    void saveUser(User u) {
        Kv kv = plugin.kv();
        if (u.nodes.isEmpty()) {
            users.remove(u.id);
            kv.delete(NS, u.id.toString());
        } else {
            users.put(u.id, u);
            kv.set(NS, u.id.toString(), u.serialize());
        }
    }

    // ================================================================ lookups (safe from any thread)

    public Group groupById(String name) {
        return name == null ? null : groups.get(name.toLowerCase(Locale.ROOT));
    }

    /** The id of the player's main group (highest weight), or the default group. */
    public String primaryGroup(UUID id) {
        String p = primary.get(id);
        return p != null ? p : defaultGroup;
    }

    /** Nice name of the player's main group, e.g. "Members" or "VIP". */
    public String displayName(UUID id) {
        Group g = groups.get(primaryGroup(id));
        return g == null ? "Members" : g.shown();
    }

    /** Color + display name of the main rank, e.g. "&#7A1224OWNER". Used by the scoreboard. */
    public String coloredName(UUID id) {
        Group g = groups.get(primaryGroup(id));
        if (g == null) return "Members";
        String c = g.color;
        return (c == null ? "" : c) + g.shown();
    }

    public String prefix(UUID id) {
        Group g = groups.get(primaryGroup(id));
        return g == null ? "" : g.prefix;
    }

    public String suffix(UUID id) {
        Group g = groups.get(primaryGroup(id));
        return g == null ? "" : g.suffix;
    }

    /** True if making 'parent' a parent of 'child' would create a loop. */
    boolean wouldLoop(Group child, Group parent) {
        return child == parent || inherits(parent, child.name, System.currentTimeMillis(), new HashSet<>());
    }

    /** True if the player is in the group directly or through another group. The default group is true for everyone. */
    public boolean inGroup(UUID id, String group) {
        String want = group.toLowerCase(Locale.ROOT);
        if (want.equals(defaultGroup)) return true;
        User u = users.get(id);
        return u != null && inherits(u, want, System.currentTimeMillis(), new HashSet<>());
    }

    private boolean inherits(Holder h, String want, long now, Set<String> seen) {
        for (Node n : h.parentNodes(now)) {
            String name = n.groupName();
            if (name.equals(want)) return true;
            Group g = groups.get(name);
            if (g != null && seen.add(name) && inherits(g, want, now, seen)) return true;
        }
        return false;
    }

    // ================================================================ resolving permissions

    /** Everything a holder gets, after inheritance: node -> allowed. Wildcards are not expanded here. */
    Map<String, Boolean> resolve(Holder h, boolean withDefault) {
        long now = System.currentTimeMillis();
        Map<String, Boolean> out = new HashMap<>();
        Set<String> seen = new HashSet<>();
        if (h instanceof Group g) seen.add(g.name);
        Group def = groups.get(defaultGroup);
        if (withDefault && def != null && seen.add(def.name)) applyHolder(def, out, seen, now);
        applyHolder(h, out, seen, now);
        return out;
    }

    /** Lower weight first, so higher weight overrides; a holder's own nodes override its parents. */
    private void applyHolder(Holder h, Map<String, Boolean> out, Set<String> seen, long now) {
        List<Group> parents = new ArrayList<>();
        for (Node n : h.parentNodes(now)) {
            Group g = groups.get(n.groupName());
            if (g != null && seen.add(g.name)) parents.add(g);
        }
        parents.sort(Comparator.comparingInt((Group g) -> g.weight).thenComparing(g -> g.name));
        for (Group g : parents) applyHolder(g, out, seen, now);
        for (Node n : h.nodes.values()) {
            if (!n.isGroup() && !n.expired(now)) out.put(n.key(), n.value());
        }
    }

    private List<String> registeredPermissions() {
        if (permNames == null) {
            List<String> l = new ArrayList<>();
            for (Permission p : Bukkit.getPluginManager().getPermissions()) l.add(p.getName().toLowerCase(Locale.ROOT));
            permNames = l;
        }
        return permNames;
    }

    /** All registered permission names, for tab completion. */
    List<String> permissionNames() {
        return new ArrayList<>(registeredPermissions());
    }

    /**
     * Turns "*" and "a.b.*" into real nodes (Bukkit has no wildcards). Broad wildcards first, so a specific node
     * (like "-essentials.ban") always wins over a wildcard.
     */
    Map<String, Boolean> expand(Map<String, Boolean> resolved) {
        Map<String, Boolean> out = new HashMap<>();
        List<String> wild = new ArrayList<>();
        for (String k : resolved.keySet()) if (k.equals("*") || k.endsWith(".*")) wild.add(k);
        wild.sort(Comparator.comparingInt(String::length));
        if (!wild.isEmpty()) {
            List<String> all = registeredPermissions();
            for (String w : wild) {
                boolean v = resolved.get(w);
                String prefix = w.equals("*") ? "" : w.substring(0, w.length() - 1);
                for (String name : all) if (name.startsWith(prefix)) out.put(name, v);
                out.put(w, v);
            }
        }
        for (Map.Entry<String, Boolean> e : resolved.entrySet()) {
            String k = e.getKey();
            if (!(k.equals("*") || k.endsWith(".*"))) out.put(k, e.getValue());
        }
        return out;
    }

    /** What the holder really gets (inheritance + wildcards). */
    Map<String, Boolean> effective(Holder h) {
        permNames = null;
        return expand(resolve(h, true));
    }

    String computePrimary(User u) {
        long now = System.currentTimeMillis();
        Group best = null;
        if (u != null) {
            for (Node n : u.parentNodes(now)) {
                Group g = groups.get(n.groupName());
                if (g == null || g.sub) continue;
                if (best == null || g.weight > best.weight || (g.weight == best.weight && g.name.compareTo(best.name) < 0)) best = g;
            }
        }
        return best != null ? best.name : defaultGroup;
    }

    // ================================================================ applying to players

    void recalcAll(boolean refreshCommands) {
        permNames = null;
        for (Player p : Bukkit.getOnlinePlayers()) recalc(p, refreshCommands);
    }

    void recalc(Player p, boolean refreshCommands) {
        UUID id = p.getUniqueId();
        User u = users.get(id);
        Map<String, Boolean> perms = expand(resolve(u != null ? u : new User(id, p.getName()), true));
        primary.put(id, computePrimary(u));
        detach(p);
        if (!applyPermissions) return; // data + placeholders only, another plugin owns the permissions
        PermissionAttachment att = p.addAttachment(plugin);
        boolean bulk = false;
        if (attachmentPerms != null) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Boolean> map = (Map<String, Boolean>) attachmentPerms.get(att);
                map.putAll(perms);
                bulk = true;
            } catch (Throwable t) {
                attachmentPerms = null;
            }
        }
        if (!bulk) for (Map.Entry<String, Boolean> e : perms.entrySet()) att.setPermission(e.getKey(), e.getValue());
        p.recalculatePermissions();
        attachments.put(id, att);
        if (refreshCommands) p.updateCommands();
    }

    private void detach(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old == null) return;
        try {
            p.removeAttachment(old);
        } catch (IllegalArgumentException ignored) {
            // already gone
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        permNames = null;
        User u = users.get(p.getUniqueId());
        if (u != null && !p.getName().equals(u.name)) {
            u.name = p.getName();
            saveUser(u);
        }
        recalc(p, false);
        Bukkit.getScheduler().runTask(plugin, p::updateCommands);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        attachments.remove(id);
        primary.remove(id);
    }

    // ================================================================ changes (used by /rank and by other code)

    void changed(Group g) {
        saveGroups();
        recalcAll(true);
    }

    void changed(User u) {
        permNames = null;
        saveUser(u);
        Player p = Bukkit.getPlayer(u.id);
        if (p != null) recalc(p, true);
    }

    /** The player's data, or a fresh empty one (it is only stored once it has something in it). */
    User userFor(UUID id, String name) {
        User u = users.get(id);
        if (u != null) {
            if (name != null) u.name = name;
            return u;
        }
        return new User(id, name);
    }

    Group createGroup(String name, int weight) {
        return createGroup(name, weight, false);
    }

    Group createGroup(String name, int weight, boolean sub) {
        Group g = new Group(name);
        g.weight = weight;
        g.sub = sub;
        groups.put(name, g);
        saveGroups();
        return g;
    }

    /** Removes the group everywhere (other groups, players, tracks). */
    void deleteGroup(Group g) {
        groups.remove(g.name);
        String key = Node.GROUP + g.name;
        for (Group o : groups.values()) o.unset(key);
        for (User u : new ArrayList<>(users.values())) {
            if (u.unset(key)) saveUser(u);
        }
        for (Map.Entry<String, List<String>> t : tracks.entrySet()) {
            List<String> l = new ArrayList<>(t.getValue());
            if (l.remove(g.name)) tracks.put(t.getKey(), l);
        }
        saveGroups();
        recalcAll(true);
    }

    void addGroup(User u, Group g, long expiry) {
        boolean had = u.get(Node.GROUP + g.name) != null;
        u.set(Node.GROUP + g.name, true, expiry);
        changed(u);
        if (!had) fire("on-group-add", u, g.name);
    }

    boolean removeGroup(User u, String group) {
        boolean had = u.unset(Node.GROUP + group);
        if (had) {
            changed(u);
            fire("on-group-remove", u, group);
        }
        return had;
    }

    /** Removes the player's ranks, then gives only this one (the default rank needs no node). Sub-ranks are kept. */
    void setGroup(User u, Group g) {
        List<String> old = new ArrayList<>();
        for (Node n : new ArrayList<>(u.nodes.values())) {
            if (n.isGroup()) {
                Group og = groups.get(n.groupName());
                if (og != null && og.sub) continue;
                old.add(n.groupName());
                u.unset(n.key());
            }
        }
        boolean add = !g.name.equals(defaultGroup);
        if (add) u.set(Node.GROUP + g.name, true, 0);
        changed(u);
        for (String o : old) if (!(add && o.equals(g.name))) fire("on-group-remove", u, o);
        if (add && !old.contains(g.name)) fire("on-group-add", u, g.name);
    }

    void clearGroups(User u) {
        List<String> old = new ArrayList<>();
        for (Node n : new ArrayList<>(u.nodes.values())) {
            if (n.isGroup()) {
                old.add(n.groupName());
                u.unset(n.key());
            }
        }
        changed(u);
        for (String o : old) fire("on-group-remove", u, o);
    }

    /** Runs the console commands from config.yml (console-commands.<event>.<group>). */
    private void fire(String event, User u, String group) {
        List<String> cmds = new ArrayList<>(cfg.getStringList("console-commands." + event + "." + group));
        Group g = groups.get(group);
        if (g != null) cmds.addAll(event.equals("on-group-add") ? g.onAdd : g.onRemove);
        for (String c : cmds) {
            String line = c.replace("{player}", u.name).replace("{uuid}", u.id.toString()).replace("{group}", group).trim();
            if (line.startsWith("/")) line = line.substring(1);
            if (!line.isEmpty()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        }
    }

    /** Gives a group a new name everywhere: other groups, players, tracks. Not for the default group. */
    Group renameGroup(Group g, String newName) {
        Group n = new Group(newName);
        n.weight = g.weight;
        n.display = g.display;
        n.prefix = g.prefix;
        n.suffix = g.suffix;
        n.color = g.color;
        n.sub = g.sub;
        n.meta.putAll(g.meta);
        n.onAdd = g.onAdd;
        n.onRemove = g.onRemove;
        n.nodes.putAll(g.nodes);
        groups.remove(g.name);
        groups.put(newName, n);
        String oldKey = Node.GROUP + g.name;
        String newKey = Node.GROUP + newName;
        for (Group o : groups.values()) o.renameParent(oldKey, newKey);
        for (User u : new ArrayList<>(users.values())) if (u.renameParent(oldKey, newKey)) saveUser(u);
        for (Map.Entry<String, List<String>> t : tracks.entrySet()) {
            List<String> l = new ArrayList<>(t.getValue());
            int at = l.indexOf(g.name);
            if (at >= 0) {
                l.set(at, newName);
                tracks.put(t.getKey(), l);
            }
        }
        saveGroups();
        recalcAll(true);
        return n;
    }

    /**
     * Moves a group in the order of importance without changing how the other groups rank against each other.
     * mode: top, bottom, above, below (the last two need ref).
     */
    void movePriority(Group g, String mode, Group ref) {
        switch (mode) {
            case "top" -> {
                int max = Integer.MIN_VALUE;
                for (Group o : groups.values()) if (o != g && !o.sub) max = Math.max(max, o.weight);
                g.weight = max == Integer.MIN_VALUE ? 0 : max + 1;
            }
            case "bottom" -> {
                int min = Integer.MAX_VALUE;
                for (Group o : groups.values()) if (o != g && !o.sub) min = Math.min(min, o.weight);
                g.weight = min == Integer.MAX_VALUE ? 0 : min - 1;
            }
            case "above" -> {
                int p = ref.weight + 1;
                for (Group o : groups.values()) if (o != g && !o.sub && o.weight >= p) o.weight += 1;
                g.weight = p;
            }
            case "below" -> {
                int p = ref.weight - 1;
                for (Group o : groups.values()) if (o != g && !o.sub && o.weight <= p) o.weight -= 1;
                g.weight = p;
            }
            default -> throw new IllegalArgumentException(mode);
        }
        changed(g);
    }

    /** A rank setting (see 'meta' in groups.yml) for a player: the highest-priority rank they have that sets it. Null if none. */
    public String meta(UUID id, String key) {
        String k = key.toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        List<Group> all = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Group def = groups.get(defaultGroup);
        if (def != null && seen.add(def.name)) all.add(def);
        User u = users.get(id);
        if (u != null) collectGroups(u, all, seen, now);
        all.sort(Comparator.comparingInt((Group g) -> g.weight).reversed().thenComparing(g -> g.name));
        for (Group g : all) {
            String v = g.meta.get(k);
            if (v != null) return v;
        }
        return null;
    }

    private void collectGroups(Holder h, List<Group> out, Set<String> seen, long now) {
        for (Node n : h.parentNodes(now)) {
            Group g = groups.get(n.groupName());
            if (g != null && seen.add(g.name)) {
                out.add(g);
                collectGroups(g, out, seen, now);
            }
        }
    }

    boolean logChanges() {
        return cfg.getBoolean("log-changes", true);
    }

    // ================================================================ timed nodes

    private void expiryTick() {
        long now = System.currentTimeMillis();
        boolean groupsChanged = false;
        for (Group g : groups.values()) if (g.purge(now)) groupsChanged = true;
        if (groupsChanged) {
            saveGroups();
            recalcAll(true);
        }
        for (User u : new ArrayList<>(users.values())) {
            List<Node> gone = u.expiredNodes(now);
            if (gone.isEmpty()) continue;
            u.purge(now);
            changed(u);
            for (Node n : gone) if (n.isGroup()) fire("on-group-remove", u, n.groupName());
        }
    }

    // ================================================================ misc for commands

    /** Ranks (most important first), then sub-ranks. */
    Map<String, Group> sortedGroups() {
        List<Group> l = new ArrayList<>(groups.values());
        l.sort(Comparator.comparing((Group g) -> g.sub)
                .thenComparingInt((Group g) -> g.sub ? 0 : -g.weight)
                .thenComparing(g -> g.name));
        Map<String, Group> out = new LinkedHashMap<>();
        for (Group g : l) out.put(g.name, g);
        return out;
    }
}
