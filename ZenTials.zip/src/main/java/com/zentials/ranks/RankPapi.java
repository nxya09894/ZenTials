package com.zentials.ranks;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * %zrank_group%        id of the main group (members, vip, ...)
 * %zrank_name%         nice name of the main group (Members, VIP, ...)
 * %zrank_prefix%       prefix of the main group      %zrank_suffix%
 * %zrank_weight%       weight of the main group
 * %zrank_color%        color of the main group (&#RRGGBB)
 * %zrank_groups%       every rank the player is in, comma separated      %zrank_subs%  same for sub-ranks
 * %zrank_in_<group>%   true / false
 * %zrank_meta_<key>%    a setting from the rank's meta: block (highest priority rank that sets it)
 *
 * Only loaded when PlaceholderAPI is installed (see RankModule).
 */
final class RankPapi extends PlaceholderExpansion {
    private static RankPapi instance;
    private final RankModule m;

    private RankPapi(RankModule m) {
        this.m = m;
    }

    static void register(RankModule m) {
        instance = new RankPapi(m);
        instance.register();
    }

    static void unhook() {
        if (instance != null) {
            instance.unregister();
            instance = null;
        }
    }

    @Override
    public @NotNull String getIdentifier() {
        return "zrank";
    }

    @Override
    public @NotNull String getAuthor() {
        return "ZenTials";
    }

    @Override
    public @NotNull String getVersion() {
        return m.plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        UUID id = player.getUniqueId();
        String k = params.toLowerCase(Locale.ROOT);
        if (k.startsWith("in_")) return String.valueOf(m.inGroup(id, k.substring(3)));
        if (k.startsWith("meta_")) {
            String v = m.meta(id, k.substring(5));
            return v == null ? "" : v;
        }
        Group g = m.groupById(m.primaryGroup(id));
        return switch (k) {
            case "group" -> m.primaryGroup(id);
            case "name", "displayname" -> m.displayName(id);
            case "prefix" -> m.prefix(id);
            case "suffix" -> m.suffix(id);
            case "weight" -> String.valueOf(g == null ? 0 : g.weight);
            case "color" -> g == null ? "" : g.color;
            case "groups", "subs" -> {
                boolean subs = k.equals("subs");
                List<String> names = new ArrayList<>();
                for (Group x : m.groups.values()) if (x.sub == subs && m.inGroup(id, x.name)) names.add(x.name);
                yield String.join(",", names);
            }
            default -> null;
        };
    }
}
