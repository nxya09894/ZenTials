package com.zentials.ranks;

/**
 * One line of a group or a player: a permission (true = allow, false = deny) or a parent group ("group.vip").
 * expiry is a time in milliseconds (System.currentTimeMillis style); 0 = never expires.
 */
record Node(String key, boolean value, long expiry) {
    static final String GROUP = "group.";

    boolean expired(long now) {
        return expiry > 0 && expiry <= now;
    }

    boolean isGroup() {
        return key.startsWith(GROUP);
    }

    String groupName() {
        return key.substring(GROUP.length());
    }

    boolean isWildcard() {
        return key.equals("*") || key.endsWith(".*");
    }

    /** Text form used in groups.yml and in the player data: [-]node[|expiry] (parents are written without "group."). */
    String write(boolean stripGroup) {
        String k = stripGroup && isGroup() ? groupName() : key;
        return (value ? "" : "-") + k + (expiry > 0 ? "|" + expiry : "");
    }
}
