package com.zentials.ranks;

import java.util.UUID;

/** A player's own nodes. Players with no nodes of their own are not stored: they are just in the default group. */
final class User extends Holder {
    final UUID id;
    volatile String name;

    User(UUID id, String name) {
        this.id = id;
        this.name = name == null ? id.toString() : name;
    }

    @Override
    String label() {
        return name;
    }

    String serialize() {
        StringBuilder sb = new StringBuilder(name);
        for (Node n : nodes.values()) sb.append('\n').append(n.write(false));
        return sb.toString();
    }

    static User parse(UUID id, String text) {
        String[] lines = text.split("\n");
        User u = new User(id, lines.length > 0 ? lines[0].trim() : null);
        for (int i = 1; i < lines.length; i++) u.parseEntry(lines[i], false);
        return u;
    }
}
