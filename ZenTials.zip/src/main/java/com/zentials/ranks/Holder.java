package com.zentials.ranks;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Something that owns permissions and parents: a Group or a User. Only touched on the main thread. */
abstract class Holder {
    final Map<String, Node> nodes = new LinkedHashMap<>();

    abstract String label();

    void set(String key, boolean value, long expiry) {
        String k = key.toLowerCase(Locale.ROOT).trim();
        nodes.put(k, new Node(k, value, expiry));
    }

    boolean unset(String key) {
        return nodes.remove(key.toLowerCase(Locale.ROOT).trim()) != null;
    }

    Node get(String key) {
        return nodes.get(key.toLowerCase(Locale.ROOT).trim());
    }

    /** Nodes that have not expired. */
    List<Node> active(long now) {
        List<Node> out = new ArrayList<>();
        for (Node n : nodes.values()) if (!n.expired(now)) out.add(n);
        return out;
    }

    List<Node> expiredNodes(long now) {
        List<Node> out = new ArrayList<>();
        for (Node n : nodes.values()) if (n.expired(now)) out.add(n);
        return out;
    }

    /** Removes expired nodes. True if anything was removed. */
    boolean purge(long now) {
        return nodes.values().removeIf(n -> n.expired(now));
    }

    /** Active parent nodes (group.x = true), in the order they were added. */
    List<Node> parentNodes(long now) {
        List<Node> out = new ArrayList<>();
        for (Node n : nodes.values()) if (n.isGroup() && n.value() && !n.expired(now)) out.add(n);
        return out;
    }

    /** Points a parent node at a new group name (keeps value, expiry and order). True if it was there. */
    boolean renameParent(String oldKey, String newKey) {
        Node hit = nodes.get(oldKey);
        if (hit == null) return false;
        Map<String, Node> copy = new LinkedHashMap<>(nodes);
        nodes.clear();
        for (Map.Entry<String, Node> e : copy.entrySet()) {
            if (e.getKey().equals(oldKey)) nodes.put(newKey, new Node(newKey, hit.value(), hit.expiry()));
            else nodes.put(e.getKey(), e.getValue());
        }
        return true;
    }

    /** Reads one saved entry: [-]node[|expiry]. For parent lists pass parent = true (the "group." part is added). */
    void parseEntry(String raw, boolean parent) {
        String e = raw == null ? "" : raw.trim();
        if (e.isEmpty()) return;
        boolean val = true;
        if (e.startsWith("-")) {
            val = false;
            e = e.substring(1).trim();
        }
        long exp = 0;
        int bar = e.indexOf('|');
        if (bar >= 0) {
            try {
                exp = Long.parseLong(e.substring(bar + 1).trim());
            } catch (NumberFormatException ignored) {
                exp = 0;
            }
            e = e.substring(0, bar).trim();
        }
        if (e.isEmpty()) return;
        set(parent ? Node.GROUP + e : e, val, exp);
    }
}
