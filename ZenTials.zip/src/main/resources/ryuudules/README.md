# Ryuudules

Put `.ryu` files in this folder. Each file is one system (commands, events, timers, functions).

## Do this
* Add or edit a file, then run `/zt reload <name>` (one file) or `/zt reload` (everything). Saved files also reload by themselves.
* Mistakes: `/ryu errors` (file + line). A broken file keeps its old version running.
* `/ryu list` shows loaded scripts. Rename a file to `name.ryu.off` to switch it off.

## Basics
```
options:
    greeting: "&aWelcome"                # read with {opt.greeting}

command /hello [name]:                   # <required> [optional]
    permission: hello.use                # also: aliases, cooldown, player-only, description, usage
    send "{opt.greeting}, {player.name}!"

on join:                                 # events: see table below
    send "Hi {player.name}"

every 10 seconds:                        # ticks / seconds / minutes / hours
    log "tick"

function double(x):                      # functions are global, prefix them with your system name
    return x * 2
```
* Indent with 4 spaces. Blocks end with `:`. Text in quotes, values in text with `{ }`. Colors: `&a`, `&#ff8800`.
* Lists `["a", "b"]`, `true/false/null`. A bare `DIAMOND` means the name `"DIAMOND"`.
* No uppercase variable names, no unary minus (write `0 - x`).

## Statements
```
set x to 5      add 1 to x      remove 1 from x      delete x
if a and not b:   else if c:   else:
loop p in server.online():   repeat 3 times:   while x < 9:   break   continue   return v   stop   cancel
send "text"   send "text" to p   broadcast "text"   console "cmd"   log "text"
later 5 seconds:                          # runs after a delay      (wait 5 seconds also works)
ask "Type an amount" into amount:         # next chat message; "cancel" cancels
```
Operators: `+ - * / %  == != < > <= >=  and or not  in`.

## Events (`on <name>:`)
`join quit respawn death kill break place interact interact-entity move teleport damage damage-entity command chat close explode drop pickup bucket world-change spawn target`
Variables: `player`, `block`, `entity`, `item`, `killer`, `from`, `to`, `message`, `damage`, `cause`, and `event` (the raw Bukkit event).
Any other Bukkit event works: `on player fish:` or `on event org.bukkit.event.player.PlayerEggThrowEvent:`.

## GUI
```
command /menu:
    player-only: true
    open gui "&6Menu" rows 3:
        slot 11 item EMERALD name "&aBuy" lore ["&7Click"]:
            send "Clicked"
        gui.set(15, item("DIAMOND", "&bShop"), "myFunction", arg)    # click calls myFunction(player, arg)
        fill GRAY_STAINED_GLASS_PANE
```

## Data
* `data.set/get/has/del/incr/keys` - private to the file. `shared.*` - same, visible to all scripts.
* `mem.*` - fast memory (lost on restart). Use `shared` for things that must be saved.
* Use one key per thing: `"land." + player.uuid`.

## Economy
`eco.balance(p)  eco.has(p, n)  eco.add(p, n, "reason")  eco.remove(p, n, "reason")  eco.pay(from, to, n, "reason")  eco.set  eco.format(n)  eco.short(n)`
They are silent (you send the message). `eco.remove` returns `false` when the money is not enough:
```
if eco.remove(player, 500, "Claim"):
    send "Paid"
else:
    send "&cNot enough money"
```
Java plugins use `EconomyApi`, shop plugins use Vault, displays use `%zen_balance%`.

## Useful calls
* Player: `send title actionbar teleport has give take count sfx("success") heal feed kick command closeinv`; properties `name uuid world x y z health food level ping gamemode`.
* `server.online() server.player(n) server.count() server.broadcast(m) server.console(c) server.tps()`.
* Text/list/math/time: `text.upper replace split join`, `list.sort reverse first last`, `math.floor round random`, `time.now() time.format`.
* `cd.use(player, "name", seconds)` cooldown (0 = go, else seconds left).
* `http.get(url, "callback")`, `json.parse/dump`, `file.read/write("notes.txt")`, `bossbar.show(...)`.
* `placeholder name:` block gives `%ryu_name%` to PlaceholderAPI.
* Any Bukkit method can be called by name: `player.setGameMode("CREATIVE")`.

## Rules
* Connect systems with global functions and `shared` keys. Name functions `system_action` to avoid clashes.
* Keep `move` and `chat` handlers tiny. Scripts run on the main thread.
* Only trusted admins should have access to this folder (scripts can run console commands).
