# Ryuudules

Put `.ryu` files in this folder. Each file is one system (commands, events, timers, functions).

## Do this
* Add or edit a file, then run `/zt reload <name>` (one file) or `/zt reload` (everything). Saved files also reload by themselves.
* Mistakes: `/ryu errors` (file + line). A broken file keeps its old version running.
* `/ryu list` shows loaded scripts. Rename a file to `name.ryu.off` to switch it off.

## Basics
```
options:
    greeting: "&aWelcome"                # read with {opt.greeting}

command /hello [name]:                   # <required> [optional]
    permission: hello.use                # also: aliases, cooldown, player-only, description, usage
    send "{opt.greeting}, {player.name}!"

on join:                                 # events: see table below
    send "Hi {player.name}"

every 10 seconds:                        # ticks / seconds / minutes / hours
    log "tick"

function double(x):                      # functions are global, prefix them with your system name
    return x * 2
```
* Indent with 4 spaces (any consistent indent works). Blocks end with `:` (the `:` may be left out when lines are indented under it). Text in quotes, values in text with `{ }`. Colors: `&a`, `&#ff8800`.
* Lists `["a", "b"]`, `true/false/null`. A bare `DIAMOND` means the name `"DIAMOND"`.
* Comments: `# like this` or `// like this`.

## Statements
```
set x to 5      add 1 to x      remove 1 from x      delete x
if a and not b:   else if c:   else:   unless a:   (unless = if not)
loop p in server.online():   repeat 3 times:   while x < 9:   break   continue   return v   stop   cancel
send "text"   send "text" to p   broadcast "text"   console "cmd"   log "text"
later 5 seconds:                          # runs after a delay      (wait 5 seconds also works)
ask "Type an amount" into amount:         # next chat message; "cancel" cancels
```
Operators: `+ - * / %  == != < > <= >=  and or not  in`.

## Events (`on <name>:`)
`join quit respawn death kill break place interact interact-entity move teleport damage damage-entity command chat close explode drop pickup bucket world-change spawn target`
Variables: `player`, `block`, `entity`, `item`, `killer`, `from`, `to`, `message`, `damage`, `cause`, and `event` (the raw Bukkit event).
Any other Bukkit event works: `on player fish:` or `on event org.bukkit.event.player.PlayerEggThrowEvent:`.

## GUI
```
command /menu:
    player-only: true
    open gui "&6Menu" rows 3:
        slot 11 item EMERALD name "&aBuy" lore ["&7Click"]:
            send "Clicked"
        gui.set(15, item("DIAMOND", "&bShop"), "myFunction", arg)    # click calls myFunction(player, arg)
        fill GRAY_STAINED_GLASS_PANE
```

## Data
* `data.set/get/has/del/incr/keys` - private to the file. `shared.*` - same, visible to all scripts.
* `mem.*` - fast memory (lost on restart). Use `shared` for things that must be saved.
* Use one key per thing: `"land." + player.uuid`.

## Economy
`eco.balance(p)  eco.has(p, n)  eco.add(p, n, "reason")  eco.remove(p, n, "reason")  eco.pay(from, to, n, "reason")  eco.set  eco.format(n)  eco.short(n)`
They are silent (you send the message). `eco.remove` returns `false` when the money is not enough:
```
if eco.remove(player, 500, "Claim"):
    send "Paid"
else:
    send "&cNot enough money"
```
Java plugins use `EconomyApi`, shop plugins use Vault, displays use `%zen_balance%`.

## Useful calls
* Player: `send title actionbar teleport has give take count sfx("success") heal feed kick command closeinv`; properties `name uuid world x y z health food level ping gamemode`.
* `server.online() server.player(n) server.count() server.broadcast(m) server.console(c) server.tps()`.
* Text/list/math/time: `text.upper replace split join`, `list.sort reverse first last`, `math.floor round random`, `time.now() time.format`.
* `cd.use(player, "name", seconds)` cooldown (0 = go, else seconds left).
* `http.get(url, "callback")`, `json.parse/dump`, `file.read/write("notes.txt")`, `bossbar.show(...)`.
* `placeholder name:` block gives `%ryu_name%` to PlaceholderAPI.
* Any Bukkit method can be called by name: `player.setGameMode("CREATIVE")`.

## Rules
* Connect systems with global functions and `shared` keys. Name functions `system_action` to avoid clashes.
* Keep `move` and `chat` handlers tiny. Scripts run on the main thread.
* Only trusted admins should have access to this folder (scripts can run console commands).

## Many ways to write the same thing
Write it the way you are used to (Skript, Python, JavaScript ...). All of these work and cost nothing at runtime,
because they are turned into the same thing once, when the file loads.

**Variables**
```
set x to 5      x = 5      let x = 5      var x = 5      let x be 5
add 1 to x      x += 1     x++            increase x by 1
remove 1 from x x -= 1     x--            decrease x by 1      subtract 1 from x
x *= 2   x /= 2   x %= 3   multiply x by 2   divide x by 2
delete x        clear x    reset x
set health of player to 20      player.health = 20      m.key = 1      list[2] = "x"      data.list[0] = 1
set names to "a", "b", "c"      (a list)        {"k": 1, other: 2}  (a map)        [1, 2, 3]
```
**Conditions**
```
a == b    a = b    a is b    a equals b    a is equal to b          a != b    a is not b    a isn't b
a > b     a is greater than b    a is more than b    a is above b   a >= b   a is at least b
a < b     a is less than b       a is below b        a <= b         a is at most b
x is between 1 and 5       x in list      x not in list      x is in list
text contains "a"      text does not contain "a"      text starts with "a"      text ends with "a"      text matches "re.*"
x is set     x is not set     x exists     x is empty     x is a number     x is a text     x is a list
player is online     player is op     player is flying     player has permission "a.b"
a and b   a && b      a or b   a || b      not a   !a
cond ? yes : no       yes if cond else no
```
`if x: stop` also works on one line, like `else: stop`, `else if c: ...`, `elif c:`, `elseif c:`, `otherwise:`, `unless c:`.
One-line loops too: `loop p in list: send "hi" to p`, `repeat 3 times: stop`, `while x < 5: x++`, `later 1s: stop`.

**Maths and text**
```
a + b   a plus b      a - b   a minus b      a * b   a times b      a / b   a divided by b      a % b   a mod b
"a" & b                 joins as text         5k = 5000   2.5m = 2500000   1b   1_000_000
"Hi {player.name}"      "Hi %player.name%"    "Hi {_name}"   "{@option}"   "{opt.option}"
```
`%word%` that is not a variable stays as it is, so PlaceholderAPI placeholders like `%zen_balance%` are not touched.

**Lists and values**
```
size of list    length of text    amount of list    first of list    last of list    name of player    uppercase of text
item 1 of list (1-based)     list[0] (0-based)      random element of list      random player      all players     online players
1..10 (a list of numbers)    yes / no / on / off    nothing / none / null
```

**Loops**
```
loop p in list:      for p in list:      for each p in list:      loop all players:  (the item is called value)
loop i from 1 to 10:      loop i from 10 to 1:      loop i from 0 to 100 step 5:      for i in 1..10:
loop 5 times:      repeat 5 times:      repeat 5:       loop "a", "b", "c":       break   continue   stop loop   skip   next
```

**Time** (`wait`, `later`, `every`, `cooldown`): `5 seconds`, `5s`, `1.5 minutes`, `2m`, `1 hour 30 minutes`, `1h and 30m`, `20 ticks`, `1 day`, `every second`, `every minute`.
```
wait 5 seconds     delay 5s     sleep 5s          later 5s:      after 5s:       every 30 seconds:      every minute:
```

**Actions written in plain words**
```
msg "x"    send "x" to p     print "x"    broadcast "x"     console "cmd"     run command "cmd"     dispatch "cmd"
execute command "cmd" as p      make p execute "cmd"
teleport p to loc      give 5 DIAMOND to p      give item("STONE") to p      kick p because "reason"      heal p      feed p
title "Hi" subtitle "There" to p      actionbar "x" to p      play sound "success" to p      play sound "entity.player.levelup"      close inventory
cancel      cancel event      uncancel      stop   exit   halt      pass (does nothing)
```

**Commands**
```
command /pay <player> [amount:number] [note...]:       cmd /pay ...:          (<name>, [name], <name:type>, [name...])
command /heal [<player>]:                              Skript style typed arguments are called arg1, arg2 ...
```
Types: `text word number int player offline player world boolean` or choices `[mode:on|off]`.
```
    permission: heal.use
    permission message: "&cNo permission"
    cooldown: 5 seconds           (or 30, 2 minutes)       cooldown message: "&cWait {time}s"
    aliases: h, hp           executable by: players        trigger:    (code can also go under trigger:)
```

**Events** (`on <event>:`) - the same event can be written many ways, several events can share a block, and most can be filtered:
```
on join:   on player join:   on break:   on block break:   on right click:   on left click:   on sneak:   on eat:   on fish:   on chat:
on join or quit:                 on break or place:
on break of diamond_ore or stone:     on break of *_ore:       on place of tnt:      on right click with stick:
on command "spawn":              on damage of fall:          on kill of zombie:       on chat containing "hello":
on break priority high:          on break ignore cancelled:   (priority: lowest low normal high highest monitor)
on load:   on start:   on unload:   on stop:   (or a plain  load:  /  unload:  block)
```
Any Bukkit event also works by name (`on player fish:`, `on event org.bukkit.event.player.PlayerFishEvent:`).
`on move` runs when a player changes block, not on every head turn (config: `ryuudules.move-block-only`).

**Functions**
```
function greet(name, hi = "Hello"):        fn greet(name, hi = "Hello"):        def greet(name: text, hi: text = "Hello") :: text:
    return hi + " " + name
```
Types after `:` and `:: type` are only notes for readers.

**GUI**
```
open gui "Title" rows 3:       open gui "Title" 3 rows:       open gui "Title" size 27:       open menu ...      (add  for p  to open for someone else)
    slot 11 item EMERALD name "&aBuy" lore ["&7Click"] glow:        slot 11 material EMERALD named "&aBuy":
    slots 0..8 item GRAY_STAINED_GLASS_PANE name " "                (a list or range of slots)
    fill GRAY_STAINED_GLASS_PANE
```
**Placeholders**: `placeholder top cache 10 seconds global:` keeps the answer for 10 seconds for everybody, `placeholder rank cache 5 seconds:` per player. Use it for anything shown on scoreboards, tab and holograms.
**Other block names**: `options:` = `settings:` = `config:` = `constants:`.

## Made for big servers (1000+ players)
* Everything above is resolved once when the file loads. Reflection (calling Bukkit methods by name) is remembered per class.
* `on move` skips head turns, events with a filter (`on break of stone:`) do no work for other blocks, and `placeholder ... cache` stops repeated work.
* `/ryu profile` shows which handler uses the most time (`/ryu profile reset` to start over). Slow handlers also warn in the console (`ryuudules.slow-warn-ms`).
* A single run longer than `ryuudules.max-run-ms` (200 ms) is stopped so a loop cannot freeze the server. An event handler that fails 100 times in 10 seconds is switched off until the next reload.
* Big files are fine. Keep `move`/`chat` handlers tiny, use `placeholder ... cache`, and avoid `data.keys()` in busy events (it waits for the database to finish saving).
