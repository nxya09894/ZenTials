# ZenTials Aura

All files in this folder are yours to edit. After editing run `/aura reload`.

| File | What it does |
|---|---|
| `config.yml` | Tab list header/footer, name tags, chat format. The top of the file lists every placeholder and colour effect. |
| `groups.yml` | Ranks: prefix, suffix, colour, chat format. Give a rank with the permission `zentials.aura.group.<name>`. |
| `animations.yml` | Named animations. Use anywhere as `%anim:name%`. |
| `scoreboard.yml` | Sidebar boards (per permission / world). |
| `tags.yml` | Chat tags players pick with `/tag`. |
| `../../data/aura.yml` | Saved choices of players. Do not edit. |

Effects: `<rainbow>`, `<rainbow:6>`, `<gradient:#ff0000:#0000ff>`, `<gradient:#ff0000:#0000ff:5>` (moving), `<pulse:#ffffff:#ff5555:3>`, `<blink:#ffffff:#555555:10>`.

Commands: `/aura reload` · `/aura group <player> <group|clear>` · `/aura preview <text>` · `/aura info` · `/tag` · `/sb`.
Permissions: `zentials.aura.admin` (admin commands), `zentials.aura.chat.effects` (use effects in chat).
