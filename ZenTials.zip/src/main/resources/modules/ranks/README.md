# Ranks (ZenRanks)

Ranks and permissions inside ZenTials, like LuckPerms but simple. Everybody is automatically in the first rank
(`members`). Every rank is one block in `groups.yml` that holds **everything** about it: priority, prefix, permissions,
parents, your own settings (meta) and console commands.

> Use Ranks **or** LuckPerms, not both. To keep LuckPerms set `modules.ranks: false` in `config.yml`
> (or `apply-permissions: false` here to use Ranks only for prefixes/placeholders).

Files in `plugins/ZenTials/modules/ranks/`:

| File | What |
|---|---|
| `groups.yml` | all ranks + tracks (the main file you edit) |
| `config.yml` | default rank, default track, switches, global console-command hooks |
| player data | saved in the ZenTials database (only players who have extra ranks/permissions) |

---------------------------------------------------------------------------

## 1. Add a rank (3 ways)

**A. One console command (easiest)**
```
/rank create builder 40 Builder
/rank prefix builder &e[Builder]
/rank addperm builder worldedit.*
/rank inherit builder vip
```

**B. Edit `groups.yml`** - copy the template at the bottom of the file, then `/rank reload`:
```yaml
  builder:
    priority: 40
    display: "Builder"
    prefix: "&e[Builder] &e"
    suffix: ""
    parents: [vip]
    permissions:
      - "worldedit.*"
      - "-essentials.ban"
    meta:
      max-homes: "4"
    on-add:
      - "broadcast &e{player} &7is now a &eBuilder"
    on-remove: []
```

**C. Mix**: change things in the file when the server is off or with `/rank reload`, use commands anytime.
Commands save the file in the same readable layout (the explanation on top is always kept).

---------------------------------------------------------------------------

## 2. Every setting of a rank

| Key | Meaning |
|---|---|
| `priority` | Bigger = more important. Decides the player's **main rank** (scoreboard, chat, `%zrank_group%`) and who wins when two ranks disagree about a permission. Negative numbers are fine. |
| `type` | `rank` (normal) or `sub` (a sub-rank, see section 2b). |
| `color` | Rank color, `&#RRGGBB` or `&c`. Read with `%zrank_color%`; the scoreboard `{rank}` uses it. |
| `display` | Nice name, used by the scoreboard `{rank}` and `%zrank_name%`. Empty = the rank name with a capital letter. |
| `prefix` / `suffix` | Text before / after the player name. `&` color codes. Read with `%zrank_prefix%` / `%zrank_suffix%`. |
| `parents` | Ranks it gets everything from (inheritance). `vip` with parent `members` has all of members too. |
| `permissions` | `"node"` = allow, `"-node"` = deny. Wildcards: `"*"`, `"essentials.*"`. A specific node always beats a wildcard. |
| `meta` | Your own settings (any key: `max-homes`, `backpack-rows`, `kit-cooldown` ...). Read with `%zrank_meta_<key>%`. A player gets the value from the highest-priority rank they have that sets the key (the default rank counts too). |
| `on-add` | Console commands when a player **gets** the rank. `{player}` `{uuid}` `{group}` work. |
| `on-remove` | Console commands when a player **loses** it (also when a timed rank ends). |

The default rank is set in `config.yml` (`default-group`). Everybody has it without being stored anywhere.

### The ranks that come with it

| # | Rank | Color | Priority |
|---|---|---|---|
| 1 | OWNER | `&#7A1224` | 100 (has `*`) |
| 2 | CO-OWNER | `&#A32638` | 90 |
| 3 | CHANCELLOR | `&#D4AF37` | 80 |
| 4 | ARCANIST | `&#6B3FA0` | 70 |
| 5 | ARBITER | `&#1D4E89` | 60 |
| 6 | WARDEN | `&#2E6F40` | 50 |
| 7 | JUSTICIAR | `&#C86D1F` | 40 |
| 8 | STEWARD | `&#1F7A8C` | 30 |
| 9 | ENVOY | `&#4F772D` | 20 |
| - | Members (first rank, everybody) | gray | 0 |

Each one inherits the rank under it (ENVOY gets Members, STEWARD gets ENVOY ... OWNER gets CO-OWNER), so a permission
you give to ENVOY is automatically in every higher rank. They have no permissions yet except OWNER (`*`) and CO-OWNER
(`zentials.admin`, `economy.admin`). Rename, recolor or delete any of them with the commands below.
Change a color: `/rank color warden &#2E6F40`.

## 2b. Sub-ranks (permission packs)

Too many ranks to edit one by one? Make a **sub-rank**: a bundle of permissions with a name. Make it once, then give it
to a player or to a rank. Change the pack later and everybody who has it is updated.

```
/rank sub create perm-homes Unlimited Homes
/rank sub addperm perm-homes zentials.homes.unlimited
/rank give Steve perm-homes            # to one player (add a time like 7d for a temporary one)
/rank inherit warden perm-homes        # or to a whole rank (warden and above get it)
/rank take Steve perm-homes            # remove
/rank sub list | info <name> | members <name> | delete <name>
```
- A sub-rank is never a player's main rank: the scoreboard, prefix and tab keep showing the real rank.
- `/rank set <player> <rank>` changes the rank but **keeps** the player's sub-ranks.
- Sub-ranks have no color/prefix and cannot be on a track or get `/rank priority`.
- In `groups.yml` it is a normal block with `type: sub`. Examples included: `perm-chat-color`, `perm-homes-unlimited`,
  `perm-back-death`, `perm-tp-admin`, `perm-economy-admin`. Edit or delete them freely.

### How the final permissions are decided
1. Start with the default rank (members).
2. Add the player's ranks, **lowest priority first**, so a higher priority overrides a lower one. A rank's parents are applied before the rank itself.
3. A rank's own permissions override its parents.
4. The player's own permissions (`/rank user <p> permission set ...`) override everything.
5. A specific node (`-essentials.ban`) always beats a wildcard (`*`).

---------------------------------------------------------------------------

## 3. Priority - full control

```
/rank priority admin 95            set a number
/rank priority vip above mod       put vip right above mod (others keep their order)
/rank priority vip below helper
/rank priority vip top             most important of all
/rank priority vip bottom          least important
/rank priority vip                 show its priority and the whole order
/rank order                        the full list, most important first
```
`above` / `below` / `top` / `bottom` move the rank and shift the others by 1 only if needed, so the order of every
other rank stays exactly the same. If two ranks share a number, `/rank order` warns you (ties are broken by name).

---------------------------------------------------------------------------

## 4. Easy commands (console or in game)

In game you need `zentials.ranks.admin` (ops have it). The console can always use everything. Aliases: `/zr`, `/ranks`, `/zenranks`.

### Ranks
| Command | What |
|---|---|
| `/rank create <name> [priority] [display name]` | new rank (default priority: 10 above the default rank) |
| `/rank delete <name>` | delete (removed from players, other ranks and tracks too) |
| `/rank rename <old> <new>` | rename everywhere (not the default rank: change `default-group`) |
| `/rank list` / `/rank order` | all ranks, most important first |
| `/rank priority <rank> <n\|top\|bottom\|above <rank>\|below <rank>>` | priority |
| `/rank prefix <rank> <text>` / `suffix` / `display` | `clear` removes it. Spaces are added for you (prefix gets one after, suffix one before) |
| `/rank addperm <rank> <node> [true\|false] [time]` | allow (or `false` = deny). Time makes it temporary |
| `/rank denyperm <rank> <node> [time]` | deny |
| `/rank delperm <rank> <node>` | remove a permission line |
| `/rank inherit <rank> <parent> [time]` / `uninherit <rank> <parent>` | parents |
| `/rank meta <rank> set <key> <value>` / `unset <key>` / `list` | your own settings |
| `/rank onadd <rank> <console command>` / `list` / `clear` | run when someone gets the rank |
| `/rank onremove <rank> <console command>` / `list` / `clear` | run when someone loses it |
| `/rank color <rank> <&#RRGGBB\|&c\|clear>` | rank color (also accepts `RRGGBB`) |
| `/rank sub create\|list\|info\|delete\|addperm\|delperm\|members ...` | sub-ranks (section 2b) |
| `/rank members <rank>` | players that have it |
| `/rank group <rank> info` | everything about a rank |
| `/rank group <rank> clone <new>` | copy a rank |

### Players
| Command | What |
|---|---|
| `/rank set <player> <rank>` | only this rank (plus the default) |
| `/rank give <player> <rank> [time]` | add a rank (`/rank add` is the same). Time = it ends by itself |
| `/rank take <player> <rank>` | remove a rank (`/rank remove` is the same) |
| `/rank promote <player> [track]` / `demote` | move along a track |
| `/rank check <player> <permission>` | does the player have it, and is it direct or inherited |
| `/rank user <player> info` | main rank, all ranks, permissions |
| `/rank user <player> permission set <node> [true\|false] [time]` / `unset` / `list` / `check` | a permission only for this player |
| `/rank user <player> parent add\|remove\|set\|clear\|list ...` | their ranks |
| `/rank user <player> clear` | back to only the default rank, no own permissions |

### Tracks (ladders for promote / demote)
```
/rank track create staff
/rank track append staff helper
/rank track append staff mod
/rank track insert staff builder 2
/rank track info staff        /rank track list        /rank track remove staff builder        /rank track delete staff
/rank promote Steve staff     /rank demote Steve staff
```
Without a track name `default-track` (config.yml) is used. A player not on the track yet starts at its first rank.

### Other
`/rank info` (summary), `/rank reload` (re-read groups.yml + config.yml), `/rank help`.

**Time** looks like `30m`, `12h`, `7d`, `2w`, `1mo`, `1d12h`.

---------------------------------------------------------------------------

## 5. Console commands on rank change

When a player gets or loses a rank (any way: `/rank set`, `give`, `take`, `promote`, a timed rank ending), these run as the console:

1. the rank's own `on-add` / `on-remove` (groups.yml, or `/rank onadd <rank> <command>`)
2. the global ones in `config.yml` -> `console-commands`

`{player}`, `{uuid}`, `{group}` are replaced. Examples:
```
/rank onadd vip broadcast &6{player} &7is now &eVIP&7!
/rank onadd vip give {player} diamond 5
/rank onremove vip tell {player} Your VIP ended.
```

---------------------------------------------------------------------------

## 6. Placeholders (PlaceholderAPI)

| Placeholder | Value |
|---|---|
| `%zrank_group%` | id of the main rank (`vip`) |
| `%zrank_name%` | display name (`VIP`) |
| `%zrank_prefix%` / `%zrank_suffix%` | prefix / suffix of the main rank |
| `%zrank_weight%` | priority of the main rank |
| `%zrank_color%` | color of the main rank (`&#7A1224`) |
| `%zrank_groups%` / `%zrank_subs%` | all ranks / all sub-ranks the player has, comma separated |
| `%zrank_in_<rank>%` | `true` / `false` (parents count) |
| `%zrank_meta_<key>%` | your own setting, e.g. `%zrank_meta_max-homes%` |

From code: `plugin.ranks().primaryGroup(uuid)`, `displayName`, `prefix`, `suffix`, `inGroup`, `meta(uuid, key)`.

---------------------------------------------------------------------------

## 7. Scoreboard / Aura

`modules/aura/config.yml`:
```yaml
rank-source: luckperms   # luckperms (default) | ranks | papi:%placeholder%
rank-names:
  default: "Members"     # LuckPerms calls the first rank "default": shown as Members
```
- `luckperms`: the player's main LuckPerms group (works without PlaceholderAPI). If LuckPerms is missing, the other sources are tried.
- `ranks`: the built-in Ranks module (uses `display`, and the rank `color` when `rank-color: true`).
- To make Aura's tab/chat style follow Ranks set `group-source: ranks` and keep a group with the same name in `aura/groups.yml`
  (or give the ranks the `zentials.aura.group.<name>` permission like the examples do).

---------------------------------------------------------------------------

## 8. Good to know

- Permissions are given with a normal Bukkit permission attachment, wildcards are expanded for you. Only permissions
  that plugins have registered can be matched by a wildcard; a plain `some.node` always works.
- Players only get the new permissions/commands right away because Ranks refreshes their command list after every change.
- Ops keep their op permissions. A `-node` (deny) removes it even for an op.
- Rank names: `a-z 0-9 _ -`, up to 32 characters. Meta keys the same.
- `/rank reload` re-reads both files. If `groups.yml` has a YAML mistake, fix it and reload; check the console.
- Old `groups.yml` files that use `weight:` still work (read as `priority`) and are rewritten with `priority` on the next change.
- If LuckPerms is installed too, a warning is printed at startup. Use only one.
