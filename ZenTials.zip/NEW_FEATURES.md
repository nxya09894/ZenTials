# ZenTials 0.9.0 - new native modules

These are part of the plugin itself (not Ryuudules). Toggle each in config.yml > modules, then restart.

| Module | Default | Commands |
|---|---|---|
| npc | on | /npc |
| holograms | on | /hologram (/holo) |
| chat | on (scoreboard inside it is OFF) | /scoreboard (/sb) |
| teleport | OFF | /sethome /home /delhome /homes /warp /warps /setwarp /delwarp /tpa /tpahere /tpaccept /tpdeny /tpcancel /back /rtp /spawn /setspawn |

Turn `modules.teleport` on only after you delete teleport.ryu: both define the same commands.

## NPCs (permission zentials.npc)
Built on the vanilla Mannequin entity (player-like, with skin). No packets, no extra plugin. Saved in plugins/ZenTials/npcs.yml.
    /npc create shop Notch          create where you stand, skin of player "Notch"
    /npc name shop &6&lSHOP         display name
    /npc skin shop <player>         change skin
    /npc equip shop hand            item in your hand -> NPC (hand/offhand/head/chest/legs/feet/clear)
    /npc action add shop message &aWelcome {player}!
    /npc action add shop player warp market        (runs as the player)
    /npc action add shop console give {player} diamond 1
    /npc action add shop sound entity.player.levelup
    /npc look shop on|off    /npc nametag shop on|off    /npc move shop    /npc tp shop
    /npc list  /npc info shop  /npc action list|clear|remove ...  /npc remove shop

## Holograms (permission zentials.hologram)
    /hologram create welcome &6&lWelcome!      /hologram addline welcome &7Online: {online}
    /hologram eco richest                       richest-players board (auto refresh)
Lines accept &colors, {online}, {max} and global PlaceholderAPI placeholders, e.g. %zen_top_1_name%.

## Chat / join / scoreboard (config.yml: chat, join, scoreboard)
Chat format with {player} {displayname} {message} and PlaceholderAPI, for example
`%luckperms_prefix%{displayname} &8» &f{message}` or `%ryu_chat_tags%{player} &8» &f{message}`.
First-join message, join/quit messages, welcome lines. Sidebar scoreboard (turn it on only if TAB is not doing it).

## Teleport (modules.teleport) - port of your teleport.ryu
Same screens, slots and texts as the script (/tp or /teleport opens the hub; the hub has an extra row: Spawn, Previous Location, My Graves, Quick Commands, Staff Panel). /tp hub, warps (player / public / mine, categories, create, edit, delete, visit price + owner payout),
saved places (10 slots, rising price, 30% sell refund), death location, player requests (accept / deny / deny & ignore),
random teleport (safe-spot pool, cost, cooldown), settings (requests on/off, ignore list), staff panel (bypass, server warps,
player warps, all prices and limits, statistics). Extra: /spawn /setspawn /back (previous location) /rtp /warps /pwarps /places /tpa /tpahere /tpaccept /tpdeny.
Staff permission is `tp.admin` (same as the script); staff keep vanilla /tp for coordinates.
Data: plugins/ZenTials/data/teleport.yml. Drop your migrated data as data/teleport-import.yml once; it is merged on start (an old root teleport-import.yml is moved there automatically).
It is ON by default. If ryuudules/teleport.ryu exists it is renamed to teleport.ryu.off automatically (same commands). An old config.yml with teleport: false is switched to true once.

## Simple chat commands (modules.chat)
/msg (m, w, tell), /r, /msgtoggle, /ignore + /unignore (saved, hides their public chat), /broadcast (bc), /clearchat (cc).
Permissions: zentials.chat.broadcast, zentials.chat.clear, zentials.chat.bypass (default op).

## Quick commands panel (modules.menu)
/tpcmds (cmds, commands) and a button in the /tp hub: clickable list of simple commands (rtp, spawn, back, warps, places, ...).
Edit `menu.items` in config.yml to add your own: material, name, lore, command, permission, close, console.

## Easy-access teleport commands (no menu)
/rtp (direct random teleport), /spawn, /back (previous location), /death (death point), /warp <name>, /places <name or number>,
/tpa <player>, /tpahere <player>, /tpaccept, /tpdeny, /tptoggle. Without arguments, /warp /places /tpa open their menu.

## Aura (modules.aura) - folder plugins/ZenTials/modules/aura/
Tab list, name tags, scoreboard and chat style in one place: tab list header/footer + names, name tags (prefix/suffix/colour), number below names, ping column,
sidebar scoreboards (per permission / world, 15 lines), chat format with hover + click on the name, chat tags (/tag menu),
groups (prefix, suffix, colour, chat format, sorted by weight), per-world disable.
Animations: `%anim:name%` (frames, scroll, typewriter in animations.yml) and colour effects that change every tick:
`<rainbow>`, `<gradient:#ff0000:#0000ff:5>` (last number = speed), `<pulse>`, `<blink>`.
Files: config.yml, groups.yml, animations.yml, scoreboard.yml, tags.yml (+ README.md; player choices are saved in data/aura.yml). `/aura reload` after editing.
Commands: /aura (reload, group, preview, info, anims), /tag, /sb. Permissions: zentials.aura.admin, zentials.aura.group.<name>,
zentials.aura.tag.<id>, zentials.aura.chat.effects.
When aura is on it takes over chat format and the sidebar; the chat module keeps join/quit, /msg, /ignore etc.
If you also run the TAB plugin, set modules.aura: false (two plugins would fight over the scoreboard).

## Ryuudules
The examples folder is gone (old copies are deleted on start). README is now short.

## Graves (modules.graves, settings in modules/graves/config.yml)
On death the items go into a grave: a player head with the owner's skin, placed on the nearest SAFE spot (never lava, fire,
cactus or void; a death in lava puts the grave on solid ground or the water surface nearby). Floating text shows name, date,
coordinates, cause and whether it is locked. Break the head and everything goes straight back into the inventory
(armor returns to the armor slots, overflow drops at your feet, xp is given). Owner-only for 15 minutes, then anyone can open it.
/death (and "Last Death Location" in the /tp menu) teleports on top of your newest grave. /graves lists all your graves and
teleports to any of them. Graves survive restarts, explosions and pistons; max 5 per player (oldest drops its items);
optional expiry, teleport cost, full xp keep.
Admin: /graves list [player] | remove <id> | tp <id> | reload. Permission: zentials.graves.admin.

## Folder layout (0.9.0)
config.yml (core: module toggles + database only) - sounds.yml - modules/<economy|teleport|graves|npc|holograms|chat|menu>/ (each feature has its
own config.yml; Aura is modules/aura/) - data/ (all saved data: teleport, graves, npcs, holograms, chat, aura, zentials.db) - ryuudules/.
Old files (teleport.yml, graves-data.yml, npcs.yml, holograms.yml, chat-data.yml, tab/, aura/) are moved to their new place automatically on first start.
Settings that used to be in config.yml (npc, holograms, chat, join, scoreboard, menu) are now in the module's own config.yml with the same keys.


## Performance
All data files save in a background thread (atomic write, merged saves), so no lag spikes. Aura caches group lookups; RTP avoids trees/leaves; graves check nearby players once per tick instead of per grave.
