# Ryuudules

Ryuudules is the ZenTials scripting system. You put `.ryu` files in this folder and ZenTials turns them
into commands, event handlers, timers, menus and whole systems. No need to touch the plugin `.jar`.

* **One file = one system.** Put a single `.ryu` file straight into this folder (for example `land.ryu`).
  Everything for that system lives in that one file: options, functions, commands, events, timers.
  You don't need sub-folders (they work, but they are optional).
* **No restart needed.** After adding or editing a file, run:
  * `/zt reload <name>`  - reload just that file (for example `/zt reload land`). A brand new file is picked up too.
  * `/zt reload`  - reload everything (the plugin config and all scripts).
  * `/ryu list` shows loaded scripts, `/ryu errors` shows mistakes with file name and line number.
  * If a file has a mistake, `/zt reload <name>` tells you the line and the old version keeps running.
* To switch a script off, rename it to `land.ryu.off` and run `/zt reload`. Deleting a file and running `/zt reload <name>` unloads it.
* Files in the `examples` folder are never loaded. This README and `examples` are rewritten on every server start,
  so do not put your own files there.

---

## 1. The basics

```
# a comment
options:                       # constants you can edit in one place
    greeting: "&aWelcome"      # use as  opt.greeting

command /hello [name]:         # <required> or [optional]
    send "{opt.greeting}, {player.name}!"

on join:                       # runs when the event happens
    send "Hi {player.name}"

every 10 seconds:              # timer
    log "tick"

function double(x):            # your own function
    return x * 2
```

* Indent with spaces (4 is normal). A line that opens a block ends with `:`.
* Text goes in quotes. Put values inside text with braces: `"Balance: {eco.balance(player)}"`.
  Inside `{ }` use single quotes for text: `"{text.upper('hi')}"`. Use `\{` for a real brace.
* Colors use `&` codes, like in chat (`&a`, `&l`, `&#ff8800`).
* Numbers are decimals (5, 2.5). Lists: `["a", "b"]`. `true`, `false`, `null`.
* A bare ALL_CAPS word is just its own name: `DIAMOND_ORE`, `LEFT_CLICK_BLOCK`. Handy for materials.
* Variables are created with `set`. They are local to the one run of a command or event.

### Skript habits that work here too

* `options:` and `options` both work. In text, `{@name}` is the same as `{opt.name}`.
* Under a command you can put your code inside `trigger:` like in Skript (or directly, both are fine).
  Extra command settings `permission message:` and `executable by: players` are accepted.
* `message "text"` is the same as `send "text"`. `cancel event` / `cancel the event` is the same as `cancel`.
* Event names can be written the Skript way: `on player join`, `on player quit`, `on block break`,
  `on block place`, `on right click`, `on player death`, ... (see the list in section 5).
* Our own style stays: `opt.name`, `set x to 5`, `later 5 seconds:`, `ask ... into x:`, `open gui`.

## 2. Blocks (top level)

| Block | Meaning |
|---|---|
| `options:` | `name: value` lines. Read with `opt.name`. |
| `command /name <a> [b:type]:` | A command. Types: `text` (default), `word`, `number`, `player`. `<msg...>` takes the rest of the line. |
| `on <event>:` | Run when an event happens (list in section 5). |
| `on load:` / `on unload:` | Run when the script is loaded / unloaded. |
| `every 5 seconds:` | Timer. Units: ticks, seconds, minutes, hours. |
| `function name(a, b):` | A function. `return value` gives a result. |

Command settings (first lines inside a command): `permission: node`, `aliases: a, b`,
`description: text`, `usage: text`, `cooldown: 5` (seconds), `player-only: true`.

Inside a command you automatically have: `sender`, `player` (if a player ran it), `args` (list),
and one variable per argument (`name`, `amount`, ...). Missing optional arguments are `null`.

## 3. Statements

```
set x to 5                      add 1 to x            remove 1 from x
set list to []                  add "a" to list       remove "a" from list
set scores["steve"] to 10       delete x

if x > 3 and not done:          else if x == 3:       else:
loop p in server.online():      repeat 5 times:       while x < 10:
break    continue    return value    stop    cancel       # cancel = cancel the event

send "text"                     send "text" to player     broadcast "text"
console "give Steve diamond 1"  log "goes to the console"

later 5 seconds:                # run the indented lines after a delay
ask "Type an amount" into amount:   # waits for the player's next chat message ("cancel" aborts)
```

Operators: `+ - * / %`, `== != < <= > >=`, `and or not`, `in` (`"a" in list`).

## 4. Reading things

* Properties: `player.name`, `player.uuid`, `player.world`, `player.x`, `.y`, `.z`, `.loc`, `.health`, `.food`,
  `.level`, `.gamemode`, `.op`, `.ping`, `.hand` / `.handtype` / `.handamount`.
  `block.type`, `block.x`, `block.world`, `loc.x`, `list.size`, `list.first`, `text.length` ...
* Methods on a player: `send(msg)`, `title(a, b)`, `actionbar(msg)`, `teleport(loc)`, `has(permission)`,
  `give("DIAMOND", 3)`, `takehand(n)`, `sfx("success")` (sounds from sounds.yml), `sound(name, vol, pitch)`,
  `heal()`, `feed()`, `kick(msg)`, `command("home")`, `gamemode("creative")`, `closeinv()`.
* Lists: `add remove contains size get join clear indexof copy isempty`.
  Text: `upper lower length contains startswith endswith replace split trim substring isnumber`.
* Anything else in the Bukkit API can usually be called by name too, for example `player.getFoodLevel()`.
* Global functions: `len(x) list(...) map(k, v, ...) str(x) num(x) int(x) type(x) player(name) uuid(x) loc(world, x, y, z)`.
* `server.online()`, `server.player(name)`, `server.count()`, `server.broadcast(msg)`, `server.console(cmd)`, `server.world(name)`.
* `math.floor ceil round(x, places) abs min max sqrt pow clamp random(a, b)`.
* `text.lower upper trim contains replace split join(list, sep) commas(n) strip repeat`.
* `time.now() time.seconds() time.format(ms, pattern) time.since(ms)`.

## 5. Events

Inside `on <event>:` you get these variables. `cancel` stops the event (where it can be stopped).

| Event | Variables |
|---|---|
| `join`, `quit`, `respawn` | `player` |
| `break`, `place` | `player`, `block` |
| `interact` | `player`, `block`, `action`, `item`, `hand` |
| `interact-entity` | `player`, `entity` |
| `death` | `player`, `killer` |
| `kill` (any entity died) | `entity`, `killer` |
| `move` | `player`, `from`, `to` (runs a lot, keep it light) |
| `teleport` | `player`, `from`, `to` |
| `damage` | `entity`, `player` (if a player), `damage`, `cause` |
| `damage-entity` | `damager`, `victim`, `player`, `damage` |
| `command` | `player`, `command`, `message` |
| `explode` | `entity`, `blocks`, `loc` |
| `block-explode` | `block`, `blocks` |
| `drop`, `pickup` | `player`, `item` (`pickup` also has `entity`) |
| `bucket` | `player`, `block` |
| `world-change` | `player`, `from` |

## 6. Chest GUIs

```
command /menu:
    player-only: true
    open gui "&6My Menu" rows 3:
        slot 11 item EMERALD name "&aHello" lore ["&7line 1", "&7line 2"]
        slot 15 item DIAMOND name "&bBuy" glow:
            send "You clicked!"            # runs when the item is clicked ("click" = LEFT, RIGHT, ...)
        slot 4 head player name "&f{player.name}"
        fill GRAY_STAINED_GLASS_PANE       # fills the empty slots
```

Variables you made before `open gui` can be used inside the click blocks (they are copied when the
slot is created, so slots made inside a `loop` each keep their own value). GUIs are locked: players
cannot take the items out.

## 7. Saving data

* `data.set("key", value)`, `data.get("key", default)`, `data.has("key")`, `data.del("key")`,
  `data.incr("key", 1)`, `data.keys("prefix", limit)` - private to this script file.
* `shared.*` - the same functions, but **every script can read and write it**. Use it to share data between systems.
* Values can be numbers, text, true/false, lists and maps. They are stored in the ZenTials database
  (fast, survives restarts, fine with huge amounts of data). If you `data.get` a list and change it,
  call `data.set` again to save the change.
* Use one key per thing, like `"land." + player.uuid`, instead of one giant list.

---

# 8. Connecting the economy (the important part)

The economy is a ZenTials module. Anything you build can use it in **four** ways:

### A) From Ryuudules scripts: the `eco` functions

Players can be a player variable, a UUID, or a name.

| Call | Does |
|---|---|
| `eco.balance(p)` / `eco.bank(p)` | Wallet / bank amount (number). |
| `eco.has(p, amount)` | `true` if the wallet has at least that much. |
| `eco.add(p, amount, "reason")` | Give money. Returns `true`/`false`. |
| `eco.remove(p, amount, "reason")` | Take money. Returns `false` if there is not enough. |
| `eco.pay(from, to, amount, "reason")` | Move money between two players in one safe step. `false` if not enough money, an account is frozen, or Lockdown Mode is on. |
| `eco.set(p, amount, "reason")` | Set the wallet to an exact amount (admin style). |
| `eco.exists(p)` | Does the player have an account. |
| `eco.format(amount)` / `eco.short(amount)` / `eco.symbol()` | `₱1,234.50` / `₱1.2K` / `₱`. |

Rules to remember:
* Amounts are normal numbers in currency units (12.5 = 12 pesos 50 centavos).
* `add`, `remove`, `pay` are **silent**: they do not message the player. You decide what to say.
* The `"reason"` shows up in the player's History and the admin Server Log. If you leave it out, it says `Script: <file name>`.
* The safe way to charge someone is to try to take the money, and only give the thing if it worked:

```
if eco.remove(player, 500, "Land claim"):
    # paid - now give the claim
else:
    send "&cYou need {eco.format(500 - eco.balance(player))} more."
```

### B) From other Java plugins or ZenTials Java modules: `EconomyApi`

```java
EconomyApi eco = Bukkit.getServicesManager().load(com.zentials.api.EconomyApi.class);
eco.withdraw(player.getUniqueId(), 100.0, "My plugin");
```
Methods: `exists balance bank has deposit withdraw transfer setBalance format formatShort symbol uuidOf`.

### C) From third-party plugins: Vault

ZenTials registers itself as the Vault economy provider automatically, so shop, auction, chest-shop and
similar plugins work without any setup.

### D) For showing numbers: PlaceholderAPI (works in TAB, holograms, scoreboards)

`%zen_balance%` `%zen_bank%` `%zen_networth%` `%zen_rank%` (and `_raw` / `_short` versions),
`%zen_symbol%`, `%zen_frozen%`, and the leaderboard `%zen_top_1_name%` ... `%zen_top_10_balance_short%`.

---

# 9. Connecting your systems to each other

When you build land, clan, shops, quests and so on as separate scripts, connect them like this:

1. **Functions are global.** A `function` in one file can be called from any other file. Give every
   function a prefix with its system name so they never clash:

```
# ryuudules/clan/clan.ryu
function clan_of(p):
    return shared.get("clan.member." + uuid(p), null)

# ryuudules/land/land.ryu  - uses the clan system
command /land trust-clan:
    player-only: true
    set clan to clan_of(player)
    if clan == null:
        send "&cYou are not in a clan."
        stop
```

2. **Shared data.** `shared.get/set` is visible to every script. Agree on key names, for example
   `land.owner.<id>`, `clan.member.<uuid>`.
3. **Economy.** Every script just calls `eco.*` (section 8). They all use the same wallets, history and
   Lockdown/Freeze rules, so nothing needs to be wired up.
4. **Order does not matter.** All files are read first, then started, so a script can call a function that
   lives in a file loaded later.
5. If two files define the same function name, the first one wins and `/ryu errors` tells you.

Suggested folder layout:

```
ryuudules/
  land/land.ryu        # claims, trust, protection
  clan/clan.ryu
  leaderboard/lb.ryu
  shop/shop.ryu
```

---

# 10. Performance and safety

* Scripts run on the main server thread. Keep event handlers short, and avoid heavy work in `move`.
* A single run stops with an error after 2,000,000 loop steps (protection against infinite loops).
* Function calls can nest 100 deep.
* An error in one script never stops the others. Look in the console or `/ryu errors`.
* Scripts can run console commands. Only trusted admins should have access to this folder.

# 11. Not in version 1 yet

Chat events, custom events, map literals `{a: 1}`, setting properties like `player.health = 5`, and
waiting in the middle of a block (use `later` blocks instead). Tell us what you need next.


---

# 12. Added in version 0.7 (used by the Land system)

* **`mem.*` - fast runtime memory** (not saved; cleared on `/ryu reload` and restart). Unlike `data`/`shared`,
  it keeps the real list/map objects, so changing them is instant. Great for indexes and caches that you
  rebuild in `on load:`. `mem.get(k, default) mem.set(k, v) mem.del(k) mem.has(k) mem.keys(prefix)`
  `mem.map(k)` and `mem.list(k)` (get or create) `mem.clear(prefix)`.
* **`shared.keys("prefix", limit)`** accepts a big limit (default 1000), so you can load everything in `on load:`.
* **Chest GUI helper for functions:** inside an `open gui` block, `gui.set(slot, item, "functionName", arg)`
  puts an item that calls `functionName(player, arg)` when clicked, and `gui.fill(MATERIAL)` fills empty slots.
  This lets you build menus with normal functions.
* **`item(material, name, lore)`** makes an item (lore is a list or one text). `player.give(item)` gives it.
  `player.handname` is the plain name of the held item, `player.removeitems("name")` removes items by name.
  `item.name`, `item.type`, `item.amount`.
* More player tools: `player.particle("end_rod", x, y, z)` (only that player sees it),
  `player.potion("haste", 0, 6)` (effect, level starting at 0, seconds; add `true` as a 4th value for a quiet effect: no particles, no icon), `player.setfood(n)`,
  `player.heal(n)`; properties `player.maxhealth`, `player.bed`, `player.played`.
* `world.highest(x, z)`, `world.spawn`, `loc.entities(radius)` (list of nearby entities),
  `entity.monster`, `list.sort()`, `list.reverse()`.
* Global functions: `ifnull(a, b)` (b if a is empty), `isnum(x)`, `tonum(x, default)`,
  `offlineplayer(name)` (works for players who are offline).
* **`event`** is the raw Bukkit event inside `on ...:` blocks, so you can call its methods,
  for example `event.setRespawnLocation(loc)` in `on respawn:`.
* New events: `spawn` (`entity`, `loc`, `reason`) and `target` (`entity`, `target`, `player`).
  `respawn` also has `respawnloc`, `interact` and `drop` also have `itemname`,
  `damage-entity` also has `attacker` (the real shooter for arrows) and `cause`.
  In `explode` / `block-explode`, change the `blocks` list (for example `set blocks to keep`) to choose
  which blocks are destroyed.
* In an `ask ... into answer:` block, typing `cancel` now runs the block with `answer` set to `"cancel"`,
  so your script decides what to do.


## Added in 0.7.3 (used by core.ryu)

* Player methods: `fly(true/false)`, `hide()` / `hide(viewer)`, `reveal()`, `clearinv()`, `invsee(other)`,
  `cureeffects()`, `hasitem("Plain Item Name")`.
* Player properties: `playtime` (seconds), `invtitle` (title of the menu they have open), `flying`.
* `eco.top()` list of `name` / `balance` maps (richest first, up to 10).
* `server.clearitems()` removes dropped items everywhere and returns the count.
* `server.textdisplay(loc, tag, text, yaw)` / `server.removedisplay(loc, tag)` keep one fixed text display per tag.
* Events: `on chat:` (variables `player`, `message`, `cancel` works; runs off the main thread, keep it to quick checks)
  and `on close:` (variables `player`, `title` of the menu that was closed).

## Added in 0.7.4 (used by db.ryu)

* Player property `ip` (their address) and method `compass(location)` (where their compass points).


## 0.8.0  -  Advanced Ryuudules (no more jar updates for new script features)

Edit a `.ryu` file and save it: the script **reloads by itself** about 2 seconds later (staff see a short message,
errors show the file and line). Turn it off with `ryuudules.auto-reload: false` in config.yml.

### Any Bukkit event, no Java needed
```
on player fish:                 # PlayerFishEvent
    send "You caught {caught}!" to player

on block form:                  # BlockFormEvent
    cancel

on event org.bukkit.event.player.PlayerEggThrowEvent:    # full class name also works
    send "egg!" to player
```
Inside any event, every property of the event is a plain name: `player`, `block`, `entity`, `cause`, `message`,
`damage`, `item` ... (it calls the matching getter), and `event` is the event itself, so
`event.setDamage(2)` or `event.setCancelled(true)` also work. `cancel` cancels cancellable events.

### Call any Bukkit method
Method calls on any object now convert values for you: text becomes an enum / material / world / UUID / chat
component / ItemStack, numbers become int/long/float/short/byte, and a `Plugin` argument is filled in.
```
player.setGameMode("CREATIVE")
player.getWorld().setStorm(true)
block.setType("DIAMOND_BLOCK")
```
Returned enums become their name (text) and returned chat components become plain text.

### wait (like Skript)
```
send "Starting..."
wait 3 seconds
send "3 seconds later"
```
Everything after `wait` in the same block runs after the delay (units: ticks, seconds, minutes, hours).

### placeholder blocks (PlaceholderAPI)
```
placeholder profession:          # %ryu_profession%    (and %ryu_profession_anything% -> params = "anything")
    return shared.get("prof." + uuid(player), "None")
```
Needs PlaceholderAPI. Keep placeholders quick: read `mem` / `shared`, no menus or Bukkit calls (some plugins ask
for placeholders off the main thread).

### Command arguments with choices
```
command /mode [state:on|off|toggle] [target:world]:
```
Tab-completes `on`, `off`, `toggle`, and `world` completes world names.

### New functions
* text: `startswith endswith capitalize title padleft padright number matches regexreplace count reverse indexof`
  (also as methods: `"hello".capitalize()`). `text.number(1234567.5, "#,##0.00")`.
* math: `mod sign ln log10 exp sin cos lerp randint chance`
* lists (return new lists): `sort rsort sortby("key") rsortby("key") reverse shuffle choice sum max min unique slice(a,b) take(n)
  first last copy indexof count`   maps: `values copy merge(other) get(key, default)`
* `cd.use(player, "name", seconds)` returns 0 and starts the cooldown, or the seconds left. `cd.left(...)`, `cd.reset(...)`
* `json.parse(text)`, `json.dump(value)`, `json.pretty(value)`
* `file.read/write/append/lines/exists/delete/list("notes.txt")`  (kept inside plugins/ZenTials/files/)
* `http.get(url, "callbackFunction")` and `http.post(url, body, "callbackFunction")`. The callback is optional
  (great for Discord webhooks) and runs later on the main thread as `callbackFunction(status, body)`. Never blocks the server.
* `call("functionName", args...)` and `exists("functionName")`
* `bossbar.show(player, "id", "title", 0.5, "RED", "NOTCHED_10")`, `bossbar.update(...)`, `bossbar.hide(player, "id")`, `bossbar.clear(player)`
* server: `server.setblock(loc, "STONE")`, `server.blockat(loc)`, `server.spawn("ZOMBIE", loc)`, `server.strike(loc)`,
  `server.explode(loc, power, breakBlocks)`, `server.drop(loc, item)`, `server.players("world")`, `server.worlds()`,
  `server.tps()`, `server.plugin("LuckPerms")` (true when enabled), `server.motd()`
* player inventory: `player.count("DIAMOND")`, `player.take("DIAMOND", 5)`, `player.slot(0)`, `player.setslot(0, item)`
* items: `item("DIAMOND_SWORD", "&bName", lore, map("enchants", map("sharpness", 5), "glow", true, "unbreakable", true, "hide", true, "model", 1001, "damage", 10, "head", "PlayerName", "amount", 3))`
